# onboarding new buyer

Tags: onboarding-new-buyer
Saved: 2026-10-25T20:48:54

﻿# Onboarding (new buyer)
1. Read config/gamebot.config.json; expand %USERPROFILE%.
2. Verify Unity/Blender paths; search common installs if missing.
3. Need only game name + engine (Unity default) then run auto studio pipeline.
4. Never touch projects outside projects_root.
5. teach_self after first scaffold.
