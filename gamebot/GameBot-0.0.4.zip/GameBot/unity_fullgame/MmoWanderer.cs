using UnityEngine;
/// <summary>MMO population: other adventurers (simulated, offline) wander between town and the wilds with nameplates.</summary>
public class MmoWanderer : MonoBehaviour
{
    public string display = "Adventurer"; Vector3 dest; float next;
    void Update()
    {
        if (PauseMenu.IsPaused || MainMenuUI.InMenu) return;
        if (Time.time > next || (dest - transform.position).magnitude < 1f) { next = Time.time + Random.Range(5f, 12f); var r = Random.insideUnitCircle * 45f; dest = new Vector3(r.x, transform.position.y, r.y); }
        Vector3 to = dest - transform.position; to.y = 0; if (to.sqrMagnitude > 0.01f) { transform.position += to.normalized * 3f * Time.deltaTime; transform.rotation = Quaternion.LookRotation(to); }
    }
    void OnGUI()
    {
        if (MainMenuUI.InMenu) return; var cam = Camera.main; if (!cam) return; var sp = cam.WorldToScreenPoint(transform.position + Vector3.up * 2.3f); if (sp.z < 0 || sp.z > 35) return;
        GUI.Label(new Rect(sp.x - 70, Screen.height - sp.y - 10, 140, 20), display, new GUIStyle(GUI.skin.label) { alignment = TextAnchor.MiddleCenter, normal = { textColor = new Color(0.5f, 0.9f, 1f) } });
    }
}
