# Legal notices and in-game menus

Tags: legal,eula,credits,settings,menu,pause,gfx
Saved: 2026-10-25T20:15:29

﻿# Legal notices + in-game menus & settings

Action playbook for Game Bot. Implement with tools — never dump a tutorial to chat.

## Legal / notices (ship checklist)
- **Title screen / first boot:** EULA or ToS accept (scroll + Accept/Decline). Store text as StreamingAssets or Resources markdown; version the doc (v1, v2) so re-prompt on update.
- **Credits:** studio, contractors, middleware (Unity/Unreal/FMOD/etc.), font/audio/asset licenses, open-source notices (third-party OSS list).
- **Copyright line:** © YEAR Owner. All rights reserved. On splash, About, and installer.
- **Privacy:** if analytics/accounts/cloud saves — Privacy Policy URL + in-game link; COPPA/age gate if needed.
- **Content ratings:** ESRB/PEGI placeholders on store + optional in-game disclaimer for hunting/weapons sims.
- **Third-party:** keep a LICENSES.txt in build root; show from Credits → Licenses.

## Menu stack (minimum viable AAA shell)
1. **Boot / Splash** → legal accept (once) → Main Menu
2. **Main Menu:** Continue / New / Load / Settings / Credits / Quit (+ Store/Wishlist later)
3. **Pause (in-game):** Resume / Settings / Controls / Quit to Menu
4. **Settings tabs:** Graphics · Audio · Controls · Accessibility · Gameplay · Language
5. **Graphics:** preset, resolution, fullscreen/borderless, vsync, shadows, foliage, FOV — call Apply on change; persist
6. **Audio:** master / music / SFX / voice; mute when unfocused
7. **Controls:** mouse sens, invert Y, key rebind, gamepad
8. **Accessibility:** text size, colorblind, subtitles, reduce flash
9. **About / Legal:** EULA, Credits, Licenses, build version string

## Unity persistence pattern
- Prefer ScriptableObject defaults + `PlayerPrefs` or JSON in persistentDataPath for overrides.
- Gate input with `Menu.Blocking` (or equivalent) so gameplay ignores clicks while menus open.
