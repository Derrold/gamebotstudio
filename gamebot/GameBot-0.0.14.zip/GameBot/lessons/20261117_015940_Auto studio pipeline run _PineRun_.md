# Auto studio pipeline run (PineRun)

Tags: auto studio pipeline
Saved: 2026-11-17T01:59:40

run_auto_game_pipeline created 34 files under C:\Users\Derrold PC\Documents\GameProjects\PineRun and UNITY 6000.6.5f1: background job started -> create PineRunUnity -> Platformer game (gameplay template: platformer; menu, settings, achievements, owned genre kit. Next: check Builds\auto_unity_status.txt, then work TaskBoard 'Auto next actions' with tools.
