"""Ed25519 (RFC 8032) for Game Bot signed updates. Uses the 'cryptography' package when present,
otherwise this pure-Python implementation (no third-party dependency; verification only takes ~50 ms)."""
from __future__ import annotations

import hashlib
import os

try:  # fast path if available
    from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey, Ed25519PublicKey  # type: ignore
    _HAVE_CRYPTO = True
except Exception:  # pragma: no cover
    _HAVE_CRYPTO = False

_p = 2 ** 255 - 19
_L = 2 ** 252 + 27742317777372353535851937790883648493
_d = -121665 * pow(121666, _p - 2, _p) % _p
_I = pow(2, (_p - 1) // 4, _p)


def _H(m: bytes) -> bytes:
    return hashlib.sha512(m).digest()


def _xrecover(y: int) -> int:
    xx = (y * y - 1) * pow(_d * y * y + 1, _p - 2, _p)
    x = pow(xx, (_p + 3) // 8, _p)
    if (x * x - xx) % _p != 0:
        x = (x * _I) % _p
    if x % 2 != 0:
        x = _p - x
    return x


_By = 4 * pow(5, _p - 2, _p) % _p
_B = (_xrecover(_By), _By, 1, _xrecover(_By) * _By % _p)  # extended coords (X, Y, Z, T)


def _add(P, Q):
    x1, y1, z1, t1 = P
    x2, y2, z2, t2 = Q
    a = (y1 - x1) * (y2 - x2) % _p
    b = (y1 + x1) * (y2 + x2) % _p
    c = t1 * 2 * _d * t2 % _p
    dd = z1 * 2 * z2 % _p
    e, f, g, h = b - a, dd - c, dd + c, b + a
    return (e * f % _p, g * h % _p, f * g % _p, e * h % _p)


def _mul(s: int, P):
    Q = (0, 1, 1, 0)
    while s > 0:
        if s & 1:
            Q = _add(Q, P)
        P = _add(P, P)
        s >>= 1
    return Q


def _enc(P) -> bytes:
    x, y, z, _ = P
    zi = pow(z, _p - 2, _p)
    x, y = x * zi % _p, y * zi % _p
    return int.to_bytes(y | ((x & 1) << 255), 32, "little")


def _dec(s: bytes):
    if len(s) != 32:
        raise ValueError("bad point length")
    y = int.from_bytes(s, "little")
    sign = y >> 255
    y &= (1 << 255) - 1
    if y >= _p:
        raise ValueError("bad point")
    x = _xrecover(y)
    if (x & 1) != sign:
        x = _p - x
    P = (x, y, 1, x * y % _p)
    if (-x * x + y * y - 1 - _d * x * x * y * y) % _p != 0:
        raise ValueError("point not on curve")
    return P


def _eq(P, Q) -> bool:
    return (P[0] * Q[2] - Q[0] * P[2]) % _p == 0 and (P[1] * Q[2] - Q[1] * P[2]) % _p == 0


def _expand(seed: bytes):
    h = _H(seed)
    a = int.from_bytes(h[:32], "little")
    a &= (1 << 254) - 8
    a |= 1 << 254
    return a, h[32:]


def public_from_seed(seed: bytes) -> bytes:
    if _HAVE_CRYPTO:
        from cryptography.hazmat.primitives import serialization as _s
        return Ed25519PrivateKey.from_private_bytes(seed).public_key().public_bytes(_s.Encoding.Raw, _s.PublicFormat.Raw)
    a, _ = _expand(seed)
    return _enc(_mul(a, _B))


def new_seed() -> bytes:
    return os.urandom(32)


def sign(seed: bytes, msg: bytes) -> bytes:
    if _HAVE_CRYPTO:
        return Ed25519PrivateKey.from_private_bytes(seed).sign(msg)
    a, prefix = _expand(seed)
    A = _enc(_mul(a, _B))
    r = int.from_bytes(_H(prefix + msg), "little") % _L
    R = _enc(_mul(r, _B))
    k = int.from_bytes(_H(R + A + msg), "little") % _L
    S = (r + k * a) % _L
    return R + int.to_bytes(S, 32, "little")


def verify(pub: bytes, msg: bytes, sig: bytes) -> bool:
    try:
        if len(sig) != 64 or len(pub) != 32:
            return False
        if _HAVE_CRYPTO:
            try:
                Ed25519PublicKey.from_public_bytes(pub).verify(sig, msg)
                return True
            except Exception:
                return False
        R, A = _dec(sig[:32]), _dec(pub)
        S = int.from_bytes(sig[32:], "little")
        if S >= _L:
            return False
        k = int.from_bytes(_H(sig[:32] + pub + msg), "little") % _L
        return _eq(_mul(S, _B), _add(R, _mul(k, A)))
    except Exception:
        return False
