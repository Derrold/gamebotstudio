"""Typo-tolerant normalization for Game Bot chat routing.

Before commands / reasoning run, tokens are fuzzy-matched against known vocab
(commands, the 19 genres, pack names, the current game's title and objects)
plus a small typo map of known misspellings. Only tokens that are not real English
words are candidates for a fix. Confident non-word hits are applied silently;
medium or ambiguous non-word hits ask: Did you mean X? (yes runs it).
"""
from __future__ import annotations

import json
import re
from dataclasses import dataclass, field
from difflib import SequenceMatcher
from pathlib import Path

HERE = Path(__file__).resolve().parent

_TYPO_PENDING: dict[str, str] = {}  # typo_key -> guessed message

_YES_RE = re.compile(
    r"^\s*(yes|yeah|yep|yup|sure|ok(ay)?|do it|go ahead|go for it|please do|sounds good|y)\b[\s!.,]*(please|thanks|do it)?[\s!.]*$",
    re.I,
)
_NO_RE = re.compile(r"^\s*(no|nope|cancel|stop|nah|nevermind|never mind)\W*$", re.I)
_NUM_RE = re.compile(r"^[\d\s.,)#-]+$")
_TOKEN_RE = re.compile(r"[A-Za-z0-9]+(?:['-][A-Za-z0-9]+)*|[^A-Za-z0-9]+")

CONFIDENT = 0.86
MEDIUM = 0.72
GAP = 0.08

_TYPOS = {
    "ad": "add", "adn": "and",
    "buld": "build", "biuld": "build", "bulid": "build", "biild": "build", "builid": "build",
    "rebuld": "rebuild", "rebiuld": "rebuild", "rebulid": "rebuild", "rebuid": "rebuild",
    "enemys": "enemies", "enemie": "enemies", "enimes": "enemies", "enimies": "enemies",
    "enmey": "enemy", "enamy": "enemy", "enemey": "enemy", "enmy": "enemy",
    "gunz": "guns", "gunns": "guns",
    "wepons": "weapons", "weopon": "weapon", "wepon": "weapon",
    "assests": "assets", "asstes": "assets", "asets": "assets",
    "imoport": "import", "inport": "import", "impot": "import",
    "lauch": "launch", "lanch": "launch", "lauanch": "launch", "lanuch": "launch",
    "plaay": "play", "ply": "play",
    "progres": "progress", "progess": "progress",
    "staus": "status", "statis": "status", "statua": "status", "statu": "status",
    "platfomer": "platformer", "platformr": "platformer", "platormer": "platformer",
    "plataformer": "platformer", "platfromer": "platformer",
    "wnat": "want", "waht": "want", "whant": "want",
    "shoooter": "shooter", "shuter": "shooter", "shootre": "shooter",
    "shooterr": "shooter", "shoter": "shooter",
    "horor": "horror", "horrorr": "horror",
    "simultion": "simulation", "simlation": "simulation",
    "puzle": "puzzle", "puzzel": "puzzle",
    "steath": "stealth", "surival": "survival", "survial": "survival", "sandox": "sandbox",
    "caled": "called", "buil": "build", "racng": "racing", "nite": "night",
    "unddo": "undo", "undoo": "undo",
    "mmorg": "mmorpg", "mmorgp": "mmorpg",
    "treess": "trees", "pak": "pack", "paks": "packs",
    "biger": "bigger", "biggr": "bigger", "wierd": "weird",
    "bushs": "bushes", "bushses": "bushes",
}


_PHRASES = [
    ("battel royale", "battle royale"),
    ("battle royal", "battle royale"),
    ("battleroyale", "battle royale"),
    ("open word", "open world"),
    ("openword", "open world"),
    ("sci fy", "sci-fi"),
    ("sci fi", "sci-fi"),
    ("sci-fy", "sci-fi"),
    ("scifi", "sci-fi"),
    ("sifi", "sci-fi"),
    ("to quite", "too quiet"),
    ("too quite", "too quiet"),
    ("to hard", "too hard"),
    ("to easy", "too easy"),
    ("to laggy", "too laggy"),
    ("to dark", "too dark"),
    ("to loud", "too loud"),
    ("to quiet", "too quiet"),
    ("to big", "too big"),
    ("to small", "too small"),
    ("to fast", "too fast"),
    ("to slow", "too slow"),
    ("its wierd", "it is weird"),
    ("its wierd", "it is weird"),
    ("its weird", "it is weird"),
    ("i cant see", "i can't see"),
    ("cant see", "can't see"),
]

_COMMANDS = (
    "rebuild", "build", "play", "launch", "run", "open", "status", "progress",
    "import", "skip", "ship", "steam", "continue", "resume", "add", "put",
    "new", "game", "chat", "assets", "asset", "packs", "pack", "use",
    "start", "make", "create", "fix", "change", "tune", "upgrade",
)

_OBJECTS = (
    "enemies", "enemy", "guns", "gun", "weapons", "weapon", "trees", "tree",
    "buildings", "building", "props", "prop", "player", "players", "camera",
    "light", "lights", "lighting", "level", "map", "maps", "boss", "health",
    "ammo", "jump", "sprint", "vehicle", "vehicles", "crate", "crates", "cover",
    "model", "models", "texture", "textures", "character", "characters",
    "npc", "npcs", "zombie", "zombies", "alien", "aliens", "monster", "monsters",
    "river", "rock", "rocks", "grass", "sky", "fog", "audio", "sound", "music",
    "hud", "menu", "inventory", "quest", "loot", "spawn", "spawns",
    "damage", "recoil", "muzzle", "movement", "controls", "gravity",
    "platform", "platforms", "coin", "coins", "checkpoint", "door", "doors",
    "chest", "wall", "walls", "floor", "roof", "window", "windows",
    "street", "city", "forest", "desert", "deer", "space", "boat", "car", "cars", "bike",
    "plane", "turret", "turrets", "barrel", "barrels", "box", "boxes",
    "sword", "swords", "bow", "magic", "spell", "spells", "armor", "shield",
    "grenade", "rocket", "jetpack", "flashlight", "torch", "sci-fi", "fps", "tps",
)

_STOP = frozenset({
    "a", "an", "the", "of", "to", "in", "is", "it", "its", "my", "me", "or", "if",
    "so", "as", "at", "be", "we", "i", "you", "your", "for", "on", "and", "more",
    "like", "with", "from", "this", "that", "just", "also", "some", "can", "please",
    "called", "named", "titled", "but", "not", "all", "any", "few", "lots",
    "very", "really", "than", "then", "them", "they", "their", "there", "here",
    "have", "has", "had", "will", "would", "could", "should", "about", "into",
    "over", "after", "before", "because", "while", "when", "what", "which", "who",
    "how", "why", "need", "want", "feel", "feels", "look", "looks", "sound",
    "sounds", "too", "kinda", "kind", "bit", "does", "did", "do", "don't",
    "dont", "cant", "can't", "wont", "won't", "im", "i'm", "i've", "ive", "was",
    "were", "are", "am", "been", "being", "out", "up", "down", "off", "again",
    "once", "only", "own", "same", "other", "another", "each", "every", "both",
    "these", "those", "something", "anything", "everything", "someone", "maybe",
    "thanks", "thank", "ok", "okay", "hi", "hey", "hello", "yo", "bye",
    "well", "still", "even", "much", "such", "via", "per", "etc",
    "got", "get", "gets", "let", "lets", "let's", "going", "gonna", "wanna",
    "one", "two", "three", "first", "last", "next", "current", "now", "already",
    "right", "left", "back", "away", "around", "between", "without", "within",
    "by", "through", "across", "under", "above", "near", "inside",
})

_GREET = frozenset({"hi", "hey", "hello", "thanks", "thank", "thx", "yo", "bye", "ok", "okay"})

# Product / app words and ordinary English that must never be rewritten to pack names or commands.
_APP_TERMS = frozenset({
    "unity", "unreal", "ollama", "blender", "python", "urp", "hdrp", "gamebot", "bot",
    "license", "edition", "installer", "install", "installed", "vram", "gpu",
    "nvidia", "amd", "windows", "hub", "paypal", "stripe",
    "xbox", "playstation", "ps5", "ps4", "nintendo", "switch", "npc", "npcs",
    "starter", "starters",
    "icon", "icons", "desktop",
    "undo", "rename", "cancel", "weather", "night", "nighttime",
})

_COMMON = frozenset({
    "mean", "means", "meaning", "report", "reporting", "happens", "happen",
    "genre", "genres", "football", "soccer", "crash", "crashed", "crashes",
    "pressed", "press", "floor", "email", "support", "download", "update",
    "version", "question", "questions", "puppy", "clouds", "pretty", "kid",
    "kids", "child", "please", "help", "bug", "bugs", "issue", "problem",
    "works", "working", "broken", "missing", "white", "black", "grey", "gray",
    "something", "anything", "nothing", "someone", "everyone", "everything",
    "does", "doesn't", "doesnt", "dont", "didn't", "isnt", "isn't",
    "explained", "explain", "tell", "show", "where", "when", "which",
    "fall", "falls", "falling", "fell", "jump", "jumps", "jumped",
    "wood", "woods", "forest", "dusk", "dawn", "slightly", "stylized", "style",
    "walk", "walks", "walked", "through", "player", "players",
    "hide", "hidden", "hiding", "name", "names", "naming",
    "guy", "guys", "shop", "shops", "shopping", "call", "calls", "calling",
    "craft", "crafty", "crafting", "pizza", "hospital", "lemonade", "stand",
    "thinking", "block", "blocks", "cute", "sad", "cartoon", "rainy", "rain",
    "outside", "time", "little", "fancy", "scary", "woods", "camp", "cars",
    "going", "fast", "maybe", "karts", "pick", "fun", "bad", "game",
    "paint", "foggy", "rainy", "take", "takes", "taking", "colors", "colour", "colours",
    "orange", "blue", "red", "green", "purple", "pink", "yellow", "gold",
    "ton", "tons", "town", "towns",
})

_LEAVE = frozenset({
    "jumping", "walking", "running", "shooting", "firing",
    "smarter", "stronger", "better", "harder", "tougher", "scarier", "deadlier",
    "punchier", "faster", "snappier", "weaker", "slower", "floaty", "boring",
    "heavier", "stiffer", "easier", "bigger", "smaller", "darker", "brighter",
    "louder", "quieter", "quiet", "quite", "longer", "shorter", "wider", "higher", "lower",
    "hard", "easy", "loud", "dark", "laggy", "lag", "weak", "bushes", "see", "white", "deer", "fast", "slow",
    "older", "newer", "aggressive", "responsive", "powerful", "challenging",
    "intelligent", "different", "interesting", "important", "awesome", "great",
    "good", "bad", "nice", "cool", "fun", "weird", "wrong", "right",
})



_WORDS_PATH = HERE / "config" / "english_words.txt"
_ENGLISH_WORDS: frozenset[str] | None = None


def _english_words() -> frozenset[str]:
    """Common English word dictionary (shipped word list + built-in protected sets)."""
    global _ENGLISH_WORDS
    if _ENGLISH_WORDS is not None:
        return _ENGLISH_WORDS
    words: set[str] = set(_STOP) | set(_COMMON) | set(_LEAVE) | set(_APP_TERMS) | set(_GREET)
    try:
        import re as _re_ew
        for line in _WORDS_PATH.read_text(encoding="utf-8").splitlines():
            w = line.strip().lower()
            if w and not w.startswith("#") and _re_ew.fullmatch(r"[a-z][a-z'-]*", w):
                words.add(w)
    except Exception:
        pass
    _ENGLISH_WORDS = frozenset(words)
    return _ENGLISH_WORDS


def is_english_word(token: str) -> bool:
    """True when the token itself is a real English word in the dictionary.

    Inflections are only accepted when the exact form is in the word list
    (so 'enemys' and 'bushs' stay misspellings of 'enemies' / 'bushes').
    Contractions of dictionary words (don't, player's) count as English.
    """
    raw = (token or "").strip()
    if not raw:
        return False
    low = raw.lower()
    words = _english_words()
    if low in words:
        return True
    if "'" in low:
        base = low.replace("'s", "").replace("n't", "").replace("'re", "").replace("'ve", "").replace("'ll", "").replace("'d", "")
        if base in words:
            return True
    return False


# Same-stem pairs: pick the closer one, never treat as ambiguous.
_FAMILY = {
    "enemy": "enemy", "enemies": "enemy",
    "gun": "gun", "guns": "gun",
    "weapon": "weapon", "weapons": "weapon",
    "tree": "tree", "trees": "tree",
    "asset": "asset", "assets": "asset",
    "pack": "pack", "packs": "pack",
    "building": "building", "buildings": "building",
    "model": "model", "models": "model",
    "character": "character", "characters": "character",
}


@dataclass
class TypoResult:
    status: str  # unchanged | confident | ask | clarify
    text: str
    original: str
    reply: str = ""
    changes: list = field(default_factory=list)


def is_yes(text: str) -> bool:
    try:
        import reasoning as _R
        return _R.is_yes(text)
    except Exception:
        return bool(_YES_RE.match(text or ""))


def typo_key(root=None, sid: str = "") -> str:
    if sid:
        return "sid:" + str(sid)
    return str(root).lower() if root else "_nogame"


def _pending_keys(root=None, sid: str = "") -> list[str]:
    keys: list[str] = [typo_key(root, sid)]
    if sid:
        keys.append(typo_key(root, ""))
        keys.append(typo_key(None, sid))
    keys.append(typo_key(None, ""))
    out, seen = [], set()
    for k in keys:
        if k not in seen:
            seen.add(k)
            out.append(k)
    return out


def _pending_text(val) -> str:
    if isinstance(val, dict):
        return str(val.get("text") or val.get("original") or "")
    return str(val or "")


def take_typo_pending(root, text: str, sid: str = "") -> str | None:
    """If the creator says yes to a typo guess, return that message so the original request resumes."""
    keys = _pending_keys(root, sid)
    if is_yes(text):
        for k in keys:
            if k in _TYPO_PENDING:
                val = _TYPO_PENDING.pop(k)
                for extra in keys:
                    _TYPO_PENDING.pop(extra, None)
                return _pending_text(val) or None
        return None
    for k in keys:
        _TYPO_PENDING.pop(k, None)
    return None


def _preserve_case(src: str, dst: str) -> str:
    if not src:
        return dst
    if src.isupper():
        return dst.upper()
    if src[:1].isupper() and (len(src) == 1 or src[1:].islower()):
        return dst[:1].upper() + dst[1:]
    if src.islower():
        return dst.lower()
    return dst


def _ratio(a: str, b: str) -> float:
    if not a or not b:
        return 0.0
    return SequenceMatcher(None, a.lower(), b.lower()).ratio()


def _load_genres() -> list[str]:
    out: list[str] = []
    try:
        import intake as IN
        out.extend(IN.TOP19)
        out.extend(IN.TOP19_LABELS.values())
        out.extend(IN.GENRE_ALIAS.keys())
    except Exception:
        out.extend([
            "action", "adventure", "rpg", "shooter", "strategy", "simulation", "sports",
            "racing", "fighting", "horror", "platformer", "puzzle", "open world",
            "survival", "sandbox", "stealth", "battle royale", "moba", "mmorpg",
            "fps", "tps", "sim", "open_world", "battle_royale",
        ])
    seen, uniq = set(), []
    for g in out:
        s = " ".join(str(g).replace("_", " ").replace("-", " ").split())
        for part in [str(g), s] + s.split():
            p = part.strip()
            if p and p.lower() not in seen:
                seen.add(p.lower())
                uniq.append(p)
    return uniq


def _load_pack_terms(root=None) -> list[str]:
    names: list[str] = []
    try:
        data = json.loads((HERE / "config" / "starter_packs.json").read_text(encoding="utf-8"))
        packs = list(data.get("basic") or [])
        for g in (data.get("genres") or {}).values():
            packs.extend(g.get("packs") or [])
        for p in packs:
            n = (p.get("name") or "").strip()
            if n:
                names.append(n)
    except Exception:
        pass
    if root:
        try:
            import asset_plan as AP
            plan = AP.load_plan(Path(root))
            if plan:
                for p in (plan.get("owned") or plan.get("packs") or []):
                    if isinstance(p, dict):
                        n = (p.get("name") or p.get("title") or "").strip()
                        if n:
                            names.append(n)
                    elif p:
                        names.append(str(p))
        except Exception:
            pass
    generic = {"pack", "packs", "starter", "free", "vol", "volume",
               "unity", "unreal", "store", "demo", "basic", "kit", "tools", "tool",
               "collection", "bundle", "pro", "lite", "units", "unit", "essentials"}
    terms: list[str] = []
    seen = set()
    for n in names:
        if n.lower() not in seen:
            seen.add(n.lower())
            terms.append(n)
        for w in re.findall(r"[A-Za-z0-9]{5,}", n):
            if w.lower() not in seen and w.lower() not in _STOP and w.lower() not in generic:
                seen.add(w.lower())
                terms.append(w)
    return terms


def _game_terms(root=None) -> list[str]:
    if not root:
        return []
    root = Path(root)
    terms: list[str] = []
    if root.name:
        terms.append(root.name)
        terms.extend(re.findall(r"[A-Za-z0-9]{3,}", root.name))
    try:
        brief = json.loads((root / "Tools" / "game_brief.json").read_text(encoding="utf-8"))
        for k in ("title", "genre", "theme", "template", "pitch", "setting", "mechanics", "style"):
            v = brief.get(k)
            if isinstance(v, str) and v.strip():
                terms.append(v.strip())
                terms.extend(re.findall(r"[A-Za-z0-9]{3,}", v))
            elif isinstance(v, list):
                for item in v:
                    if isinstance(item, str) and item.strip():
                        terms.append(item.strip())
    except Exception:
        pass
    return terms


def vocab_for(root=None, extra=()) -> list[str]:
    seen, out = set(), []
    for src in (_COMMANDS, _OBJECTS, _APP_TERMS, _load_genres(), _load_pack_terms(root), _game_terms(root), extra):
        for w in src:
            s = str(w).strip()
            if not s:
                continue
            k = s.lower()
            if k not in seen and k not in _STOP:
                seen.add(k)
                out.append(s)
    return out


def _candidates(word: str, vocab: list[str], n: int = 4) -> list[tuple[float, str]]:
    w = word.lower()
    scored: list[tuple[float, str]] = []
    for v in vocab:
        r = _ratio(w, v)
        if r >= MEDIUM:
            scored.append((r, v))
    # keep one member per word family (the closest)
    best_fam: dict[str, tuple[float, str]] = {}
    rest: list[tuple[float, str]] = []
    for r, v in scored:
        fam = _FAMILY.get(v.lower())
        if fam:
            prev = best_fam.get(fam)
            if not prev or r > prev[0] or (r == prev[0] and abs(len(v) - len(word)) < abs(len(prev[1]) - len(word))):
                best_fam[fam] = (r, v)
        else:
            rest.append((r, v))
    scored = rest + list(best_fam.values())
    scored.sort(key=lambda x: (-x[0], abs(len(x[1]) - len(word))))
    return scored[:n]


def _apply_phrases(text: str) -> tuple[str, list[tuple[str, str]]]:
    changes = []
    out = text
    for src, dst in sorted(_PHRASES, key=lambda p: -len(p[0])):
        def repl(m, _dst=dst, _src=src):
            return _preserve_case(m.group(0), _dst)
        nxt, n = re.subn(rf"(?i)\b{re.escape(src)}\b", repl, out)
        if n:
            changes.append((src, dst))
            out = nxt
    return out, changes



def _is_known_inflection(low: str, vset: dict) -> bool:
    stems = [low]
    if low.endswith("ies") and len(low) > 4:
        stems.append(low[:-3] + "y")
    if low.endswith("es") and len(low) > 3:
        stems.append(low[:-2])
    if low.endswith("s") and not low.endswith("ss") and len(low) > 3:
        stems.append(low[:-1])
    if low.endswith("ing") and len(low) > 5:
        stems += [low[:-3], low[:-3] + "e"]
    if low.endswith("ed") and len(low) > 3:
        stems += [low[:-2], low[:-1]]
    # "starter" / "builder" are inflections of command stems, not typos of them
    if low.endswith("ers") and len(low) > 5:
        stems += [low[:-3], low[:-1]]
    if low.endswith("er") and len(low) > 4:
        stems += [low[:-2], low[:-1]]
    known = set(vset) | _LEAVE | _COMMON | _APP_TERMS | _STOP
    return any(s in known and s != low for s in stems)



def _is_protected_name_token(tok: str) -> bool:
    """Leave inventor titles and identifiers alone (QaPuzzleFour, PineRun, NightWard).

    CamelCase tokens are not misspellings of vocab words. Fuzzy matching
    'QaPuzzleFour' against the genre alias 'puzzler' is 0.74 (medium) and
    would otherwise ask to rename the game.
    """
    if not tok or tok.isdigit():
        return False
    # internal capital or multiple capitals that are not a pure acronym (FPS, RPG)
    if re.search(r"[a-z][A-Z]", tok):
        return True
    if re.search(r"[A-Z].*[A-Z]", tok) and not tok.isupper():
        return True
    # mixed letters and digits: Game2, 4KMaps
    if len(tok) >= 3 and re.search(r"[A-Za-z].*\d|\d.*[A-Za-z]", tok):
        return True
    return False


def _fix_token(tok: str, vocab: list[str], pack_terms: list[str] | None = None, name_vocab: list[str] | None = None, names_only: bool = False) -> tuple[str, str, str]:
    """Return (new_token, status, replacement_word).
    status is exact | typo | confident | ask | none
    """
    low = tok.lower()
    if low in _STOP or low in _LEAVE or low in _APP_TERMS or low in _COMMON or _NUM_RE.match(tok):
        return tok, "exact", tok
    # Never rewrite a real English word (words/loop/art/ready must not become swords/loot/kart/sword).
    if is_english_word(tok):
        return tok, "exact", tok
    vset = {v.lower(): v for v in vocab}
    if low in vset:
        return tok, "exact", tok
    if low in _TYPOS:
        dst = _TYPOS[low]
        return _preserve_case(tok, dst), "typo", dst
    if any(ch.isdigit() for ch in tok):
        return tok, "exact", tok
    if names_only or _is_protected_name_token(tok):
        names = [v for v in (name_vocab or []) if v and str(v).strip()]
        cands = _candidates(tok, names) if names else []
        if not cands:
            return tok, "exact", tok
        best_r, best = cands[0]
        second_r = cands[1][0] if len(cands) > 1 else 0.0
        if best_r >= CONFIDENT and (len(cands) == 1 or best_r - second_r >= GAP):
            return _preserve_case(tok, best), "confident", best
        if best_r >= MEDIUM:
            return _preserve_case(tok, best), "ask", best
        return tok, "exact", tok
    if len(tok) <= 2:
        return tok, "none", tok
    if _is_known_inflection(low, vset):
        return tok, "exact", tok
    cands = _candidates(tok, vocab)
    # Pack-name fragments (e.g. "Units" from "Toon RTS Units") must not hijack
    # correctly spelled words such as Unity, mean, edition, etc.
    pack_lows = {p.lower() for p in (pack_terms or [])}
    if cands and not _looks_garbled(tok):
        kept = [(r, v) for r, v in cands if v.lower() not in pack_lows]
        if kept:
            cands = kept
        else:
            return tok, "none", tok
    if not cands:
        return tok, "none", tok
    best_r, best = cands[0]
    second_r = cands[1][0] if len(cands) > 1 else 0.0
    # 3-letter tokens need a stronger unique match or they ask
    if len(tok) == 3 and best_r < 0.92:
        if best_r >= MEDIUM:
            return _preserve_case(tok, best), "ask", best
        return tok, "none", tok
    if best_r >= CONFIDENT and (len(cands) == 1 or best_r - second_r >= GAP):
        return _preserve_case(tok, best), "confident", best
    if best_r >= MEDIUM:
        # two close candidates -> ask, using the top guess
        return _preserve_case(tok, best), "ask", best
    return tok, "none", tok


def _looks_garbled(word: str) -> bool:
    w = word.lower()
    if len(w) < 3:
        return False
    if w in _STOP or w in _GREET or w in _TYPOS:
        return False
    letters = re.sub(r"[^a-z]", "", w)
    if not letters:
        return False
    vowels = len(re.findall(r"[aeiouy]", letters))
    if vowels == 0 and len(letters) >= 3:
        return True
    # common smash patterns: long consonant clusters, almost no unique vowels
    if len(letters) >= 4 and vowels / len(letters) <= 0.15:
        return True
    return False


def _is_nonsense(original: str, statuses: list[str], tokens: list[str]) -> bool:
    words = [t for t in tokens if re.match(r"[A-Za-z]", t)]
    if not words:
        return False
    if all(w.lower() in _GREET or w.lower() in _STOP for w in words):
        return False
    useful = any(s in ("exact", "typo", "confident", "ask") and t.lower() not in _STOP for s, t in zip(statuses, tokens) if re.match(r"[A-Za-z]", t))
    # a known command/object/genre word or typo hit means it is a real request
    if useful:
        return False
    content = [w for w in words if w.lower() not in _STOP]
    if not content:
        return False
    if len(content) >= 2 and all(_looks_garbled(w) or (len(w) >= 4 and _ratio(w, max(_COMMANDS + _OBJECTS, key=lambda v: _ratio(w, v))) < MEDIUM) for w in content):
        return True
    if len(content) == 1 and len(content[0]) >= 5 and _looks_garbled(content[0]):
        return True
    # three+ unknown tokens with no stopwords (pure smash)
    if len(content) >= 3 and all(w.lower() not in _STOP for w in words):
        return True
    return False


def normalize(text: str, root=None, extra_vocab=()) -> TypoResult:
    original = text or ""
    t = original.strip()
    if not t or t.startswith("SYSTEM NOTE") or is_yes(t) or _NO_RE.match(t) or _NUM_RE.match(t):
        return TypoResult("unchanged", original, original)
    vocab = vocab_for(root, extra=extra_vocab)
    pack_terms = _load_pack_terms(root)
    work, phrase_changes = _apply_phrases(original)
    tokens = _TOKEN_RE.findall(work)
    new_parts: list[str] = []
    changes = list(phrase_changes)
    worst = "exact"  # exact < typo/confident < ask
    rank = {"exact": 0, "none": 0, "typo": 1, "confident": 1, "ask": 2}
    word_statuses: list[str] = []
    word_tokens: list[str] = []
    name_vocab = list(_game_terms(root)) + [str(x) for x in (extra_vocab or ()) if x]
    prev_word = ""
    in_title = False
    title_starters = {"called", "named", "titled"}
    title_articles = {"the", "of", "a", "an", "and"}
    for tok in tokens:
        if not re.match(r"[A-Za-z0-9]", tok):
            new_parts.append(tok)
            if re.search(r"[,.!?;:]", tok):
                in_title = False
            continue
        if in_title and tok.lower() in _STOP and tok.lower() not in title_articles:
            in_title = False
        names_only = prev_word.lower() in title_starters or in_title
        nxt, st, repl = _fix_token(tok, vocab, pack_terms=pack_terms, name_vocab=name_vocab, names_only=names_only)
        if prev_word.lower() in title_starters or names_only:
            in_title = True
        prev_word = tok
        new_parts.append(nxt)
        word_statuses.append(st)
        word_tokens.append(tok)
        if st in ("typo", "confident", "ask") and nxt.lower() != tok.lower():
            changes.append((tok, repl))
        if rank.get(st, 0) > rank.get(worst, 0):
            worst = st
    fixed = "".join(new_parts)
    # collapse leftover double spaces from phrase rewrite, keep trailing/leading if original had none extra
    if _is_nonsense(original, word_statuses, word_tokens) and worst != "ask":
        return TypoResult("clarify", original, original, reply=_clarify_reply())
    if worst == "ask":
        return TypoResult("ask", fixed, original, reply=_ask_reply(fixed), changes=changes)
    if changes and fixed != original:
        return TypoResult("confident", fixed, original, changes=changes)
    return TypoResult("unchanged", original, original, changes=changes)


def _ask_reply(guess: str) -> str:
    g = (guess or "").strip()
    return f'Did you mean "{g}"? (yes runs it)'


def _clarify_reply() -> str:
    return (
        "I didn't catch that. Did you want to (1) change something in the game, "
        "(2) start a new game, or (3) rebuild or play the current one?"
    )



_FOREIGN_HINTS = frozenset({
    "quiero", "juego", "juegos", "llamado", "llamada", "voy", "responder",
    "preguntas", "pregunta", "escritorio", "icono", "plataformas", "plataforma",
    "hacer", "tambien", "también", "por", "para", "como", "está", "esta",
    "jeu", "jeux", "appele", "appelé", "veux", "vouloir", "plateforme",
    "spiel", "spiele", "heisse", "heiße", "machen", "und", "nicht",
})


def _looks_non_english(text: str) -> bool:
    """True when the message is clearly not English (e.g. Spanish intake)."""
    words = re.findall(r"[A-Za-zÀ-ÿ]+", text or "")
    if len(words) < 4:
        return False
    return sum(1 for w in words if w.lower() in _FOREIGN_HINTS) >= 2


def typo_turn(text: str, root=None, extra_vocab=(), sid: str = "") -> TypoResult:
    """Normalize one user message. Stores typo pending when status is ask."""
    if _looks_non_english(text or ""):
        return TypoResult("unchanged", text or "", text or "")
    res = normalize(text, root=root, extra_vocab=extra_vocab)
    if res.status == "ask" and res.text.strip():
        _TYPO_PENDING[typo_key(root, sid)] = {"text": res.text, "original": res.original}
        if not res.reply:
            res.reply = _ask_reply(res.text)
    return res