﻿# Accessibility
Subtitles, colorblind-safe UI, remappable controls, scalable text, reduce-flash option, pause anywhere.
