# Auto studio pipeline run (CornerMart)

Tags: auto studio pipeline
Saved: 2026-11-05T11:13:56

run_auto_game_pipeline created 32 files under C:\Users\ExtremeHybrid\Documents\GameProjects\CornerMart and UNITY 6000.6.5f1: background job started -> create CornerMartUnity -> sim game (menu, settings, achievements, owned assets) -> Builds\Windows\CornerMart.exe. St. Next: check Builds\auto_unity_status.txt, then work TaskBoard 'Auto next actions' with tools.
