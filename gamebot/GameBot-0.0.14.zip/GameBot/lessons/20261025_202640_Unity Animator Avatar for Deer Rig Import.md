# Unity Animator Avatar for Deer Rig Import

Tags: Unity Animator Avatar Deer Rig Import
Saved: 2026-10-25T20:26:40

To properly set up an Animator Avatar in Unity for a deer model, the Generic animation type should be used instead of Humanoid. This is because deer have a different bone structure and movement mechanics compared to bipedal characters. The documentation on docs.unity3d.com provides detailed instructions on how to configure the generic rig correctly.
