/// <summary>
/// Input helper that works when a project is on the new Input System
/// (activeInputHandler = Input System Package) and still compiles if the
/// old Input Manager is present as a fallback.
/// </summary>
using UnityEngine;
#if ENABLE_INPUT_SYSTEM
using UnityEngine.InputSystem;
using UnityEngine.InputSystem.Controls;
#endif

public static class GameBotInput
{
    public static bool GetKey(KeyCode key)
    {
#if ENABLE_INPUT_SYSTEM
        if (TryKey(key, out var k))
            return Keyboard.current != null && k.isPressed;
        if (TryMouse(key, out var btn))
            return btn != null && btn.isPressed;
        return false;
#elif ENABLE_LEGACY_INPUT_MANAGER
        return Input.GetKey(key);
#else
        return Input.GetKey(key);
#endif
    }

    public static bool GetKeyDown(KeyCode key)
    {
#if ENABLE_INPUT_SYSTEM
        if (TryKey(key, out var k))
            return Keyboard.current != null && k.wasPressedThisFrame;
        if (TryMouse(key, out var btn))
            return btn != null && btn.wasPressedThisFrame;
        return false;
#elif ENABLE_LEGACY_INPUT_MANAGER
        return Input.GetKeyDown(key);
#else
        return Input.GetKeyDown(key);
#endif
    }

    public static bool GetKeyUp(KeyCode key)
    {
#if ENABLE_INPUT_SYSTEM
        if (TryKey(key, out var k))
            return Keyboard.current != null && k.wasReleasedThisFrame;
        if (TryMouse(key, out var btn))
            return btn != null && btn.wasReleasedThisFrame;
        return false;
#elif ENABLE_LEGACY_INPUT_MANAGER
        return Input.GetKeyUp(key);
#else
        return Input.GetKeyUp(key);
#endif
    }

    public static bool GetMouseButton(int button)
    {
#if ENABLE_INPUT_SYSTEM
        var b = MouseBtn(button);
        return b != null && b.isPressed;
#elif ENABLE_LEGACY_INPUT_MANAGER
        return Input.GetMouseButton(button);
#else
        return Input.GetMouseButton(button);
#endif
    }

    public static bool GetMouseButtonDown(int button)
    {
#if ENABLE_INPUT_SYSTEM
        var b = MouseBtn(button);
        return b != null && b.wasPressedThisFrame;
#elif ENABLE_LEGACY_INPUT_MANAGER
        return Input.GetMouseButtonDown(button);
#else
        return Input.GetMouseButtonDown(button);
#endif
    }

    public static bool GetMouseButtonUp(int button)
    {
#if ENABLE_INPUT_SYSTEM
        var b = MouseBtn(button);
        return b != null && b.wasReleasedThisFrame;
#elif ENABLE_LEGACY_INPUT_MANAGER
        return Input.GetMouseButtonUp(button);
#else
        return Input.GetMouseButtonUp(button);
#endif
    }

    public static Vector3 mousePosition
    {
        get
        {
#if ENABLE_INPUT_SYSTEM
            if (Mouse.current == null) return Vector3.zero;
            var p = Mouse.current.position.ReadValue();
            return new Vector3(p.x, p.y, 0f);
#elif ENABLE_LEGACY_INPUT_MANAGER
            return Input.mousePosition;
#else
            return Input.mousePosition;
#endif
        }
    }

    public static Vector2 mouseScrollDelta
    {
        get
        {
#if ENABLE_INPUT_SYSTEM
            if (Mouse.current == null) return Vector2.zero;
            // Input System reports wheel ticks in UI units (~120 per notch on Windows).
            return Mouse.current.scroll.ReadValue() / 120f;
#elif ENABLE_LEGACY_INPUT_MANAGER
            return Input.mouseScrollDelta;
#else
            return Input.mouseScrollDelta;
#endif
        }
    }

    public static float GetAxis(string axis)
    {
#if ENABLE_INPUT_SYSTEM
        if (Mouse.current == null) return 0f;
        // Default Input Manager mouse axis sensitivity is 0.1 * pixel delta.
        var d = Mouse.current.delta.ReadValue() * 0.1f;
        if (axis == "Mouse X") return d.x;
        if (axis == "Mouse Y") return d.y;
        return 0f;
#elif ENABLE_LEGACY_INPUT_MANAGER
        return Input.GetAxis(axis);
#else
        return Input.GetAxis(axis);
#endif
    }

#if ENABLE_INPUT_SYSTEM
    static bool TryKey(KeyCode code, out KeyControl key)
    {
        key = null;
        if (Keyboard.current == null) return false;
        var mapped = MapKey(code);
        if (mapped == Key.None) return false;
        key = Keyboard.current[mapped];
        return key != null;
    }

    static bool TryMouse(KeyCode code, out ButtonControl btn)
    {
        btn = null;
        if (code == KeyCode.Mouse0) { btn = MouseBtn(0); return btn != null; }
        if (code == KeyCode.Mouse1) { btn = MouseBtn(1); return btn != null; }
        if (code == KeyCode.Mouse2) { btn = MouseBtn(2); return btn != null; }
        return false;
    }

    static ButtonControl MouseBtn(int button)
    {
        if (Mouse.current == null) return null;
        if (button == 0) return Mouse.current.leftButton;
        if (button == 1) return Mouse.current.rightButton;
        if (button == 2) return Mouse.current.middleButton;
        return null;
    }

    static Key MapKey(KeyCode code)
    {
        switch (code)
        {
            case KeyCode.A: return Key.A; case KeyCode.B: return Key.B; case KeyCode.C: return Key.C;
            case KeyCode.D: return Key.D; case KeyCode.E: return Key.E; case KeyCode.F: return Key.F;
            case KeyCode.G: return Key.G; case KeyCode.H: return Key.H; case KeyCode.I: return Key.I;
            case KeyCode.J: return Key.J; case KeyCode.K: return Key.K; case KeyCode.L: return Key.L;
            case KeyCode.M: return Key.M; case KeyCode.N: return Key.N; case KeyCode.O: return Key.O;
            case KeyCode.P: return Key.P; case KeyCode.Q: return Key.Q; case KeyCode.R: return Key.R;
            case KeyCode.S: return Key.S; case KeyCode.T: return Key.T; case KeyCode.U: return Key.U;
            case KeyCode.V: return Key.V; case KeyCode.W: return Key.W; case KeyCode.X: return Key.X;
            case KeyCode.Y: return Key.Y; case KeyCode.Z: return Key.Z;
            case KeyCode.Alpha0: return Key.Digit0; case KeyCode.Alpha1: return Key.Digit1;
            case KeyCode.Alpha2: return Key.Digit2; case KeyCode.Alpha3: return Key.Digit3;
            case KeyCode.Alpha4: return Key.Digit4; case KeyCode.Alpha5: return Key.Digit5;
            case KeyCode.Alpha6: return Key.Digit6; case KeyCode.Alpha7: return Key.Digit7;
            case KeyCode.Alpha8: return Key.Digit8; case KeyCode.Alpha9: return Key.Digit9;
            case KeyCode.Space: return Key.Space;
            case KeyCode.LeftShift: return Key.LeftShift; case KeyCode.RightShift: return Key.RightShift;
            case KeyCode.LeftControl: return Key.LeftCtrl; case KeyCode.RightControl: return Key.RightCtrl;
            case KeyCode.LeftAlt: return Key.LeftAlt; case KeyCode.RightAlt: return Key.RightAlt;
            case KeyCode.Escape: return Key.Escape; case KeyCode.Return: return Key.Enter;
            case KeyCode.Tab: return Key.Tab; case KeyCode.Backspace: return Key.Backspace;
            case KeyCode.LeftArrow: return Key.LeftArrow; case KeyCode.RightArrow: return Key.RightArrow;
            case KeyCode.UpArrow: return Key.UpArrow; case KeyCode.DownArrow: return Key.DownArrow;
            case KeyCode.LeftWindows: return Key.LeftWindows; case KeyCode.RightWindows: return Key.RightWindows;
            default: return Key.None;
        }
    }
#endif
}
