"""Game-dev helpers for Game Bot (generic, any creator): auto research on failure, Unity batch log check,
make-a-game scaffold. Imported by agent_core."""
from __future__ import annotations

import os

import gb_config  # noqa: F401  (config.json -> GAMEBOT_* env defaults)
import re
import shutil
from datetime import datetime
from pathlib import Path

from firefox_tools import firefox_search
from learn_tools import teach_self

# Generic for any creator: projects live in %USERPROFILE%\Documents\GameProjects (override with GAMEBOT_PROJECTS).
GAME_PROJECTS = Path(os.environ.get("GAMEBOT_PROJECTS") or (Path.home() / "Documents" / "GameProjects"))

FAIL_PATTERNS = [
    (r"error CS\d{4}[^\n]{0,160}", "site:docs.unity3d.com OR site:learn.microsoft.com"),
    (r"(?:NullReference|MissingReference|UnassignedReference|InvalidOperation|Argument)Exception[^\n]{0,160}", "Unity"),
    (r"Scripting: method [^\n]{0,120}not found|executeMethod[^\n]{0,120}(?:could not|not found)[^\n]{0,80}", "Unity batchmode executeMethod"),
    (r"(?:AttributeError|TypeError|KeyError|RuntimeError): [^\n]{0,160}", "site:docs.blender.org bpy"),
    (r"(?:LNK\d{4}|C\d{4}):[^\n]{0,160}|ERROR: [^\n]{0,160}|BUILD FAILED[^\n]{0,120}", "Unreal Engine 5"),
    (r"Unknown tool [^\n]{0,60}", ""),
]


def detect_failure(tool_name: str, out: str) -> str:
    """Return a short error snippet if a tool output looks like a compile/tool/API failure."""
    o = str(out or "")
    if tool_name in ("firefox_search", "firefox_open", "teach_self", "list_lessons", "read_lesson",
                     "search_playbooks", "read_playbook", "recall", "remember", "now_local", "system_info"):
        return ""
    for pat, _ in FAIL_PATTERNS:
        m = re.search(pat, o)
        if m:
            return m.group(0).strip()
    if o.startswith("Error:"):
        return o[:200]
    return ""


def research_query(snippet: str) -> str:
    for pat, site in FAIL_PATTERNS:
        if re.search(pat, snippet):
            core = re.sub(r"[A-Z]:\\[^\s:]+", "", snippet)  # drop local paths
            core = re.sub(r"\(\d+,\d+\)", "", core)
            return f"{core[:140]} {site}".strip()
    return snippet[:150]


def auto_research(snippet: str) -> str:
    """firefox_search the error text against official docs. Returns search results text."""
    q = research_query(snippet)
    try:
        res = firefox_search(q, 5)
    except Exception as e:  # never crash the turn
        res = f"search failed: {e}"
    return f"AUTO-RESEARCH query: {q}\n{str(res)[:3500]}"


def research_error(error_text: str) -> str:
    """Tool: look up an error message in official docs (Unity / Unreal / Blender / C#)."""
    return auto_research(error_text or "")


def builder_log_check(log_path: str, script_out: str) -> str:
    """After a Unity batchmode run: if the log has 'error CS', restore files this run backed up, then teach_self."""
    p = Path(log_path)
    if not p.exists():
        return "BUILDER_LOG_MISSING (Unity may not have run — is the project open in the Editor?)"
    log = p.read_text(encoding="utf-8", errors="replace")
    errs = re.findall(r"[^\n]*error CS\d{4}[^\n]*", log)
    if not errs:
        ok = "Exiting batchmode successfully" in log or "Exiting batchmode" in log
        return f"BUILDER_LOG_CLEAN (no 'error CS'; batchmode exit seen={ok})"
    first = errs[0].strip()[:300]
    restored = []
    # Restore only backups created by THIS run (lines 'BACKUP <path>' printed by the editing script)
    for b in re.findall(r"^BACKUP (.+\.bak_\d{8}_\d{6})\s*$", script_out or "", re.M):
        bp = Path(b.strip())
        target = Path(str(bp).rsplit(".bak_", 1)[0])
        if bp.exists() and bp.stat().st_size > 10_000 and target.exists():
            keep = target.with_suffix(target.suffix + f".broken_{datetime.now():%Y%m%d_%H%M%S}")
            shutil.copy2(target, keep)
            shutil.copy2(bp, target)
            restored.append(f"{target.name} <- {bp.name} (broken copy kept as {keep.name})")
    try:
        teach_self(
            f"Unity batch compile error {first[:60]}",
            f"Symptom: Unity batch log had {len(errs)} 'error CS' lines. First: {first}\n"
            f"Action taken: {'restored ' + '; '.join(restored) if restored else 'no backups from this run — errors pre-existed; did NOT restore'}.\n"
            "Next time: dry-run code edits first and check every referenced symbol exists BEFORE the inserted line, "
            "then research the CS code on docs.unity3d.com / learn.microsoft.com and patch surgically.",
            "unity,fix,builder,compile",
        )
    except Exception:
        pass
    return (f"BUILDER_LOG_ERRORS count={len(errs)} first: {first}\n"
            f"RESTORED: {restored or 'nothing (no backups from this run)'}\n" + "\n".join(e.strip()[:200] for e in errs[:5]))


def _safe_name(s: str) -> str:
    s = re.sub(r"[^A-Za-z0-9 _-]+", "", s or "").strip()
    return "".join(w[:1].upper() + w[1:] for w in s.split())[:40] or "NewGame"


def make_game_scaffold(name: str = "", pitch: str = "", engine: str = "Unity") -> str:
    """Create Documents\\GameProjects\\<Name>\\ with Docs (Pitch, GDD, ScenePlan, TaskBoard, Bugs), Art, Audio,
    Tools, Builds. Never overwrites existing files. Unity project itself is created later in batchmode."""
    nm = _safe_name(name)
    root = GAME_PROJECTS / nm
    made = []
    for d in ("Docs", "Art\\Blender", "Art\\Textures", "Audio", "Tools", "Builds"):
        (root / d.replace("\\", "/")).mkdir(parents=True, exist_ok=True)
    eng = "Unreal Engine 5 (install only with the creator's OK)" if "unreal" in (engine or "").lower() else "Unity 6000.6.5f1 (default; newest installed 6000.x)"
    today = datetime.now().strftime("%Y-%m-%d")
    files = {
        "Docs\\Pitch.md": f"# {nm} — pitch\nDate: {today}\nEngine: {eng}\n\n## Two-line pitch\n{pitch or 'TODO: fill from the request'}\n\n## Pillars (3)\n1. \n2. \n3. \n\n## Comparable games\n\n## Scope\nS / M / L — be honest (AAA = years; this scaffold runs the pipeline step by step).\n",
        "Docs\\GDD.md": f"# {nm} — Game Design Document\nEngine: {eng}\n\n## Pitch\n{pitch}\n\n## Pillars\n\n## Core loop (one sentence)\n\n## Meta loop (one sentence)\n\n## Player verbs\n\n## Content list (maps, items, enemies/animals) with counts\n\n## Progression & economy tables\n\n## UX flow\nMain menu -> profile -> hub -> loadout -> play -> results -> hub\n\n## Tech & budgets\n60 fps target, tri/texture/draw-call budgets\n\n## Art direction\n\n## Audio\n\n## Milestones (gates: aaa-production-checklist.md)\n\n## Risks\n\n## IP guardrails\nOriginal or CC0/licensed assets only; no trademarks. Log licences in Docs\\Credits.md.\n",
        "Docs\\ScenePlan.md": f"# {nm} — first scene plan (vertical slice)\n\n## Scene\nName: Slice01. Built by an Editor builder script (Tools/SceneBuilder.cs, -executeMethod SceneBuilder.Build) — no manual edits.\n\n## Contents\n- Player rig (camera, input, movement)\n- Core loop interaction #1\n- Grey-box terrain/layout\n- HUD (prompt, objective, feedback)\n- One enemy/animal/NPC with simple FSM\n- Win/finish -> results screen\n\n## Verify\nBatch build exits 0, no 'error CS', smoke test reaches results screen.\n",
        "Docs\\TaskBoard.md": f"# {nm} — task board\n\n## Now\n- [ ] Fill Pitch.md + GDD.md\n- [ ] Create Unity project (batchmode -createProject)\n- [ ] SceneBuilder.cs grey-box\n\n## Next\n- [ ] Player controller + input\n- [ ] Core loop prototype (Gate 1)\n- [ ] Blender asset factory script #1 (Gate 2)\n\n## Later\n- [ ] Meta systems (save, progression, settings)\n- [ ] Vertical slice polish\n",
        "Docs\\Bugs.md": f"# {nm} — bugs\n| id | severity | repro | status |\n|---|---|---|---|\n",
        "Docs\\Credits.md": f"# {nm} — credits & licences\n| asset | source URL | licence | date |\n|---|---|---|---|\n",
    }
    for rel, content in files.items():
        p = root / rel.replace("\\", "/")
        if not p.exists():
            p.write_text(content, encoding="utf-8")
            made.append(rel)
    return (f"SCAFFOLD {root}\ncreated: {made or 'nothing new (already existed)'}\n"
            f"Next tools: write_text_file to fill Docs\\GDD.md; create Unity project with run_powershell: "
            f"& 'C:\\Program Files\\Unity\\Hub\\Editor\\6000.6.5f1\\Editor\\Unity.exe' -batchmode -quit -createProject '{root}\\{nm}Unity' -logFile '{root}\\Builds\\create.log'")


GAME_REQUEST = re.compile(
    r"\b(make|build|create|start|scaffold)\b[^.?!]{0,40}\b(new\s+)?(game|vertical slice|game project|prototype)\b|\bvertical slice\b",
    re.I,
)
WEAPON_WORDS = ("gun", "rifle", "weapon", "shotgun", "pistol", "revolver", "bow")


def wants_new_game(text: str) -> bool:
    t = (text or "").lower()
    # 2026-10-25: questions/planning ("which playbook...", "how do I ship...?") must not create folders
    import re as _r
    if not _r.search(r"\b(called|named|titled)\b", t) and (t.rstrip().endswith("?") or _r.match(r"\s*(how|what|which|why|when|where|should|can|could|do|does|is|explain|tell)\b", t) or _r.search(r"\b(which|what) (playbook|phase|step)", t)):
        return False
    return bool(GAME_REQUEST.search(t))


_NAME_STOP = re.compile(r"\s+(?:and|with|that|where|which|using|in|on|for|to|then|so|but|about)\b.*$", re.I)  # not plus: titles like Open World Plus


def _trim_name(nm: str) -> str:
    nm = re.split(r"\s+[-\u2013\u2014]\s+|\s*[,;:.]\s+", (nm or "").strip())[0]  # "X - tiny prototype" -> "X"
    nm = _NAME_STOP.sub("", nm.strip())
    return nm.strip(" -_.,") or "NewGame"


def resolve_game_name(user_text: str = "", name: str | None = None) -> str:
    """Explicit name always wins; never let junk genre words override intake title."""
    if name and str(name).strip() and str(name).strip() != "NewGame":
        # Intake/explicit titles: keep words like Plus; only strip junk punctuation
        s = re.sub(r"[^A-Za-z0-9 _-]+", "", str(name).strip())[:40].strip()
        return s or "NewGame"
    return game_name_from(user_text or "")


def game_name_from(text: str) -> str:
    """Prefer called/named/titled. Reject junk guesses like 'new fps' -> NFps."""
    m = re.search(r"(?:called|named|titled)\s+[\"\']?([A-Za-z0-9 _-]{2,40})", text or "", re.I)
    if m:
        return _trim_name(m.group(1))
    m = re.search(r"(?:make|build|create|start)\s+(?:a|an|the|me a)?\s*([A-Za-z0-9 _-]{2,40}?)\s+(?:game|vertical slice|prototype)", text or "", re.I)
    if not m:
        return "NewGame"
    nm = (m.group(1) or "").strip()
    nm = re.sub(r"^(?:vertical slice|prototype)\s+(?:for|of)\s+(?:a|an|the|my)?\s*", "", nm, flags=re.I)
    nm = _trim_name(nm) if nm else "NewGame"
    junk = {
        "new", "a", "an", "the", "my", "small", "big", "tiny", "little", "cool", "fun",
        "3d", "2d", "game", "games", "prototype", "slice", "vertical", "simple", "basic",
        "quick", "test", "demo", "me", "another", "some", "one", "this", "that",
        "action", "adventure", "rpg", "shooter", "fps", "tps", "strategy", "simulation",
        "sim", "simulator", "sports", "racing", "racer", "fighting", "horror", "platformer",
        "platform", "puzzle", "puzzler", "open", "world", "openworld", "survival", "sandbox",
        "stealth", "battle", "royale", "moba", "mmorpg", "mmo", "role", "playing",
    }
    parts = re.sub(r"[^a-z0-9]+", " ", nm.lower()).split()
    if not parts or all(p in junk for p in parts):
        return "NewGame"
    return nm
