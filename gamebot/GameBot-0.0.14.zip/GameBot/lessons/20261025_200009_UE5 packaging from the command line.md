# UE5 packaging from the command line

Tags: unreal,build,packaging
Saved: 2026-10-25T20:00:09

<UE>\Engine\Build\BatchFiles\RunUAT.bat BuildCookRun -project=<p>.uproject -noP4 -platform=Win64 -clientconfig=Shipping -build -cook -stage -pak -archive -archivedirectory=<out> -unattended. Success = BUILD SUCCESSFUL + exit 0. Unreal is NOT installed on this PC yet (needs the creator's OK). Sources: https://dev.epicgames.com/documentation/unreal-engine/packaging-and-cooking-games-in-unreal-engine https://unrealcommunity.wiki/how-to-package-your-game-with-commands-uq8b4tix
