# Prefab vs ScriptableObject for weapon data

Tags: unity,design,weapons,data
Saved: 2026-10-25T20:00:06

Prefab = the visual/behaviour object (model, colliders, muzzle point). ScriptableObject = shared tunable data (damage, mag, cycle, price, rank). Pattern: WeaponData SO referenced by the weapon prefab. Source: https://docs.unity3d.com/Manual/class-ScriptableObject.html
