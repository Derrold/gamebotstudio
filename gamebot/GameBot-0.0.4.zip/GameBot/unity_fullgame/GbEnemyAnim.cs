using UnityEngine;

/// <summary>Drives the enemy's walk/idle animation from its movement, keeps it on the terrain, and growls now and then.</summary>
public class GbEnemyAnim : MonoBehaviour
{
    Animator an; AudioSource src; Vector3 last; float nextGrowl; bool hasMoving; Transform player;
    void Start()
    {
        an = GetComponentInChildren<Animator>(); src = GetComponent<AudioSource>(); last = transform.position;
        if (an && an.runtimeAnimatorController) foreach (var p in an.parameters) if (p.name == "Moving") hasMoving = true;
        nextGrowl = Time.time + Random.Range(2f, 8f);
        var pl = GameObject.FindGameObjectWithTag("Player"); if (pl) player = pl.transform;
    }
    void LateUpdate()
    {
        var t = Terrain.activeTerrain;
        if (t) { var p = transform.position; p.y = t.SampleHeight(p) + t.transform.position.y; transform.position = p; }
        float sp = (transform.position - last).magnitude / Mathf.Max(Time.deltaTime, 1e-4f); last = transform.position;
        if (hasMoving) an.SetBool("Moving", sp > 0.3f);
        if (src && src.clip && Time.time > nextGrowl && player && (player.position - transform.position).sqrMagnitude < 900f) { src.pitch = Random.Range(0.85f, 1.15f); src.Play(); nextGrowl = Time.time + Random.Range(5f, 11f); }
    }
}
