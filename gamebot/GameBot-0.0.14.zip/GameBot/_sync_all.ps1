$G="C:\Users\ExtremeHybrid\Documents\GameProjects"; $u="C:\Program Files\Unity\Hub\Editor\6000.6.5f1\Editor\Unity.exe"; $src="C:\Users\ExtremeHybrid\ollama-web\unity_fullgame"; Add-Type -A System.Drawing; Add-Type -A System.IO.Compression.FileSystem
$log="$G\_screens\sync_log.txt"; Set-Content $log ""
function L($m){ Add-Content $log $m }
foreach($d in gci $G -Directory | ? Name -notlike "_*"){ $n=$d.Name; $pp=(gci $d.FullName -Directory | ? Name -like "*Unity" | select -First 1).FullName; if(!$pp -or !(Test-Path "$pp\Assets")){continue}
 $bk="$G\$n\Tools\Unity_pre_sync"; New-Item -ItemType Directory -Force $bk | Out-Null; Copy-Item "$pp\Assets\Editor\SceneBuilder.cs" $bk -Force -EA 0; Copy-Item "$pp\Assets\Scripts\*.cs" $bk -Force -EA 0
 gci $src -Filter *.cs | % { if($_.Name -eq "SceneBuilder.cs"){Copy-Item $_.FullName "$pp\Assets\Editor\" -Force} else {Copy-Item $_.FullName "$pp\Assets\Scripts\" -Force} }
 $bl="$G\$n\Builds\sync.log"; $q=Start-Process $u -ArgumentList "-batchmode","-nographics","-quit","-projectPath","`"$pp`"","-executeMethod","SceneBuilder.BuildWindows","-logFile","`"$bl`"" -PassThru; $null=$q.Handle; $q.WaitForExit()
 Get-Process dotnet -EA 0 | ? Path -like "*Unity*" | Stop-Process -Force
 $cs=(Select-String $bl -Pattern 'error CS\d{4}').Count
 if($q.ExitCode -ne 0 -or $cs -gt 0){ L "$n SYNC FAIL exit=$($q.ExitCode) CS=$cs -> restoring"; Copy-Item "$bk\SceneBuilder.cs" "$pp\Assets\Editor\" -Force; gci $bk -Filter *.cs | ? Name -ne "SceneBuilder.cs" | % { Copy-Item $_.FullName "$pp\Assets\Scripts\" -Force }; $q=Start-Process $u -ArgumentList "-batchmode","-nographics","-quit","-projectPath","`"$pp`"","-executeMethod","SceneBuilder.BuildWindows","-logFile","`"$G\$n\Builds\sync_restore.log`"" -PassThru; $null=$q.Handle; $q.WaitForExit(); Get-Process dotnet -EA 0 | ? Path -like "*Unity*" | Stop-Process -Force; L "$n restored exit=$($q.ExitCode) CS=$((Select-String "$G\$n\Builds\sync_restore.log" -Pattern 'error CS\d{4}').Count)"; continue }
 gci $src -Filter *.cs | % { Copy-Item $_.FullName "$G\$n\Tools\Unity\" -Force -EA 0 }
 L "$n OK CS=0"; Select-String $bl -Pattern '^DRESS |^DRESS_MAT|^DRESS_MATPICK|DRESS_FAIL' | % { L ("  " + $_.Line) }
 $exe=(gci "$G\$n\Builds\Windows\*.exe" | ? Name -notlike "Unity*" | select -First 1).FullName; $png="$G\_screens\${n}_latest.png"
 $r=Start-Process $exe -ArgumentList "-gbplay","-gbdrive","-gbshot",$png -PassThru; $r.WaitForExit(120000)|Out-Null; if(!$r.HasExited){$r.Kill()}; L ("  QA " + (gc "$png.txt" -EA 0))
 if(Test-Path $png){ $i=[Drawing.Image]::FromFile($png);$b=New-Object Drawing.Bitmap $i,640,360;$b.Save("$G\_screens\${n}_latest_sm.jpg",[Drawing.Imaging.ImageFormat]::Jpeg);$i.Dispose();$b.Dispose() }
 $iz=gci "$G\$n\Builds\Installer\*.zip" -EA 0 | select -First 1; if($iz){ $ship=gci "$G\$n\Builds\Windows" | ? { $_.Name -notmatch "DontShip|DoNotShip|_BackUpThisFolder" -and $_.Extension -ne ".pdb" }; Compress-Archive -Path $ship.FullName -DestinationPath $iz.FullName -Force }
}
L "ALL DONE"
