"""Scan Unity build/Editor logs for Input Manager deprecation and admin warnings."""
from __future__ import annotations

import re
from pathlib import Path

INPUT_DEPRECATION = "This project uses Input Manager, which is marked for deprecation."
ADMIN_WARNING = "Unity is not designed to run with Administrator privileges."

# Keep in sync with the $rules list in auto_studio.AUTO_UNITY_PS1.
# Bare "Licensing::" is intentionally omitted: every Unity run logs
# "[Licensing::Module] Trying to connect..." even when the license is valid.
UNITY_FAIL_RULES: list[tuple[str, str]] = [
    (r"error CS\d{4}", "A game script didn't compile."),
    (
        r"No valid Unity Editor license|License is not active|has not been activated|No valid license|license has expired|Failed to activate|entitlement.*(denied|missing)|ActivationFailed|com\.unity\.editor\.headless",
        "Unity isn't activated on this PC. Open Unity Hub, sign in, then Preferences > Licenses > Add > Get a free Personal license, and build again.",
    ),
    (
        r"Build target .*(not supported|not installed)|Switching to .*StandaloneWindows.* is disabled|[Mm]odule .* not (loaded|installed)|Windows Build Support",
        "Windows Build Support is missing. Open Unity Hub > Installs > gear > Add modules > 'Windows Build Support (Mono)'.",
    ),
    (
        r"Multiple Unity instances cannot open the same project|another Unity instance is running",
        "Another Unity window has this project open. Close Unity and build again.",
    ),
    (
        r"executeMethod.*(not found|could not be found)",
        "Game Bot's build script didn't load (usually caused by a script compile error).",
    ),
    (
        r"No space left on device|not enough (disk )?space",
        "The disk is full. Free some space and build again.",
    ),
    (r"BuildFailedException|Error building Player|Build Failed|Aborting batchmode due to failure", ""),
]


def classify_unity_fail(log_text: str) -> dict:
    """Pick a plain-English hint from a Unity build/create log (same rules as the pipeline)."""
    text = log_text or ""
    for pat, hint in UNITY_FAIL_RULES:
        m = re.search(pat, text, re.I)
        if not m:
            continue
        why = ""
        for line in text.splitlines():
            if re.search(pat, line, re.I):
                why = line.strip()
                break
        return {"hint": hint, "why": why, "pattern": pat}
    return {"hint": "", "why": "", "pattern": None}


def iter_log_files(root: Path) -> list[Path]:
    root = Path(root)
    out: list[Path] = []
    for rel in (
        Path("Builds") / "auto_unity_status.txt",
        Path("Builds") / "build.log",
        Path("Builds") / "create.log",
    ):
        p = root / rel
        if p.is_file():
            out.append(p)
    for proj in [root, *root.glob("*Unity")]:
        logs = proj / "Logs"
        if not logs.is_dir():
            continue
        for p in logs.glob("*.log"):
            if p.stat().st_size <= 40_000_000:
                out.append(p)
    seen = set()
    uniq = []
    for p in out:
        k = str(p.resolve()) if p.exists() else str(p)
        if k not in seen:
            seen.add(k)
            uniq.append(p)
    return uniq


def scan_logs(root: Path, text: str | None = None) -> dict:
    """Return whether the Input Manager deprecation or admin warning appears.

    If text is given, scan that string only (unit tests). Otherwise scan the
    project's Builds/*.log and <Project>Unity/Logs/Editor.log.
    """
    hits_input: list[str] = []
    hits_admin: list[str] = []
    files = []
    if text is not None:
        chunks = [("memory", text)]
    else:
        chunks = []
        for p in iter_log_files(root):
            try:
                chunks.append((str(p), p.read_text(encoding="utf-8", errors="replace")))
                files.append(str(p))
            except Exception:
                continue
    for name, body in chunks:
        if INPUT_DEPRECATION.lower() in body.lower():
            hits_input.append(name)
        if ADMIN_WARNING.lower() in body.lower():
            hits_admin.append(name)
    handler = None
    if text is None:
        for p in Path(root).rglob("ProjectSettings.asset"):
            try:
                t = p.read_text(encoding="utf-8", errors="replace")
            except Exception:
                continue
            m = re.search(r"activeInputHandler:\s*(\d)", t)
            if m:
                handler = int(m.group(1))
                break
    return {
        "input_deprecation": bool(hits_input),
        "admin_warning": bool(hits_admin),
        "input_deprecation_files": hits_input,
        "admin_warning_files": hits_admin,
        "activeInputHandler": handler,
        "scanned": files if text is None else ["memory"],
        "ok_input": not bool(hits_input) and (handler in (None, 1) if text is None else True),
        "ok_admin": not bool(hits_admin),
    }
