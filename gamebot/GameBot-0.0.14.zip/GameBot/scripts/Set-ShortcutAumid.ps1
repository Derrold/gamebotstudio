# Set or read System.AppUserModel.ID on a .lnk (Inno writes the same ID).
param(
  [Parameter(Mandatory=$true)][string]$Path,
  [string]$Aumid = "AlphaMaxStudios.GameBot",
  [switch]$ReadOnly
)

$setType = @"
using System;
using System.IO;
using System.Runtime.InteropServices;
using System.Runtime.InteropServices.ComTypes;
using System.Text;

public static class ShortcutAumidUtil
{
    static readonly Guid FmtId = new Guid("9F4C2855-9F79-4B39-A8D0-E1D42DE1D5F3");
    const uint PidAumid = 5;

    [ComImport, Guid("00021401-0000-0000-C000-000000000046")]
    class CShellLink {}

    [ComImport, InterfaceType(ComInterfaceType.InterfaceIsIUnknown), Guid("000214F9-0000-0000-C000-000000000046")]
    interface IShellLinkW
    {
        void GetPath([Out, MarshalAs(UnmanagedType.LPWStr)] StringBuilder pszFile, int cchMaxPath, IntPtr pfd, int fFlags);
        void GetIDList(out IntPtr ppidl);
        void SetIDList(IntPtr pidl);
        void GetDescription([Out, MarshalAs(UnmanagedType.LPWStr)] StringBuilder pszName, int cchMaxName);
        void SetDescription([MarshalAs(UnmanagedType.LPWStr)] string pszName);
        void GetWorkingDirectory([Out, MarshalAs(UnmanagedType.LPWStr)] StringBuilder pszDir, int cchMaxPath);
        void SetWorkingDirectory([MarshalAs(UnmanagedType.LPWStr)] string pszDir);
        void GetArguments([Out, MarshalAs(UnmanagedType.LPWStr)] StringBuilder pszArgs, int cchMaxPath);
        void SetArguments([MarshalAs(UnmanagedType.LPWStr)] string pszArgs);
        void GetHotkey(out short pwHotkey);
        void SetHotkey(short wHotkey);
        void GetShowCmd(out int piShowCmd);
        void SetShowCmd(int iShowCmd);
        void GetIconLocation([Out, MarshalAs(UnmanagedType.LPWStr)] StringBuilder pszIconPath, int cchIconPath, out int piIcon);
        void SetIconLocation([MarshalAs(UnmanagedType.LPWStr)] string pszIconPath, int iIcon);
        void SetRelativePath([MarshalAs(UnmanagedType.LPWStr)] string pszPathRel, int dwReserved);
        void Resolve(IntPtr hwnd, int fFlags);
        void SetPath([MarshalAs(UnmanagedType.LPWStr)] string pszFile);
    }

    [ComImport, InterfaceType(ComInterfaceType.InterfaceIsIUnknown), Guid("886D8EEB-8CF2-4446-8D02-CDBA1DBDCF99")]
    interface IPropertyStore
    {
        uint GetCount(out uint cProps);
        uint GetAt(uint iProp, out PropertyKey pkey);
        uint GetValue(ref PropertyKey key, out PropVariant pv);
        uint SetValue(ref PropertyKey key, ref PropVariant pv);
        uint Commit();
    }

    [StructLayout(LayoutKind.Sequential, Pack = 4)]
    struct PropertyKey
    {
        public Guid fmtid;
        public uint pid;
        public PropertyKey(Guid f, uint p) { fmtid = f; pid = p; }
    }

    [StructLayout(LayoutKind.Explicit, Size = 24)]
    struct PropVariant
    {
        [FieldOffset(0)] public ushort vt;
        [FieldOffset(8)] public IntPtr ptr;
    }

    [DllImport("ole32.dll")]
    static extern int PropVariantClear(ref PropVariant pvar);

    [DllImport("propsys.dll", CharSet = CharSet.Unicode)]
    static extern int PropVariantToString(ref PropVariant propvar, [Out, MarshalAs(UnmanagedType.LPWStr)] StringBuilder psz, uint cch);

    static PropVariant FromString(string s)
    {
        var pv = new PropVariant();
        pv.vt = 31; // VT_LPWSTR
        pv.ptr = Marshal.StringToCoTaskMemUni(s);
        return pv;
    }

    public static void SetAumid(string lnkPath, string aumid)
    {
        var sl = (IShellLinkW)new CShellLink();
        var pf = (IPersistFile)sl;
        if (File.Exists(lnkPath))
            pf.Load(lnkPath, 2); // STGM_READWRITE
        var store = (IPropertyStore)sl;
        var key = new PropertyKey(FmtId, PidAumid);
        PropVariant pv = FromString(aumid);
        try
        {
            int hr = (int)store.SetValue(ref key, ref pv);
            if (hr != 0) throw new System.ComponentModel.Win32Exception(hr);
            hr = (int)store.Commit();
            if (hr != 0) throw new System.ComponentModel.Win32Exception(hr);
        }
        finally
        {
            PropVariantClear(ref pv);
        }
        pf.Save(lnkPath, true);
        File.SetLastWriteTimeUtc(lnkPath, DateTime.UtcNow);
    }

    public static string GetAumid(string lnkPath)
    {
        var sl = (IShellLinkW)new CShellLink();
        var pf = (IPersistFile)sl;
        pf.Load(lnkPath, 2); // STGM_READWRITE
        var store = (IPropertyStore)sl;
        var key = new PropertyKey(FmtId, PidAumid);
        PropVariant pv;
        uint ghr = store.GetValue(ref key, out pv);
        if (ghr != 0) return "";
        try
        {
            if (pv.vt == 31 && pv.ptr != IntPtr.Zero)
                return Marshal.PtrToStringUni(pv.ptr) ?? "";
            var sb = new StringBuilder(1024);
            int hr = PropVariantToString(ref pv, sb, (uint)sb.Capacity);
            if (hr != 0) return "";
            return sb.ToString();
        }
        finally
        {
            PropVariantClear(ref pv);
        }
    }
}
"@

if (-not ("ShortcutAumidUtil" -as [type])) {
  Add-Type -TypeDefinition $setType -ReferencedAssemblies System.dll, System.Windows.Forms.dll
}

$full = [System.IO.Path]::GetFullPath($Path)
if ($ReadOnly) {
  if (-not (Test-Path -LiteralPath $full)) { throw "shortcut not found: $full" }
  $id = [ShortcutAumidUtil]::GetAumid($full)
  Write-Output $id
  return
}
if (-not (Test-Path -LiteralPath $full)) { throw "shortcut not found: $full" }
[ShortcutAumidUtil]::SetAumid($full, $Aumid)
$got = [ShortcutAumidUtil]::GetAumid($full)
if ($got -ne $Aumid) { throw "AUMID write failed (got '$got')" }
Write-Output "AUMID $got on $full"
