using UnityEngine;
/// <summary>Anything a weapon, ability or unit can hurt (team 0 = player side, 1 = enemy side, 2+ = free-for-all bots).</summary>
public interface IGbDamage { void Damage(int amount, int fromTeam); int Team { get; } bool Dead { get; } Transform Tr { get; } }
public static class GbCombat
{
    public static System.Collections.Generic.List<IGbDamage> All = new System.Collections.Generic.List<IGbDamage>();
    public static IGbDamage Nearest(Vector3 p, float range, System.Func<IGbDamage, bool> ok)
    {
        IGbDamage best = null; float bd = range;
        for (int i = All.Count - 1; i >= 0; i--) { var u = All[i]; if (u == null || u.Dead || u.Tr == null) { All.RemoveAt(i); continue; } if (!ok(u)) continue; float d = Vector3.Distance(p, u.Tr.position); if (d < bd) { bd = d; best = u; } }
        return best;
    }
    public static void HurtPlayer(int d)
    {
        if (GameState.Won || GameState.Lost) return;
        GenreState.Health -= d; GenreState.LastHurt = Time.time;
        if (GenreState.Health > 0) return;
        if (GenreState.Family == "battle_royale") { GenreState.Health = 0; GenreState.Lose("Eliminated - you placed #" + (GenreState.Alive + 1)); return; }
        GenreState.Health = GenreState.MaxHealth;
        var p = GameObject.FindGameObjectWithTag("Player"); var gp = p ? p.GetComponent<GamePlayer>() : null;
        if (gp) gp.Respawn(); else GameState.Die();
    }
}
