using UnityEngine;
/// <summary>Sokoban-style block: pushed one tile at a time; blocked by walls/other blocks.</summary>
public class PushBlock : MonoBehaviour
{
    public float tile = 2f; Vector3 target, start; bool moving;
    void Start() { target = start = transform.position; }
    public bool TryPush(Vector3 dir)
    {
        if (moving) return false;
        dir.y = 0; dir = Mathf.Abs(dir.x) > Mathf.Abs(dir.z) ? new Vector3(Mathf.Sign(dir.x), 0, 0) : new Vector3(0, 0, Mathf.Sign(dir.z));
        if (Physics.BoxCast(transform.position, Vector3.one * tile * 0.4f, dir, Quaternion.identity, tile, ~0, QueryTriggerInteraction.Ignore)) return false;
        target = transform.position + dir * tile; moving = true; return true;
    }
    public void ResetBlock() { transform.position = target = start; moving = false; }
    void Update()
    {
        if (!moving) return;
        transform.position = Vector3.MoveTowards(transform.position, target, 6f * Time.deltaTime);
        if ((transform.position - target).sqrMagnitude < 0.0001f) moving = false;
    }
}
