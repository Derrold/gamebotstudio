using UnityEngine;
/// <summary>Sports family (arena football): ball physics, goals, kick/dribble for the player, rival AI striker + keeper, 3 min clock, first to N wins.</summary>
public class SportsMatch : MonoBehaviour
{
    public Rigidbody ball; public Transform player, rival, keeper, ourGoal, theirGoal; Vector3 ballStart, pStart, rStart, kStart; float charge, rivalKickCd, kickCd, resetAt = -1;
    public static SportsMatch I;
    void Start() { I = this; ballStart = ball.position; pStart = player.position; rStart = rival.position; kStart = keeper.position; }
    public void Goal(bool forUs)
    {
        if (resetAt > 0 || GameState.Won || GameState.Lost) return;
        if (forUs) { GenreState.ScoreUs++; AchievementSystem.Unlock("first_goal"); GameHUD.Flash("GOAL! " + GenreState.ScoreUs + " : " + GenreState.ScoreThem); } else { GenreState.ScoreThem++; GameHUD.Flash("Rival scores. " + GenreState.ScoreUs + " : " + GenreState.ScoreThem); }
        if (GenreState.ScoreUs >= GenreState.GoalsToWin) { if (GenreState.ScoreThem == 0) AchievementSystem.Unlock("clean_sheet"); GenreState.Win(); return; }
        if (GenreState.ScoreThem >= GenreState.GoalsToWin) { GenreState.Lose("The rival reached " + GenreState.GoalsToWin + " goals"); return; }
        resetAt = Time.time + 2f;
    }
    void Kickoff() { resetAt = -1; ball.linearVelocity = Vector3.zero; ball.angularVelocity = Vector3.zero; ball.position = ballStart; var cc = player.GetComponent<CharacterController>(); if (cc) cc.enabled = false; player.position = pStart; if (cc) cc.enabled = true; rival.position = rStart; keeper.position = kStart; }
    void Update()
    {
        if (GameState.Won || GameState.Lost || PauseMenu.IsPaused || MainMenuUI.InMenu) return;
        if (resetAt > 0) { if (Time.time >= resetAt) Kickoff(); return; }
        GenreState.MatchTime -= Time.deltaTime;
        if (GenreState.MatchTime <= 0) { if (GenreState.ScoreUs > GenreState.ScoreThem) GenreState.Win(); else if (GenreState.ScoreUs < GenreState.ScoreThem) GenreState.Lose("Full time - the rival led"); else { GenreState.MatchTime = 30f; GameHUD.Flash("Level at full time - 30s of golden-goal extra time!"); } return; }
        if (ball.position.y < -3 || Mathf.Abs(ball.position.x) > 40 || Mathf.Abs(ball.position.z) > 60) Kickoff();
        // player kick (charge while held)
        Vector3 toBall = ball.position - player.position; toBall.y = 0; kickCd -= Time.deltaTime;
        if (Input.GetKey(KeyCode.Space) || Input.GetMouseButton(0)) charge = Mathf.Min(1f, charge + Time.deltaTime * 1.5f);
        bool release = Input.GetKeyUp(KeyCode.Space) || Input.GetMouseButtonUp(0) || (GameBotQA.AutoFire && toBall.magnitude < 2.2f);
        if (release) { if (toBall.magnitude < 2.4f && kickCd <= 0) { kickCd = 0.3f; var dir = (player.forward + Vector3.up * 0.12f).normalized; ball.AddForce(dir * (9f + 16f * charge), ForceMode.VelocityChange); } charge = 0; }
        else if (toBall.magnitude < 1.3f) ball.AddForce(player.forward * 6f * Time.deltaTime, ForceMode.VelocityChange); // dribble
        // rival striker: get behind ball relative to our goal, then shoot
        rivalKickCd -= Time.deltaTime; Vector3 aim = (ourGoal.position - ball.position); aim.y = 0; aim.Normalize();
        Vector3 behind = ball.position - aim * 1.2f; behind.y = rival.position.y; Vector3 rv = behind - rival.position; rv.y = 0;
        rival.position += Vector3.ClampMagnitude(rv, 1f) * 5.4f * Time.deltaTime; if (rv.sqrMagnitude > 0.01f) rival.rotation = Quaternion.LookRotation(aim);
        if ((ball.position - rival.position).magnitude < 1.8f && rivalKickCd <= 0) { rivalKickCd = 1.1f; ball.AddForce((aim + Vector3.up * 0.1f) * Random.Range(9f, 17f), ForceMode.VelocityChange); }
        // rival keeper: tracks ball along goal line
        var kp = keeper.position; kp.x = Mathf.MoveTowards(kp.x, Mathf.Clamp(ball.position.x, theirGoal.position.x - 4f, theirGoal.position.x + 4f), 4.5f * Time.deltaTime); keeper.position = kp;
        if ((ball.position - keeper.position).magnitude < 1.6f) { Vector3 away = ball.position - theirGoal.position; away.y = 0; ball.linearVelocity = away.normalized * 10f + Vector3.up * 3f; }
    }
    void OnGUI() { if (!MainMenuUI.InMenu && charge > 0) { GUI.color = Color.yellow; GUI.DrawTexture(new Rect(Screen.width / 2 - 100, Screen.height - 110, 200 * charge, 14), Texture2D.whiteTexture); GUI.color = Color.white; } }
}
