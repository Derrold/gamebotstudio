﻿# Analytics (optional)
Prefer none at launch. If used: opt-in, no PII, document in privacy policy. Local playtests first.
