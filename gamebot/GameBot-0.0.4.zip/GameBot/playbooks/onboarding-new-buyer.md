# Onboarding a new creator (first run of a purchased Game Bot)
Goal: working in under 2 minutes on any Windows PC, without touching anyone else's files.

## First run (automatic)
1. Load config\gamebot.config.json (template: config\gamebot.config.example.json; env GAMEBOT_PROJECTS/GAMEBOT_UNITY/GAMEBOT_BLENDER override). If missing or a path is empty, auto-detect and write it:
   - unity_editor: newest C:\Program Files\Unity\Hub\Editor\6000.*\Editor\Unity.exe (else empty -> human gate: install Unity Hub + 6000.x LTS)
   - blender: newest C:\Program Files\Blender Foundation\Blender*\blender.exe (else empty -> human gate: install Blender)
   - projects_root: %USERPROFILE%\Documents\GameProjects
2. system_info once for GPU/VRAM -> set default quality target in memory (remember).
3. First message usually names a game. Ask **Unity or Unreal?** (and missing title/genre/template) per new-game-intake before creating anything.
4. After engine pick: run run_auto_game_pipeline; then progressive asset questions; report paths + human gates.

## Rules
- Only read/write inside projects_root\<Name> and the bot folder. Never browse other users' folders, never import someone else's project paths, never reuse paths from lessons that point outside projects_root.
- Intake questions (engine/title/genre/assets) are required product behavior, not optional.
- Engine: ask Unity or Unreal when not chosen; installing UE5 ~60 GB = human gate.
- English UI, creator's timezone from the OS clock.
