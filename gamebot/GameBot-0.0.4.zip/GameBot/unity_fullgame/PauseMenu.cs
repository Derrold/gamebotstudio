﻿using UnityEngine;
using UnityEngine.SceneManagement;

public class PauseMenu : MonoBehaviour
{
    public static bool IsPaused;
    bool settings;
    int tab;
    string waitingRebind;
    readonly System.Collections.Generic.Dictionary<string, System.Action<KeyCode>> _setters = new System.Collections.Generic.Dictionary<string, System.Action<KeyCode>>();

    void Update()
    {
        if (GameState.Won || GameState.Lost) return;
        if (Input.GetKeyDown(GameSettings.KeyPause))
        {
            if (IsPaused) Resume(); else Pause();
        }
    }

    void Pause()
    {
        IsPaused = true; settings = false;
        Time.timeScale = 0f;
        Cursor.lockState = CursorLockMode.None;
        Cursor.visible = true;
        GameState.SaveContinue();
    }
    void Resume()
    {
        IsPaused = false; settings = false; waitingRebind = null;
        Time.timeScale = 1f;
        Cursor.lockState = CursorLockMode.Locked;
        Cursor.visible = false;
    }

    void OnGUI()
    {
        if (GameState.Won)
        {
            DrawCenter(GenreState.WinText(), true);
            return;
        }
        if (GameState.Lost)
        {
            DrawCenter("YOU LOSE — out of lives.\n" + (GenreState.Family == "platformer" ? "Coins: " + GameState.Coins : GenreState.Objective()), true);
            return;
        }
        if (!IsPaused) return;
        float W = Screen.width, H = Screen.height;
        GUI.Box(new Rect(W * 0.25f, H * 0.15f, W * 0.5f, H * 0.7f), "");
        GUILayout.BeginArea(new Rect(W * 0.25f + 20, H * 0.15f + 20, W * 0.5f - 40, H * 0.7f - 40));
        var btn = new GUIStyle(GUI.skin.button) { fontSize = 20, fixedHeight = 40 };
        var lab = new GUIStyle(GUI.skin.label) { fontSize = 18 };
        if (!settings)
        {
            GUILayout.Label("Paused", new GUIStyle(GUI.skin.label){fontSize=30,fontStyle=FontStyle.Bold});
            if (GUILayout.Button("Resume", btn)) Resume();
            if (GUILayout.Button("Settings", btn)) settings = true;
            if (GUILayout.Button("Quit to Main Menu", btn))
            {
                IsPaused = false; Time.timeScale = 1f;
                MainMenuUI.InMenu = true;
                SceneManager.LoadScene("MainMenu");
            }
        }
        else
        {
            GUILayout.Label("Settings", new GUIStyle(GUI.skin.label){fontSize=28,fontStyle=FontStyle.Bold});
            GUILayout.BeginHorizontal();
            if (GUILayout.Button("Video", btn)) tab = 0;
            if (GUILayout.Button("Audio", btn)) tab = 1;
            if (GUILayout.Button("Controls", btn)) tab = 2;
            GUILayout.EndHorizontal();
            if (tab == 0)
            {
                GUILayout.Label("Res " + GameSettings.Width + "x" + GameSettings.Height, lab);
                if (GUILayout.Button("1920x1080", btn)) { GameSettings.Width=1920; GameSettings.Height=1080; }
                if (GUILayout.Button("1280x720", btn)) { GameSettings.Width=1280; GameSettings.Height=720; }
                GameSettings.Fullscreen = GUILayout.Toggle(GameSettings.Fullscreen, " Fullscreen", lab);
                GameSettings.VSync = GUILayout.Toggle(GameSettings.VSync, " VSync", lab);
                GUILayout.Label("Quality", lab);
                GameSettings.Quality = Mathf.RoundToInt(GUILayout.HorizontalSlider(GameSettings.Quality, 0, QualitySettings.names.Length - 1));
            }
            else if (tab == 1)
            {
                GUILayout.Label("Master", lab); GameSettings.MasterVol = GUILayout.HorizontalSlider(GameSettings.MasterVol, 0, 1);
                GUILayout.Label("Music", lab); GameSettings.MusicVol = GUILayout.HorizontalSlider(GameSettings.MusicVol, 0, 1);
                GUILayout.Label("SFX", lab); GameSettings.SfxVol = GUILayout.HorizontalSlider(GameSettings.SfxVol, 0, 1);
            }
            else
            {
                GUILayout.Label("Sensitivity " + GameSettings.LookSens.ToString("0.0"), lab);
                GameSettings.LookSens = GUILayout.HorizontalSlider(GameSettings.LookSens, 0.5f, 8f);
                Bind("Forward","fwd",()=>GameSettings.KeyForward,k=>GameSettings.KeyForward=k,lab,btn);
                Bind("Back","back",()=>GameSettings.KeyBack,k=>GameSettings.KeyBack=k,lab,btn);
                Bind("Left","left",()=>GameSettings.KeyLeft,k=>GameSettings.KeyLeft=k,lab,btn);
                Bind("Right","right",()=>GameSettings.KeyRight,k=>GameSettings.KeyRight=k,lab,btn);
                Bind("Jump","jump",()=>GameSettings.KeyJump,k=>GameSettings.KeyJump=k,lab,btn);
                Bind("Pause","pause",()=>GameSettings.KeyPause,k=>GameSettings.KeyPause=k,lab,btn);
                if (!string.IsNullOrEmpty(waitingRebind))
                {
                    GUILayout.Label("Press key for " + waitingRebind + "...", lab);
                    Event e = Event.current;
                    if (e.isKey && e.type == EventType.KeyDown && e.keyCode != KeyCode.None)
                    { if (_setters.TryGetValue(waitingRebind, out var s)) s(e.keyCode); waitingRebind=null; e.Use(); }
                }
            }
            GUILayout.FlexibleSpace();
            GUILayout.BeginHorizontal();
            if (GUILayout.Button("Apply", btn)) GameSettings.ApplyAll();
            if (GUILayout.Button("Back", btn)) settings = false;
            GUILayout.EndHorizontal();
        }
        GUILayout.EndArea();
    }

    void Bind(string label, string id, System.Func<KeyCode> get, System.Action<KeyCode> set, GUIStyle lab, GUIStyle btn)
    {
        _setters[id] = set;
        GUILayout.BeginHorizontal();
        GUILayout.Label(label + ": " + get(), lab, GUILayout.Width(260));
        if (GUILayout.Button("Rebind", btn, GUILayout.Width(100))) waitingRebind = id;
        GUILayout.EndHorizontal();
    }

    void DrawCenter(string msg, bool toMenu)
    {
        float W = Screen.width, H = Screen.height;
        GUI.Box(new Rect(W * 0.2f, H * 0.3f, W * 0.6f, H * 0.4f), "");
        GUILayout.BeginArea(new Rect(W * 0.2f + 20, H * 0.3f + 20, W * 0.6f - 40, H * 0.4f - 40));
        var lab = new GUIStyle(GUI.skin.label) { fontSize = 26, alignment = TextAnchor.MiddleCenter };
        var btn = new GUIStyle(GUI.skin.button) { fontSize = 22, fixedHeight = 44 };
        GUILayout.Label(msg, lab);
        if (toMenu && GUILayout.Button("Main Menu", btn))
        {
            Time.timeScale = 1f; IsPaused = false; MainMenuUI.InMenu = true;
            SceneManager.LoadScene("MainMenu");
        }
        GUILayout.EndArea();
    }
}

