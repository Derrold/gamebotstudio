# Pricing, wishlists, launch week
- Price: research 5-10 comparable titles (genre, length, review count) with firefox_search; Steam regional pricing from Valve's recommended table. Launch discount 10-20% common; no discount larger than planned first sale.
- Wishlists: Coming Soon page early (human clicks publish); events: Steam Next Fest (demo), relevant themed fests; capsule A/B via updated art. Track wishlist->purchase conversion.
- Release date: avoid huge releases and major sales; announce date 4-8 weeks ahead.
- Launch week plan (Docs\Store\launch_week.md): day 0 build live on default branch (human Release click), hotfix branch ready, monitor crash logs + reviews 2x/day, patch within 48 h for blockers, thank-you post (human posts).
- Never promise dates the build can't meet; release regression gate (qa-test-plans) must pass first.
