"""Game Bot agent core: an automatic game studio for any creator. Acts with tools, never tutorials."""
from __future__ import annotations

from editions import load_edition, apply_to_agent_options
load_edition()

from pathlib import Path as _Path
BOT_ROOT = str(_Path(__file__).resolve().parent)

import json
import os
import re
import sys
import urllib.request
from pathlib import Path
from typing import Callable

# CUDA_VISIBLE_DEVICES left unset: Ollama auto-detects GPUs (hard-coded "1" hid the only NVIDIA GPU, index 0)
os.environ.pop("OLLAMA_API_KEY", None)

import gb_config

from firefox_tools import firefox_close, firefox_open, firefox_search
from learn_tools import lessons_for_prompt, list_lessons, read_lesson, teach_self, relevant_lessons, search_playbooks, read_playbook
from gamedev_core import auto_research, detect_failure, game_name_from, make_game_scaffold, research_error
from auto_studio import (run_asset_auto, run_auto_game_pipeline, run_ship_prep, wants_asset, wants_auto_game,
                         wants_ship_prep, resolve_project, intake_ready_for_pipeline, conversation_engine_choice)
from pc_tools import (
    forget,
    launch_app,
    list_files,
    note_read,
    note_write,
    now_local,
    open_path,
    open_url,
    read_text_file,
    recall,
    remember,
    run_blender_script,
    run_powershell,
    system_info,
    write_text_file,
)

try:
    gb_config.ensure_config()
except Exception:
    pass

MODEL = os.environ.get("OLLAMA_MODEL", "gamebot-trained")

def model_tools():
    return TOOLS

OLLAMA = os.environ.get("OLLAMA_HOST", "http://127.0.0.1:11434")

_TURN: dict = {"busy": False, "status": "", "since": 0.0, "orig": "", "done_steps": []}


_STATUS_RE = re.compile(
    r"\s*(?:(?:hey|so|ok|okay|and)[\s,]+)?"
    r"(?:eta|eat|etta|eda|ets|status|stat|stats|progress|update|updates|any update|any updates|any status|"
    r"how long|how long left|how much longer|still working|you still working|working|done yet|are you done|"
    r"you done|are you there|are you working|are you still working|stuck|are you stuck|you stuck|"
    r"where are we|where are we at|what'?s the status|whats the eta|what'?s the eta|status update)"
    r"(?:[\s,]+(?:please|pls|plz|now|bro|man|buddy|on (?:it|that|the build)))*\s*[?.!]*\s*"
    r"|\s*\?+\s*", re.I)


def wants_status(text: str) -> bool:
    """True only when the WHOLE message is a status ask ("eta", "eat" typo, "status?", "?", "how long")."""
    return bool(_STATUS_RE.fullmatch(text or ""))


def unity_bg_status(r=None) -> str:
    """Real background Unity job status for the current project ('' when nothing is running)."""
    try:
        from auto_studio import build_status, resolve_project, unity_job_running
        root = resolve_project("")
        if root and unity_job_running(root):
            return build_status(root)
    except Exception:
        pass
    return ""


def _pending_note() -> str:
    try:
        from owned_assets import PENDING_IMPORTS
        if PENDING_IMPORTS:
            return "\nQueued after it: import " + ", ".join(PENDING_IMPORTS[:3])
    except Exception:
        pass
    return ""


def progress_report() -> str:
    import time as _t
    if not _TURN.get("busy"):
        bg = unity_bg_status()
        if bg:
            return bg + _pending_note()
        try:
            from auto_studio import last_build_summary
            last = last_build_summary()
        except Exception:
            last = ""
        return ("Idle. " + last) if last else "Idle."
    st = (_TURN.get("status") or "Working").rstrip(". ")
    elapsed = int(_t.time() - float(_TURN.get("since") or _t.time()))
    ask = (_TURN.get("orig") or "")[:60]
    done = _TURN.get("done_steps") or []
    extra = (" done: " + ", ".join(done[-4:])) if done else ""
    bg = unity_bg_status()
    return f'Working on "{ask}": now {st} ({elapsed}s so far){extra}' + (f"\nBackground: {bg}{_pending_note()}" if bg else "")


# Optional private plugin (OFF by default). The sellable Game Bot never touches any personal project.
# Enable only on the owner's machine: set GAMEBOT_PRIVATE_PLUGIN=1 (plugin lives in _personal_archive_not_for_sale).
PLUGIN = None
# Review fix 2: never in a shipped build - needs the owner-only archive folder (excluded from the product zip)
# AND both GAMEBOT_DEV=1 and GAMEBOT_PRIVATE_PLUGIN=1.
if (os.environ.get("GAMEBOT_PRIVATE_PLUGIN") == "1" and os.environ.get("GAMEBOT_DEV") == "1"
        and (Path(__file__).resolve().parent / "_personal_archive_not_for_sale" / "private_plugin.py").is_file()):
    try:
        sys.path.insert(0, str(Path(__file__).resolve().parent / "_personal_archive_not_for_sale"))
        import private_plugin as PLUGIN  # type: ignore
    except Exception:
        PLUGIN = None


def _fn(name, desc, props=None, req=None):
    return {"type": "function", "function": {"name": name, "description": desc,
            "parameters": {"type": "object", "properties": props or {}, **({"required": req} if req else {})}}}


S = {"type": "string"}
I = {"type": "integer"}
TOOLS = [
    _fn("run_auto_game_pipeline", "FULL automatic studio setup AFTER intake (Unity or Unreal chosen). If engine not chosen yet, do not call — ask intake first. FULL automatic studio setup for a game: scaffold GameProjects\\<Name>, Pitch, GDD, ScenePlan, TaskBoard, Legal/Privacy, QA, Steam checklist + capsule folders + placeholder VDFs, website stub, and a Unity grey-box slice build in the background. Use for any make/build/new game request.", {"request": S, "project": S}, ["request"]),
    _fn("import_owned_asset", "Import a downloaded Unity .unitypackage from the local Asset Store cache into a GameProjects project (pass project=<title> when the user names one; else the active project) by list number or pack name. Updates ATTRIBUTION.md and rebuilds the Windows player by default.", {"request": S, "project": S}, ["request"]),
    _fn("run_ship_prep", "Store/ship prep for the current game: Steam checklist, capsule folders, SteamPipe VDFs with PLACEHOLDER_APPID, Epic upload stub, store copy.", {"request": S, "project": S}, ["request"]),
    _fn("make_asset", "Build a 3D prop in Blender headless and export FBX into the current game's Art\\Blender\\Exports (crate, barrel, rock, tree, table, chair, lamp, fence, house, car, sword...).", {"request": S, "project": S}, ["request"]),
    _fn("firefox_search", "Live web search in headless Firefox.", {"query": S, "max_results": I}, ["query"]),
    _fn("firefox_open", "Open http(s) URL in headless Firefox and read text. NOT for .exe paths.", {"url": S}, ["url"]),
    _fn("open_url", "Open http(s) URL in default browser.", {"url": S}, ["url"]),
    _fn("launch_app", "Start a Windows .exe (Blender, Unity Hub etc).", {"path": S, "args": S}, ["path"]),
    _fn("open_path", "Open local file/folder.", {"path": S}, ["path"]),
    _fn("run_blender_script", "Run Blender headless with a Python script to BUILD/export a model (FBX).", {"script_path": S, "script_code": S, "output_fbx": S}),
    _fn("write_text_file", "Write a file on disk.", {"path": S, "content": S}, ["path", "content"]),
    _fn("read_text_file", "Read a text file.", {"path": S, "max_chars": I}, ["path"]),
    _fn("list_files", "List files in a folder.", {"path": S, "pattern": S}),
    _fn("run_powershell", "Run PowerShell (prefer safe, never delete user data).", {"command": S, "timeout_sec": I}, ["command"]),
    _fn("system_info", "PC specs (GPU/CPU/RAM) for engine and performance choices.", {}),
    _fn("remember", "Save lasting fact.", {"fact": S}, ["fact"]),
    _fn("recall", "Recall memory.", {"query": S}),
    _fn("teach_self", "Save a lesson.", {"title": S, "lesson": S, "tags": S}, ["title", "lesson"]),
    _fn("list_lessons", "List lessons.", {"query": S}),
    _fn("read_lesson", "Read a lesson.", {"title_or_filename": S}, ["title_or_filename"]),
    _fn("note_write", "Save markdown note.", {"title": S, "content": S}, ["title", "content"]),
    _fn("note_read", "Read note.", {"title": S}, ["title"]),
    _fn("search_playbooks", "Search Game Bot's game-dev playbooks (auto-studio-mode, index, Unity, Unreal, Blender, assets, design, animation, VFX, AI, physics, camera, terrain, lighting, progression, quests, netcode, profiling, FPS passes, QA, accessibility, legal, Steamworks/EOS, custom items/weapons, batchmode bake, save/load, input, localization, Steam Deck, trailers, pricing/launch, support/patch notes, stores, mobile, monetization, modding). Use BEFORE answering game-dev questions.", {"query": S}, ["query"]),
    _fn("read_playbook", "Read one playbook by name fragment, e.g. complete-game-builder-index, auto-studio-mode, unity-workflow.", {"name": S}, ["name"]),
    _fn("research_error", "Look up an exact error message (error CS####, Unreal, Blender bpy, exception) in official docs via web search.", {"error_text": S}, ["error_text"]),
    _fn("make_game_scaffold", "Create only the bare project folder + docs in Documents\\GameProjects\\<Name>. Prefer run_auto_game_pipeline.", {"name": S, "pitch": S, "engine": S}, ["name"]),
    _fn("now_local", "Local time.", {}),
    _fn("inspect_scene", "Inspect the BUILT game scene before changing code: returns hierarchy (parent/child), components, colliders, scripts, positions, the player's and camera's children, renderer counts (primitive vs owned-pack meshes, packs used) and warnings FOLLOWS_PLAYER / FOLLOWS_CAMERA / PRIMITIVES_ONLY / MISSING_SCRIPTS. Unity (batchmode) or Unreal (editor python). ALWAYS call this first for any visual or gameplay bug report (something follows the player, wrong/missing models, grey boxes, stuck, falls through floor) before editing code.", {"project": S, "scene": S}, ["project"]),
    _fn("rebuild_game", "Re-run the project's Unity build (scene + Windows player) after a code/asset fix. Returns at once; check status with the progress panel.", {"project": S}, ["project"]),
]


def _run_auto_game_pipeline_gated(request: str = "", **kwargs) -> str:
    """Refuse to scaffold/build until full intake is answered; forward name/engine/etc.

    Engine choice is taken ONLY from real user chat turns (+ _TURN orig), never from
    model-crafted tool arguments like "(engine: unity)".
    Never invent NewGame when intake._LAST already has a title.
    """
    try:
        _tg = INTAKE.tool_gate()
        if _tg:
            return _tg
    except Exception:
        pass
    msgs = _TURN.get("messages") or []
    orig = (_TURN.get("orig") or "").strip()
    ok, ask = intake_ready_for_pipeline(orig, msgs)
    if not ok:
        try:
            import chat_store as _cs
            existing = _cs.current_game_root(msgs)
            if existing:
                if _cs.wants_play_demo(orig):
                    return _cs.launch_game_demo(existing, msgs)
                return (
                    f"PROJECT_EXISTS: This chat already has {existing.name} at {existing}. "
                    f"Build status: {_cs._format_build_status(__import__('auto_studio', fromlist=['build_status']).build_status(existing))}. "
                    "Do not start intake or a new project."
                )
        except Exception:
            pass
        return "INTAKE_REQUIRED (no project created yet). Ask the creator now:\n" + ask
    _blk = _pipeline_rerun_block(orig)
    if _blk:
        return _blk
    text = (request or kwargs.get("user_text") or kwargs.get("text") or "").strip()
    name = kwargs.get("name") or None
    engine = kwargs.get("engine") or None
    template = kwargs.get("template") if "template" in kwargs else None
    desktop_icon = bool(kwargs.get("desktop_icon", False))
    # Prefer intake last-state when the model/forced path omitted kwargs
    try:
        st = getattr(INTAKE, "_LAST", {}).get("st")
        if st:
            if not name:
                name = st.get("title") or None
            if not engine:
                engine = st.get("engine") or None
            if template is None and st.get("template"):
                tpl = st.get("template")
                if st.get("engine") == "Unity" and tpl == "3D (URP)":
                    template = "urp"
                elif st.get("engine") == "Unity" and "Built-in" in str(tpl):
                    template = "builtin"
                else:
                    template = None
            if not kwargs.get("desktop_icon") and st.get("icon") is not None:
                desktop_icon = bool(st.get("icon"))
            # Rebuild rich user_text from intake when caller only passed a short reply
            if st.get("phase") in ("assets", "idle") and (not text or len(text) < 80 or text.lower().strip() in {
                "unity", "unreal", "yes", "no", "1", "2", "import", "my assets", "assets from unity"
            } or re.search(r"assets?\s+from\s+unity|\bimport\b", text, re.I)):
                try:
                    payload = INTAKE._run_payload(st)
                    text = (payload.get("run") or {}).get("user_text") or text
                    if not name:
                        name = (payload.get("run") or {}).get("name") or name
                    if not engine:
                        engine = (payload.get("run") or {}).get("engine") or engine
                except Exception:
                    bits = [st.get("req") or "", f"engine {st.get('engine')}", f"genre {st.get('genre')}"]
                    for k, label in (("loop", "core loop"), ("story", "story"), ("goals", "goals"),
                                     ("setting", "setting"), ("style", "art/tone")):
                        if st.get(k):
                            bits.append(f"{label}: {st[k]}")
                    text = " | ".join(x for x in bits if x)
    except Exception:
        pass
    if not text:
        text = orig
    genre, brief = None, None
    try:
        st = getattr(INTAKE, "_LAST", {}).get("st")
        if st and st.get("genre") and (not kwargs.get("name") or kwargs.get("name") == st.get("title")):
            run = (INTAKE._run_payload(st).get("run") or {})
            genre, brief = run.get("genre"), run.get("brief")
    except Exception:
        pass
    # Never let a bare request override an explicit/intake title
    return run_auto_game_pipeline(
        text or orig,
        name=name,
        engine=engine,
        template=template,
        desktop_icon=desktop_icon,
        genre=genre,
        brief=brief,
    )


_REBUILD_RE = re.compile(r"\b(re-?build|build (it |the game |again)|re-?run (the )?(pipeline|build)|new build|make (a )?new build)\b", re.I)


def _pipeline_rerun_block(orig: str) -> str | None:
    """After intake already ran the pipeline (asset questions / idle), the model may NOT call it again on its own
    (e.g. after a bare 'unity' it invented 'fishing game called Herring Bay'). Only an explicit rebuild ask runs it."""
    try:
        st = getattr(INTAKE, "_LAST", {}).get("st")
        if not st or st.get("phase") not in ("assets", "idle") or not st.get("title"):
            return None
        from auto_studio import GAME_PROJECTS, build_status
        from gamedev_core import _safe_name
        root = GAME_PROJECTS / _safe_name(st["title"])
        if not root.is_dir():
            return None
        if _REBUILD_RE.search(orig or ""):
            return None
        return (f"PIPELINE_NOT_RUN: {root.name} already exists ({root}) and the creator did not ask for a rebuild or a new game. "
                f"Build status: {build_status(root)}. Do NOT call run_auto_game_pipeline again and do not invent a request. "
                "Answer the creator's last message briefly and continue the current asset question.")
    except Exception:
        return None

def _inspect_scene(project: str = "", scene: str = "") -> str:
    from auto_studio import inspect_scene
    return inspect_scene(project, scene)


def _rebuild_game(project: str = "") -> str:
    from auto_studio import queue_unity_rebuild, resolve_project
    root = resolve_project(project or "")
    return queue_unity_rebuild(root) if root else "rebuild_game: no project found (pass project=<game title>)."


DISPATCH: dict[str, Callable[..., str]] = {
    "run_auto_game_pipeline": lambda **a: _run_auto_game_pipeline_gated(a.get("request", "") or a.get("user_text", "") or "", **{k: v for k, v in a.items() if k not in ("request",)}),
    "run_ship_prep": lambda **a: run_ship_prep(a.get("request", "")),
    "make_asset": lambda **a: run_asset_auto(a.get("request", "") or a.get("name", "")),
    "scan_owned_assets": lambda **a: scan_owned_assets(a.get("request", "") or a.get("engine", "") or ""),
    "import_owned_asset": lambda **a: import_owned_asset_tool(a.get("request", "") or a.get("pack", "") or a.get("name", "") or "", a.get("project", "") or ""),
    "firefox_search": lambda **a: firefox_search(a.get("query", ""), a.get("max_results", 5)),
    "firefox_open": lambda **a: firefox_open(a.get("url", "")),
    "open_url": lambda **a: open_url(a.get("url", "")),
    "launch_app": lambda **a: launch_app(a.get("path", ""), a.get("args", "")),
    "open_path": lambda **a: open_path(a.get("path", "")),
    "run_blender_script": lambda **a: run_blender_script(a.get("script_path", ""), a.get("script_code", ""), a.get("output_fbx", "")),
    "write_text_file": lambda **a: write_text_file(a.get("path", ""), a.get("content", "")),
    "read_text_file": lambda **a: _read_text_file_safe(a.get("path", ""), a.get("max_chars", 8000)),
    "list_files": lambda **a: list_files(a.get("path", ""), a.get("pattern", "*")),
    "run_powershell": lambda **a: run_powershell(a.get("command", ""), a.get("timeout_sec", 60)),
    "system_info": lambda **a: system_info(),
    "remember": lambda **a: remember(a.get("fact", "")),
    "recall": lambda **a: recall(a.get("query", "")),
    "teach_self": lambda **a: teach_self(a.get("title", ""), a.get("lesson", ""), a.get("tags", "")),
    "list_lessons": lambda **a: list_lessons(a.get("query", "")),
    "read_lesson": lambda **a: read_lesson(a.get("title_or_filename", "")),
    "note_write": lambda **a: note_write(a.get("title", ""), a.get("content", "")),
    "note_read": lambda **a: note_read(a.get("title", "")),
    "now_local": lambda **a: now_local(),
    "inspect_scene": lambda **a: _inspect_scene(a.get("project", "") or a.get("name", ""), a.get("scene", "")),
    "rebuild_game": lambda **a: _rebuild_game(a.get("project", "") or a.get("name", "")),
    "search_playbooks": lambda **a: search_playbooks(a.get("query", "")),
    "read_playbook": lambda **a: read_playbook(a.get("name", "")),
    "research_error": lambda **a: research_error(a.get("error_text", "")),
    "make_game_scaffold": lambda **a: make_game_scaffold(a.get("name", ""), a.get("pitch", ""), a.get("engine", "Unity")),
}

import intake as INTAKE  # deterministic new-game intake (engine/title/genre/template/icon, then assets one at a time)
from owned_assets import scan_owned_assets, import_owned_asset_tool

SYSTEM = (
    "You are Game Bot, an automatic game studio for any creator. You ACT with tools. English only.\n"
    "SOLE JOB: make games end to end: design, docs, Blender assets, Unity/Unreal code and scenes, UI, audio, VFX, AI, QA, builds, store prep.\n"
    "Paths come from config\\gamebot.config.json (projects_root, unity_editor, blender; auto-detected). Work only inside projects_root\\<GameName>; never touch other folders, saves, or projects the creator did not name.\n"
    "RULES:\n"
    "- NEW GAME INTAKE (required): before creating or building, ask missing pieces — especially **Unity or Unreal?** when not chosen. Also title if missing, genre if unclear, Unity template (3D URP vs Built-in). Read playbook new-game-intake. Do NOT silently default to Unity when the user has not picked.\n"
    "- After intake.py finishes (engine, title if needed, genre if needed, Unity URP/Built-in or Unreal template, desktop icon yes/no): run_auto_game_pipeline. Never ask 'should I proceed?' once intake is answered — just build.\n"
    "- After the project exists: progressive asset questions one step at a time (see new-game-intake examples: FPS characters vs weapons; platformer player vs tileset). Do NOT call make_asset until the creator picks an asset category. Coach My Assets download (owned != on disk). Call scan_owned_assets to list local Asset Store-5.x / Fab VaultCache downloads. When the creator picks a number/name, call import_owned_asset (or intake will import) so the pack lands in the project + ATTRIBUTION.md + rebuild. Fallbacks Kenney/OGA/itch/Poly Pizza/Quaternius.\n"
    "- Never write long tutorials. Call tools, then report what you DID with real paths.\n"
    "- On feature / fix / ship (after intake): read_playbook complete-game-builder-index (and auto-studio-mode / new-game-intake), then execute with tools until a TRUE human gate.\n"
    "- New game (intake done): run_auto_game_pipeline. Ship/Steam/Epic: run_ship_prep. Props/models: make_asset (Blender), else CC0 intake per asset-intake.\n"
    "- Unity 6000.x when Unity chosen; Unreal when Unreal chosen. Projects live in Documents\\GameProjects\\<Name>.\n"
"- Prefer Blender (headless bpy) for custom assets; CC0 assets (Kenney, Poly Haven, ambientCG) with ATTRIBUTION.md rows.\n"
    "- Human gates ONLY: store accounts + tax/bank, real Steam AppID/DepotID and Epic/EOS IDs (never invent; use PLACEHOLDER_APPID), age ratings, store review submit, final Release click, paid purchases, large engine installs, public deploys, legal review.\n"
    "- Never touch projects the creator did not name. Never delete saves or user data.\n"
    "- After each milestone call teach_self with what worked.\n"
    "- BUG REPORTS (visual or gameplay: something follows the player/camera, grey boxes instead of models, missing assets, stuck, falling, enemy not reacting): FIRST call inspect_scene(project) and read its WARN lines + player/camera children. Name the real cause from that output, then read_text_file the responsible script (usually Tools\\Unity\\SceneBuilder*.cs or a gameplay .cs), fix it with write_text_file, and call rebuild_game. Never edit code before inspect_scene, never guess.\n"
    "- Scenes must use the creator's OWNED packs (genre kit imported automatically; import_owned_asset for more). Only player-held items (weapon, CharacterVisual) may be children of the player; never parent walls/buildings/props to the player or camera.\n"
    "- A missing Docs\\TaskBoard.md or Builds\\auto_unity_status.txt is NORMAL for a new/early project: never stop or say you won't guess; run run_auto_game_pipeline (or create the file) and keep working.\n"
    "\nPlaybooks: complete-game-builder-index, auto-studio-mode, unity-workflow, unreal-workflow, assets-pipeline, asset-intake, game-design, narrative-writing-gdd, models-and-ui, legal-notices-and-menus, qa-test-plans, fps-performance-passes, performance-profiling, ship-build-installer-desktop, store-steam-epic-mobile, steamworks-sdk-integration, steam-store-marketing, turnkey-assets-stores-gaps, websites-and-concept-art, product-safety, onboarding-new-buyer, unity-custom-item-weapon-pipeline, unity-batchmode-content-bake, automated-playtest-runner, save-load-systems, input-system, dialogue-localization, addressables-content-update, steam-deck-verified, trailer-capture-checklist, pricing-wishlist-launch-week, customer-support-patch-notes, self-learn-loop, and the rest under playbooks/.\n"
)

ACTION_WORDS = (
    "you do it", "do it all", "make it", "build", "add", "create", "install", "launch",
    "open blender", "put it in", "integrate", "fix", "run ", "do that", "proceed", "yes", "ship", "auto",
)
LOOKUP_WORDS = ("find", "search", "look up", "online", "blender", "make", "build", "add a", "steam", "capsule",
                "unity", "unreal", "asset", "model", "prop")

NO_TUTORIAL_NOTE = ("SYSTEM NOTE: {what} already ran (result above). Report ONLY what was done with the real paths, "
                    "then continue the next TaskBoard steps with tools (no tutorial, no 'proceed?'). Stop only at a human gate.")
PROGRESSIVE_ASSET_NOTE = ("SYSTEM NOTE: run_auto_game_pipeline already ran (result above). Brief status with real paths, then ASK the next progressive asset question for this genre (one choice only). Examples: platformer — player character or tileset/env first?; FPS — characters or weapons?; horror — player or dark env?. Do NOT call make_asset yet. Do NOT dump a link list. Coach My Assets download next.")


_STALL_RE = re.compile(r"(won'?t|will not|cannot|can'?t|unable to|not going to)\s+guess|"
                       r"(taskboard(\.md)?|auto_unity_status(\.txt)?)[^\n]{0,80}(missing|not found|does(n'?t| not) exist|is absent)|"
                       r"(missing|no|not find|cannot find|can'?t find)[^\n]{0,40}(taskboard|auto_unity_status)", re.I)


def is_missing_file_stall(text: str) -> bool:
    return bool(text) and bool(_STALL_RE.search(text))


def ensure_project_files(user_text: str) -> tuple[str, str]:
    """Missing TaskBoard / status file -> create them (or run the pipeline) instead of stalling."""
    try:
        root = resolve_project(user_text)
    except Exception:
        root = None
    if root is None:
        _ekw = {}
        try:
            _est = getattr(INTAKE, "_LAST", {}).get("st")
            if _est and _est.get("title"):
                _ekw["name"] = _est.get("title")
            if _est and _est.get("engine"):
                _ekw["engine"] = _est.get("engine")
        except Exception:
            pass
        return "run_auto_game_pipeline", _run_auto_game_pipeline_gated(user_text, **_ekw)
    made = []
    tb = root / "Docs" / "TaskBoard.md"
    if not tb.exists():
        tb.parent.mkdir(parents=True, exist_ok=True)
        tb.write_text(f"# {root.name} - task board\n\n## Auto next actions\n- [ ] Fill Pitch.md + GDD.md\n"
                      "- [ ] Unity grey-box slice (Tools\\auto_unity.ps1)\n- [ ] Player controller + core loop\n", encoding="utf-8")
        made.append(str(tb))
    st = root / "Builds" / "auto_unity_status.txt"
    if not st.exists() and not (root / "Tools" / "auto_unity.ps1").exists():
        st.parent.mkdir(parents=True, exist_ok=True)
        st.write_text("NOT_STARTED\n", encoding="utf-8")
        made.append(str(st))
    try:
        from auto_studio import build_status
        real = build_status(root)
    except Exception:
        real = ""
    return "ensure_project_files", (f"PROJECT {root}\ncreated: {made or 'nothing (files already exist)'}\n"
                                    f"Build status (real): {real or 'unknown'}\n"
                                    "Continue the TaskBoard 'Auto next actions' with tools.")


def _read_text_file_safe(path: str, max_chars: int = 8000):
    low = (path or "").lower().replace("/", "\\")
    if (low.endswith("taskboard.md") or low.endswith("auto_unity_status.txt")) and not Path(path).exists():
        if low.endswith("auto_unity_status.txt"):
            bg = unity_bg_status()
            if bg:
                return "Status file not at that path, but: " + bg
            return ("No status file yet at that path - the Unity background build is queued or has not started. "
                    "Do not stop. Continue the next TaskBoard step.")
        return "TaskBoard.md missing - call run_auto_game_pipeline (new game) to create it, then continue."
    return read_text_file(path, max_chars)


def chat_once(messages: list[dict]) -> dict:
    import time
    import urllib.error
    from ollama_ensure import ensure_ollama, ollama_up
    if not ollama_up():
        _TURN["status"] = "Starting model server..."
        ok, reason = ensure_ollama(timeout=30)
        if not ok:
            raise RuntimeError(f"Model server failed to start: {reason}")
    try:
        import session_hygiene as _SHF
        messages = _SHF.fit_to_window(messages)
    except Exception:
        pass
    body = {
        "model": MODEL,
        "messages": messages,
        "stream": False,
        "tools": TOOLS,
        "options": apply_to_agent_options({"temperature": 0.1}),
    }
    raw = json.dumps(body).encode("utf-8")
    last_err = None
    for attempt in range(3):
        req = urllib.request.Request(
            f"{OLLAMA}/api/chat", data=raw,
            headers={"Content-Type": "application/json"}, method="POST",
        )
        try:
            with urllib.request.urlopen(req, timeout=300) as resp:
                return json.loads(resp.read().decode("utf-8"))
        except urllib.error.HTTPError as e:
            detail = e.read().decode("utf-8", errors="replace")[:800]
            last_err = RuntimeError(f"Ollama HTTP {e.code}: {detail}")
            time.sleep(1.5 * (attempt + 1))
        except Exception as e:
            last_err = e
            time.sleep(1.5 * (attempt + 1))
    raise last_err if last_err else RuntimeError("Ollama chat failed")


def claims_fake_success(text: str) -> bool:
    t = (text or "").lower()
    return any(x in t for x in ("successfully created", "has been successfully", "fbx file is now located", "you can proceed with integrating"))


def looks_like_tutorial(text: str) -> bool:
    t = (text or "").lower()
    if not t:
        return False
    if "```json" in t and "launch_app" in t:
        return True
    if "would you like me to proceed" in t or "would you like me to" in t:
        return True
    if "step 1:" in t and "step 2:" in t:
        return True
    if "here's how" in t or "follow these steps" in t:
        return True
    return False



def blender_job_failed(tool_out: str) -> bool:
    o = (tool_out or "").lower()
    if "rejected:" in o:
        return True
    if "exists=false" in o:
        return True
    if "script missing" in o or "blender missing" in o:
        return True
    if "placeholder" in o:
        return True
    return False

def _personal_wants_integrate(lu: str) -> bool:
    if PLUGIN is None:
        return False
    return bool(getattr(PLUGIN, "wants_integrate", lambda _t: False)(lu))


def needs_action(text: str) -> bool:
    t = (text or "").lower()
    return any(w in t for w in ACTION_WORDS) or any(w in t for w in LOOKUP_WORDS)


def new_session() -> list[dict]:
    mem = recall("")
    lessons = lessons_for_prompt(6)
    sys_ = SYSTEM + f"\n\nSaved memory:\n{mem}\n\nSelf-taught lessons:\n{lessons}"
    return [{"role": "system", "content": sys_}]


def _inject(messages, emit, name, out, what, args=None):
    emit({"type": "tool", "name": name, "args": args or {"forced": what}})
    emit({"type": "tool_result", "name": name, "chars": len(str(out))})
    messages.append({"role": "assistant", "content": "", "tool_calls": [{"function": {"name": name, "arguments": args or {}}}]})
    messages.append({"role": "tool", "content": str(out)[:10000]})
    messages.append({"role": "user", "content": NO_TUTORIAL_NOTE.format(what=name)})


def _pending_new_game_text(messages: list | None, latest: str = "") -> str | None:
    """If latest is an intake answer (engine pick) after a make-game ask, return that make-game text."""
    if wants_auto_game(latest):
        return latest
    from auto_studio import engine_choice_from_text
    if not engine_choice_from_text(latest):
        return None
    for m in reversed(messages or []):
        if m.get("role") != "user":
            continue
        c = str(m.get("content") or "")
        if c.startswith("SYSTEM NOTE"):
            continue
        if c.strip() == (latest or "").strip():
            continue
        if wants_auto_game(c):
            return c
    return None


def _forced_intent(text: str, messages: list | None = None):
    """Return (tool_name, callable) for requests that must run before the model."""
    if not text or text.startswith("SYSTEM NOTE"):
        return None
    # Never force pipeline while intake.py still has unanswered steps (template/icon/etc.)
    try:
        _tg = INTAKE.tool_gate()
        if _tg:
            return None
    except Exception:
        pass
    # Asset-phase replies (import / my assets / etc.) must NOT re-fire the studio pipeline.
    # That was creating a second project named NewGame after OpenWorldPlus already existed.
    try:
        st = getattr(INTAKE, "_LAST", {}).get("st")
        if st and st.get("phase") == "assets":
            tl = (text or "").lower()
            if re.search(r"\b(import|my assets|asset store|assets?\s+from\s+unity|owned|pack|free|cc0|kenney|skip)\b", tl):
                return None
            # Pipeline already ran when intake completed; do not launch again from a short reply
            if not wants_auto_game(text):
                return None
    except Exception:
        pass
    pending = _pending_new_game_text(messages, text)
    if pending:
        # Combine original make ask + latest intake answer so title/genre/engine stay in scope
        combo = pending if pending == text else (pending + "\n" + text)
        kw = {}
        try:
            st = getattr(INTAKE, "_LAST", {}).get("st")
            if st and st.get("title"):
                kw["name"] = st.get("title")
            if st and st.get("engine"):
                kw["engine"] = st.get("engine")
            if st and st.get("icon") is not None:
                kw["desktop_icon"] = bool(st.get("icon"))
            if st and st.get("phase") in ("assets", "idle"):
                try:
                    payload = INTAKE._run_payload(st)
                    run = payload.get("run") or {}
                    combo = run.get("user_text") or combo
                    kw = {**kw, **{k: run[k] for k in ("name", "engine", "template", "desktop_icon") if k in run and run[k] is not None}}
                except Exception:
                    pass
        except Exception:
            pass
        return "run_auto_game_pipeline", lambda: _run_auto_game_pipeline_gated(combo, **kw)
    if wants_ship_prep(text):
        return "run_ship_prep", lambda: run_ship_prep(text)
    if wants_asset(text):
        return "make_asset", lambda: run_asset_auto(text)
    return None


def _run_turn_impl(messages: list[dict], on_event: Callable[[dict], None] | None = None):
    def emit(ev: dict) -> None:
        if on_event:
            on_event(ev)

    forced = 0
    researched = 0
    _once_ran: dict = {}
    answer = ""
    _orig = next((m.get("content") or "" for m in reversed(messages) if m.get("role") == "user" and not str(m.get("content", "")).startswith("SYSTEM NOTE")), "")
    _TURN["messages"] = messages
    _TURN["orig"] = _orig
    _lu = _orig.lower()
    # Existing game chat: resume or launch the built exe instead of starting intake / a new pipeline.
    try:
        import chat_store as _cs
        import asset_plan as _AP
        _root = _cs.chat_game_root(messages)
        _st = None
        try:
            _st = INTAKE._active(messages)
        except Exception:
            _st = None
        _intake_busy = bool(_st and _st.get("phase") in ("intake", "asset_gate"))
        if _root and not _intake_busy:
            _title = _cs._pretty_title(game=_root.name, root=_root) or _root.name
            _ch = _AP.choice_reply(_root, _orig, messages)
            if _ch:
                emit({"type": "status", "text": "Updating the asset plan..."})
                messages.append({"role": "assistant", "content": _ch})
                emit({"type": "done"})
                return messages, _ch
            if _AP.wants_assets(_orig) and not _cs.wants_play_demo(_orig):
                emit({"type": "status", "text": "Scanning your owned asset packs..."})
                answer = _AP.assets_reply(_root, _orig, _title)
                messages.append({"role": "assistant", "content": answer})
                emit({"type": "done"})
                return messages, answer
            if re.match(r"^\s*(please\s+)?(re-?build|build (it |the game )?again|remake it|rebuild (it|the game|my game))\b", _orig, re.I):
                from auto_studio import queue_unity_rebuild
                _q = queue_unity_rebuild(_root)
                if _q.startswith("Unity rebuild queued"):
                    answer = f"Rebuilding {_title} with the latest Game Bot templates and your packs. I'll tell you when it's ready - say \"play\" then."
                elif "already running" in _q:
                    answer = f"{_title} is already building - I'll pick up your changes on the next build."
                else:
                    answer = f"I couldn't start a rebuild of {_title}: {_q}"
                messages.append({"role": "assistant", "content": answer})
                emit({"type": "done"})
                return messages, answer
            if INTAKE.is_new_game(_orig) and not re.search(r"\b(new|another|different|second|other)\s+(\w+\s+){0,2}game\b", _orig, re.I):
                answer = (f"This chat is {_title}, so I won't start the questions over. Tell me what to change "
                          f"(for example \"more enemies\", \"add a river\" or \"rebuild\"), or say \"use my assets\" to re-import your packs. "
                          f"For a different game, click New chat.")
                messages.append({"role": "assistant", "content": answer})
                emit({"type": "done"})
                return messages, answer
        if not _root and not _intake_busy and _AP.wants_assets(_orig) and not INTAKE.is_new_game(_orig):
            emit({"type": "status", "text": "Scanning your owned asset packs..."})
            answer = _AP.owned_list_text() + "\n\nTell me what game to make and I'll map these packs to it before building."
            messages.append({"role": "assistant", "content": answer})
            emit({"type": "done"})
            return messages, answer
        if _root and _cs.wants_play_demo(_orig):
            emit({"type": "status", "text": f"Launching {_root.name}..."})
            answer = _cs.launch_game_demo(_root, messages)
            messages.append({"role": "assistant", "content": answer})
            emit({"type": "done"})
            return messages, answer
        if _root and _cs.wants_resume(_orig):
            emit({"type": "status", "text": "Checking build status..."})
            answer = _cs.resume_reply(_root, messages)
            messages.append({"role": "assistant", "content": answer})
            emit({"type": "done"})
            return messages, answer
    except Exception:
        pass
    # Per-turn knowledge injection: relevant lessons + playbook sections (replaces previous injection)
    if _orig and messages and messages[0].get("role") == "system":
        try:
            _kb = "[KB] Relevant self-taught lessons:\n" + relevant_lessons(_orig, 4, 300) + "\n\nRelevant playbook sections:\n" + search_playbooks(_orig, 3, 900)
            _base = str(messages[0].get("content", "")).split("\n\n[KB]")[0]
            messages[0]["content"] = _base + "\n\n" + _kb[:2600]
        except Exception:
            pass
    # NEW-GAME INTAKE (intake.py): deterministic questions before anything is created; after the answers it runs the pipeline.
    _ik, _ik_follow = None, ""
    try:
        if _orig and messages and messages[-1].get("role") == "user":
            _ik = INTAKE.step(messages, _orig)
    except Exception as _e:
        emit({"type": "status", "text": f"intake error: {_e}"})
        _ik = None
    if isinstance(_ik, str):
        messages.append({"role": "assistant", "content": _ik})
        emit({"type": "done"})
        return messages, _ik
    # AUTO STUDIO: only force pipeline after intake (engine chosen). Else model asks Unity/Unreal + intake.
    _intent = _forced_intent(_orig, messages)
    if isinstance(_ik, dict) and _ik.get("run"):
        _ik_follow = _ik.get("followup") or ""
        _intent = ("run_auto_game_pipeline", lambda: run_auto_game_pipeline(**_ik["run"]))
    elif isinstance(_ik, dict) and _ik.get("asset"):
        _ik_follow = _ik.get("followup") or ""
        _intent = ("make_asset", lambda: run_asset_auto(_ik["asset"], project=_ik.get("project")))
    # Intake-driven actions (pipeline after the last intake answer, Blender asset from an asset answer) are
    # deterministic: run them and report the real tool result. No model loop -> no re-fired pipeline,
    # no invented "NOT_STARTED" / "No assets yet" text.
    if isinstance(_ik, dict) and (_ik.get("run") or _ik.get("asset")) and messages and messages[-1].get("role") == "user":
        _name, _call = _intent
        emit({"type": "status", "text": "Running the studio pipeline..." if _name == "run_auto_game_pipeline" else "Building the asset in Blender..."})
        try:
            _out = _call()
        except Exception as e:
            _out = f"Error: {e}"
        emit({"type": "tool", "name": _name, "args": {"request": _orig[:200]}})
        emit({"type": "tool_result", "name": _name, "chars": len(str(_out))})
        answer = _intake_action_report(_name, str(_out))
        if _ik_follow:
            answer = answer + "\n\n" + _ik_follow
        messages.append({"role": "assistant", "content": answer})
        emit({"type": "done"})
        return messages, answer
    if _intent and _intent[0] == "run_auto_game_pipeline" and not (isinstance(_ik, dict) and _ik.get("run")):
        _ok, _ask = intake_ready_for_pipeline(_orig, messages)
        if not _ok:
            _intent = None
            if messages and messages[-1].get("role") == "user":
                messages.append({"role": "user", "content": "SYSTEM NOTE: Intake incomplete. Do NOT call run_auto_game_pipeline yet. Ask the creator this intake now (short chat message, no tools):\n" + _ask})
    if _intent and messages and messages[-1].get("role") == "user":
        _name, _call = _intent
        _status_map = {"run_auto_game_pipeline": "Running the studio pipeline...",
                       "run_ship_prep": "Preparing store/ship files...",
                       "make_asset": "Building the asset in Blender..."}
        if _name == "make_asset" and re.search(r"\b(import|my assets|asset store|owned)\b", (_orig or ""), re.I):
            _status_map["make_asset"] = "Importing owned Unity assets..."
        emit({"type": "status", "text": _status_map[_name]})
        try:
            _out = _call()
        except Exception as e:
            _out = f"Error: {e}"
        _inject(messages, emit, _name, _out, _name, {"request": _orig[:200]})
        forced = 1
        _once_ran[_name] = True
        _err = detect_failure(_name, str(_out))
        if _err:
            researched = 1
            _rs = auto_research(_err)
            _inject(messages, emit, "firefox_search", _rs, "auto_research", {"query": _err[:120]})
    elif PLUGIN is not None and _personal_wants_integrate(_lu):
        emit({"type": "status", "text": "Private plugin: integrating..."})
        _n, _out = PLUGIN.force_add_weapon(_orig)
        _inject(messages, emit, _n, _out, "private plugin")
        forced = 2
    for _ in range(10):
        emit({"type": "status", "text": "Thinking..."})
        data = chat_once(messages)
        msg = data.get("message") or {}
        messages.append(msg)
        tool_calls = msg.get("tool_calls") or []
        if tool_calls:
            for tc in tool_calls:
                fn = tc.get("function") or {}
                name = fn.get("name")
                args = fn.get("arguments") or {}
                if isinstance(args, str):
                    try:
                        args = json.loads(args)
                    except Exception:
                        args = {}
                emit({"type": "tool", "name": name, "args": args})
                _once = name in ("run_auto_game_pipeline", "run_ship_prep")
                if _once and _once_ran.get(name):
                    out = (f"{name} ALREADY RAN this turn (see the earlier result). Do NOT call it again. "
                           "Now give the creator a short final report: project path, build status, and the next TaskBoard step.")
                else:
                    try:
                        import tool_guard as _TG
                        _why = _TG.guard(name, args if isinstance(args, dict) else {})
                    except Exception as _ge:  # fail closed for the risky tools
                        _why = (f"REFUSED: tool sandbox unavailable ({_ge})" if name in (
                            "run_powershell", "write_text_file", "read_text_file", "run_blender_script", "launch_app", "list_files", "open_path") else None)
                    try:
                        out = _why or DISPATCH.get(name, lambda **k: f"Unknown tool {name}")(**args)
                    except Exception as e:
                        out = f"Error: {e}"
                    if _once:
                        _once_ran[name] = True
                emit({"type": "tool_result", "name": name, "chars": len(str(out))})
                messages.append({"role": "tool", "content": str(out)[:10000]})
                if name == "run_auto_game_pipeline" and "INTAKE_REQUIRED" not in str(out) and forced < 5:
                    forced += 1
                    messages.append({"role": "user", "content": PROGRESSIVE_ASSET_NOTE})

                # AUTO-RESEARCH ON FAILURE: search docs once per turn, then patch/retry once and teach_self
                _err = detect_failure(name, str(out))
                if _err and researched < 1:
                    researched += 1
                    emit({"type": "status", "text": "Tool failed - researching the error online..."})
                    _rs = auto_research(_err)
                    emit({"type": "tool", "name": "firefox_search", "args": {"auto_research": _err[:120]}})
                    emit({"type": "tool_result", "name": "firefox_search", "chars": len(_rs)})
                    messages.append({"role": "assistant", "content": "", "tool_calls": [{"function": {"name": "firefox_search", "arguments": {"query": _err[:120]}}}]})
                    messages.append({"role": "tool", "content": _rs})
                    messages.append({"role": "user", "content": "SYSTEM NOTE: The last tool failed with: " + _err[:200] + ". Use the search results (firefox_open an official doc if needed), fix surgically, retry ONCE, then call teach_self with symptom/cause/fix/source URL. If still failing, report the exact error."})
                # Blender stub failed on a build ask -> run the generic prop generator instead
                if name == "run_blender_script" and blender_job_failed(str(out)) and forced < 3:
                    forced += 1
                    emit({"type": "status", "text": "Blender stub failed - running the generic prop generator..."})
                    _inject(messages, emit, "make_asset", run_asset_auto(_orig), "make_asset", {"request": _orig[:200]})
            continue

        content = msg.get("content") or ""
        last_user = _orig or next((m["content"] for m in reversed(messages) if m.get("role") == "user"), "")
        used_tool = any(m.get("role") == "tool" for m in messages[-12:])
        recent_tools = [m.get("content", "") for m in messages[-12:] if m.get("role") == "tool"]
        blender_ok = any("exists=true" in (t or "").lower() or "exported" in (t or "").lower() for t in recent_tools)
        should_force = (not used_tool) or looks_like_tutorial(content) or (claims_fake_success(content) and not blender_ok)
        if content and needs_action(last_user) and should_force and forced < 4:
            forced += 1
            lu = (last_user or "").lower()
            emit({"type": "status", "text": "Forcing real action..."})
            if wants_auto_game(last_user):
                _fkw = {}
                try:
                    _fst = getattr(INTAKE, "_LAST", {}).get("st")
                    if _fst and _fst.get("title"):
                        _fkw["name"] = _fst.get("title")
                    if _fst and _fst.get("engine"):
                        _fkw["engine"] = _fst.get("engine")
                except Exception:
                    pass
                name, out = "run_auto_game_pipeline", _run_auto_game_pipeline_gated(last_user, **_fkw)
            elif wants_ship_prep(last_user):
                name, out = "run_ship_prep", run_ship_prep(last_user)
            elif wants_asset(last_user) or (any(w in lu for w in ("blender", "fbx", "model", "prop", "mesh")) and any(w in lu for w in ("make", "build", "create", "add"))):
                name, out = "make_asset", run_asset_auto(last_user)
            elif any(w in lu for w in ("spec", "hardware", "my pc", "this pc", "gpu", "vram")):
                name, out = "system_info", system_info()
            elif any(w in lu for w in ("unity", "unreal", "ue5", "blender python", "bpy", "prefab", "scriptableobject", "batchmode", "shader", "material", "umg", "canvas", "game design", "gdd", "loop", "economy", "progression", "error cs", "compile", "package", "packaging")):
                name = "search_playbooks"
                out = search_playbooks(last_user) + "\n\n--- web ---\n" + str(firefox_search(last_user + " documentation", 4))[:3000]
            else:
                name, out = "search_playbooks", search_playbooks(last_user) + "\n\n--- web ---\n" + str(firefox_search(last_user, 4))[:2500]
            messages.append({"role": "assistant", "content": "", "tool_calls": [{"function": {"name": name, "arguments": {}}}]})
            messages.append({"role": "tool", "content": str(out)[:10000]})
            messages.append({"role": "user", "content": "SYSTEM NOTE: You dumped a tutorial or skipped tools. Tools already ran. Now report ONLY what was done and file paths created. No steps for the user. No proceed?"})
            continue

        if is_missing_file_stall(content) and forced < 4:
            forced += 1
            emit({"type": "status", "text": "Creating missing project files..."})
            name, out = ensure_project_files(last_user)
            _inject(messages, emit, name, out, name, {"request": (last_user or "")[:200]})
            continue

        answer = content
        if answer and "```json" in answer and "launch_app" in answer:
            answer = re.sub(r"```json[\s\S]*?```", "", answer).strip()
        break
    # Always show the real result of a forced studio step, so a vague/misleading model line can't hide it.
    if _intent and forced >= 1:
        try:
            _pipeline_fact = str(_out).strip().splitlines()
            _fact = " ".join(_pipeline_fact[:3])[:600]
            if _fact and _fact[:80] not in (answer or ""):
                answer = ((answer or "").strip() + "\n\nDone this turn (" + _intent[0] + "): " + _fact).strip()
        except Exception:
            pass
    if _ik_follow:
        answer = ((answer or "").strip() + "\n\n" + _ik_follow).strip()
    emit({"type": "done"})
    return messages, answer


def _intake_action_report(name: str, out: str) -> str:
    lines = [l for l in (out or "").splitlines() if l.strip()]
    if name == "run_auto_game_pipeline":
        root = next((l[5:].strip() for l in lines if l.startswith("ROOT ")), "")
        unity = next((l for l in lines if l.startswith(("UNITY", "UNREAL"))), "")
        brief = ""
        try:
            import json as _j
            b = _j.loads((Path(root) / "Tools" / "game_brief.json").read_text(encoding="utf-8")) if root else {}
            if b:
                brief = (f"Genre: {b.get('genre_label')} (gameplay template: {b.get('family')}). Your story, setting and "
                         f"{len(b.get('goals') or [])} goals are baked into the intro, objectives, win screen and achievements "
                         f"({', '.join(b.get('ach_titles') or [])}).")
        except Exception:
            pass
        try:
            from auto_studio import build_status
            bs = build_status(Path(root)) if root else ""
        except Exception:
            bs = ""
        if not root:
            return "Pipeline result: " + " ".join(lines[:4])[:600]
        plan_lines = []
        if "ASSET_PLAN" in (out or ""):
            for l in (out or "").split("ASSET_PLAN", 1)[1].splitlines()[1:]:
                if not l.startswith("- "):
                    break
                plan_lines.append(l)
        packs = ("Using your packs:\n" + "\n".join(plan_lines)) if plan_lines else ""
        building = ("I'm building the playable Windows version in the background now (terrain, buildings, enemies, gun and sound "
                    "from those packs). I'll tell you when it's ready to play.") if unity.startswith("UNITY ") else (
                    "Unity isn't installed, so I couldn't start the build yet." if "not installed" in unity else "")
        return "\n".join(x for x in [f"Created {Path(root).name} at {root}.", brief, packs, building] if x)
    if name == "make_asset":
        head = next((l for l in lines if l.startswith("ASSET ")), lines[0] if lines else "")
        ok = "exists=True" in head
        uc = next((l for l in lines if l.startswith("UNITY_COPY")), "")
        rb = next((l for l in lines if "rebuild" in l.lower() or "already running" in l.lower()), "")
        if ok:
            return "\n".join(x for x in ["Made it in Blender: " + head.replace("ASSET ", ""), uc.replace("UNITY_COPY ", "In Unity: "), rb] if x)
        return "Blender couldn't make that asset: " + " ".join(lines[:4])[:500]
    return " ".join(lines[:4])[:600]


def shutdown_tools() -> None:
    try:
        firefox_close()
    except Exception:
        pass


def _synth_status(messages: list[dict]) -> str:
    """Never return an empty answer: summarize what tools ran this turn."""
    tools = []
    for m in reversed(messages):
        if m.get("role") == "user" and not str(m.get("content", "")).startswith("SYSTEM NOTE"):
            break
        if m.get("role") == "tool":
            tools.append(str(m.get("content") or "").strip())
    steps = [s for s in (_TURN.get("done_steps") or []) if s]
    if not steps and not tools:
        return "I didn't get a reply from the model on that one - please send it again."
    lines = ["Started: " + ", ".join(dict.fromkeys(steps)) if steps else "Started your request."]
    if tools:
        last = tools[0].splitlines()
        lines.append("Latest result: " + " ".join(last[:6])[:500])
    lines.append("It keeps running in the background - watch the Working status bottom-right.")
    return "\n".join(lines)


def run_turn(messages: list[dict], on_event: Callable[[dict], None] | None = None):
    import time as _time
    _last_user = next((m.get("content") or "" for m in reversed(messages) if m.get("role") == "user"), "")
    _TURN.update({
        "busy": True, "since": _time.time(), "status": "Starting.",
        "orig": _last_user, "done_steps": [],
    })
    try:
        import chat_store as _cs
        import session_hygiene as _SH
        _cs.inject_summary(messages, sid=str(_SH._LIVE.get("sid") or ""))
        try:
            _SH.inject_recall(messages, sid=str(_SH._LIVE.get("sid") or ""), user_text=_last_user)
        except Exception:
            pass
    except Exception:
        pass

    def emit(ev: dict) -> None:
        if not ev:
            return
        t = ev.get("type")
        if t == "status":
            _TURN["status"] = str(ev.get("text") or "")
        elif t == "tool":
            _TURN["status"] = "Running " + str(ev.get("name") or "tool")
        elif t == "tool_result":
            _TURN.setdefault("done_steps", []).append(str(ev.get("name") or ""))
        if on_event:
            on_event(ev)

    try:
        messages, answer = _run_turn_impl(messages, on_event=emit)
        if not (answer or "").strip():
            answer = _synth_status(messages)
            messages.append({"role": "assistant", "content": answer})
        try:
            import chat_store as _cs
            cleaned = _cs.sanitize_user_answer(answer, messages)
            if (cleaned or "") != (answer or ""):
                answer = cleaned
                if messages and messages[-1].get("role") == "assistant":
                    messages[-1]["content"] = answer
                else:
                    messages.append({"role": "assistant", "content": answer})
        except Exception:
            pass
        return messages, answer
    finally:
        _TURN.update({"busy": False, "status": ""})
