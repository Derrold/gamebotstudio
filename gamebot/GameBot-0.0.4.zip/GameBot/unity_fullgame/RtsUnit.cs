using UnityEngine;
/// <summary>Team combatant for strategy + MOBA: soldiers, minions, heroes, towers, keeps/cores. Auto-acquires enemies, moves, attacks, shows a health bar.</summary>
public class RtsUnit : MonoBehaviour, IGbDamage
{
    public int team, hp = 60, maxHp = 60, dmg = 8; public float range = 2.2f, speed = 3.5f, cd = 0.9f, aggro = 9f; public string kind = "soldier";
    public bool selected; public Vector3? moveTo; public bool attackMove; public Vector3 lanePush; public bool hasLane;
    IGbDamage target; float next; LineRenderer shot; float shotOff; GameObject ring; bool dead;
    public int Team => team; public bool Dead => dead || this == null; public Transform Tr => this ? transform : null;
    public bool Structure => kind == "tower" || kind == "core" || kind == "keep" || kind == "hq";
    void OnEnable() { GbCombat.All.Add(this); }
    void OnDisable() { GbCombat.All.Remove(this); }
    void Start()
    {
        shot = new GameObject("Shot").AddComponent<LineRenderer>(); shot.transform.SetParent(transform, false); shot.positionCount = 2; shot.startWidth = 0.08f; shot.endWidth = 0.03f;
        shot.material = new Material(Shader.Find("Sprites/Default")); var c = team == 0 ? new Color(0.3f, 0.7f, 1f) : new Color(1f, 0.3f, 0.2f); shot.startColor = c; shot.endColor = c; shot.enabled = false;
        if (!Structure) { ring = GameObject.CreatePrimitive(PrimitiveType.Cylinder); ring.name = "SelectRing"; Destroy(ring.GetComponent<Collider>()); ring.transform.SetParent(transform, false); ring.transform.localPosition = new Vector3(0, 0.05f, 0); ring.transform.localScale = new Vector3(1.6f, 0.02f, 1.6f); ring.GetComponent<Renderer>().material.color = new Color(0.2f, 1f, 0.3f); ring.SetActive(false); }
    }
    public void Damage(int amount, int fromTeam)
    {
        if (dead || fromTeam == team) return; hp -= amount;
        if (hp > 0) return; dead = true;
        if (team == 1 && fromTeam == 0) { GenreState.Kills++; GenreState.Quartz += 15; if (GenreState.IsMoba) GenreState.AddXp(kind == "tower" ? 120 : 30); }
        if (kind == "tower" && team == 1) { GenreState.TowersDown++; AchievementSystem.Unlock("tower_down"); GameHUD.Flash("Enemy tower destroyed!"); }
        if (kind == "tower" && team == 0) GameHUD.Flash("We lost a tower!");
        if ((kind == "core" || kind == "keep") && team == 1) { AchievementSystem.Unlock(GenreState.IsMoba ? "core_down" : "keep_down"); GenreState.Win(); }
        if ((kind == "core" || kind == "hq") && team == 0) GenreState.Lose(GenreState.IsMoba ? "Your core was destroyed" : "Your HQ fell");
        if (kind == "hero") { var h = GetComponent<MobaHero>(); if (h) { h.Died(); dead = false; hp = maxHp; return; } }
        Destroy(gameObject);
    }
    bool Protected() { if (!GenreState.IsMoba) return false; if (kind == "core" && team == 1) return GenreState.TowersDown < GenreState.EnemyTowers; return false; }
    void Update()
    {
        if (GameState.Won || GameState.Lost || PauseMenu.IsPaused || MainMenuUI.InMenu || dead) return;
        if (ring) ring.SetActive(selected);
        if (Time.time > shotOff) shot.enabled = false;
        if (kind == "hero" && GetComponent<MobaHero>() && GetComponent<MobaHero>().respawnAt > 0) return;
        if (target != null && (target.Dead || target.Tr == null || Vector3.Distance(target.Tr.position, transform.position) > aggro * 1.6f)) target = null;
        if (target == null && (moveTo == null || attackMove)) target = GbCombat.Nearest(transform.position, Structure ? range : aggro, u => u.Team != team && u.Team >= 0 && !(u is RtsUnit ru && ru.Protected()));
        if (target != null)
        {
            Vector3 to = target.Tr.position - transform.position; to.y = 0;
            if (to.magnitude > range + (target is RtsUnit tu && tu.Structure ? 1.8f : 0f)) { if (!Structure) Step(target.Tr.position); }
            else
            {
                if (!Structure && to.sqrMagnitude > 0.01f) transform.rotation = Quaternion.LookRotation(to);
                if (Time.time >= next) { next = Time.time + cd; target.Damage(dmg, team); shot.SetPosition(0, transform.position + Vector3.up * (Structure ? 4f : 1f)); shot.SetPosition(1, target.Tr.position + Vector3.up); shot.enabled = true; shotOff = Time.time + 0.08f; }
            }
            return;
        }
        if (moveTo.HasValue) { if (Step(moveTo.Value)) moveTo = null; return; }
        if (hasLane && !Structure) Step(lanePush);
    }
    bool Step(Vector3 p)
    {
        Vector3 to = p - transform.position; to.y = 0; if (to.magnitude < 0.6f) return true;
        Vector3 sep = Vector3.zero; foreach (var u in GbCombat.All) { if (u == null || u.Tr == null || (object)u == this) continue; var d = transform.position - u.Tr.position; d.y = 0; if (d.magnitude < 1.1f && d.magnitude > 0.01f) sep += d.normalized * (1.1f - d.magnitude); }
        var dir = (to.normalized + sep * 1.5f); dir.y = 0;
        transform.position += dir.normalized * speed * Time.deltaTime; if (to.sqrMagnitude > 0.01f) transform.rotation = Quaternion.Slerp(transform.rotation, Quaternion.LookRotation(to), Time.deltaTime * 8f); return false;
    }
    void OnGUI()
    {
        if (MainMenuUI.InMenu || dead) return; var cam = Camera.main; if (!cam) return;
        var sp = cam.WorldToScreenPoint(transform.position + Vector3.up * (Structure ? 6f : 2.4f)); if (sp.z < 0) return;
        float w = Structure ? 80 : 40, h = 6; var r = new Rect(sp.x - w / 2, Screen.height - sp.y, w, h);
        GUI.color = Color.black; GUI.DrawTexture(r, Texture2D.whiteTexture); GUI.color = team == 0 ? new Color(0.2f, 0.8f, 1f) : new Color(1f, 0.25f, 0.2f);
        GUI.DrawTexture(new Rect(r.x + 1, r.y + 1, (w - 2) * Mathf.Clamp01((float)hp / maxHp), h - 2), Texture2D.whiteTexture); GUI.color = Color.white;
    }
}
