"""Game Bot desktop window â€” native frame, no console."""
from __future__ import annotations

import os
import subprocess
import sys
import time
import urllib.request
from pathlib import Path

ROOT = Path(__file__).resolve().parent
URL = "http://127.0.0.1:7870/"
HEALTH = "http://127.0.0.1:7870/api/health"
LOG = ROOT / "desktop_window.log"
os.chdir(ROOT)
try:
    from editions import load_edition
    load_edition()
except Exception:
    pass
os.environ.setdefault("OLLAMA_MODEL", "gamebot-trained")
os.environ.setdefault("QWEN_HEADLESS", "1")


def _log(msg: str) -> None:
    try:
        with LOG.open("a", encoding="utf-8") as f:
            f.write(msg + "\n")
    except Exception:
        pass


def _pythonw() -> str:
    cand = Path(sys.executable).with_name("pythonw.exe")
    return str(cand if cand.exists() else sys.executable)


def healthy() -> bool:
    try:
        with urllib.request.urlopen(HEALTH, timeout=2) as r:
            return r.status == 200
    except Exception:
        return False


def start_server():
    if healthy():
        return None
    flags = getattr(subprocess, "CREATE_NO_WINDOW", 0)
    return subprocess.Popen(
        [_pythonw(), str(ROOT / "app.py")],
        cwd=str(ROOT),
        creationflags=flags,
        stdout=open(ROOT / "app_child.out.log", "ab", buffering=0),
        stderr=open(ROOT / "app_child.err.log", "ab", buffering=0),
        stdin=subprocess.DEVNULL,
    )


def wait_ready(timeout: float = 45.0) -> bool:
    t0 = time.time()
    while time.time() - t0 < timeout:
        if healthy():
            return True
        time.sleep(0.4)
    return False


def main() -> int:
    LOG.write_text("launch\n", encoding="utf-8")
    import license_bind
    license_bind.enforce(gui=True)
    try:
        from ollama_ensure import ensure_ollama
        ok, reason = ensure_ollama(timeout=30)
        if not ok:
            _log("ollama failed: " + reason)
    except Exception as e:
        _log("ollama ensure: " + repr(e))
    proc = start_server()
    if not wait_ready():
        _log("server failed")
        return 1
    import webview

    webview.create_window(
        os.environ.get("GAMEBOT_TITLE", "Game Bot"),
        URL,
        width=1280,
        height=800,
        min_size=(900, 600),
        confirm_close=False,
    )
    _log("window up")
    webview.start()
    if proc is not None and proc.poll() is None:
        proc.terminate()
        try:
            proc.wait(timeout=5)
        except Exception:
            proc.kill()
    return 0


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except Exception as e:
        _log(repr(e))
        raise