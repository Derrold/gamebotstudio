# Auto studio pipeline run (QaRpgFive)

Tags: auto studio pipeline
Saved: 2026-11-17T06:40:06

run_auto_game_pipeline created 34 files under C:\Users\Derrold PC\Documents\GameProjects\QaRpgFive and UNITY 6000.6.5f1: background job started -> create QaRpgFiveUnity -> RPG game (gameplay template: rpg; menu, settings, achievements, owned genre kit) -> Builds\. Next: check Builds\auto_unity_status.txt, then work TaskBoard 'Auto next actions' with tools.
