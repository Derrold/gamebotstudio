using UnityEngine;
/// <summary>Horror threat: wanders, hunts the player when near (faster in the dark), catching = death.</summary>
public class Stalker : MonoBehaviour
{
    public float speed = 2.6f, sense = 14f;
    Transform p; Vector3 wander; float nextWander;
    void Start() { var g = GameObject.FindGameObjectWithTag("Player"); if (g) p = g.transform; wander = transform.position; }
    void Update()
    {
        if (!p || GameState.Won || GameState.Lost || PauseMenu.IsPaused || MainMenuUI.InMenu) return;
        Vector3 to = p.position - transform.position; to.y = 0; float d = to.magnitude;
        GenreState.Fear = Mathf.Clamp01(1f - d / sense);
        float s = speed * (FlashlightController.On ? 0.7f : 1.3f);
        if (d < sense) { transform.rotation = Quaternion.LookRotation(to); transform.position += to.normalized * s * Time.deltaTime; }
        else { if (Time.time > nextWander) { wander = transform.position + new Vector3(Random.Range(-8f, 8f), 0, Random.Range(-8f, 8f)); nextWander = Time.time + 4f; } transform.position = Vector3.MoveTowards(transform.position, wander, speed * 0.5f * Time.deltaTime); }
        if (d < 1.2f) { var gp = p.GetComponent<GamePlayer>(); if (gp) gp.Respawn(); transform.position += -to.normalized * 12f; }
    }
}
