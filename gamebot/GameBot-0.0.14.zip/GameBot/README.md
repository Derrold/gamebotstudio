# Game Bot

> **NVIDIA RTX 20 series or newer, or AMD RX 6000 series or newer, with at least 8 GB VRAM; 12 GB recommended.**


Local automatic game studio. You talk; it builds with tools (Unity / Blender / files). No cloud LLM required once Ollama is set up.

## Requirements
- Windows 10/11
- [Ollama](https://ollama.com) with a fast chat model (default tag: `qwen-fast`)
- Unity Hub + Editor (default path in `config/gamebot.config.json`)
- Blender (optional but recommended for assets)
- Python 3.12+ (for the UI server)

## First-time setup
1. Edit `config/gamebot.config.json` — set `projects_root`, `unity_editor`, `blender`.
2. Pull your model: `ollama pull qwen-fast` (or change `OLLAMA_MODEL`).
3. Start: double-click **Game Bot** on the Desktop, or run `start-game-bot.ps1`.
4. Open http://127.0.0.1:7870/

## First prompt
Say something like: `Make a game called SkyRunner — 3D endless runner, Unity.`

Game Bot should scaffold under `projects_root` and keep acting (design docs, Unity create, greybox, etc.). It will research errors itself.

## Human gates (you must do these)
- Steam / Epic tax & bank
- Real store AppIDs / product IDs (never invent them)
- Age ratings
- Final store **Release** click
- Large engine installs if not already present

## Safety
- Stays inside `projects_root`
- Does not invent AppIDs
- Does not wipe save games in patches
- Personal / third-party project integrators are **not** included in this product build

## Playbooks
See `playbooks/complete-game-builder-index.md` for the full studio checklist (Steam, Epic, mobile, Deck, trailers, legal menus, FPS passes, etc.).

## Support files
- `start-game-bot.ps1` — launches the UI
- `config/gamebot.config.json` — paths and empty store ID placeholders
- `playbooks/` — skills the bot reads while working

## GPU and AI model (automatic)
Game Bot picks the right AI model for your PC automatically from your GPU's video memory - there is nothing to choose. NVIDIA RTX 20 series or newer, or AMD RX 6000 series or newer, with at least 8 GB VRAM; 12 GB recommended. Cards with 12 GB or more automatically get a larger model. If the expected model isn't installed, Game Bot falls back to an installed one instead of erroring. Install the model once from Setup ("Download the recommended AI model for this PC") or Start menu > Game Bot > Set up AI model. One desktop shortcut: Game Bot.
