﻿from PIL import Image
from pathlib import Path
jpg = Path(r"C:\Users\ExtremeHybrid\ollama-web\icons\qwen-bot-devil.jpg")
png = Path(r"C:\Users\ExtremeHybrid\ollama-web\icons\qwen-bot-devil.png")
ico = Path(r"C:\Users\ExtremeHybrid\ollama-web\icons\qwen-bot-devil.ico")
im = Image.open(jpg).convert("RGBA")
w, h = im.size
side = min(w, h)
left = (w - side) // 2
top = (h - side) // 2
im = im.crop((left, top, left + side, top + side))
im.save(png)
sizes = [(16,16),(32,32),(48,48),(64,64),(128,128),(256,256)]
imgs = [im.resize(s, Image.Resampling.LANCZOS) for s in sizes]
imgs[-1].save(ico, format="ICO", sizes=[(s.width, s.height) for s in imgs])
print("ICO", ico, ico.stat().st_size)
