# Auto studio pipeline run (DarkWard)

Tags: auto studio pipeline
Saved: 2026-11-05T10:39:09

run_auto_game_pipeline created 32 files under C:\Users\ExtremeHybrid\Documents\GameProjects\DarkWard and UNITY 6000.6.5f1: background job started -> create DarkWardUnity -> horror game (menu, settings, achievements, owned assets) -> Builds\Windows\DarkWard.exe. Sta. Next: check Builds\auto_unity_status.txt, then work TaskBoard 'Auto next actions' with tools.
