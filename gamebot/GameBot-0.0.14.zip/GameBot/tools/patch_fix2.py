"""Fix2 (2026-11-13): shared known-bad import list + 180 s same-file import hang check; full-message status words."""
import sys, shutil, re
from pathlib import Path

TAG = ".bak_fix2_20261113"

def rd(p):
    with open(p, encoding="utf-8-sig", newline="") as fh:
        b = fh.read()
    nl = "\r\n" if "\r\n" in b else "\n"
    return b.replace("\r\n", "\n"), nl, p.read_bytes()[:3] == b"\xef\xbb\xbf"

def wr(p, t, nl, bom):
    if not Path(str(p) + TAG).exists():
        shutil.copy2(p, str(p) + TAG)
    data = t.replace("\n", nl)
    with open(p, "w", encoding="utf-8-sig" if bom else "utf-8", newline="") as fh:
        fh.write(data)

def sub1(t, old, new, name):
    if new in t:
        return t
    n = t.count(old)
    if n != 1:
        raise SystemExit(f"{name}: expected 1 match, found {n}: {old[:70]!r}")
    return t.replace(old, new)

def main(d):
    d = Path(d)
    # ---- agent_core.wants_status: whole-message status words (incl. typos 'eat'/'etta' and a bare '?')
    p = d / "agent_core.py"; t, nl, bom = rd(p)
    old = '''def wants_status(text: str) -> bool:
    return bool(re.match(r"^\\s*(eta|status|progress|update|how long|still working|working|done yet|are you (done|there|working)|stuck)\\b", (text or ""), re.I))
'''
    new = '''_STATUS_RE = re.compile(
    r"\\s*(?:(?:hey|so|ok|okay|and)[\\s,]+)?"
    r"(?:eta|eat|etta|eda|ets|status|stat|stats|progress|update|updates|any update|any updates|any status|"
    r"how long|how long left|how much longer|still working|you still working|working|done yet|are you done|"
    r"you done|are you there|are you working|are you still working|stuck|are you stuck|you stuck|"
    r"where are we|where are we at|what'?s the status|whats the eta|what'?s the eta|status update)"
    r"(?:[\\s,]+(?:please|pls|plz|now|bro|man|buddy|on (?:it|that|the build)))*\\s*[?.!]*\\s*"
    r"|\\s*\\?+\\s*", re.I)


def wants_status(text: str) -> bool:
    """True only when the WHOLE message is a status ask ("eta", "eat" typo, "status?", "?", "how long")."""
    return bool(_STATUS_RE.fullmatch(text or ""))
'''
    t = sub1(t, old, new, "agent_core.wants_status")
    wr(p, t, nl, bom)

    # ---- intake: status words never reach the intake/asset flow (no tools, no pack questions)
    p = d / "intake.py"; t, nl, bom = rd(p)
    old = '''    t = (text or "").strip()
    if not t or t.startswith("SYSTEM NOTE"):
        return None
    st = _active(messages)
'''
    new = '''    t = (text or "").strip()
    if not t or t.startswith("SYSTEM NOTE"):
        return None
    try:  # "eta" / "eat" / "status?" / "?" are status-only: answer progress, never treat as an asset/pack reply
        from agent_core import wants_status as _ws
        if _ws(t):
            try:
                from agent_core import progress_report as _pr
                return _pr()
            except Exception:
                return "Nothing new to report yet - the current step is still running."
    except Exception:
        pass
    st = _active(messages)
'''
    t = sub1(t, old, new, "intake._step_impl guard")
    old = r'''        if st.get("awaiting_pack") or re.match(r"^\s*\d{1,3}\s*$", t) or re.search(r"\b(import|use|pick)\b|assets?\s+from\s+unity|my assets|asset store", tl):
'''
    new = r'''        if not re.match(r"^\s*(free|cc0|kenney|fallback|you pick|any|skip|none|no)\b", tl) and (
                st.get("awaiting_pack") or re.match(r"^\s*\d{1,3}\s*$", t) or re.search(r"\b(import|use|pick)\b|assets?\s+from\s+unity|my assets|asset store", tl)):
'''
    t = sub1(t, old, new, "intake awaiting_pack branch")
    wr(p, t, nl, bom)

    # ---- owned_assets: strict pack matching (number, exact/contained name, or whole-word tokens)
    p = d / "owned_assets.py"; t, nl, bom = rd(p)
    old = '''    ql = q.lower()
    for p in ordered:
        name = (p.get("name") or "").lower()
        if ql == name or ql in name or name in ql:
            return p
    # publisher - name pattern
    for p in ordered:
        blob = f"{p.get('publisher','')} {p.get('name','')}".lower()
        if ql in blob:
            return p
    return None
'''
    new = '''    ql = q.lower().strip(" .!?\\"'")
    toks = _pack_tokens(ql)
    if not toks:
        return None
    for p in ordered:
        name = (p.get("name") or "").lower()
        if name and (ql == name or (len(name) >= 6 and name in ql)):
            return p
    # every meaningful word must start a whole word in the pack name ("cliff", "nature ess") - never a substring like "eat"
    for p in ordered:
        name = (p.get("name") or "").lower()
        if all(re.search(r"(?<![a-z0-9])" + re.escape(w), name) for w in toks):
            return p
    for p in ordered:
        blob = f"{p.get('publisher','')} {p.get('name','')}".lower()
        if all(re.search(r"(?<![a-z0-9])" + re.escape(w), blob) for w in toks):
            return p
    return None


_PACK_STOP = {"the", "a", "an", "and", "of", "for", "pack", "packs", "asset", "assets", "please", "pls", "one", "that",
              "it", "my", "owned", "some", "free", "eta", "eat", "status", "progress", "update", "stuck", "working"}


def _pack_tokens(q: str) -> list:
    """Meaningful words of a pack query (>=3 letters, not filler/status words)."""
    return [w for w in re.findall(r"[a-z0-9]+", (q or "").lower()) if len(w) >= 3 and w not in _PACK_STOP]
'''
    t = sub1(t, old, new, "owned_assets.resolve_pack")
    old = '''    if not q:
        return ASK_WHICH_PACK
    hit = resolve_pack(q, engine=engine, genre=genre, extra=extra)
'''
    new = '''    if not q:
        return ASK_WHICH_PACK
    try:
        from agent_core import wants_status as _ws
        if _ws(q):
            return ASK_WHICH_PACK  # a status word is never a pack pick
    except Exception:
        pass
    if not q.isdigit() and not _pack_tokens(q):
        return ASK_WHICH_PACK
    hit = resolve_pack(q, engine=engine, genre=genre, extra=extra)
'''
    t = sub1(t, old, new, "owned_assets.import_owned_asset")
    wr(p, t, nl, bom)

    # ---- gb_kits: shared known-bad import list (shipped + learned by the watchdog) applies to EVERY project
    p = d / "gb_kits.py"; t, nl, bom = rd(p)
    old = '''    except Exception:
        skip = set()
    for guid, k in mem.items():
'''
    new = '''    except Exception:
        skip = set()
    shared = known_bad_imports()
    for guid, k in mem.items():
'''
    t = sub1(t, old, new, "gb_kits skip load")
    old = '''        if rel.lower() in skip:
            continue
'''
    new = '''        if rel.lower() in skip or rel.lower()[len("assets/"):] in shared:
            continue
'''
    t = sub1(t, old, new, "gb_kits skip check")
    anchor = "\ndef "
    i = t.find(anchor)
    helper = '''

def known_bad_imports() -> set:
    """Pack files known to hang Unity's importer (paths without 'Assets/', lower case).
    Shipped list: config/known_bad_imports.txt. Learned list: %LOCALAPPDATA%/GameBot/known_bad_imports.txt (build watchdog)."""
    import os
    out = set()
    for f in (Path(__file__).resolve().parent / "config" / "known_bad_imports.txt",
              Path(os.environ.get("LOCALAPPDATA", str(Path.home()))) / "GameBot" / "known_bad_imports.txt"):
        try:
            if f.is_file():
                for line in f.read_text(encoding="utf-8", errors="replace").splitlines():
                    s = line.strip().replace("\\\\", "/").lower()
                    if s and not s.startswith("#"):
                        out.add(s[len("assets/"):] if s.startswith("assets/") else s)
        except Exception:
            pass
    return out
'''
    if "def known_bad_imports" not in t:
        t = t[:i] + helper + t[i:]
    wr(p, t, nl, bom)
    kb = d / "config" / "known_bad_imports.txt"
    kb.parent.mkdir(exist_ok=True)
    if not kb.exists():
        kb.write_text("# Pack files that hang Unity's importer. Game Bot never copies these into a project.\n"
                      "# One path per line, relative to Assets/. The build watchdog adds new ones to\n"
                      "# %LOCALAPPDATA%\\GameBot\\known_bad_imports.txt automatically.\n"
                      "Cliff Mansion/Model/Bed/bed.fbx\n", encoding="utf-8")

    # ---- auto_studio watchdog: same 'Importing' file for > 180 s = hung; learned files go to the shared list
    p = d / "auto_studio.py"; t, nl, bom = rd(p)
    old = '''  $null = $p.Handle; $last = -1; $still = 0; $hung = $false
  while (-not $p.HasExited) {
    Start-Sleep 15
    $len = if (Test-Path $blog) { (Get-Item $blog).Length } else { 0 }
    if ($len -eq $last) { $still += 15 } else { $still = 0; $last = $len }
    if ($still -ge 360) { $hung = $true; break }
  }
'''
    new = '''  $null = $p.Handle; $last = -1; $still = 0; $hung = $false; $impKey = ""; $impStill = 0
  while (-not $p.HasExited) {
    Start-Sleep 15
    $len = if (Test-Path $blog) { (Get-Item $blog).Length } else { 0 }
    if ($len -eq $last) { $still += 15 } else { $still = 0; $last = $len }
    # the same 'Importing' file with no 'Imported' after it for > 180 s = hung import (the log can keep growing meanwhile)
    $cur = ""
    $tl = Get-Content -LiteralPath $blog -Tail 400 -ErrorAction SilentlyContinue | Where-Object { $_ -match "^(Importing|Imported) 'GUID" } | Select-Object -Last 1
    if ($tl -and $tl -match "^Importing 'GUID: \\w+ - Path: (.+?)' with importer") { $cur = $Matches[1] }
    if ($cur -and $cur -eq $impKey) { $impStill += 15 } else { $impStill = 0; $impKey = $cur }
    if ($still -ge 360 -or $impStill -ge 180) { $hung = $true; break }
  }
'''
    t = sub1(t, old, new, "auto_studio watchdog loop")
    old = '''    Add-Content -Path (Join-Path $root "Tools\\skip_imports.txt") -Value $rel
'''
    new = '''    Add-Content -Path (Join-Path $root "Tools\\skip_imports.txt") -Value $rel
    try { $kbd = Join-Path $env:LOCALAPPDATA "GameBot"; New-Item -ItemType Directory -Force $kbd | Out-Null; Add-Content -Path (Join-Path $kbd "known_bad_imports.txt") -Value ($rel -replace '^Assets/', '') } catch {}
'''
    t = sub1(t, old, new, "auto_studio shared list append")
    wr(p, t, nl, bom)
    print("patched", d)

if __name__ == "__main__":
    for d in sys.argv[1:]:
        main(d)
