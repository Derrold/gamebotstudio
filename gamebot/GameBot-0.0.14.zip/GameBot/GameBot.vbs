' Game Bot launcher (no console). Live model = gamebot-trained.
' Prefer GameBot.exe so the taskbar uses the branded icon + AppUserModelID.
Set sh = CreateObject("WScript.Shell")
Set fso = CreateObject("Scripting.FileSystemObject")
d = fso.GetParentFolderName(WScript.ScriptFullName)
sh.CurrentDirectory = d
sh.Environment("PROCESS")("OLLAMA_MODEL") = "gamebot-trained"
exe = d & "\GameBot.exe"
If fso.FileExists(exe) Then
  sh.Run """" & exe & """", 0, False
  WScript.Quit 0
End If
On Error Resume Next
sh.Run "pyw -3 """ & d & "\desktop_window.py""", 0, False
If Err.Number <> 0 Then
  Err.Clear
  sh.Run "pythonw """ & d & "\desktop_window.py""", 0, False
End If
If Err.Number <> 0 Then MsgBox "Game Bot needs Python 3.11+ (python.org) on PATH. See PREREQUISITES.txt.", 16, "Game Bot"
