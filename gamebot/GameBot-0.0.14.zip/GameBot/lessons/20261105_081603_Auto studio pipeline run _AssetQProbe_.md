# Auto studio pipeline run (AssetQProbe)

Tags: auto studio pipeline
Saved: 2026-11-05T08:16:03

run_auto_game_pipeline created 32 files under C:\Users\ExtremeHybrid\Documents\GameProjects\AssetQProbe and UNITY 6000.6.5f1: background job started -> create AssetQProbeUnity -> Assets/Scenes/Slice01.unity (grey-box, player, goal, HUD) -> Builds\Windows\AssetQProbe.e. Next: check Builds\auto_unity_status.txt, then work TaskBoard 'Auto next actions' with tools.
