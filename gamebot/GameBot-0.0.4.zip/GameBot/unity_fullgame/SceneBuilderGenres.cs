using System.Collections.Generic;
using UnityEditor;
using UnityEditor.SceneManagement;
using UnityEngine;

// Game Bot B-fix: dedicated gameplay families (action, fighting, strategy, moba, sports, sandbox, stealth, battle_royale, mmorpg)
// + shared owned-pack dressing helpers (character, nature, props). Lives in Assets/Editor next to SceneBuilder.cs.
public static partial class SceneBuilder
{
    // ---------------- exact genre routing (no substring collisions: mmorpg != rpg, battle_royale != fps, stealth != horror, sandbox != survival)
    static readonly Dictionary<string, string> ExactFamily = new Dictionary<string, string> {
        {"action","action"},{"adventure","adventure"},{"rpg","rpg"},{"shooter","fps"},{"fps","fps"},{"strategy","strategy"},{"simulation","sim"},{"sim","sim"},
        {"sports","sports"},{"racing","racing"},{"fighting","fighting"},{"horror","horror"},{"platformer","platformer"},{"puzzle","puzzle"},{"open_world","adventure"},
        {"survival","survival"},{"sandbox","sandbox"},{"stealth","stealth"},{"battle_royale","battle_royale"},{"moba","moba"},{"mmorpg","mmorpg"},{"roguelike","roguelike"},
        {"action-adventure","adventure"},{"metroidvania","platformer"},{"farming","sim"} };
    static readonly string[][] FamilyPriority = {
        new[]{"battle_royale","battle royale","battle-royale","br "}, new[]{"mmorpg","mmo"}, new[]{"moba"}, new[]{"stealth","sneak","infiltrat"}, new[]{"sandbox","voxel","block build"},
        new[]{"fighting","fighter","brawler","beat 'em","martial"}, new[]{"strategy","rts","tactics","tower defense"}, new[]{"sports","soccer","football","basketball","hockey"},
        new[]{"roguelike","roguelite","rogue-like","rogue"}, new[]{"racing","race","driving","kart"}, new[]{"horror","scary"}, new[]{"shooter","fps","first person shooter"},
        new[]{"rpg","role playing","role-playing"}, new[]{"puzzle","sokoban"}, new[]{"survival","crafting"}, new[]{"simulation","tycoon","shop","management","sim"},
        new[]{"open_world","open world"}, new[]{"adventure"}, new[]{"platformer","platform"}, new[]{"action","hack and slash","hack-and-slash"} };
    static readonly string[] PriorityFamily = { "battle_royale", "mmorpg", "moba", "stealth", "sandbox", "fighting", "strategy", "sports", "roguelike", "racing", "horror", "fps", "rpg", "puzzle", "survival", "sim", "adventure", "adventure", "platformer", "action" };
    public static string FamilyFor(string g)
    {
        g = (g ?? "").Trim().ToLower().Replace(" ", "_");
        if (ExactFamily.TryGetValue(g, out var f)) return f;
        string t = g.Replace("_", " ");
        for (int i = 0; i < FamilyPriority.Length; i++) foreach (var k in FamilyPriority[i]) if (t.Contains(k.Replace("_", " ").Trim())) return PriorityFamily[i];
        return "platformer";
    }
    static bool BuildExtra(string g)
    {
        switch (g)
        {
            case "action": BuildAction(); return true;
            case "fighting": BuildFighting(); return true;
            case "strategy": BuildStrategy(); return true;
            case "moba": BuildMoba(); return true;
            case "sports": BuildSports(); return true;
            case "sandbox": BuildSandbox(); return true;
            case "stealth": BuildStealth(); return true;
            case "battle_royale": BuildBattleRoyale(); return true;
            case "mmorpg": BuildMmo(); return true;
        }
        return false;
    }

    // ---------------- owned-pack helpers
    static readonly string[] EnvWords = { "wall", "floor", "ceiling", "roof", "fort", "building", "house", "terrain", "tile", "fence", "door", "window", "stair", "pillar", "column", "frame", "plane", "ground", "rock", "tree", "bush", "grass", "road", "kit", "setup", "camera", "controller", "spawn", "icon", "ui", "canvas", "demo", "projector", "light" };
    static List<GameObject> CharPool()
    {
        var l = Owned(new[] { "player", "character", "monster", "stylized", "humanoid", "human", "man_", "woman", "soldier", "zombie", "knight", "villager" }, EnvWords);
        l.RemoveAll(x => { var p = AssetDatabase.GetAssetPath(x).ToLower(); return p.Contains("first person") || p.Contains("fps") || x.GetComponentsInChildren<Renderer>(true).Length == 0; });
        l.Sort((a, b) => Score(b).CompareTo(Score(a)));
        return l;
    }
    static int Score(GameObject g) { var p = AssetDatabase.GetAssetPath(g).ToLower(); int s = 0; if (p.Contains("stylized")) s += 4; if (p.EndsWith("player.prefab")) s += 3; if (p.EndsWith(".prefab")) s += 2; if (g.GetComponentInChildren<SkinnedMeshRenderer>(true)) s += 3; return s; }
    static void Tint(GameObject v, Color c, float k = 0.55f)
    {
        foreach (var r in v.GetComponentsInChildren<Renderer>(true)) { var ms = r.sharedMaterials; for (int i = 0; i < ms.Length; i++) if (ms[i]) { var m = new Material(ms[i]); var bc = m.HasProperty("_BaseColor") ? m.GetColor("_BaseColor") : m.HasProperty("_Color") ? m.color : Color.white; var nc = Color.Lerp(bc, c, k); if (m.HasProperty("_BaseColor")) m.SetColor("_BaseColor", nc); if (m.HasProperty("_Color")) m.SetColor("_Color", nc); ms[i] = m; } r.sharedMaterials = ms; }
    }
    /// <summary>Put an owned character model on a host (player/enemy/unit/NPC). Host keeps its collider; visual has none. Feet sit at host.position.y + footY.</summary>
    static GameObject Dressed(GameObject host, GameObject pf, float height, Color? tint, float footY = 0f)
    {
        if (host == null || pf == null) return null;
        var v = Spawn(pf, null, false); foreach (var a in v.GetComponentsInChildren<Animator>(true)) a.applyRootMotion = false;
        FitTo(v, host.transform.position + Vector3.up * (footY + height / 2f), new Vector3(height * 0.7f, height, height * 0.7f), true, host.transform.eulerAngles.y);
        v.name = "CharacterVisual"; v.transform.SetParent(host.transform, true);
        foreach (var t in v.GetComponentsInChildren<Transform>(true)) t.gameObject.tag = "Untagged"; // pack prefabs (e.g. Stylized Player.prefab) ship tagged Player
        foreach (var r in host.GetComponents<Renderer>()) r.enabled = false;
        foreach (Transform c in host.transform) if (c != v.transform && c.GetComponent<Renderer>() && c.name != "SelectRing") c.GetComponent<Renderer>().enabled = false;
        if (tint.HasValue) Tint(v, tint.Value);
        _dressCount++; _dressUsed.Add(AssetDatabase.GetAssetPath(pf));
        return v;
    }
    static int _dressCount; static HashSet<string> _dressUsed = new HashSet<string>();
    static GameObject Ch(int i = 0) { var l = CharPool(); return l.Count == 0 ? null : l[i % l.Count]; }
    /// <summary>Player character model (replaces the old TryAttachImportedVisual that attached the FIRST model in Assets - often a wall/fort piece that then followed the player).</summary>
    static void AttachCharacter(GameObject player, bool visible = true)
    {
        var pf = Ch(); if (pf == null) { Debug.Log("CHAR_VISUAL none (no owned character pack)"); return; }
        var cc = player.GetComponent<CharacterController>(); float foot = cc ? cc.center.y - cc.height / 2f : -1f;
        var v = Dressed(player, pf, 1.8f, null, foot); if (v == null) return;
        if (!visible) foreach (var r in v.GetComponentsInChildren<Renderer>(true)) r.shadowCastingMode = UnityEngine.Rendering.ShadowCastingMode.ShadowsOnly;
        Debug.Log("CHAR_VISUAL " + AssetDatabase.GetAssetPath(pf));
    }
    static void ThirdPerson(GameObject player, float back = 5f, float up = 2.6f)
    {
        var cam = player.GetComponentInChildren<Camera>(); if (!cam) return;
        cam.transform.localPosition = new Vector3(0, up, -back); cam.transform.localRotation = Quaternion.Euler(12, 0, 0);
    }
    static void HoldItem(GameObject player, string[] keys, float len)
    {
        var vis = player.transform.Find("CharacterVisual"); if (!vis) return;
        var pool = new List<GameObject>(); foreach (var pf in OwnedAll()) { var f = System.IO.Path.GetFileNameWithoutExtension(AssetDatabase.GetAssetPath(pf)).ToLower(); foreach (var k in keys) if (f.Contains(k)) { pool.Add(pf); break; } }
        if (pool.Count == 0) return;
        var w = Spawn(pool[0], null, false); FitTo(w, Vector3.zero, new Vector3(0.15f, 0.15f, len), true);
        var holder = new GameObject("Weapon"); holder.transform.SetParent(vis, false); holder.transform.position = player.transform.position + player.transform.right * 0.45f + Vector3.up * 0.1f; holder.transform.rotation = player.transform.rotation;
        w.transform.SetParent(holder.transform, true); w.transform.localPosition = new Vector3(0, 0, len * 0.45f); w.transform.localRotation = Quaternion.identity;
        _dressUsed.Add(AssetDatabase.GetAssetPath(pool[0])); Debug.Log("HELD_ITEM " + AssetDatabase.GetAssetPath(pool[0]));
    }
    static List<GameObject> Trees() { var t = Owned(new[] { "tree", "pine", "conifer", "oak", "birch" }, new[] { "terrain", "leaf", "leaves", "billboard", "lod", "branch", "impostor", "stump", "projector", "grass" }); return t; }
    static List<GameObject> Bushes() => Owned(new[] { "bush", "fern", "plant", "shrub", "flower" }, new[] { "terrain", "lod", "billboard", "pot", "projector" });
    static List<GameObject> Rocks() => Owned(new[] { "rock", "stone", "boulder" }, new[] { "terrain", "lod", "texture", "wall", "floor" });
    static List<GameObject> Props(params string[] keys) => Owned(keys, new[] { "demo", "example", "canvas", "projector", "camera", "setup", "scene" });
    static int Place(List<GameObject> pool, Vector3 p, float h, Transform root, bool col, float yaw, System.Random rnd = null)
    {
        if (pool.Count == 0) return 0; var pf = pool[rnd == null ? Mathf.Abs((int)(p.x * 7 + p.z * 13)) % pool.Count : rnd.Next(pool.Count)];
        var go = Spawn(pf, root, col); FitTo(go, p + Vector3.up * h / 2f, new Vector3(h * 3f, h, h * 3f), true, yaw);
        if (col && go.GetComponentInChildren<Collider>() == null) { var bb = Bounds(go); var bc = go.AddComponent<BoxCollider>(); bc.center = go.transform.InverseTransformPoint(bb.center); var ls = go.transform.lossyScale; bc.size = new Vector3(bb.size.x / Mathf.Max(ls.x, 1e-3f) * 0.6f, bb.size.y / Mathf.Max(ls.y, 1e-3f), bb.size.z / Mathf.Max(ls.z, 1e-3f) * 0.6f); }
        _dressCount++; _dressUsed.Add(AssetDatabase.GetAssetPath(pf)); return 1;
    }
    /// <summary>Owned trees/bushes/rocks in a ring (or band) around a point. Keeps a clear radius r0.</summary>
    static int Nature(Vector3 c, float r0, float r1, int nt, int nb, int nr, Transform root, bool col = true, int seed = 3)
    {
        var rnd = new System.Random(seed); var t = Trees(); var b = Bushes(); var r = Rocks(); int n = 0;
        for (int i = 0; i < nt + nb + nr; i++)
        {
            float a = (float)rnd.NextDouble() * Mathf.PI * 2f, d = Mathf.Lerp(r0, r1, (float)rnd.NextDouble()); var p = c + new Vector3(Mathf.Cos(a) * d, 0, Mathf.Sin(a) * d);
            if (i < nt) n += Place(t, p, Mathf.Lerp(6f, 11f, (float)rnd.NextDouble()), root, col, rnd.Next(360), rnd);
            else if (i < nt + nb) n += Place(b, p, Mathf.Lerp(0.8f, 1.8f, (float)rnd.NextDouble()), root, false, rnd.Next(360), rnd);
            else n += Place(r, p, Mathf.Lerp(0.6f, 2.2f, (float)rnd.NextDouble()), root, col, rnd.Next(360), rnd);
        }
        return n;
    }
    static Material GroundMat(Color fallback) => OwnedMat(new[] { "grass", "ground", "dirt", "soil", "moss", "terrain" }, fallback, new[] { "normal", "rough", "car", "skybox", "water" });
    static void SkinGround(Color fallback)
    {
        var g = GameObject.Find("Ground"); if (!g) return; var s = g.transform.lossyScale;
        g.GetComponent<Renderer>().sharedMaterial = Tiled(GroundMat(fallback), s.x * 2f, s.z * 2f);
    }
    static Transform DressRoot() { var r = GameObject.Find("GenreDressing"); return r ? r.transform : new GameObject("GenreDressing").transform; }
    static GameObject Host(string name, Vector3 p, float radius = 0.4f, float height = 1.8f)
    {
        var h = new GameObject(name); h.transform.position = p; var col = h.AddComponent<CapsuleCollider>(); col.radius = radius; col.height = height; col.center = new Vector3(0, height / 2f, 0); return h;
    }
    static GameObject Building(string name, Vector3 p, Vector3 size, Color? tint, Transform root, float yaw = 0)
    {
        var box = Box(name, p + Vector3.up * size.y / 2f, size, new Color(0.55f, 0.5f, 0.45f), root); box.transform.rotation = Quaternion.Euler(0, yaw, 0);
        var pool = Owned(new[] { "building", "house", "cottage", "cabin", "hut" }, new[] { "interior", "light", "door", "window", "roof", "wall", "floor", "demo" });
        if (pool.Count == 0) return box;
        var v = Spawn(pool[Mathf.Abs(name.GetHashCode()) % pool.Count], root, true); FitTo(v, p + Vector3.up * size.y / 2f, size, true, yaw);
        if (tint.HasValue) Tint(v, tint.Value, 0.35f); box.GetComponent<Renderer>().enabled = false; _dressCount++; _dressUsed.Add(AssetDatabase.GetAssetPath(pool[Mathf.Abs(name.GetHashCode()) % pool.Count]));
        return box;
    }
    static void LogDress() { Debug.Log("GENRE_DRESS mode=" + _mode + " placed=" + _dressCount + " prefabs=" + string.Join(" | ", _dressUsed)); }
    static GameObject Unit(string name, Vector3 p, int team, string kind, int hp, int dmg, float range, float speed, float height, Color tint, int charIdx = 0)
    {
        var h = Host(name, p, 0.45f, height); var u = h.AddComponent<RtsUnit>(); u.team = team; u.kind = kind; u.hp = u.maxHp = hp; u.dmg = dmg; u.range = range; u.speed = speed;
        Dressed(h, Ch(charIdx), height, tint);
        if (h.transform.Find("CharacterVisual") == null) { var cap = GameObject.CreatePrimitive(PrimitiveType.Capsule); Object.DestroyImmediate(cap.GetComponent<Collider>()); cap.transform.SetParent(h.transform, false); cap.transform.localPosition = Vector3.up * height / 2f; cap.transform.localScale = new Vector3(0.8f, height / 2f, 0.8f); cap.GetComponent<Renderer>().sharedMaterial = Mat(tint); }
        return h;
    }
    static GameObject Structure(string name, Vector3 p, int team, string kind, int hp, int dmg, float range, Vector3 size, Color tint, Transform root)
    {
        var b = Building(name, p, size, tint, root); var col = b.GetComponent<BoxCollider>(); if (col == null) b.AddComponent<BoxCollider>();
        var u = b.AddComponent<RtsUnit>(); u.team = team; u.kind = kind; u.hp = u.maxHp = hp; u.dmg = dmg; u.range = range; u.speed = 0; u.cd = 1.1f; u.aggro = range;
        return b;
    }

    // ================= ACTION: melee arena, raider waves, warlord boss
    static void BuildAction()
    {
        var scene = Begin("action", new Color(0.36f, 0.42f, 0.26f), 12f); _dressCount = 0; _dressUsed.Clear(); SkinGround(new Color(0.36f, 0.42f, 0.26f)); var root = DressRoot();
        var camps = new[] { new Vector3(-28, 0, 12), new Vector3(26, 0, 22), new Vector3(0, 0, 44) }; int n = 0;
        var crates = Props("crate", "barrel", "box", "pallet", "barricade", "container");
        foreach (var c in camps)
        {
            for (int k = 0; k < 4; k++) { float a = k * 90 * Mathf.Deg2Rad; Place(crates, c + new Vector3(Mathf.Cos(a) * 6, 0, Mathf.Sin(a) * 6), 1.2f, root, true, k * 40); }
            var fire = new GameObject("CampFire").AddComponent<Light>(); fire.transform.position = c + Vector3.up; fire.color = new Color(1f, 0.55f, 0.2f); fire.range = 12; fire.intensity = 3;
            for (int k = 0; k < 4; k++) { var e = Host("Raider_" + n, c + new Vector3((k % 2) * 3 - 1.5f, 0, (k / 2) * 3 - 1.5f)); var et = e.AddComponent<EnemyTarget>(); et.hp = 3; et.speed = 3.2f; et.sight = 13f; et.dps = 9f; Dressed(e, Ch(n), 1.8f, new Color(0.75f, 0.15f, 0.1f)); n++; }
        }
        var boss = Host("Warlord", new Vector3(0, 0, 52), 0.8f, 3f); var bt = boss.AddComponent<EnemyTarget>(); bt.hp = 18; bt.speed = 2.4f; bt.sight = 16f; bt.dps = 22f; bt.isBoss = true; Dressed(boss, Ch(), 3.0f, new Color(0.25f, 0.05f, 0.05f), 0f);
        var bl = new GameObject("WarlordLight").AddComponent<Light>(); bl.transform.position = new Vector3(0, 4, 52); bl.color = Color.red; bl.range = 14; bl.intensity = 4;
        var player = MakeWalker(new Vector3(0, 1.1f, -30f)); ThirdPerson(player); AttachCharacter(player); HoldItem(player, new[] { "sword", "axe", "blade", "mace" }, 1.1f); player.AddComponent<MeleeAttack>();
        Nature(new Vector3(0, 0, 10), 48f, 62f, 40, 30, 16, root, true, 5); Nature(new Vector3(0, 0, 10), 8f, 40f, 6, 24, 6, root, false, 9);
        LogDress(); End(scene);
    }

    // ================= FIGHTING: 2.5D ring duel, best of 3
    static void BuildFighting()
    {
        var scene = Begin("fighting", new Color(0.25f, 0.25f, 0.28f), 5f); _dressCount = 0; _dressUsed.Clear(); var root = DressRoot();
        var ring = Box("Ring", new Vector3(0, 0.3f, 0), new Vector3(22, 0.6f, 6), new Color(0.6f, 0.15f, 0.12f)); ring.GetComponent<Renderer>().sharedMaterial = Tiled(OwnedMat(new[] { "wood", "plank", "concrete", "floor" }, new Color(0.6f, 0.15f, 0.12f), new[] { "car", "normal" }), 6, 2);
        for (int i = -1; i <= 1; i += 2) for (int k = -1; k <= 1; k += 2) Box("Post", new Vector3(i * 10.5f, 1.4f, k * 2.6f), new Vector3(0.3f, 2.2f, 0.3f), Color.white);
        var props = Props("bench", "bin", "barrel", "crate", "hydrant", "bollard", "barricade", "box", "lamp", "light");
        for (int i = 0; i < 14; i++) Place(props, new Vector3(-16 + i * 2.5f, 0, 6 + (i % 3)), 1.2f, root, false, 180 + i * 17);
        Nature(new Vector3(0, 0, 14), 4f, 12f, 8, 10, 4, root, false, 11);
        for (int i = 0; i < 6; i++) { var w = new GameObject("Spectator_" + i); w.transform.position = new Vector3(-12 + i * 4.8f, 0, 9); Dressed(w, Ch(i), 1.8f, Color.HSVToRGB(i / 6f, 0.4f, 0.8f)); w.transform.rotation = Quaternion.Euler(0, 180, 0); }
        var p1 = new GameObject("Player"); p1.tag = "Player"; p1.transform.position = new Vector3(-3, 0.6f, 0); var p2 = new GameObject("Rival"); p2.transform.position = new Vector3(3, 0.6f, 0);
        var v1 = Dressed(p1, Ch(), 1.8f, new Color(0.2f, 0.45f, 1f), 0f); var v2 = Dressed(p2, Ch(1), 1.85f, new Color(1f, 0.2f, 0.15f), 0f);
        var f1 = p1.AddComponent<Fighter>(); var f2 = p2.AddComponent<Fighter>(); f2.isAI = true; f1.other = f2; f2.other = f1; f1.visual = v1 ? v1.transform : null; f2.visual = v2 ? v2.transform : null;
        var cam = GameObject.Find("Main Camera"); if (cam) { cam.transform.position = new Vector3(0, 2.8f, -9); cam.AddComponent<FightCamera>(); }
        for (int i = -1; i <= 1; i += 2) { var l = new GameObject("RingLight").AddComponent<Light>(); l.type = LightType.Spot; l.transform.position = new Vector3(i * 5, 9, -3); l.transform.LookAt(Vector3.zero); l.range = 20; l.spotAngle = 60; l.intensity = 30; }
        LogDress(); End(scene);
    }

    // ================= STRATEGY: RTS-lite, capture points, train units, raid waves, destroy keep
    static void BuildStrategy()
    {
        var scene = Begin("strategy", new Color(0.45f, 0.42f, 0.32f), 14f); _dressCount = 0; _dressUsed.Clear(); SkinGround(new Color(0.45f, 0.42f, 0.32f)); var root = DressRoot();
        var blue = new Color(0.2f, 0.45f, 1f); var red = new Color(1f, 0.25f, 0.18f);
        var hq = Structure("HQ", new Vector3(0, 0, -48), 0, "hq", 900, 14, 9f, new Vector3(12, 9, 12), blue, root);
        var keep = Structure("EnemyKeep", new Vector3(0, 0, 52), 1, "keep", 900, 16, 9f, new Vector3(12, 10, 12), red, root);
        Structure("EnemyTower_W", new Vector3(-14, 0, 38), 1, "tower", 350, 14, 10f, new Vector3(4, 9, 4), red, root); Structure("EnemyTower_E", new Vector3(14, 0, 38), 1, "tower", 350, 14, 10f, new Vector3(4, 9, 4), red, root);
        var bar = Props("barricade", "bollard", "barrel", "crate", "fence", "pallet");
        Vector3[] pts = { new Vector3(-32, 0, 0), new Vector3(0, 0, 6), new Vector3(32, 0, 0) }; string[] nm = { "West Quarry", "Center Quarry", "East Quarry" };
        for (int i = 0; i < 3; i++)
        {
            var cp = new GameObject(nm[i]); cp.transform.position = pts[i]; cp.AddComponent<CapturePoint>();
            var pole = Box("Pole", pts[i] + Vector3.up * 3, new Vector3(0.3f, 6, 0.3f), Color.gray, cp.transform); var flag = Box("Flag", pts[i] + new Vector3(0.9f, 5.3f, 0), new Vector3(1.6f, 1f, 0.1f), Color.white, cp.transform); flag.name = "Flag";
            var crystal = Owned(new[] { "crystal", "gem", "quartz", "rock", "stone" }, new[] { "terrain", "lod", "wall", "floor", "texture" }); Place(crystal, pts[i] + new Vector3(-2, 0, 1.5f), 2.2f, root, true, i * 50);
            for (int k = 0; k < 5; k++) { float a = k * 72 * Mathf.Deg2Rad; Place(bar, pts[i] + new Vector3(Mathf.Cos(a) * 7, 0, Mathf.Sin(a) * 7), 1.2f, root, true, k * 72); }
            var ring = GameObject.CreatePrimitive(PrimitiveType.Cylinder); ring.name = "CaptureRing"; Object.DestroyImmediate(ring.GetComponent<Collider>()); ring.transform.position = pts[i] + Vector3.up * 0.02f; ring.transform.localScale = new Vector3(12, 0.02f, 12); ring.GetComponent<Renderer>().sharedMaterial = Mat(new Color(0.9f, 0.9f, 0.6f));
        }
        var tplRoot = new GameObject("UnitTemplates");
        var sold = Unit("SoldierTemplate", new Vector3(0, 0, -200), 0, "soldier", 70, 9, 2.2f, 4.2f, 1.8f, blue, 0); sold.transform.SetParent(tplRoot.transform); sold.SetActive(false);
        var guard = Unit("GuardianTemplate", new Vector3(4, 0, -200), 0, "guardian", 170, 16, 2.6f, 3.2f, 2.3f, new Color(0.15f, 0.3f, 0.9f), 0); guard.transform.SetParent(tplRoot.transform); guard.SetActive(false);
        var enemy = Unit("RaiderTemplate", new Vector3(8, 0, -200), 1, "raider", 70, 9, 2.2f, 3.8f, 1.8f, red, 1); enemy.transform.SetParent(tplRoot.transform); enemy.SetActive(false);
        for (int i = 0; i < 4; i++) Unit("Soldier_" + i, new Vector3(-4.5f + i * 3, 0, -38), 0, "soldier", 70, 9, 2.2f, 4.2f, 1.8f, blue, 0);
        for (int i = 0; i < 4; i++) Unit("Garrison_" + i, new Vector3(-4.5f + i * 3, 0, 42), 1, "raider", 70, 9, 2.2f, 3.8f, 1.8f, red, 1);
        var cam = GameObject.Find("Main Camera"); var cmd = cam.AddComponent<RtsCommander>(); cam.transform.position = new Vector3(0, 34, -62); cmd.soldierTpl = sold; cmd.guardianTpl = guard; cmd.enemyTpl = enemy; cmd.hq = hq.transform; cmd.enemyKeep = keep.transform;
        Nature(new Vector3(0, 0, 0), 62f, 80f, 60, 30, 20, root, true, 7); Nature(new Vector3(0, 0, 0), 12f, 55f, 10, 30, 10, root, false, 17);
        LogDress(); End(scene);
    }

    // ================= MOBA: one lane, towers, cores, minion waves, hero abilities
    static void BuildMoba()
    {
        var scene = Begin("moba", new Color(0.3f, 0.45f, 0.25f), 14f); _dressCount = 0; _dressUsed.Clear(); SkinGround(new Color(0.3f, 0.45f, 0.25f)); var root = DressRoot();
        var lane = Box("Lane", new Vector3(0, 0.02f, 0), new Vector3(12, 0.04f, 130), new Color(0.55f, 0.48f, 0.35f)); Object.DestroyImmediate(lane.GetComponent<Collider>());
        lane.GetComponent<Renderer>().sharedMaterial = Tiled(OwnedMat(new[] { "dirt", "path", "gravel", "sand", "ground", "soil" }, new Color(0.55f, 0.48f, 0.35f), new[] { "grass", "normal" }), 3, 30);
        var blue = new Color(0.2f, 0.45f, 1f); var red = new Color(1f, 0.25f, 0.18f);
        var allyCore = Structure("AllyCore", new Vector3(0, 0, -62), 0, "core", 1400, 20, 9f, new Vector3(9, 8, 9), blue, root);
        var enemyCore = Structure("EnemyCore", new Vector3(0, 0, 62), 1, "core", 1400, 20, 9f, new Vector3(9, 8, 9), red, root);
        Structure("AllyTower_1", new Vector3(5, 0, -40), 0, "tower", 650, 24, 10f, new Vector3(3.5f, 9, 3.5f), blue, root); Structure("AllyTower_2", new Vector3(-5, 0, -16), 0, "tower", 650, 24, 10f, new Vector3(3.5f, 9, 3.5f), blue, root);
        Structure("EnemyTower_1", new Vector3(5, 0, 16), 1, "tower", 650, 24, 10f, new Vector3(3.5f, 9, 3.5f), red, root); Structure("EnemyTower_2", new Vector3(-5, 0, 40), 1, "tower", 650, 24, 10f, new Vector3(3.5f, 9, 3.5f), red, root);
        var tplRoot = new GameObject("MinionTemplates");
        var am = Unit("AllyMinionTemplate", new Vector3(0, 0, -300), 0, "minion", 60, 7, 2f, 3.6f, 1.3f, blue, 0); am.transform.SetParent(tplRoot.transform); am.SetActive(false);
        var em = Unit("EnemyMinionTemplate", new Vector3(3, 0, -300), 1, "minion", 60, 7, 2f, 3.6f, 1.3f, red, 1); em.transform.SetParent(tplRoot.transform); em.SetActive(false);
        var hero = Unit("Player", new Vector3(0, 0, -52), 0, "hero", 260, 14, 2.8f, 6.5f, 2.0f, new Color(1f, 0.85f, 0.3f), 0); hero.tag = "Player"; var u = hero.GetComponent<RtsUnit>(); u.aggro = 6f; u.cd = 0.7f;
        var mh = hero.AddComponent<MobaHero>(); mh.allyMinionTpl = am; mh.enemyMinionTpl = em; mh.allyBase = allyCore.transform; mh.enemyBase = enemyCore.transform;
        HoldItem(hero, new[] { "sword", "axe", "staff", "blade" }, 1.1f);
        var cam = GameObject.Find("Main Camera"); cam.transform.position = new Vector3(0, 26, -67);
        var rnd = new System.Random(4); var t = Trees(); var b = Bushes(); var r = Rocks();
        for (int i = 0; i < 90; i++) { float z = Mathf.Lerp(-70, 70, (float)rnd.NextDouble()); float x = (rnd.Next(2) == 0 ? -1 : 1) * Mathf.Lerp(9f, 40f, (float)rnd.NextDouble()); var p = new Vector3(x, 0, z); if (i % 3 == 0) Place(b, p, 1.4f, root, false, rnd.Next(360), rnd); else if (i % 7 == 0) Place(r, p, 1.6f, root, true, rnd.Next(360), rnd); else Place(t, p, Mathf.Lerp(6, 10, (float)rnd.NextDouble()), root, true, rnd.Next(360), rnd); }
        LogDress(); End(scene);
    }

    // ================= SPORTS: arena football 1v1 + keeper
    static void BuildSports()
    {
        var scene = Begin("sports", new Color(0.2f, 0.55f, 0.22f), 10f); _dressCount = 0; _dressUsed.Clear(); var root = DressRoot();
        var pitch = Box("Pitch", new Vector3(0, -0.05f, 0), new Vector3(40, 0.1f, 70), new Color(0.2f, 0.55f, 0.22f)); pitch.GetComponent<Renderer>().sharedMaterial = Tiled(GroundMat(new Color(0.2f, 0.55f, 0.22f)), 8, 14);
        foreach (var l in new[] { new Vector4(0, 0, 40, 0.15f), new Vector4(0, 35, 40, 0.15f), new Vector4(0, -35, 40, 0.15f), new Vector4(20, 0, 0.15f, 70), new Vector4(-20, 0, 0.15f, 70) }) { var ln = Box("Line", new Vector3(l.x, 0.02f, l.y), new Vector3(l.z, 0.02f, l.w), Color.white); Object.DestroyImmediate(ln.GetComponent<Collider>()); }
        foreach (var s in new[] { -1, 1 })
        {
            float z = 33.5f * s; Box("GoalPostL", new Vector3(-4, 1.25f, z), new Vector3(0.25f, 2.5f, 0.25f), Color.white); Box("GoalPostR", new Vector3(4, 1.25f, z), new Vector3(0.25f, 2.5f, 0.25f), Color.white); Box("Crossbar", new Vector3(0, 2.5f, z), new Vector3(8.25f, 0.25f, 0.25f), Color.white);
            Box("GoalBack", new Vector3(0, 1.25f, z + 1.8f * s), new Vector3(8, 2.5f, 0.1f), new Color(0.9f, 0.9f, 0.9f, 0.5f));
            var g = new GameObject(s > 0 ? "TheirGoal" : "OurGoal"); g.transform.position = new Vector3(0, 1.2f, z + 1f * s); var bc = g.AddComponent<BoxCollider>(); bc.isTrigger = true; bc.size = new Vector3(7.8f, 2.4f, 1.4f); g.AddComponent<SportsGoal>().countsForUs = s > 0;
        }
        foreach (var w in new[] { new Vector4(0, 36.5f, 44, 1), new Vector4(0, -36.5f, 44, 1), new Vector4(21, 0, 1, 74), new Vector4(-21, 0, 1, 74) }) { var wall = Box("Boards", new Vector3(w.x, 0.6f, w.y), new Vector3(w.z, 1.2f, w.w), new Color(0.15f, 0.2f, 0.5f)); }
        var ball = GameObject.CreatePrimitive(PrimitiveType.Sphere); ball.name = "Ball"; ball.transform.position = new Vector3(0, 0.6f, 0); ball.transform.localScale = Vector3.one * 0.7f; var rb = ball.AddComponent<Rigidbody>(); rb.mass = 0.45f; rb.linearDamping = 0.35f; rb.angularDamping = 0.6f; rb.interpolation = RigidbodyInterpolation.Interpolate; rb.collisionDetectionMode = CollisionDetectionMode.Continuous;
        var bm = new PhysicsMaterial("BallBounce") { bounciness = 0.6f, dynamicFriction = 0.4f }; ball.GetComponent<Collider>().material = bm; ball.GetComponent<Renderer>().sharedMaterial = Mat(Color.white);
        var player = MakeWalker(new Vector3(0, 1.1f, -8f)); ThirdPerson(player, 6f, 3f); AttachCharacter(player); var v = player.transform.Find("CharacterVisual"); if (v) Tint(v.gameObject, new Color(0.2f, 0.45f, 1f), 0.4f);
        var rival = Host("RivalStriker", new Vector3(0, 0, 8), 0.45f, 1.8f); Dressed(rival, Ch(1), 1.8f, new Color(1f, 0.2f, 0.15f)); rival.transform.rotation = Quaternion.Euler(0, 180, 0);
        var keeper = Host("RivalKeeper", new Vector3(0, 0, 31.5f), 0.6f, 1.9f); Dressed(keeper, Ch(1), 1.9f, new Color(1f, 0.7f, 0.1f)); keeper.transform.rotation = Quaternion.Euler(0, 180, 0);
        var m = new GameObject("Match").AddComponent<SportsMatch>(); m.ball = rb; m.player = player.transform; m.rival = rival.transform; m.keeper = keeper.transform; m.ourGoal = GameObject.Find("OurGoal").transform; m.theirGoal = GameObject.Find("TheirGoal").transform;
        var seats = Props("bench", "chair", "bin", "lamp", "bollard", "barrier", "barricade", "hydrant", "sign"); for (int i = 0; i < 24; i++) { float z = -30 + (i % 12) * 5.4f; float x = i < 12 ? -24 : 24; Place(seats, new Vector3(x, 0, z), 1.1f, root, false, x < 0 ? 90 : -90); }
        for (int i = 0; i < 10; i++) { var s = new GameObject("Fan_" + i); s.transform.position = new Vector3(i < 5 ? -26 : 26, 0, -20 + (i % 5) * 10); Dressed(s, Ch(i), 1.8f, Color.HSVToRGB(i / 10f, 0.5f, 0.9f)); s.transform.LookAt(new Vector3(0, 0, s.transform.position.z)); }
        Nature(Vector3.zero, 46f, 62f, 40, 20, 8, root, false, 21);
        for (int i = 0; i < 4; i++) { var l = new GameObject("Floodlight").AddComponent<Light>(); l.type = LightType.Spot; l.transform.position = new Vector3((i % 2 == 0 ? -22 : 22), 16, (i < 2 ? -30 : 30)); l.transform.LookAt(Vector3.zero); l.range = 70; l.spotAngle = 70; l.intensity = 25; }
        LogDress(); End(scene);
    }

    // ================= SANDBOX: block building island, harvest, Sky Beacon
    static void BuildSandbox()
    {
        var scene = Begin("sandbox", new Color(0.35f, 0.5f, 0.25f), 5f); _dressCount = 0; _dressUsed.Clear(); SkinGround(new Color(0.35f, 0.5f, 0.25f)); var root = DressRoot();
        var sea = GameObject.CreatePrimitive(PrimitiveType.Plane); sea.name = "Sea"; sea.transform.position = new Vector3(0, -1.2f, 0); sea.transform.localScale = new Vector3(40, 1, 40); Object.DestroyImmediate(sea.GetComponent<Collider>());
        sea.GetComponent<Renderer>().sharedMaterial = OwnedMat(new[] { "water", "ocean", "sea" }, new Color(0.1f, 0.35f, 0.6f), new[] { "normal", "foam" });
        var kill = new GameObject("SeaHazard"); kill.transform.position = new Vector3(0, -3, 0); var kc = kill.AddComponent<BoxCollider>(); kc.isTrigger = true; kc.size = new Vector3(600, 2, 600); kill.AddComponent<Hazard>();
        var mats = new List<Material>(); var names = new List<string>();
        foreach (var k in new[] { new[] { "wood", "plank" }, new[] { "stone", "rock", "cobble", "concrete" }, new[] { "brick" }, new[] { "metal", "steel", "glass", "tile" } }) { var m = OwnedMat(k, Color.HSVToRGB(mats.Count * 0.2f, 0.4f, 0.8f), new[] { "normal", "rough", "car", "terrain" }); mats.Add(m); names.Add(k[0]); }
        var rnd = new System.Random(8); var t = Trees(); var r = Rocks();
        for (int i = 0; i < 14; i++)
        {
            float a = (float)rnd.NextDouble() * Mathf.PI * 2, d = Mathf.Lerp(10, 22, (float)rnd.NextDouble()); var p = new Vector3(Mathf.Cos(a) * d, 0, Mathf.Sin(a) * d);
            var node = new GameObject(i % 3 == 0 ? "RockNode_" + i : "TreeNode_" + i); node.transform.position = p; var pool = i % 3 == 0 ? r : t;
            if (Place(pool, p, i % 3 == 0 ? 1.6f : 6f, node.transform, true, rnd.Next(360), rnd) == 0) { var bx = Box("NodeBox", p + Vector3.up, new Vector3(1.2f, 2, 1.2f), new Color(0.4f, 0.3f, 0.2f), node.transform); }
            node.AddComponent<SandboxNode>().yield = i % 3 == 0 ? 6 : 8;
        }
        var beacon = GameObject.CreatePrimitive(PrimitiveType.Sphere); beacon.name = "SkyBeacon"; beacon.transform.position = new Vector3(10, 10.5f, 10); beacon.transform.localScale = Vector3.one * 1.6f; beacon.GetComponent<Collider>().isTrigger = true; beacon.AddComponent<SkyBeacon>();
        var bmat = new Material(Shader.Find("Universal Render Pipeline/Lit") ?? Shader.Find("Standard")); bmat.color = new Color(1f, 0.85f, 0.2f); bmat.EnableKeyword("_EMISSION"); bmat.SetColor("_EmissionColor", new Color(1f, 0.7f, 0.1f) * 3f); beacon.GetComponent<Renderer>().sharedMaterial = bmat;
        var bl = new GameObject("BeaconLight").AddComponent<Light>(); bl.transform.position = beacon.transform.position; bl.color = new Color(1f, 0.8f, 0.3f); bl.range = 18; bl.intensity = 5;
        var pad = Box("BeaconPad", new Vector3(10, 0.05f, 10), new Vector3(3, 0.1f, 3), new Color(1f, 0.85f, 0.2f)); Object.DestroyImmediate(pad.GetComponent<Collider>());
        var bench = Box("Workbench", new Vector3(-3, 0.5f, 3), new Vector3(2.4f, 1, 1.2f), new Color(0.5f, 0.35f, 0.2f)); bench.GetComponent<Renderer>().sharedMaterial = mats[0];
        var tools = Props("saw", "drill", "chisel", "axe", "plane_", "rasp", "file", "toolbox", "hammer"); for (int i = 0; i < 5; i++) Place(tools, new Vector3(-3.8f + i * 0.4f, 1.0f, 3), 0.3f, root, false, i * 30);
        for (int i = 0; i < 6; i++) { var b = GameObject.CreatePrimitive(PrimitiveType.Cube); b.name = "PlacedBlock"; b.transform.position = new Vector3(-6 + (i % 3) + 0.5f, 0.5f + i / 3, 6.5f); b.GetComponent<Renderer>().sharedMaterial = mats[i % mats.Count]; }
        Nature(Vector3.zero, 5f, 24f, 0, 30, 0, root, false, 13);
        var player = MakeWalker(new Vector3(0, 1.1f, 0)); var sb = player.AddComponent<SandboxBuilder>(); sb.mats = mats.ToArray(); sb.matNames = names.ToArray(); AttachCharacter(player, false);
        LogDress(); End(scene);
    }

    // ================= STEALTH: night compound, guard vision cones, intel, extraction
    static void BuildStealth()
    {
        var scene = Begin("stealth", new Color(0.22f, 0.24f, 0.22f), 8f); _dressCount = 0; _dressUsed.Clear(); SkinGround(new Color(0.22f, 0.24f, 0.22f)); var root = DressRoot();
        RenderSettings.ambientLight = new Color(0.16f, 0.17f, 0.24f); var sun = GameObject.Find("Directional Light"); if (sun) { var l = sun.GetComponent<Light>(); l.intensity = 0.25f; l.color = new Color(0.55f, 0.6f, 0.9f); }
        var compound = new GameObject("Compound").transform; Walls(compound, 36, 3.5f, new Color(0.35f, 0.35f, 0.38f));
        foreach (Transform w in compound) w.GetComponent<Renderer>().sharedMaterial = Tiled(OwnedMat(new[] { "concrete", "brick", "stone", "plaster" }, new Color(0.35f, 0.35f, 0.38f), new[] { "normal", "floor", "car" }), 12, 1.5f);
        Building("Warehouse_A", new Vector3(-18, 0, 12), new Vector3(12, 7, 10), new Color(0.5f, 0.5f, 0.55f), root, 0); Building("Office_B", new Vector3(16, 0, 16), new Vector3(10, 8, 10), null, root, 90); Building("Barracks_C", new Vector3(14, 0, -14), new Vector3(10, 6, 8), new Color(0.4f, 0.45f, 0.4f), root, 0);
        var crates = Props("crate", "container", "barrel", "pallet", "shelf", "rack", "cabinet", "tub", "box", "toolbox");
        var rnd = new System.Random(12); for (int i = 0; i < 26; i++) { var p = new Vector3(rnd.Next(-32, 32), 0, rnd.Next(-30, 32)); if (Mathf.Abs(p.x) < 4 && p.z < -24) continue; Place(crates, p, Mathf.Lerp(1.0f, 2.2f, (float)rnd.NextDouble()), root, true, rnd.Next(360), rnd); }
        var bushes = Bushes(); for (int i = 0; i < 10; i++) { var p = new Vector3(rnd.Next(-30, 30), 0, rnd.Next(-28, 28)); var cz = new GameObject("CoverBush_" + i); cz.transform.position = p; var bc = cz.AddComponent<BoxCollider>(); bc.isTrigger = true; bc.size = new Vector3(2.6f, 2f, 2.6f); bc.center = Vector3.up; cz.AddComponent<CoverZone>(); if (Place(bushes, p, 1.6f, cz.transform, false, rnd.Next(360), rnd) == 0) { var s = GameObject.CreatePrimitive(PrimitiveType.Sphere); Object.DestroyImmediate(s.GetComponent<Collider>()); s.transform.SetParent(cz.transform, false); s.transform.localPosition = Vector3.up * 0.8f; s.transform.localScale = new Vector3(2.4f, 1.6f, 2.4f); s.GetComponent<Renderer>().sharedMaterial = Mat(new Color(0.15f, 0.35f, 0.15f)); } }
        Vector3[] intel = { new Vector3(-18, 1, 4.5f), new Vector3(16, 1, 8.5f), new Vector3(20, 1, -20) };
        for (int i = 0; i < intel.Length; i++) { var q = Pickup("Intel_" + i, PrimitiveType.Cube, intel[i], new Color(0.3f, 1f, 0.6f), "intel", 0.5f); var doc = Props("book", "laptop", "computer", "folder", "paper", "list"); if (doc.Count > 0) { var dv = Spawn(doc[0], q.transform, false); FitTo(dv, intel[i], Vector3.one * 0.5f, true); dv.transform.SetParent(q.transform, true); q.GetComponent<Renderer>().enabled = false; _dressCount++; } }
        var ex = Box("Extraction", new Vector3(30, 0.05f, 30), new Vector3(5, 0.1f, 5), new Color(0.1f, 1f, 0.3f)); ex.GetComponent<Collider>().isTrigger = true; ex.AddComponent<ExitGate>(); var exc = ex.GetComponent<BoxCollider>(); exc.size = new Vector3(1, 30, 1);
        var el = new GameObject("ExtractionLight").AddComponent<Light>(); el.transform.position = new Vector3(30, 3, 30); el.color = Color.green; el.range = 10; el.intensity = 4;
        Vector3[][] routes = { new[] { new Vector3(-26, 0, -6), new Vector3(-26, 0, 24), new Vector3(-8, 0, 24) }, new[] { new Vector3(4, 0, 4), new Vector3(26, 0, 4), new Vector3(26, 0, 26) }, new[] { new Vector3(0, 0, -20), new Vector3(24, 0, -24), new Vector3(24, 0, -6) }, new[] { new Vector3(-10, 0, 30), new Vector3(10, 0, 30), new Vector3(10, 0, 12) } };
        for (int i = 0; i < routes.Length; i++) { var gd = Host("Guard_" + i, routes[i][0], 0.4f, 1.8f); gd.transform.position += Vector3.up * 0.9f; var gp = gd.AddComponent<GuardPatrol>(); var pts = new Vector3[routes[i].Length]; for (int k = 0; k < pts.Length; k++) pts[k] = routes[i][k] + Vector3.up * 0.9f; gp.points = pts; Dressed(gd, Ch(i), 1.8f, new Color(0.15f, 0.2f, 0.45f), -0.9f); var fl = new GameObject("GuardTorch").AddComponent<Light>(); fl.type = LightType.Spot; fl.transform.SetParent(gd.transform, false); fl.transform.localPosition = new Vector3(0, 0.6f, 0.3f); fl.transform.localRotation = Quaternion.Euler(20, 0, 0); fl.range = 14; fl.spotAngle = 70; fl.intensity = 12; }
        for (int i = 0; i < 6; i++) { var lamp = new GameObject("YardLamp").AddComponent<Light>(); lamp.transform.position = new Vector3(-24 + i * 10, 5, (i % 2 == 0) ? -2 : 20); lamp.color = new Color(1f, 0.8f, 0.5f); lamp.range = 9; lamp.intensity = 2.5f; }
        var lampPf = Props("lamp", "light"); for (int i = 0; i < 6; i++) Place(lampPf, new Vector3(-24 + i * 10, 0, (i % 2 == 0) ? -2.6f : 19.4f), 4.5f, root, false, 0);
        var player = MakeWalker(new Vector3(0, 1.1f, -30f)); ThirdPerson(player, 4.5f, 2.3f); AttachCharacter(player); player.AddComponent<StealthPlayer>();
        Nature(Vector3.zero, 40f, 56f, 40, 16, 8, root, false, 19);
        LogDress(); End(scene);
    }

    // ================= BATTLE ROYALE: storm circle, 11 bots, loot, last one standing
    static void BuildBattleRoyale()
    {
        var scene = Begin("battle_royale", new Color(0.4f, 0.48f, 0.3f), 22f); _dressCount = 0; _dressUsed.Clear(); _blocked.Clear(); _coverPool = null; WorldTerrain(300f, 118f); var root = DressRoot();
        var storm = GameObject.CreatePrimitive(PrimitiveType.Cylinder); storm.name = "StormWall"; Object.DestroyImmediate(storm.GetComponent<Collider>()); storm.transform.position = new Vector3(0, 15, 0);
        var sm = new Material(Shader.Find("Sprites/Default")); sm.color = new Color(0.6f, 0.2f, 0.9f, 0.18f); storm.GetComponent<Renderer>().sharedMaterial = sm; storm.AddComponent<StormZone>();
        Vector3[] towns = { new Vector3(-55, 0, 45), new Vector3(50, 0, 50), new Vector3(-45, 0, -45), new Vector3(55, 0, -40), new Vector3(0, 0, 5) };
        var rnd = new System.Random(31);
        // world from the creator's owned packs (asset plan): buildings, cover, Blender-made extras (castle, dragon...)
        WorldBuildings(root, 110f); WorldCover(root, 110f); WorldExtras(root, 110f);
        var crate = Props("crate", "box", "container", "barrel", "pallet");
        string[] kinds = { "ammo", "med", "armor", "ammo" };
        for (int i = 0; i < 22; i++) { var t = towns[i % towns.Length]; var p = t + new Vector3(rnd.Next(-16, 16), 0.5f, rnd.Next(-16, 16)); var c = Box("LootCrate_" + i, p, Vector3.one * 0.9f, new Color(0.9f, 0.75f, 0.2f)); c.GetComponent<Collider>().isTrigger = true; c.AddComponent<LootCrate>().kind = kinds[i % 4]; if (crate.Count > 0) { var cv = Spawn(crate[i % crate.Count], c.transform, false); FitTo(cv, p, Vector3.one * 0.9f, true); cv.transform.SetParent(c.transform, true); c.GetComponent<Renderer>().enabled = false; _dressCount++; } var gl = new GameObject("LootGlow").AddComponent<Light>(); gl.transform.SetParent(c.transform, false); gl.color = new Color(1f, 0.85f, 0.3f); gl.range = 3; gl.intensity = 2; }
        string[] names = { "Vex", "Nyla", "Brick", "Juno", "Kade", "Ozzy", "Raze", "Sol", "Tamsin", "Wren", "Zed" };
        var epool = EnemyPool(); int bsk = 0, ban = 0;
        for (int i = 0; i < 11; i++) { float a = (-60f + i * 30f) * Mathf.Deg2Rad; var p = OnGround(Mathf.Cos(a) * 70, Mathf.Sin(a) * 70); /* no bot within ~40 m of the player spawn (was 10 m -> started at 41 HP) */ var bot = Host(names[i], p, 0.45f, 1.8f); bot.AddComponent<BrBot>().team = 2 + i; if (epool.Count > 0) DressAnimated(bot, epool[i % epool.Count], ref bsk, ref ban); else Dressed(bot, Ch(i), 1.8f, Color.HSVToRGB(i / 11f, 0.6f, 0.9f)); }
        var bgrowl = FindClip(new[] { "growl|grunt|shout|hey|voice|scream|step|footstep" }, "gb_enemy");
        foreach (var bb in Object.FindObjectsByType<BrBot>(FindObjectsSortMode.None)) { var src = bb.gameObject.AddComponent<AudioSource>(); src.playOnAwake = false; src.spatialBlend = 1f; src.minDistance = 3f; src.maxDistance = 40f; src.clip = bgrowl; src.volume = 0.7f; }
        Debug.Log("WORLD_ENEMIES 11 skinned=" + bsk + " animated=" + ban + " (battle royale bots)");
        var player = MakeWalker(new Vector3(0, 1.1f, -80f)); var gun = player.AddComponent<GunController>(); gun.damage = 14; gun.fireRate = 0.11f; AttachWeaponModel(player); AttachCharacter(player, false);
        WorldTrees(root, 300f, 118f);
        SnapAllToTerrain(root); WorldBounds(140f);
        foreach (var b in Object.FindObjectsByType<BrBot>(FindObjectsSortMode.None)) if (!b.GetComponent<GbEnemyAnim>()) b.gameObject.AddComponent<GbEnemyAnim>();
        WorldAudio(true);
        LogDress(); End(scene);
    }

    // ================= MMORPG: hub town, 3 quest givers, mob camps, world boss, simulated population
    static void BuildMmo()
    {
        var scene = Begin("mmorpg", new Color(0.32f, 0.5f, 0.26f), 14f); _dressCount = 0; _dressUsed.Clear(); SkinGround(new Color(0.32f, 0.5f, 0.26f)); var root = DressRoot();
        for (int i = 0; i < 7; i++) { float a = i * (360f / 7) * Mathf.Deg2Rad; Building("House_" + i, new Vector3(Mathf.Cos(a) * 16, 0, Mathf.Sin(a) * 16 - 20), new Vector3(8, 7, 8), i % 2 == 0 ? (Color?)null : new Color(0.85f, 0.78f, 0.7f), root, -i * (360f / 7) + 90); }
        var street = Props("bench", "lamp", "barrel", "crate", "sign", "cart", "stand", "awning", "fence"); for (int i = 0; i < 14; i++) { float a = i * 25 * Mathf.Deg2Rad; Place(street, new Vector3(Mathf.Cos(a) * 9, 0, Mathf.Sin(a) * 9 - 20), 1.2f, root, true, i * 25); }
        string[] qn = { "Warden Hale", "Sister Mae", "Elder Voss" }; string[] offers = { "Wolves are mauling our flock. Cull 5 of them in the western woods.", "Gather 4 moonherbs near the eastern pond for my remedies.", "The Ancient Treant stirs in the north. End it." };
        for (int i = 0; i < 3; i++) { var p = new Vector3(-6 + i * 6, 0, -14); var npc = Host("QuestGiver_" + i, p, 0.4f, 1.8f); Dressed(npc, Ch(i), 1.8f, Color.HSVToRGB(0.1f + i * 0.3f, 0.5f, 0.9f)); npc.transform.rotation = Quaternion.Euler(0, 180, 0); var z = new GameObject("TalkZone"); z.transform.SetParent(npc.transform, false); var bc = z.AddComponent<BoxCollider>(); bc.isTrigger = true; bc.size = new Vector3(3.5f, 3, 3.5f); bc.center = Vector3.up * 1.5f; var qg = z.AddComponent<MmoQuestGiver>(); qg.quest = i; qg.npcName = qn[i]; qg.offer = offers[i]; }
        string[] pn = { "Kaelith", "Brom", "Ysra", "Thorn", "Mira", "Odo", "Lune" };
        for (int i = 0; i < 7; i++) { var w = Host("Adventurer_" + pn[i], new Vector3(-20 + i * 6, 0, -5 + (i % 2) * 8), 0.4f, 1.8f); w.GetComponent<Collider>().isTrigger = true; w.AddComponent<MmoWanderer>().display = pn[i] + " <Lv " + (2 + i % 5) + ">"; Dressed(w, Ch(i), 1.8f, Color.HSVToRGB(i / 7f, 0.45f, 0.9f)); }
        var animals = Owned(new[] { "dog", "wolf", "deer", "horse", "tiger", "pig", "boar" });
        var wolves = animals.FindAll(a => a.name.ToLower().Contains("dog") || a.name.ToLower().Contains("wolf")); if (wolves.Count == 0) wolves = animals; var stags = animals.FindAll(a => a.name.ToLower().Contains("deer") || a.name.ToLower().Contains("tiger")); if (stags.Count == 0) stags = animals;
        for (int i = 0; i < 7; i++) { var p = new Vector3(-48 + (i % 3) * 6, 0, 0 + (i / 3) * 7); var m = Host("Wolf_" + i, p, 0.5f, 1f); var mm = m.AddComponent<MmoMob>(); mm.kind = "wolf"; mm.maxHp = 45; mm.dmg = 6; mm.xp = 40; if (wolves.Count > 0) Dressed(m, wolves[0], 1.0f, new Color(0.5f, 0.5f, 0.55f), 0f); }
        for (int i = 0; i < 5; i++) { var p = new Vector3(40 + (i % 3) * 6, 0, 10 + (i / 3) * 8); var m = Host("Stag_" + i, p, 0.6f, 1.6f); var mm = m.AddComponent<MmoMob>(); mm.kind = "stag"; mm.maxHp = 60; mm.dmg = 8; mm.xp = 55; mm.gold = 6; if (stags.Count > 0) Dressed(m, stags[0], 1.6f, null, 0f); }
        for (int i = 0; i < 6; i++) { var hp = new Vector3(30 + (i % 3) * 5, 0.6f, -12 - (i / 3) * 5); var h = Pickup("Moonherb_" + i, PrimitiveType.Sphere, hp, new Color(0.6f, 0.9f, 1f), "herb", 0.4f); var hb = Bushes(); if (hb.Count > 0) { var hv = Spawn(hb[i % hb.Count], h.transform, false); FitTo(hv, hp, Vector3.one * 0.8f, true); hv.transform.SetParent(h.transform, true); _dressCount++; } }
        var pond = GameObject.CreatePrimitive(PrimitiveType.Cylinder); pond.name = "Pond"; Object.DestroyImmediate(pond.GetComponent<Collider>()); pond.transform.position = new Vector3(36, 0.02f, -16); pond.transform.localScale = new Vector3(10, 0.02f, 7); pond.GetComponent<Renderer>().sharedMaterial = OwnedMat(new[] { "water" }, new Color(0.15f, 0.4f, 0.6f), new[] { "normal", "foam" });
        var boss = Host("AncientTreant", new Vector3(0, 0, 58), 1.6f, 7f); var bm = boss.AddComponent<MmoMob>(); bm.kind = "boss"; bm.maxHp = 520; bm.dmg = 16; bm.xp = 300; bm.gold = 80; bm.aggro = 12; bm.speed = 2.2f;
        var tr = Trees(); if (tr.Count > 0) { Dressed(boss, tr[0], 7f, new Color(0.35f, 0.2f, 0.1f), 0f); } var bl = new GameObject("TreantGlow").AddComponent<Light>(); bl.transform.position = new Vector3(0, 6, 58); bl.color = new Color(0.4f, 1f, 0.3f); bl.range = 18; bl.intensity = 3;
        var player = MakeWalker(new Vector3(0, 1.1f, -26f)); ThirdPerson(player); AttachCharacter(player); HoldItem(player, new[] { "sword", "axe", "bow", "blade" }, 1.1f); player.AddComponent<MmoPlayer>();
        Nature(new Vector3(0, 0, 5), 34f, 75f, 110, 50, 24, root, true, 29);
        LogDress(); End(scene);
    }
}
