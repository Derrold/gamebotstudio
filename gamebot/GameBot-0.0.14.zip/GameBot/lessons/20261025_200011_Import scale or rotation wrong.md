# Import scale or rotation wrong

Tags: blender,unity,fix,assets
Saved: 2026-10-25T20:00:11

100x/0.01x: export apply_scale_options='FBX_SCALE_UNITS' after applying scale; Unity import Convert Units on, Scale Factor 1. Rotated 90deg: axis_forward='-Z', axis_up='Y'; or parent the mesh under a child with a fix rotation. Verify renderer.bounds.size (rifle ~1m). Source: https://docs.unity3d.com/Manual/FBXImporter-Model.html
