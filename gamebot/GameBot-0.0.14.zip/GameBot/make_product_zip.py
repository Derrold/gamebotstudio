﻿"""Build dist\\GameBot-product.zip (clean sellable copy). Run from the Game Bot folder."""
import json, re, zipfile
from pathlib import Path

ROOT = Path(__file__).resolve().parent
OUT = ROOT / "dist" / "GameBot-product.zip"
SKIP_DIRS = re.compile(r"^(_|unity_fullgame[._]bak|__pycache__|dist|work|notes|bug_reports|summaries|sessions_archive|\.git|GameBotSigningKey)", re.I)
# never ship signing keys or the publisher signing tools (review fix 1)
NEVER = re.compile(r"(?i)(GameBotSigningKey|\.key$|\.pem$|_private|^tools\\(make_update_key|sign_release)\.py$)")
SKIP_FILES = re.compile(r"(^_|\.bak|\.log$|\.pyc$|^_.*\.py$|^config\\gamebot\.config\.json$|^config\\gpu_auto\.json$|^config\\install_prefs\.json$|^config\\.*\.user\.json$|^license\.json$|6gb|^memory\.json$|ebay|specs_|"
                        r"^README\.md$|train|smoke|answer|^icons\\(?!game-bot)|^(?!requirements|SELLABLE|LICENSE|PREREQUISITES|config\\update_pubkey\.txt$).*\.txt$|\.zip$|alphamax|colt|pump45|hunting|qwen|cli_|deploy\.py$|teach_seed\.py$|^lessons\\index\.json$)", re.I)
PERSONAL = re.compile(r"alphamax|hvacr|extremehybrid|derrold|frankendriver|prof_k", re.I)
GENERIC_LESSON = re.compile(r"(Auto studio pipeline|Custom item_weapon pipeline|Batchmode content bake|Product safety|Buyer onboarding|FPS pass method)\.md$")

added, skipped, lessons = [], [], []
OUT.parent.mkdir(exist_ok=True)
with zipfile.ZipFile(OUT, "w", zipfile.ZIP_DEFLATED) as z:
    for p in sorted(ROOT.rglob("*")):
        if not p.is_file():
            continue
        rel = str(p.relative_to(ROOT))
        if NEVER.search(rel):
            skipped.append(rel + "  (signing key/tool)"); continue
        if any(SKIP_DIRS.match(part) for part in p.relative_to(ROOT).parts[:-1]) or SKIP_FILES.search(rel):
            skipped.append(rel); continue
        if rel.startswith("lessons\\") and not GENERIC_LESSON.search(rel):
            skipped.append(rel); continue
        try:
            txt = p.read_text(encoding="utf-8-sig")
            # the publisher copyright header ("Alphamax Studios") is not personal data
            chk = re.sub(r"(?im)^.*copyright \(c\) \d{4} alphamax studios.*$", "", txt).replace("alphamaxstudios@gmail.com", "")
            if PERSONAL.search(chk):
                skipped.append(rel + "  (personal text)"); continue
        except UnicodeDecodeError:
            pass
        if rel.startswith("lessons\\"):
            lessons.append({"file": p.name, "title": p.stem[16:], "tags": "", "path": "lessons\\" + p.name, "saved": p.stem[:15]})
        z.write(p, "GameBot\\" + rel); added.append(rel)
    z.writestr("GameBot\\memory.json", (ROOT / "memory_generic.json").read_text(encoding="utf-8"))
    z.writestr("GameBot\\lessons\\index.json", json.dumps(lessons, indent=2))
    z.writestr("GameBot\\README.md", (ROOT / "BUYER_README.md").read_text(encoding="utf-8"))
print(f"ZIP {OUT} files={len(added)+3} skipped={len(skipped)}")
for s in skipped:
    print("SKIP", s)

