"""Game Bot asset plan: map every thing a game needs (ground, grass, trees, buildings, cover, enemies, weapons,
sounds + anything named in the brief) to a pack the creator really owns, and say plainly what is missing.

Sources (read only):
  1. %APPDATA%\\Unity\\Asset Store-5.x  (downloaded, owned Asset Store packs)
  2. Documents\\UnityProjects\\<project>\\Assets\\<folder>  (packs already inside the creator's own projects;
     copied FROM, never modified)
  3. Epic VaultCache for Unreal (via owned_assets)
The plan is saved as <Game>\\Tools\\asset_plan.json; gb_kits.py imports it, writes Tools\\asset_map.json for
SceneBuilder, and runs Blender for every thing the creator chose to have modelled.
Intake answers (title/loop/story/setting/style) are STYLE references only - they never become asset names."""
from __future__ import annotations

import json
import os
import re
import subprocess
import sys
from datetime import datetime
from pathlib import Path
from urllib.parse import quote_plus

ROOT = Path(__file__).resolve().parent
UNITY_PROJECTS = Path.home() / "Documents" / "UnityProjects"
GAME_PROJECTS = Path.home() / "Documents" / "GameProjects"

def _pack_display_name(stem: str) -> str:
    """Repair names the Unity cache truncated ('ountry House FREE' -> 'Country House FREE')."""
    try:
        from owned_assets import _fix_pack_name
        return _fix_pack_name(stem)
    except Exception:
        return stem


# need -> label, category regex (Asset Store folder), name regex, exclude regex
NEEDS = {
    "ground": ("ground textures", r"textures ?materials", r"ground|grass|soil|terrain|dirt|nature", r"water|icon|ui|sky"),
    "grass": ("grass", r"vegetation", r"grass|foliage|bush|plant|fern", r"tree only"),
    "trees": ("trees", r"vegetation|environments", r"tree|conifer|pine|forest|nature starter|nature", r"interior|water|street"),
    "buildings": ("buildings", r"environments|urban|props", r"house|building|city|town|village|apartment|mansion|cabin|cottage", r"interior|furniture|shelves|terrain|heightmap|road"),
    "cover": ("cover props", r"props", r"street props|barricade|harbor|crate|barrel|container|storage|sandbag|military|prop", r"weapon|gun|furniture|tool|carpentry|grenade|interior|sewing"),
    "enemies": ("enemy characters", r"characters", r"character|soldier|zombie|humanoid|monster|animal|creature|enemy|player", r"easy fps|hands|arms"),
    "weapons": ("guns", r"weapons", r"gun|rifle|weapon|ar |pistol|kalashnikov|shotgun", r"melee|bow|crossbow|grenade|icon|optic|attachment|medieval|vintage|western"),
    "weapon_sfx": ("gun sounds", r"audio", r"weapon|gun|shot", r"ui|door|sewing|music"),
    "ambient": ("ambient sound", r"audio ?ambient|audio", r"ambien|nature|wind|forest|essentials", r"ui|door|sewing|weapon|music"),
    "sfx_misc": ("hit / creature sounds", r"audio ?sound ?fx", r"cinematic|sound effects|sfx", r"ui|door|sewing|weapon"),
}
CORE_ORDER = ["ground", "grass", "trees", "buildings", "cover", "enemies", "weapons", "weapon_sfx", "ambient", "sfx_misc"]
FAMILY_NEEDS = {
    "fps": CORE_ORDER, "battle_royale": CORE_ORDER,
    "survival": ["ground", "grass", "trees", "buildings", "enemies", "ambient", "sfx_misc"],
    "adventure": ["ground", "grass", "trees", "buildings", "enemies", "ambient", "sfx_misc"],
    "rpg": ["ground", "grass", "trees", "buildings", "enemies", "ambient", "sfx_misc"],
    "mmorpg": ["ground", "grass", "trees", "buildings", "enemies", "ambient", "sfx_misc"],
    "action": ["ground", "grass", "trees", "buildings", "enemies", "ambient", "sfx_misc"],
    "strategy": ["ground", "trees", "buildings", "enemies", "ambient", "sfx_misc"],
    "moba": ["ground", "trees", "enemies", "ambient", "sfx_misc"],
    "stealth": ["buildings", "cover", "enemies", "ambient", "sfx_misc"],
    "roguelike": ["cover", "enemies", "weapons", "weapon_sfx", "ambient", "sfx_misc"],
    "racing": ["ground", "trees", "ambient"], "horror": ["enemies", "ambient", "sfx_misc"],
    # review fix 5: every builder family has an explicit list (these used to fall back to sounds only)
    "platformer": ["ground", "trees", "enemies", "ambient", "sfx_misc"],
    "puzzle": ["ground", "cover", "ambient", "sfx_misc"],
    "sim": ["ground", "buildings", "cover", "enemies", "ambient", "sfx_misc"],
    "fighting": ["ground", "enemies", "ambient", "sfx_misc"],
    "sports": ["ground", "grass", "enemies", "ambient", "sfx_misc"],
    "sandbox": ["ground", "grass", "trees", "ambient", "sfx_misc"],
}
# Unknown family: plan for the full general list (and say so) instead of silently planning almost nothing.
DEFAULT_NEEDS = ["ground", "grass", "trees", "buildings", "enemies", "ambient", "sfx_misc"]

# Things a brief can name. key -> (label, brief regex, pack-name regex, size class)
EXTRA = {
    "house": ("house", r"\bhouses?\b|\bhomes?\b|\bcabins?\b|\bcottages?\b|\bvillage\b|\btown\b|\bsuburb", r"house|home|cabin|cottage|building", "building"),
    "car": ("car", r"\bcars?\b|\bvehicles?\b|\btrucks?\b|\bjeeps?\b|\bsedans?\b", r"car|vehicle|truck|pickup|sedan|taxi|police", "car"),
    "castle": ("castle", r"\bcastles?\b|\bfortress|\bkeep\b", r"castle|fortress|fort\b|medieval wall", "big"),
    "boat": ("boat", r"\bboats?\b|\bships?\b|\bdocks?\b|\bharbou?r", r"boat|ship|harbou?r|port", "car"),
    "tank": ("tank", r"\btanks?\b", r"\btank", "car"),
    "helicopter": ("helicopter", r"\bhelicopters?\b|\bheli\b|\bchopper", r"helicopter|heli", "car"),
    "plane": ("plane", r"\bplanes?\b|\bjets?\b|\baircraft|\bairport", r"plane|jet|aircraft|airplane", "car"),
    "dragon": ("dragon", r"\bdragons?\b", r"dragon", "creature"),
    "zombie": ("zombie", r"\bzombies?\b|\bundead\b", r"zombie|undead", "humanoid"),
    "robot": ("robot", r"\brobots?\b|\bmechs?\b|\bdroids?\b", r"robot|mech|droid", "humanoid"),
    "horse": ("horse", r"\bhorses?\b", r"horse|animals", "creature"),
    "soldier": ("soldier", r"\bsoldiers?\b|\barmy\b|\bmilitary\b|\btroops?\b", r"soldier|military|army|swat|character", "humanoid"),
    "sword": ("sword", r"\bswords?\b|\bblades?\b|\bknights?\b", r"sword|medieval weapons|blade", "prop"),
    "tower": ("tower", r"\btowers?\b", r"tower", "big"),
    "bridge": ("bridge", r"\bbridges?\b", r"bridge", "big"),
}

CHOICE_WORDS = {
    "blender": r"\bblender\b|\bmodel it\b|\bmake (it|them|one)\b|\bbuild (it|them|one)\b",
    "placeholder": r"\bplaceholders?\b|\bblock ?out\b|\bskip\b|\bany\b|\bwhatever\b|\bdoesn'?t matter\b|\bgray ?box",
    "store": r"\basset store\b|\bstore\b|\bsearch\b|\bbuy\b|\bdownload\b|\bfind (me )?(one|a pack)\b|\blink\b",
}


def _norm(s: str) -> str:
    return re.sub(r"[^a-z0-9]+", "", (s or "").lower())


def _words(s: str) -> str:
    """'CopyNukeTownFromCod' -> 'copy nuke town from cod' (style text only)."""
    s = re.sub(r"([a-z])([A-Z])", r"\1 \2", s or "")
    return re.sub(r"[^a-z0-9]+", " ", s.lower())


def _asset_store_dirs() -> list[Path]:
    app = os.environ.get("APPDATA") or str(Path.home() / "AppData" / "Roaming")
    base = Path(app) / "Unity"
    return [p for p in base.glob("Asset Store-5.x*") if p.is_dir()] if base.is_dir() else []


_CAT_CACHE: dict = {}


def catalog(refresh: bool = False) -> list[dict]:
    """Every owned pack on this PC: Asset Store downloads + folders already in the creator's Unity projects."""
    if _CAT_CACHE.get("rows") is not None and not refresh:
        return _CAT_CACHE["rows"]
    rows: list[dict] = []
    for c in _asset_store_dirs():
        for f in c.rglob("*.unitypackage"):
            rel = f.relative_to(c).parts
            rows.append({
                "name": _pack_display_name(f.stem), "publisher": rel[0] if len(rel) > 1 else "",
                "category": rel[1] if len(rel) > 2 else "", "size_mb": round(f.stat().st_size / 1048576, 1),
                "path": str(f), "kind": "unitypackage",
            })
    seen = {_norm(r["name"]) for r in rows}
    if UNITY_PROJECTS.is_dir():
        for proj in sorted(UNITY_PROJECTS.iterdir()):
            a = proj / "Assets"
            if not proj.is_dir() or "_bak" in proj.name.lower() or proj.name.startswith("_") or not a.is_dir():
                continue
            for d in sorted(a.iterdir()):
                if not d.is_dir() or d.name.lower() in ("editor", "scripts", "scenes", "resources", "streamingassets", "settings",
                                                       "shaders", "textmesh pro", "plugins", "gizmos", "_project", "thirdparty",
                                                       "original", "gen", "icon", "models", "audio", "art", "weapons", "3d models"):
                    continue
                if d.name.startswith("_") or _norm(d.name) in seen:
                    continue
                rows.append({"name": d.name, "publisher": f"in your Unity project {proj.name}", "category": "",
                             "size_mb": None, "path": str(d), "kind": "folder", "project": proj.name})
    rows.sort(key=lambda r: (r["kind"] != "unitypackage", r["name"].lower()))
    _CAT_CACHE["rows"] = rows
    return rows


def _score(need: str, p: dict, template: str = "", style: str = "") -> float:
    label, cat_re, name_re, excl_re = NEEDS[need]
    name = p["name"].lower()
    cat = (p.get("category") or "").lower()
    blob = f"{name} {cat}"
    if re.search(excl_re, name):
        return -99
    if re.search(r"complete projects|editor extensions|scripting|shaders|hdrp", blob):
        return -99
    s = 0.0
    if cat and re.search(cat_re, cat):
        s += 4
    elif cat:
        s -= 3
    if re.search(name_re, name):
        s += 3
    elif re.search(name_re, cat):
        s += 1.5
    else:
        return -99
    if p["kind"] == "folder":
        s -= 1.5
    mb = p.get("size_mb") or 0
    s -= 0 if mb < 150 else (1 if mb < 500 else (3 if mb < 1200 else 6))
    urp = "urp" in name
    if template.lower().find("urp") >= 0:
        s += 1 if urp else 0
    elif urp:
        s -= 2.5
    for w in set(re.findall(r"[a-z]{4,}", style)):
        if w in name:
            s += 0.8
    # need-specific sanity
    if need == "trees" and not re.search(r"vegetation", cat) and "nature" not in name:
        s -= 2
    if need == "enemies" and re.search(r"animal", name):
        if not re.search(r"animal|creature|beast|wolf|bear|deer|wildlife|hunt", style or ""):
            return -99  # human enemies must be rigged humanoids, never an animal pack
        s -= 1.5
    if need == "weapon_sfx" and not re.search(r"weapon", blob):
        s -= 3
    if need == "ambient" and "ambient" not in cat and not re.search(r"ambien|nature", name):
        s -= 3
    return s


def pick(need: str, template: str = "", style: str = "", n: int = 2) -> list[dict]:
    scored = [(_score(need, p, template, style), p) for p in catalog()]
    scored = [x for x in scored if x[0] > 2]
    scored.sort(key=lambda x: (-x[0], x[1].get("size_mb") or 0))
    out = []
    for _, p in scored:
        if p not in out:
            out.append(p)
        if len(out) >= n:
            break
    return out


def extras_from_brief(*texts: str) -> list[str]:
    blob = _words(" ".join(t or "" for t in texts))
    return [k for k, (_, rx, _, _) in EXTRA.items() if re.search(rx, blob)]


def pick_extra(key: str) -> list[dict]:
    label, _, pack_re, _ = EXTRA[key]
    hits = []
    for p in catalog():
        if re.search(r"complete projects|editor extensions|hdrp|interior", (p["name"] + " " + (p.get("category") or "")).lower()):
            continue
        if re.search(pack_re, p["name"].lower()):
            hits.append(p)
    hits.sort(key=lambda p: (p["kind"] != "unitypackage", p.get("size_mb") or 0))
    return hits[:1]


def store_url(label: str) -> str:
    return "https://assetstore.unity.com/search#q=" + quote_plus(label) + "&price=0-0"


def build_plan(family: str, brief: dict | None = None, template: str = "", choices: dict | None = None) -> dict:
    brief = brief or {}
    style = _words(" ".join(str(brief.get(k) or "") for k in ("setting", "style", "story", "loop", "display_title")))
    needs = FAMILY_NEEDS.get(family, DEFAULT_NEEDS)
    plan = {"family": family, "template": template, "made": datetime.now().isoformat(timespec="seconds"),
            "needs": {}, "extras": {}, "missing": [], "choices": dict(choices or {}),
            "family_known": family in FAMILY_NEEDS}
    for nd in needs:
        packs = pick(nd, template, style, n=2 if nd in ("trees", "grass", "buildings", "cover", "enemies", "weapons") else 1)
        plan["needs"][nd] = [{"name": p["name"], "publisher": p["publisher"], "path": p["path"], "kind": p["kind"],
                              "size_mb": p.get("size_mb")} for p in packs]
        if not packs:
            plan["missing"].append({"key": nd, "label": NEEDS[nd][0], "core": True})
    for ex in extras_from_brief(*(str(brief.get(k) or "") for k in ("setting", "style", "story", "loop", "goals"))):
        packs = pick_extra(ex)
        # brief extras already covered by a core need (house -> buildings, soldier -> enemies) only count when matched
        plan["extras"][ex] = [{"name": p["name"], "publisher": p["publisher"], "path": p["path"], "kind": p["kind"],
                               "size_mb": p.get("size_mb")} for p in packs]
        if not packs:
            plan["missing"].append({"key": ex, "label": EXTRA[ex][0], "core": False, "size": EXTRA[ex][3]})
    return plan


def unresolved(plan: dict) -> list[dict]:
    ch = plan.get("choices") or {}
    return [m for m in plan.get("missing") or [] if ch.get(m["key"]) not in ("blender", "placeholder")]


def missing_question(plan: dict, title: str = "your game") -> str:
    miss = unresolved(plan)
    if not miss:
        return ""
    lines = [f"Before I build {title}, here's what you don't have a pack for:"]
    for m in miss:
        lines.append(f"- You don't have a {m['label']} pack.")
    lines.append("")
    lines.append("For each one I can:")
    lines.append("1. Point you to free Asset Store packs for it (you download, then say \"rescan\")")
    lines.append("2. Make it in Blender and import it")
    lines.append("3. Use a simple placeholder for now")
    ex = miss[0]["label"]
    lines.append(f"Reply with a number or word for all of them (\"2\" / \"blender\"), or per item (\"{ex} blender\").")
    return "\n".join(lines)


def parse_choices(text: str, plan: dict) -> dict:
    """'2' / 'blender' / 'house blender, dragon placeholder' / 'store'."""
    t = (text or "").lower().strip()
    miss = unresolved(plan)
    out: dict = {}
    num = {"1": "store", "2": "blender", "3": "placeholder"}
    def _which(seg: str):
        s = seg.strip(" .!,;")
        if s in num:
            return num[s]
        m = re.search(r"\b([123])\b", s)
        for k in ("placeholder", "store", "blender"):  # "make it a placeholder" must not mean Blender
            if re.search(CHOICE_WORDS[k], s):
                return k
        return num[m.group(1)] if m else None
    # per-item
    for m in miss:
        lab = re.escape(m["label"].split()[0])
        mm = re.search(rf"{lab}s?\W+([a-z0-9 ]{{1,30}}?)(?:[,;.]|\band\b|$)", t) or re.search(rf"([a-z0-9 ]{{1,30}}?)\W+(?:for |the )?{lab}s?\b", t)
        if mm:
            c = _which(mm.group(1))
            if c:
                out[m["key"]] = c
    if not out:
        c = _which(t)
        if c:
            out = {m["key"]: c for m in miss}
    return out


def store_reply(plan: dict, keys: list[str]) -> str:
    lines = ["Here are free Asset Store searches:"]
    for m in plan.get("missing") or []:
        if m["key"] in keys:
            lines.append(f"- {m['label']}: {store_url(m['label'])}")
    lines.append("Add one to My Assets, then in Unity open Window > Package Manager > My Assets and click Download. "
                 "Say \"rescan\" when it's downloaded and I'll pick it up. Or say \"blender\" or \"placeholder\" instead.")
    return "\n".join(lines)


def summary_lines(plan: dict) -> str:
    out = []
    for nd, packs in (plan.get("needs") or {}).items():
        if packs:
            out.append(f"- {NEEDS[nd][0]}: " + ", ".join(p["name"] for p in packs))
    for ex, packs in (plan.get("extras") or {}).items():
        if packs:
            out.append(f"- {EXTRA[ex][0]}: " + ", ".join(p["name"] for p in packs))
    ch = plan.get("choices") or {}
    for m in plan.get("missing") or []:
        c = ch.get(m["key"])
        if c == "blender":
            out.append(f"- {m['label']}: made in Blender")
        elif c == "placeholder":
            out.append(f"- {m['label']}: placeholder (no pack)")
    return "\n".join(out)


CONFIRM_RX = re.compile(r"^\s*(yes|yep|yeah|y|ok(ay)?|sure|build( it)?|go( ahead)?|start( building)?|looks good|sounds good|do it|confirm(ed)?|that'?s? (fine|good|right))\b[\s.!]*$", re.I)


def confirm_text(plan: dict, title: str = "your game") -> str:
    """Echo the picks back and wait for an explicit yes before building."""
    lines = [f"Here's the asset plan for {title}:", summary_lines(plan) or "- (no packs needed)"]
    if not plan.get("family_known", True):
        lines.append("(I don't have a dedicated builder for this genre, so I planned the general set.)")
    lines.append("")
    lines.append('Say "build" to start, or tell me what to change (for example "trees placeholder" or "buildings blender").')
    return "\n".join(lines)


def save_plan(root: Path, plan: dict) -> Path:
    p = root / "Tools" / "asset_plan.json"
    p.parent.mkdir(parents=True, exist_ok=True)
    tmp = p.with_name(p.name + ".tmp")
    tmp.write_text(json.dumps(plan, indent=1), encoding="utf-8")
    os.replace(tmp, p)
    return p


def load_plan(root: Path) -> dict | None:
    p = root / "Tools" / "asset_plan.json"
    try:
        return json.loads(p.read_text(encoding="utf-8")) if p.is_file() else None
    except Exception:
        return None


# ------------------------------------------------------------------ chat replies

GROUPS = [
    ("Ground & terrain textures", r"textures|terrain|landscape|heightmap|ground"),
    ("Trees, grass & plants", r"vegetation|tree|grass|foliage|bush|plant|nature"),
    ("Buildings & environments", r"environment|urban|house|building|city|street|port|island|mansion"),
    ("Props", r"props(?!weapon)|furniture|tools|shelves|harbor|street props"),
    ("Characters & creatures", r"character|animal|humanoid"),
    ("Weapons", r"weapon|gun|rifle|pistol|grenade|bow"),
    ("Vehicles", r"vehicle|car|truck|pickup|sedan"),
    ("Audio", r"audio|sound|music|ambien"),
]


def _group_of(p: dict) -> str:
    name = p["name"].lower()
    blob = f"{p.get('category','')} {name}".lower()
    if re.search(r"audio|sound|music", blob):
        return "Audio"
    if re.search(r"weapon|\bgun|rifle|pistol|grenade|\bbow\b|crossbow|shotgun", blob):
        return "Weapons"
    if re.search(r"vehicle", blob):
        return "Vehicles"
    if re.search(r"character|animal|humanoid", blob):
        return "Characters & creatures"
    if re.search(r"vegetation|\btrees?\b|grass|foliage|bush|plant|conifer|nature starter", blob):
        return "Trees, grass & plants"
    if re.search(r"props", blob):
        return "Props"
    if re.search(r"textures|terrain|landscape|heightmap|ground", blob):
        return "Ground & terrain textures"
    if re.search(r"environment|urban|house|building|city|street|port|island|mansion", blob):
        return "Buildings & environments"
    return "Other"


def owned_list_text(full: bool = False) -> str:
    rows = catalog(refresh=True)
    store = [r for r in rows if r["kind"] == "unitypackage"]
    folders = [r for r in rows if r["kind"] == "folder"]
    if not rows:
        return ("I don't see any downloaded Unity Asset Store packs on this PC (checked %APPDATA%\\Unity\\Asset Store-5.x "
                "and Documents\\UnityProjects). In Unity: Window > Package Manager > My Assets > Download, then say \"rescan\".")
    groups: dict = {}
    for r in store:
        groups.setdefault(_group_of(r), []).append(r)
    lines = [f"You have {len(store)} downloaded Asset Store packs on this PC:"]
    order = [g for g, _ in GROUPS] + ["Other"]
    for g in order:
        items = groups.get(g) or []
        if not items:
            continue
        names = sorted(i["name"] for i in items)
        shown = names if full else names[:12]
        more = "" if len(names) == len(shown) else f" (+{len(names) - len(shown)} more)"
        lines.append(f"\n{g} ({len(names)}): " + ", ".join(shown) + more)
    if folders:
        byp: dict = {}
        for f in folders:
            byp.setdefault(f.get("project") or "?", []).append(f["name"])
        lines.append("\nAlso already inside your Unity projects (I copy from these, never change them):")
        for proj, names in byp.items():
            lines.append(f"- {proj}: " + ", ".join(sorted(names)[: (60 if full else 12)]))
    return "\n".join(lines)


def assets_reply(root: Path | None, text: str = "", title: str = "") -> str:
    """'my assets' / 'list all assets' / 'i have assets in unity' / 'use my assets' in a game chat."""
    t = (text or "").lower()
    full = bool(re.search(r"\ball\b|\bfull\b|\bevery|wrong|not right|that'?s not|those aren'?t|no\b", t))
    body = owned_list_text(full=full)
    if not root:
        return body
    plan = load_plan(root)
    use_now = bool(re.search(r"\buse\b|\bimport\b|\badd\b|\bput\b|\brebuild\b|\bapply\b", t))
    if plan is None or use_now or re.search(r"rescan|refresh|again|wrong|\bnot\b|n't", t):
        try:
            brief = json.loads((root / "Tools" / "game_brief.json").read_text(encoding="utf-8"))
        except Exception:
            brief = {}
        fam = brief.get("family") or ""
        if not fam:
            g = brief.get("genre") or ""
            if not g and (root / "Tools" / "genre.txt").is_file():
                g = (root / "Tools" / "genre.txt").read_text(encoding="utf-8").strip()
            try:
                from auto_studio import builder_family
                fam = builder_family(g or "fps")
            except Exception:
                fam = g or "fps"
        old = (plan or {}).get("choices") or {}
        plan = build_plan(fam, brief, (plan or {}).get("template", ""), old)
        save_plan(root, plan)
    nm = title or root.name
    lines = [body, "", f"For {nm} I'm using:", summary_lines(plan) or "- (nothing matched yet)"]
    miss = unresolved(plan)
    if miss:
        lines += ["", missing_question(plan, nm)]
    elif use_now:
        try:
            from auto_studio import queue_unity_rebuild
            queue_unity_rebuild(root)
            lines += ["", f"Importing those into {nm} and rebuilding now. I'll show the result when the build finishes."]
        except Exception as e:
            lines += ["", f"I couldn't start the rebuild: {e}"]
    else:
        lines += ["", "Say \"use my assets\" to import these and rebuild, or name a different pack for anything above."]
    return "\n".join(lines)


ASSET_PHRASE = re.compile(
    r"\b(my|our|owned|downloaded)\s+(assets?|packs?)\b|\blist\s+(all\s+)?(the\s+|my\s+)?(assets?|packs?)\b|"
    r"\bassets?\s+(in|from)\s+unity\b|\bi\s+(have|own|bought|got)\s+(assets?|packs?|.{0,20}\bassets?\b)|"
    r"\buse\s+(my|the|all)\s+(assets?|packs?)\b|\bwhat\s+assets?\b|\bshow\s+(me\s+)?(the\s+|my\s+)?assets?\b|"
    r"\brescan\b|\bscan\s+(my\s+)?(assets?|packs?)\b|\bimport\s+(my\s+)?(assets?|packs?)\b|\bunity\s+asset\s+store\b|"
    r"\b(are|is)\s*(not|n'?t)\s+(my\s+)?(assets?|packs?)\b|\bnot\s+(my\s+)?(assets?|packs?)\b|\bwrong\s+(assets?|packs?|list)\b",
    re.I)


def wants_assets(text: str) -> bool:
    return bool(ASSET_PHRASE.search(text or ""))


# ------------------------------------------------------------------ Blender for chosen needs

BLENDER_SIZE = {"building": 9.0, "car": 4.5, "big": 18.0, "creature": 3.0, "humanoid": 1.8, "prop": 1.0}


def find_blender() -> Path | None:
    for c in [Path(r"C:\Program Files\Blender Foundation")]:
        if c.is_dir():
            hits = sorted(c.glob("Blender*/blender.exe"), reverse=True)
            if hits:
                return hits[0]
    return None


def run_blender_needs(root: Path) -> list[str]:
    """Model every need the creator assigned to Blender (headless) -> Art/Blender/Exports/<Name>.fbx."""
    plan = load_plan(root) or {}
    ch = plan.get("choices") or {}
    want = [m for m in plan.get("missing") or [] if ch.get(m["key"]) == "blender"]
    log = []
    if not want:
        return log
    bl = find_blender()
    if not bl:
        return ["BLENDER missing - placeholders used for: " + ", ".join(m["label"] for m in want)]
    out = root / "Art" / "Blender" / "Exports"
    out.mkdir(parents=True, exist_ok=True)
    script = ROOT / "scripts" / "make_prop_generic.py"
    made = plan.setdefault("blender", {})
    for m in want:
        name = "GB_" + re.sub(r"[^A-Za-z0-9]+", "", m["label"].title())
        fbx = out / f"{name}.fbx"
        env = dict(os.environ, PROP_NAME=name, PROP_OUT=str(out), PROP_HINT=m["label"])
        try:
            r = subprocess.run([str(bl), "--background", "--factory-startup", "--python", str(script)], env=env,
                               capture_output=True, text=True, timeout=300, encoding="utf-8", errors="replace", creationflags=0x08000000)
            ok = fbx.is_file()
            log.append(f"BLENDER {m['label']} -> {fbx.name} exit={r.returncode} ok={ok}")
            if ok:
                made[m["key"]] = {"fbx": str(fbx), "unity": f"Assets/Art/Imports/Blender/{fbx.name}",
                                  "size": m.get("size") or "prop", "label": m["label"]}
                att = root / "ATTRIBUTION.md"
                if att.is_file() and fbx.name not in att.read_text(encoding="utf-8", errors="replace"):
                    with att.open("a", encoding="utf-8") as f:
                        f.write(f"| {m['label']} | Art/Blender/Exports/{fbx.name} | original (Game Bot Blender) | studio | original | "
                                f"{datetime.now():%Y-%m-%d} | modelled because no owned pack |\n")
        except Exception as e:
            log.append(f"BLENDER {m['label']} failed: {e}")
    save_plan(root, plan)
    return log


if __name__ == "__main__":
    if len(sys.argv) > 2 and sys.argv[1] == "blender":
        for line in run_blender_needs(Path(sys.argv[2])):
            print(line)
    elif len(sys.argv) > 1 and sys.argv[1] == "list":
        print(owned_list_text(full=True))
    else:
        fam = sys.argv[1] if len(sys.argv) > 1 else "fps"
        brief = {"setting": " ".join(sys.argv[2:])}
        pl = build_plan(fam, brief)
        print(summary_lines(pl))
        print(missing_question(pl, "Test"))


def choice_reply(root: Path | None, text: str, messages: list | None = None) -> str | None:
    """In an existing game chat, answer the missing-asset question (blender / placeholder / store / rescan)."""
    if not root:
        return None
    plan = load_plan(root)
    if not plan or not unresolved(plan):
        return None
    prev = next((str(m.get("content") or "") for m in reversed((messages or [])[:-1]) if m.get("role") == "assistant"), "")
    if "you don't have a pack for" not in prev and "Asset Store searches" not in prev:
        return None
    t = (text or "").lower()
    title = root.name
    if re.search(r"\b(rescan|scan again|refresh|downloaded|got it|done)\b", t):
        catalog(refresh=True)
        try:
            brief = json.loads((root / "Tools" / "game_brief.json").read_text(encoding="utf-8"))
        except Exception:
            brief = {}
        plan = build_plan(plan.get("family") or "fps", brief, plan.get("template", ""), plan.get("choices"))
        save_plan(root, plan)
        if unresolved(plan):
            return "I scanned again. " + missing_question(plan, title)
    else:
        ch = parse_choices(text, plan)
        if not ch:
            return None
        stores = [k for k, v in ch.items() if v == "store"]
        plan.setdefault("choices", {}).update({k: v for k, v in ch.items() if v != "store"})
        save_plan(root, plan)
        if stores:
            return store_reply(plan, stores)
        if unresolved(plan):
            return missing_question(plan, title)
    try:
        from auto_studio import queue_unity_rebuild
        queue_unity_rebuild(root)
    except Exception as e:
        return f"Got it, but I couldn't start the rebuild: {e}"
    return "Got it. Rebuilding with:\n" + summary_lines(plan) + "\nI'll show you the result when the build finishes."
