"""One provider layer for every chat, intake, and code-gen model call.

Supports:
  - Ollama (default gamebot-trained, or any installed model)
  - LM Studio / llama.cpp via a local OpenAI-compatible URL
  - Optional cloud: OpenAI, Anthropic, OpenRouter, xAI (user-entered key)

All paths have timeouts, retries, and a clear error if the model is
unreachable. Vulkan device-lost retries once at a lower context. An Ollama crash or
mid-request disconnect is detected, reported clearly, retried once, and the
model is reloaded with the edition num_ctx (not the 4096 default). API keys are never logged.
"""
from __future__ import annotations

import json
import os
import time
import urllib.error
import urllib.request
from typing import Any

import model_settings as MS
import secret_store as SS
import tool_parse as TP

DEFAULT_TIMEOUT = 300
RETRIES = 3
CLOUD_TIMEOUT = 120

# Friendly, no-secret errors
OLLAMA_DOWN = (
    "I can't reach the model server (Ollama). Open Ollama, or reinstall it, "
    "then send your message again."
)
COMPAT_DOWN = (
    "I can't reach the local model server at {url}. Start LM Studio or llama.cpp "
    "(OpenAI-compatible server) on that address, then send your message again. Nothing was built."
)
CLOUD_DOWN = (
    "I can't reach {name}. Check your internet connection and the API key in Settings, "
    "then send your message again. Nothing was built."
)
CLOUD_NO_KEY = (
    "No API key is saved for {name}. Open Settings, paste your key (it stays on this PC, "
    "encrypted), and try again. Cloud models send prompts off this PC. Nothing was built."
)
MODEL_MISSING = (
    "The selected model \"{name}\" is not available. Pick another model in Settings, "
    "or switch back to the Game Bot trained model. Nothing was built."
)
DEVICE_LOST_MSG = (
    "The graphics driver reset while running the local model (this can happen on some AMD cards). "
    "I retried with a smaller context window but it still failed. Close other GPU apps and try again, "
    "or pick a different model in Settings. Nothing was built."
)

DEVICE_LOST_MARKERS = (
    "vk_error_device_lost",
    "device lost",
    "device_lost",
    "vkqueuedevicelost",
    "vulkan error",
    "cuda error",
    "hdd error: failed to create context",  # not used; kept short
)


# Connection drops (Ollama killed / restarted mid-request) are not device-lost.
# Treat them separately so a retry reloads the edition num_ctx instead of lowering it to 4096.
CONNECTION_DROP_MARKERS = (
    "connection reset", "10054", "forcibly closed", "connection refused", "10061",
    "urlerror", "broken pipe", "winerror 10053", "10053", "remotely closed",
    "unexpected eof", "connection aborted", "connectionerror", "errno 10054",
    "failed to start",
)

OLLAMA_DROPPED_MSG = (
    "Ollama stopped or disconnected while I was answering. I restarted the model "
    "and retried once, but it still is not ready. Open Ollama and send your message again."
)
OLLAMA_RETRY_NOTE = (
    "Ollama stopped mid-answer, so I restarted it and retried your message.\n\n"
)


def is_device_lost(err: Any) -> bool:
    s = str(err or "").lower() + " " + repr(err).lower()
    return any(m in s for m in ("vk_error_device_lost", "device lost", "device_lost", "vkqueuedevicelost"))


def is_connection_drop(err: Any) -> bool:
    """True when Ollama (or the HTTP path to it) dropped mid-request — not a Vulkan device-lost."""
    if is_device_lost(err):
        return False
    s = str(err or "").lower() + " " + repr(err).lower()
    return any(m in s for m in CONNECTION_DROP_MARKERS)


def _annotate_drop_retry(data: dict) -> dict:
    if not isinstance(data, dict):
        return data
    msg = data.get("message")
    if not isinstance(msg, dict):
        return data
    content = str(msg.get("content") or "")
    if content and not content.startswith("Ollama stopped"):
        msg = dict(msg)
        msg["content"] = OLLAMA_RETRY_NOTE + content
        data = dict(data)
        data["message"] = msg
    return data


def lower_ctx(cur: int | None = None) -> int:
    """Drop num_ctx one step for an AMD retry. Never raises the 8 GB lock."""
    try:
        if cur is None:
            cur = int(os.environ.get("GAMEBOT_NUM_CTX") or 8192)
    except ValueError:
        cur = 8192
    nxt = 4096 if cur > 4096 else 2048 if cur > 2048 else 1024
    os.environ["GAMEBOT_NUM_CTX"] = str(nxt)
    return nxt


def _timeout_for(provider: str) -> int:
    if provider in MS.CLOUD_PROVIDERS:
        return CLOUD_TIMEOUT
    return DEFAULT_TIMEOUT


def _headers_without_secrets(headers: dict) -> dict:
    out = {}
    for k, v in (headers or {}).items():
        lk = k.lower()
        if lk in ("authorization", "x-api-key", "api-key"):
            out[k] = "[REDACTED]"
        else:
            out[k] = v
    return out


def _http_json(url: str, body: dict, headers: dict | None = None, timeout: float = DEFAULT_TIMEOUT) -> dict:
    raw = json.dumps(body).encode("utf-8")
    hdrs = {"Content-Type": "application/json", **(headers or {})}
    req = urllib.request.Request(url, data=raw, headers=hdrs, method="POST")
    try:
        with urllib.request.urlopen(req, timeout=timeout) as resp:
            return json.loads(resp.read().decode("utf-8", "replace") or "{}")
    except urllib.error.HTTPError as e:
        detail = e.read().decode("utf-8", "replace")[:800]
        detail = SS.redact_text(detail)
        raise RuntimeError(f"HTTP {e.code} from model server: {detail}") from None
    except Exception as e:
        raise RuntimeError(SS.redact_text(f"{type(e).__name__}: {e}")) from None


def _get_json(url: str, headers: dict | None = None, timeout: float = 8.0) -> dict:
    req = urllib.request.Request(url, headers=headers or {}, method="GET")
    try:
        with urllib.request.urlopen(req, timeout=timeout) as resp:
            return json.loads(resp.read().decode("utf-8", "replace") or "{}")
    except Exception as e:
        raise RuntimeError(SS.redact_text(f"{type(e).__name__}: {e}")) from None


def _compat_base(url: str) -> str:
    u = (url or MS.DEFAULT_COMPAT_URL).strip().rstrip("/")
    if not u.startswith(("http://", "https://")):
        u = "http://" + u
    if u.endswith("/chat/completions"):
        u = u[: -len("/chat/completions")]
    return u


def _openai_messages(messages: list[dict]) -> list[dict]:
    out = []
    for m in messages or []:
        if not isinstance(m, dict):
            continue
        role = m.get("role") or "user"
        item = {"role": role, "content": m.get("content") if m.get("content") is not None else ""}
        if role == "assistant" and m.get("tool_calls"):
            item["tool_calls"] = []
            for i, tc in enumerate(m["tool_calls"]):
                fn = (tc or {}).get("function") or tc or {}
                args = fn.get("arguments")
                if not isinstance(args, str):
                    args = json.dumps(args or {})
                item["tool_calls"].append({
                    "id": (tc or {}).get("id") or f"call_{i}",
                    "type": "function",
                    "function": {"name": fn.get("name") or "", "arguments": args},
                })
        if role == "tool":
            item["role"] = "tool"
            item["content"] = str(m.get("content") or "")
            if m.get("tool_call_id"):
                item["tool_call_id"] = m["tool_call_id"]
            elif m.get("name"):
                item["name"] = m["name"]
        out.append(item)
    return out


def _openai_tools(tools: list | None) -> list | None:
    if not tools:
        return None
    out = []
    for t in tools:
        if not isinstance(t, dict):
            continue
        if t.get("type") == "function" and isinstance(t.get("function"), dict):
            out.append(t)
        elif t.get("name"):
            out.append({"type": "function", "function": {
                "name": t.get("name"),
                "description": t.get("description") or "",
                "parameters": t.get("parameters") or t.get("input_schema") or {"type": "object", "properties": {}},
            }})
    return out or None


def _normalize_openai(data: dict) -> dict:
    choice = (data.get("choices") or [{}])[0]
    msg = choice.get("message") or {}
    content = msg.get("content") or ""
    if isinstance(content, list):
        content = "".join(str(p.get("text") or p) if isinstance(p, dict) else str(p) for p in content)
    native = {"role": "assistant", "content": content or "", "tool_calls": msg.get("tool_calls") or []}
    calls, _mal = TP.extract(native)
    if calls:
        native["tool_calls"] = calls
    elif not native.get("tool_calls"):
        native.pop("tool_calls", None)
    return {"message": native, "done": True, "provider": "openai_compat"}


def _anthropic_messages(messages: list[dict]) -> tuple[str, list[dict]]:
    system = []
    out = []
    for m in messages or []:
        role = m.get("role") or "user"
        content = m.get("content")
        if role == "system":
            system.append(str(content or ""))
            continue
        if role == "tool":
            out.append({"role": "user", "content": [{
                "type": "tool_result",
                "tool_use_id": m.get("tool_call_id") or m.get("id") or "tool",
                "content": str(content or ""),
            }]})
            continue
        if role == "assistant" and m.get("tool_calls"):
            blocks = []
            if content:
                blocks.append({"type": "text", "text": str(content)})
            for i, tc in enumerate(m["tool_calls"]):
                fn = (tc or {}).get("function") or tc or {}
                args = fn.get("arguments")
                if isinstance(args, str):
                    try:
                        args = json.loads(args)
                    except Exception:
                        args = {}
                blocks.append({
                    "type": "tool_use",
                    "id": (tc or {}).get("id") or f"call_{i}",
                    "name": fn.get("name") or "",
                    "input": args or {},
                })
            out.append({"role": "assistant", "content": blocks})
            continue
        if role not in ("user", "assistant"):
            role = "user"
        out.append({"role": role, "content": content if content is not None else ""})
    return "\n".join(system), out


def _anthropic_tools(tools: list | None) -> list | None:
    mapped = _openai_tools(tools)
    if not mapped:
        return None
    out = []
    for t in mapped:
        fn = t.get("function") or {}
        out.append({
            "name": fn.get("name"),
            "description": fn.get("description") or "",
            "input_schema": fn.get("parameters") or {"type": "object", "properties": {}},
        })
    return out


def _normalize_anthropic(data: dict) -> dict:
    blocks = data.get("content") or []
    texts, calls = [], []
    if isinstance(blocks, str):
        texts.append(blocks)
        blocks = []
    for blk in blocks:
        if not isinstance(blk, dict):
            continue
        if blk.get("type") == "text":
            texts.append(str(blk.get("text") or ""))
        elif blk.get("type") == "tool_use":
            calls.append({"function": {"name": blk.get("name"), "arguments": blk.get("input") or {}}})
    native = {"role": "assistant", "content": "".join(texts), "tool_calls": calls}
    if not calls:
        recovered, _ = TP.extract(native)
        if recovered:
            native["tool_calls"] = recovered
    if not native.get("tool_calls"):
        native.pop("tool_calls", None)
    return {"message": native, "done": True, "provider": "anthropic"}


def ensure_ready() -> tuple[bool, str]:
    """Check that the selected provider is reachable. Never auto-pulls a model."""
    s = MS.get()
    provider = s["provider"]
    if provider == "ollama":
        try:
            from ollama_ensure import ensure_model
            name = MS.active_model_name()
            return ensure_model(name)
        except Exception as e:
            return False, OLLAMA_DOWN + " " + SS.redact_text(str(e))
    if provider == "openai_compat":
        url = _compat_base(s["compat_url"])
        try:
            _get_json(url + "/models", timeout=5.0)
            return True, ""
        except Exception:
            return False, COMPAT_DOWN.format(url=url)
    name = {"openai": "OpenAI", "anthropic": "Anthropic", "openrouter": "OpenRouter", "xai": "xAI"}.get(provider, provider)
    if not SS.has_key(provider):
        return False, CLOUD_NO_KEY.format(name=name)
    return True, ""


def _chat_ollama(messages: list[dict], tools: list | None, options: dict, timeout: float) -> dict:
    from ollama_ensure import ensure_ollama, ollama_up, ollama_base
    if not ollama_up():
        ok, reason = ensure_ollama(timeout=30)
        if not ok:
            raise RuntimeError(f"Model server failed to start: {reason or OLLAMA_DOWN}")
    try:
        from editions import apply_to_agent_options
        opts = apply_to_agent_options({"temperature": 0.1, **(options or {})})
    except Exception:
        opts = {"temperature": 0.1, **(options or {})}
    body = {
        "model": MS.active_model_name(),
        "messages": messages,
        "stream": False,
        "keep_alive": "30m",
        "options": opts,
    }
    if tools:
        body["tools"] = tools
    data = _http_json(ollama_base() + "/api/chat", body, timeout=timeout)
    msg = data.get("message") or {}
    calls, _ = TP.extract(msg)
    if calls:
        msg = dict(msg)
        msg["tool_calls"] = calls
        data["message"] = msg
    data["done"] = True
    data["provider"] = "ollama"
    return data


def _chat_openai_compat(base: str, model: str, messages: list[dict], tools: list | None,
                        options: dict, headers: dict, timeout: float, provider: str) -> dict:
    body: dict[str, Any] = {
        "model": model,
        "messages": _openai_messages(messages),
        "temperature": float((options or {}).get("temperature", 0.1)),
        "stream": False,
    }
    ot = _openai_tools(tools)
    if ot:
        body["tools"] = ot
        body["tool_choice"] = "auto"
    data = _http_json(_compat_base(base) + "/chat/completions", body, headers=headers, timeout=timeout)
    out = _normalize_openai(data)
    out["provider"] = provider
    return out


def _chat_anthropic(model: str, messages: list[dict], tools: list | None, options: dict, timeout: float) -> dict:
    key = SS.get("anthropic")
    if not key:
        raise RuntimeError(CLOUD_NO_KEY.format(name="Anthropic"))
    system, msgs = _anthropic_messages(messages)
    body: dict[str, Any] = {
        "model": model or "claude-sonnet-4-5",
        "max_tokens": int((options or {}).get("num_predict") or 4096),
        "temperature": float((options or {}).get("temperature", 0.1)),
        "messages": msgs,
    }
    if system:
        body["system"] = system
    at = _anthropic_tools(tools)
    if at:
        body["tools"] = at
    headers = {
        "x-api-key": key,
        "anthropic-version": "2023-06-01",
    }
    data = _http_json("https://api.anthropic.com/v1/messages", body, headers=headers, timeout=timeout)
    return _normalize_anthropic(data)


def _cloud_headers(provider: str) -> dict:
    key = SS.get(provider)
    names = {"openai": "OpenAI", "openrouter": "OpenRouter", "xai": "xAI"}
    if not key:
        raise RuntimeError(CLOUD_NO_KEY.format(name=names.get(provider, provider)))
    if provider == "openai":
        return {"Authorization": f"Bearer {key}"}
    if provider == "openrouter":
        return {
            "Authorization": f"Bearer {key}",
            "HTTP-Referer": "https://gamebotstudio.com",
            "X-Title": "Game Bot",
        }
    if provider == "xai":
        return {"Authorization": f"Bearer {key}"}
    return {"Authorization": f"Bearer {key}"}


def _cloud_url(provider: str) -> str:
    return {
        "openai": "https://api.openai.com/v1",
        "openrouter": "https://openrouter.ai/api/v1",
        "xai": "https://api.x.ai/v1",
    }[provider]


def _cloud_default_model(provider: str) -> str:
    return {
        "openai": "gpt-4o-mini",
        "openrouter": "openai/gpt-4o-mini",
        "xai": "grok-4-fast",
        "anthropic": "claude-sonnet-4-5",
    }.get(provider, "")


def chat(messages: list[dict], tools: list | bool | None = None, options: dict | None = None,
         extra_opts: dict | None = None) -> dict:
    """Run one chat completion. `tools` is the Ollama/OpenAI tools list, or False/None to disable."""
    s = MS.get()
    provider = s["provider"]
    opts = {**(options or {}), **(extra_opts or {})}
    tool_list = None if tools in (False, None) else (tools if isinstance(tools, list) else None)
    timeout = _timeout_for(provider)
    last_err: Exception | None = None
    lost_retried = False
    drop_retried = False

    for attempt in range(RETRIES):
        try:
            if provider == "ollama":
                result = _chat_ollama(messages, tool_list, opts, timeout)
                return _annotate_drop_retry(result) if drop_retried else result
            if provider == "openai_compat":
                model = MS.active_model_name()
                return _chat_openai_compat(s["compat_url"], model, messages, tool_list, opts, {}, timeout, "openai_compat")
            if provider == "anthropic":
                model = MS.active_model_name() or _cloud_default_model("anthropic")
                return _chat_anthropic(model, messages, tool_list, opts, timeout)
            if provider in ("openai", "openrouter", "xai"):
                model = MS.active_model_name() or _cloud_default_model(provider)
                return _chat_openai_compat(
                    _cloud_url(provider), model, messages, tool_list, opts,
                    _cloud_headers(provider), timeout, provider,
                )
            raise RuntimeError(f"Unknown model provider: {provider}")
        except Exception as e:
            last_err = e
            if is_connection_drop(e) and not drop_retried and provider == "ollama":
                drop_retried = True
                time.sleep(1.0)
                try:
                    from ollama_ensure import ensure_ollama, keep_model_loaded
                    ensure_ollama(timeout=30)
                    keep_model_loaded(indefinite=False)
                except Exception:
                    pass
                continue
            if is_device_lost(e) and not lost_retried and provider == "ollama":
                lost_retried = True
                new_ctx = lower_ctx(opts.get("num_ctx"))
                opts["num_ctx"] = new_ctx
                # Give the driver / Ollama a moment, then retry with the smaller window.
                time.sleep(2.0)
                try:
                    from ollama_ensure import ensure_ollama
                    ensure_ollama(timeout=30)
                except Exception:
                    pass
                continue
            if attempt + 1 < RETRIES and not _fatal_client_error(e):
                time.sleep(1.5 * (attempt + 1))
                continue
            break
    raise _friendly(last_err, provider, s) if last_err else RuntimeError("Model chat failed")


def _fatal_client_error(err: Exception) -> bool:
    s = str(err or "")
    if s.startswith("No API key") or "HTTP 401" in s or "HTTP 403" in s:
        return True
    if "not available" in s.lower() and "model" in s.lower():
        return True
    return False


def _friendly(err: Exception, provider: str, s: dict) -> RuntimeError:
    msg = SS.redact_text(str(err))
    if is_device_lost(err):
        return RuntimeError(DEVICE_LOST_MSG)
    if provider == "ollama":
        if is_connection_drop(err):
            return RuntimeError(OLLAMA_DROPPED_MSG)
        low = msg.lower()
        if "failed to start" in low or "10061" in low or "connection refused" in low or "urlerror" in low:
            if str(err).startswith("Model server failed to start:"):
                return RuntimeError(str(err))
            return RuntimeError(OLLAMA_DROPPED_MSG)
        if "not found" in low and "model" in low:
            return RuntimeError(MODEL_MISSING.format(name=MS.active_model_name()))
        return RuntimeError(msg)
    if provider == "openai_compat":
        return RuntimeError(COMPAT_DOWN.format(url=_compat_base(s.get("compat_url") or "")))
    name = {"openai": "OpenAI", "anthropic": "Anthropic", "openrouter": "OpenRouter", "xai": "xAI"}.get(provider, provider)
    if "No API key" in msg:
        return RuntimeError(CLOUD_NO_KEY.format(name=name))
    return RuntimeError(CLOUD_DOWN.format(name=name) + " " + msg)


def allowed_tool_names(tools: list | None) -> set[str] | None:
    if not tools:
        return None
    names = set()
    for t in tools:
        if isinstance(t, dict):
            n = t.get("function", {}).get("name") if isinstance(t.get("function"), dict) else t.get("name")
            if n:
                names.add(n)
    return names or None
