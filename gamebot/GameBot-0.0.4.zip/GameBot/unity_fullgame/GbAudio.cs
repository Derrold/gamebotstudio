using UnityEngine;

/// <summary>Game sound: gunfire, reload, hits, enemy, ambient loop. Clips come from the creator's owned audio packs
/// (SceneBuilder.WorldAudio) or Game Bot's generated fallback clips, so a build is never silent.</summary>
public class GbAudio : MonoBehaviour
{
    public AudioClip fire, reload, hit, enemy, ambient;
    public static GbAudio I;
    AudioSource one, amb;
    void Awake()
    {
        I = this;
        var srcs = GetComponents<AudioSource>();
        one = srcs.Length > 0 ? srcs[0] : gameObject.AddComponent<AudioSource>();
        amb = srcs.Length > 1 ? srcs[1] : gameObject.AddComponent<AudioSource>();
        one.playOnAwake = false; one.spatialBlend = 0f;
        amb.clip = ambient; amb.loop = true; amb.spatialBlend = 0f; if (amb.volume <= 0f) amb.volume = 0.35f;
        if (ambient && !amb.isPlaying) amb.Play();
        if (FindAnyObjectByType<AudioListener>() == null) { var c = Camera.main; (c ? c.gameObject : gameObject).AddComponent<AudioListener>(); }
    }
    AudioClip Get(string k)
    {
        switch (k) { case "fire": return fire; case "reload": return reload; case "hit": return hit; case "enemy": return enemy; case "ambient": return ambient; }
        return null;
    }
    public static void Play(string k, float vol = 1f) { if (I == null) return; var c = I.Get(k); if (c) I.one.PlayOneShot(c, vol); }
    public static void PlayAt(string k, Vector3 p, float vol = 1f) { if (I == null) return; var c = I.Get(k); if (c) AudioSource.PlayClipAtPoint(c, p, vol); }
}
