using UnityEngine;
/// <summary>Battle royale rival: roams inside the safe zone, fights the player and other bots with hitscan, loots, takes storm damage.</summary>
public class BrBot : MonoBehaviour, IGbDamage
{
    public int hp = 100, team = 2; public float speed = 4f, sight = 32f; public string tag2 = "Rival";
    Vector3 dest; float nextShot, nextDest, armedAt = -1f; IGbDamage target; bool dead; LineRenderer tr; float trOff; Transform player;
    public int Team => team; public bool Dead => dead || this == null; public Transform Tr => this ? transform : null;
    void OnEnable() { GbCombat.All.Add(this); }
    void OnDisable() { GbCombat.All.Remove(this); }
    void Start() { player = GameObject.FindGameObjectWithTag("Player")?.transform; dest = transform.position; tr = gameObject.AddComponent<LineRenderer>(); tr.positionCount = 2; tr.startWidth = 0.04f; tr.endWidth = 0.01f; tr.material = new Material(Shader.Find("Sprites/Default")); tr.startColor = tr.endColor = new Color(1f, 0.6f, 0.2f); tr.enabled = false; }
    public void Damage(int amount, int fromTeam)
    {
        if (dead) return; hp -= amount; if (hp > 0) return; dead = true; GenreState.Alive--;
        if (fromTeam == 0) { GenreState.Kills++; AchievementSystem.NotifyKill(GenreState.Kills, 11); GameHUD.Flash("Eliminated " + name + " - " + GenreState.Alive + " left"); } else GameHUD.Flash(name + " was eliminated - " + GenreState.Alive + " left");
        if (GenreState.Alive <= 0) { AchievementSystem.Unlock("victory_royale"); GenreState.Win(); }
        Destroy(gameObject);
    }
    void Update()
    {
        if (GameState.Won || GameState.Lost || PauseMenu.IsPaused || MainMenuUI.InMenu || dead) return;
        if (Time.time > trOff) tr.enabled = false;
        if (armedAt < 0f) armedAt = Time.time + 12f; // drop-in grace: bots ignore the player for the first 12 s of play
        if (StormZone.I && StormZone.I.Outside(transform.position)) { if (Random.value < Time.deltaTime * 2f) Damage(StormZone.I.Dps, 9); dest = StormZone.I.center; }
        if (target == null || target.Dead || target.Tr == null || Vector3.Distance(target.Tr.position, transform.position) > sight) target = null;
        if (target == null)
        {
            IGbDamage best = GbCombat.Nearest(transform.position, sight, u => (object)u != this && u.Team != team);
            float pd = player ? Vector3.Distance(player.position, transform.position) : 999f;
            if (player && Time.time >= armedAt && pd < sight && (best == null || pd < Vector3.Distance(best.Tr.position, transform.position))) { Engage(player.position, true); return; }
            target = best;
        }
        if (target != null) { Engage(target.Tr.position, false); return; }
        if (Time.time > nextDest || (dest - transform.position).magnitude < 1f) { nextDest = Time.time + 8f; var c = StormZone.I ? StormZone.I.center : Vector3.zero; float r = StormZone.I ? StormZone.I.radius * 0.7f : 40f; var rp = Random.insideUnitCircle * r; dest = new Vector3(c.x + rp.x, transform.position.y, c.z + rp.y); }
        Move(dest);
    }
    void Engage(Vector3 pos, bool isPlayer)
    {
        Vector3 to = pos - transform.position; to.y = 0; if (to.sqrMagnitude > 0.01f) transform.rotation = Quaternion.LookRotation(to);
        if (to.magnitude > 14f) Move(pos); else if (to.magnitude < 6f) Move(transform.position - to.normalized * 3f);
        if (Time.time < nextShot) return; nextShot = Time.time + Random.Range(0.45f, 0.9f);
        Vector3 eye = transform.position + Vector3.up * 1.4f, aim = pos + Vector3.up * 1.2f;
        if (Physics.Raycast(eye, (aim - eye).normalized, out var hit, sight, ~0, QueryTriggerInteraction.Ignore) && !(isPlayer ? hit.collider.CompareTag("Player") : (target != null && hit.collider.transform.IsChildOf(target.Tr)))) return; // no line of sight
        tr.SetPosition(0, eye); tr.SetPosition(1, aim); tr.enabled = true; trOff = Time.time + 0.06f;
        if (Random.value < 0.33f) { int d = Random.Range(6, 13); if (isPlayer) GbCombat.HurtPlayer(d); else target?.Damage(d, team); }
    }
    void Move(Vector3 p) { Vector3 to = p - transform.position; to.y = 0; if (to.magnitude < 0.2f) return; transform.position += to.normalized * speed * Time.deltaTime; }
}
