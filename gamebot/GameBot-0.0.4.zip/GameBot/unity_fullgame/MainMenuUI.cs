﻿using UnityEngine;
using UnityEngine.SceneManagement;

/// <summary>Main menu: Start / Continue / Settings / Quit + full Settings (video/audio/controls).</summary>
public class MainMenuUI : MonoBehaviour
{
    public static bool InMenu = true;
    enum Panel { Main, Settings, Achievements, Story }
    Panel panel = Panel.Main;
    int tab; // 0 video 1 audio 2 controls
    Vector2 scroll;
    string waitingRebind; // which key slot
    string story => GenreState.Story();

    void Start()
    {
        InMenu = true;
        Time.timeScale = 1f;
        Cursor.lockState = CursorLockMode.None;
        Cursor.visible = true;
        GameSettings.LoadAndApply();
        AchievementSystem.Load();
    }

    void OnGUI()
    {
        float W = Screen.width, H = Screen.height;
        var box = new Rect(W * 0.2f, H * 0.08f, W * 0.6f, H * 0.84f);
        GUI.Box(box, "");
        GUILayout.BeginArea(new Rect(box.x + 24, box.y + 24, box.width - 48, box.height - 48));
        var title = new GUIStyle(GUI.skin.label) { fontSize = 36, fontStyle = FontStyle.Bold, alignment = TextAnchor.MiddleCenter };
        var btn = new GUIStyle(GUI.skin.button) { fontSize = 22, fixedHeight = 44 };
        var lab = new GUIStyle(GUI.skin.label) { fontSize = 18 };

        if (panel == Panel.Main)
        {
            GUILayout.Label(GenreState.Name, title);
            GUILayout.Space(12);
            // tagline = the creator's core loop from intake (was a hard-coded platformer line for every genre)
            string tag = !string.IsNullOrEmpty(GenreState.BriefLoop) ? GenreState.BriefLoop : (GenreState.Family == "platformer" ? "A short 3D platformer trail run — collect, dodge, summit." : "");
            if (tag.Length > 0) GUILayout.Label(tag, lab);
            GUILayout.Space(20);
            if (GUILayout.Button("Start", btn)) { GameState.ResetRun(); GameState.ClearContinue(); InMenu = false; SceneManager.LoadScene("Game"); }
            GUI.enabled = GameState.HasContinue();
            if (GUILayout.Button("Continue", btn)) { GameState.LoadContinue(); InMenu = false; SceneManager.LoadScene("Game"); }
            GUI.enabled = true;
            if (GUILayout.Button("Settings", btn)) panel = Panel.Settings;
            if (GUILayout.Button("Achievements", btn)) panel = Panel.Achievements;
            if (GUILayout.Button("Story / Goals", btn)) panel = Panel.Story;
            if (GUILayout.Button("Quit", btn)) Application.Quit();
        }
        else if (panel == Panel.Story)
        {
            GUILayout.Label("Story & Goals", title);
            GUILayout.Space(8);
            scroll = GUILayout.BeginScrollView(scroll);
            GUILayout.Label(story, lab);
            GUILayout.EndScrollView();
            if (GUILayout.Button("Back", btn)) panel = Panel.Main;
        }
        else if (panel == Panel.Achievements)
        {
            GUILayout.Label("Achievements", title);
            GUILayout.Space(8);
            foreach (var a in AchievementSystem.ForMode())
            {
                string mark = a.Unlocked ? "[UNLOCKED] " : "[locked] ";
                GUILayout.Label(mark + a.Title + " — " + a.Desc, lab);
            }
            GUILayout.FlexibleSpace();
            if (GUILayout.Button("Back", btn)) panel = Panel.Main;
        }
        else DrawSettings(btn, lab);
        GUILayout.EndArea();
    }

    void DrawSettings(GUIStyle btn, GUIStyle lab)
    {
        GUILayout.Label("Settings", new GUIStyle(GUI.skin.label){fontSize=32,fontStyle=FontStyle.Bold});
        GUILayout.BeginHorizontal();
        if (GUILayout.Button("Video", btn)) tab = 0;
        if (GUILayout.Button("Audio", btn)) tab = 1;
        if (GUILayout.Button("Controls", btn)) tab = 2;
        GUILayout.EndHorizontal();
        GUILayout.Space(10);
        if (tab == 0)
        {
            GUILayout.Label("Resolution: " + GameSettings.Width + "x" + GameSettings.Height, lab);
            if (GUILayout.Button("1920x1080", btn)) { GameSettings.Width = 1920; GameSettings.Height = 1080; }
            if (GUILayout.Button("1280x720", btn)) { GameSettings.Width = 1280; GameSettings.Height = 720; }
            if (GUILayout.Button("2560x1440", btn)) { GameSettings.Width = 2560; GameSettings.Height = 1440; }
            GameSettings.Fullscreen = GUILayout.Toggle(GameSettings.Fullscreen, " Fullscreen", lab);
            GameSettings.VSync = GUILayout.Toggle(GameSettings.VSync, " VSync", lab);
            GUILayout.Label("Quality: " + QualitySettings.names[Mathf.Clamp(GameSettings.Quality,0,QualitySettings.names.Length-1)], lab);
            GameSettings.Quality = Mathf.RoundToInt(GUILayout.HorizontalSlider(GameSettings.Quality, 0, QualitySettings.names.Length - 1));
        }
        else if (tab == 1)
        {
            GUILayout.Label("Master " + GameSettings.MasterVol.ToString("0.00"), lab);
            GameSettings.MasterVol = GUILayout.HorizontalSlider(GameSettings.MasterVol, 0f, 1f);
            GUILayout.Label("Music " + GameSettings.MusicVol.ToString("0.00"), lab);
            GameSettings.MusicVol = GUILayout.HorizontalSlider(GameSettings.MusicVol, 0f, 1f);
            GUILayout.Label("SFX " + GameSettings.SfxVol.ToString("0.00"), lab);
            GameSettings.SfxVol = GUILayout.HorizontalSlider(GameSettings.SfxVol, 0f, 1f);
        }
        else
        {
            GUILayout.Label("Look sensitivity " + GameSettings.LookSens.ToString("0.0"), lab);
            GameSettings.LookSens = GUILayout.HorizontalSlider(GameSettings.LookSens, 0.5f, 8f);
            KeyRow("Forward", "fwd", () => GameSettings.KeyForward, k => GameSettings.KeyForward = k, lab, btn);
            KeyRow("Back", "back", () => GameSettings.KeyBack, k => GameSettings.KeyBack = k, lab, btn);
            KeyRow("Left", "left", () => GameSettings.KeyLeft, k => GameSettings.KeyLeft = k, lab, btn);
            KeyRow("Right", "right", () => GameSettings.KeyRight, k => GameSettings.KeyRight = k, lab, btn);
            KeyRow("Jump", "jump", () => GameSettings.KeyJump, k => GameSettings.KeyJump = k, lab, btn);
            KeyRow("Pause", "pause", () => GameSettings.KeyPause, k => GameSettings.KeyPause = k, lab, btn);
            if (!string.IsNullOrEmpty(waitingRebind))
            {
                GUILayout.Label("Press a key for " + waitingRebind + "...", lab);
                Event e = Event.current;
                if (e.isKey && e.type == EventType.KeyDown && e.keyCode != KeyCode.None)
                {
                    ApplyRebind(e.keyCode);
                    waitingRebind = null;
                    e.Use();
                }
            }
        }
        GUILayout.FlexibleSpace();
        GUILayout.BeginHorizontal();
        if (GUILayout.Button("Apply", btn)) { GameSettings.ApplyAll(); }
        if (GUILayout.Button("Back", btn)) panel = Panel.Main;
        GUILayout.EndHorizontal();
    }

    void KeyRow(string label, string id, System.Func<KeyCode> get, System.Action<KeyCode> set, GUIStyle lab, GUIStyle btn)
    {
        GUILayout.BeginHorizontal();
        GUILayout.Label(label + ": " + get(), lab, GUILayout.Width(280));
        if (GUILayout.Button("Rebind", btn, GUILayout.Width(120))) waitingRebind = id;
        GUILayout.EndHorizontal();
        // stash setter via id
        if (waitingRebind == null) { /* no-op */ }
        _setters[id] = set;
    }
    readonly System.Collections.Generic.Dictionary<string, System.Action<KeyCode>> _setters = new System.Collections.Generic.Dictionary<string, System.Action<KeyCode>>();
    void ApplyRebind(KeyCode k) { if (_setters.TryGetValue(waitingRebind, out var s)) s(k); }
}

