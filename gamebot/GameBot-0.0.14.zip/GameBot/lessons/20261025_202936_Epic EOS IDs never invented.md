# Epic EOS IDs never invented

Tags: epic eos
Saved: 2026-10-25T20:29:36

EGS upload via BuildPatchTool to sandbox Dev->Stage->Live; EOS needs ProductId/SandboxId/DeploymentId/Client creds from the creator's portal - never invent. Source: https://dev.epicgames.com/docs/epic-online-services
