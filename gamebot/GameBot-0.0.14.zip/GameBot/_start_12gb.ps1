$env:GAMEBOT_EDITION_LOCK='12gb'
$env:GAMEBOT_EDITION='12gb'
$env:OLLAMA_MODEL='gamebot-12gb'
Set-Location C:\Users\ExtremeHybrid\ollama-web
Start-Process -FilePath "$env:LOCALAPPDATA\Programs\Python\Python312\pythonw.exe" -ArgumentList 'desktop_window.py' -WorkingDirectory 'C:\Users\ExtremeHybrid\ollama-web'
