﻿# Project hygiene
.gitignore Library/Temp/obj; Git LFS for FBX/PNG/WAV; never commit secrets or AppIDs passwords; backup before batchmode bake.
