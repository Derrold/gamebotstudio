using UnityEngine;
/// <summary>Harvestable tree/rock for sandbox: E gives blocks, regrows after a while.</summary>
public class SandboxNode : MonoBehaviour
{
    public int yield = 8, uses = 3; Vector3 baseScale;
    void Start() { baseScale = transform.localScale; }
    public void Harvest() { if (uses <= 0) return; uses--; GenreState.Blocks += yield; AchievementSystem.Unlock("harvest"); GameHUD.Flash("+" + yield + " blocks (" + GenreState.Blocks + ")"); transform.localScale = baseScale * (0.6f + 0.13f * uses); if (uses <= 0) Invoke(nameof(Regrow), 40f); }
    void Regrow() { uses = 3; transform.localScale = baseScale; }
}
