# unity custom item weapon pipeline

Tags: unity-custom-item-weapon-pipeline
Saved: 2026-10-25T20:48:54

﻿# Unity custom item / weapon pipeline (generic)
1. Blender FBX under Assets/Models/<Type>/<Id>/
2. ScriptableObject or codegen registration
3. Prefab + UI/shop unlock same id
4. batchmode -executeMethod bake; research_error on CS errors
5. Use config projects_root — never hardcode another studio path
