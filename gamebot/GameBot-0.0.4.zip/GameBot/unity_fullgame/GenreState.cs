using UnityEngine;

/// <summary>Per-genre runtime state (mode baked into scene by SceneBuilder via GenreConfig).</summary>
public static partial class GenreState
{
    public static string Mode = "platformer";   // intake genre id the creator picked (open_world, survival, ...)
    public static string Family = "platformer"; // gameplay template that implements it
    public static string Title = "";
    // Creator's intake brief (story / goals / setting / loop / tone) - drives intro, objectives, win text
    public static string BriefStory = "", BriefSetting = "", BriefLoop = "", BriefStyle = "";
    public static string[] BriefGoals = new string[0];
    public static bool HasBrief => !string.IsNullOrEmpty(BriefStory) || (BriefGoals != null && BriefGoals.Length > 0);
    // FPS
    public static int Kills, EnemiesTotal, Ammo, Reserve, MagSize = 12, Health = 100;
    // Racing
    public static int Lap, TotalLaps = 3, NextCheckpoint, CheckpointCount;
    public static float RaceTime, BestLap = -1f, LapStart;
    public static float SpeedKmh;
    // Shared loop stats for the 7 extra genres
    public static int Items, ItemsTotal, Xp, Level = 1, Pads, PadsTotal, Wood, Food, Cash, Stock, Sales, Wave, WavesTotal = 3, Alive;
    public static float Battery = 100f, Hunger = 100f, TimeLeft, Fear;
    public static bool HasKey, QuestTaken, FireBuilt;
    public static int CashGoal = 300;
    public static bool IsHorror => Family == "horror"; public static bool IsRpg => Family == "rpg"; public static bool IsPuzzle => Family == "puzzle";
    public static bool IsSurvival => Family == "survival"; public static bool IsAdventure => Family == "adventure"; public static bool IsSim => Family == "sim"; public static bool IsRogue => Family == "roguelike";
    public static void AddXp(int x) { Xp += x; while (Xp >= Level * 100) { Xp -= Level * 100; Level++; AchievementSystem.Unlock("level_up"); } }
    public static void Item(string kind)
    {
        Items++;
        if (IsHorror) { AchievementSystem.Unlock("fuse_first"); }
        if (IsRpg) { AddXp(60); AchievementSystem.Unlock("relic_first"); }
        if (IsAdventure && kind == "key") { HasKey = true; AchievementSystem.Unlock("found_key"); }
        if (IsAdventure && kind != "key") AchievementSystem.Unlock("explorer");
        if (IsStealth) { AchievementSystem.Unlock("intel_first"); GameHUD.Flash("Intel " + Items + "/" + ItemsTotal + (Items >= ItemsTotal ? " - get to extraction!" : "")); }
        if (IsMmo && kind == "herb") { Items--; Herbs++; AddXp(25); MmoQuestCheck(); }
        if (IsBR) Items--;
    }
    public static bool IsFps => Family == "fps";
    public static bool IsRacing => Family == "racing";
    public static void ResetMode()
    {
        Kills = 0; Ammo = MagSize; Reserve = 60; Health = 100;
        Lap = 0; NextCheckpoint = 0; RaceTime = 0f; LapStart = 0f; SpeedKmh = 0f;
        Items = 0; Xp = 0; Level = 1; Pads = 0; Wood = 0; Food = 0; Cash = 0; Stock = 5; Sales = 0; Wave = 0; Alive = 0;
        Battery = 100f; Hunger = 100f; Fear = 0f; HasKey = false; QuestTaken = false; FireBuilt = false;
        TimeLeft = Family == "survival" ? 120f : 0f; _goalIdx = 0;
        ResetExtra();
    }
    public static string Name => string.IsNullOrEmpty(Title) ? Application.productName : Title;
    static string CannedStory()
    {
        var xs = ExtraStory(); if (xs != null) return xs;
        string n = Name.ToUpper();
        if (IsFps) return n + "\n\nA rogue drone swarm has seized the outpost. You are the last operator inside.\n" +
            "Mouse to aim, Left Click to fire, R to reload. Grab yellow ammo crates.\n\nGoals:\n- Eliminate every hostile drone\n- Do not let your health hit zero\n- Sector Clear: wipe the zone\n\nPress Start when ready.";
        if (IsRacing) return n + "\n\nThe ridge circuit is open. Three laps, every checkpoint, no shortcuts.\n" +
            "W/S throttle and brake, A/D steer, Space handbrake, R reset to last checkpoint.\n\nGoals:\n- Pass every checkpoint gate in order\n- Finish " + TotalLaps + " laps\n- Ridge Runner: lap under 45s\n\nPress Start when ready.";
        if (IsHorror) return n + "\n\nThe power died in the east wing. Something walks the halls when the lights are out.\n" +
            "WASD move, mouse look, F flashlight (battery drains). Stay out of its reach.\n\nGoals:\n- Find all fuses (" + ItemsTotal + ")\n- Reach the exit door once power is back\n- Lights Out: escape without dying\n\nPress Start when ready.";
        if (IsRpg) return n + "\n\nThe village elder needs a hero. Ember relics are scattered across the vale.\n" +
            "WASD move, walk up to the elder to talk. Relics give XP; levels raise your power.\n\nGoals:\n- Accept the elder's quest\n- Recover every relic (" + ItemsTotal + ")\n- Return to the elder to complete the quest\n\nPress Start when ready.";
        if (IsPuzzle) return n + "\n\nAn ancient vault opens only when every stone rests on its glyph.\n" +
            "Walk into a block to push it one tile. R resets the room.\n\nGoals:\n- Push all blocks onto glowing pads (" + PadsTotal + ")\n- Solve the room to win\n\nPress Start when ready.";
        if (IsSurvival) return n + "\n\nStranded at dusk. The cold comes in two minutes.\n" +
            "Walk over trees for wood and bushes for food. Press C with 5 wood to build a campfire. Hunger drains over time.\n\nGoals:\n- Build a campfire\n- Do not starve\n- Survive until dawn\n\nPress Start when ready.";
        if (IsAdventure) return n + "\n\nThe old map points to a sealed shrine beyond the gate.\n" +
            "Follow the objective marker. Find the gate key, explore the ruins, open the gate.\n\nGoals:\n- Find the gate key\n- Open the sealed gate\n- Reach the shrine\n\nPress Start when ready.";
        if (IsSim) return n + "\n\nYour first day running the shop. Customers are lining up.\n" +
            "Stand behind the counter to serve customers. Walk to the stock crates to restock shelves.\n\nGoals:\n- Serve customers (each sale +$25)\n- Keep stock above zero\n- Earn $" + CashGoal + " to win the day\n\nPress Start when ready.";
        if (IsRogue) return n + "\n\nOne life. Every run the dungeon reshuffles.\n" +
            "Mouse aim, Left Click fire, R reload. Clear each wave to open the next.\n\nGoals:\n- Survive " + WavesTotal + " waves\n- Permadeath: die once and the run is over\n\nPress Start when ready.";
        return n + "\n\nYou are a trail runner racing the mountain ridge.\nCollect coins, avoid hazard pits, reach the summit flag.\n\n" +
            "Goals:\n- Collect coins for score\n- Reach the end flag to win\n- Clean Trail: finish with zero deaths\n\nPress Start when ready.";
    }
    static string CannedObjective()
    {
        var xo = ExtraObjective(); if (xo != null) return xo;
        if (IsFps) return "Objective: eliminate all enemies (" + Kills + "/" + EnemiesTotal + ")";
        if (IsRacing) return "Objective: complete " + TotalLaps + " laps - next checkpoint " + (NextCheckpoint == 0 ? "FINISH" : NextCheckpoint.ToString());
        if (IsHorror) return "Objective: find fuses " + Items + "/" + ItemsTotal + (Items >= ItemsTotal ? " - power restored, reach the EXIT" : "");
        if (IsRpg) return !QuestTaken ? "Objective: talk to the village elder" : Items < ItemsTotal ? "Objective: recover relics " + Items + "/" + ItemsTotal : "Objective: return to the elder";
        if (IsPuzzle) return "Objective: blocks on pads " + Pads + "/" + PadsTotal;
        if (IsSurvival) return "Objective: " + (FireBuilt ? "keep fed until dawn" : "gather 5 wood and press C to build a fire") + " - dawn in " + Mathf.CeilToInt(TimeLeft) + "s";
        if (IsAdventure) return HasKey ? "Objective: open the gate and reach the shrine (marker)" : "Objective: find the gate key (marker)";
        if (IsSim) return "Objective: earn $" + CashGoal + " - cash $" + Cash + "  stock " + Stock + (Stock == 0 ? " - RESTOCK!" : "");
        if (IsRogue) return "Objective: wave " + Wave + "/" + WavesTotal + " - hostiles left " + Alive;
        return "Objective: collect coins, avoid red hazards, reach the green summit flag";
    }
    static string CannedWinText()
    {
        var xw = ExtraWin(); if (xw != null) return xw;
        if (IsFps) return "SECTOR CLEAR!\nHostiles down: " + Kills + "  Deaths: " + GameState.Deaths;
        if (IsRacing) return "RACE COMPLETE!\nTotal time: " + RaceTime.ToString("0.00") + "s  Best lap: " + BestLap.ToString("0.00") + "s";
        if (IsHorror) return "YOU ESCAPED!\nFuses: " + Items + "  Deaths: " + GameState.Deaths;
        if (IsRpg) return "QUEST COMPLETE!\nLevel " + Level + "  Relics: " + Items;
        if (IsPuzzle) return "VAULT SOLVED!\nPads: " + Pads + "/" + PadsTotal;
        if (IsSurvival) return "DAWN BREAKS - YOU SURVIVED!\nWood: " + Wood + "  Food: " + Food;
        if (IsAdventure) return "SHRINE REACHED!\nTreasures found: " + Items;
        if (IsSim) return "DAY COMPLETE!\nCash $" + Cash + "  Sales: " + Sales;
        if (IsRogue) return "RUN CLEARED!\nWaves: " + WavesTotal + "  Kills: " + Kills;
        return "YOU WIN - Summit reached!\nCoins: " + GameState.Coins + "  Deaths: " + GameState.Deaths;
    }
    public static void Win()
    {
        if (GameState.Won) return;
        GameState.Won = true;
        for (int i = 0; i < (BriefGoals == null ? 0 : BriefGoals.Length); i++) AchievementSystem.UnlockGoal(i);
        AchievementSystem.NotifyGoal();
        GameState.ClearContinue();
        Cursor.lockState = CursorLockMode.None; Cursor.visible = true;
    }

    // ---- intake brief: the creator's story / goals drive the text the player sees ----
    static int _goalIdx;
    static string Controls()
    {
        var xc = ExtraControls(); if (xc != null) return xc;
        if (IsFps) return "Mouse to aim, Left Click to fire, R to reload. Grab yellow ammo crates.";
        if (IsRacing) return "W/S throttle and brake, A/D steer, Space handbrake, R reset to last checkpoint.";
        if (IsHorror) return "WASD move, mouse look, F flashlight (battery drains). Stay out of its reach.";
        if (IsRpg) return "WASD move, walk up to NPCs to talk. Finds give XP; levels raise your power.";
        if (IsPuzzle) return "Walk into a block to push it one tile. R resets the room.";
        if (IsSurvival) return "Walk over trees for wood and bushes for food. Press C with 5 wood to build a fire. Hunger drains over time.";
        if (IsAdventure) return "WASD move, mouse look. Follow the objective marker, find the key, explore, open the gate.";
        if (IsSim) return "Stand behind the counter to serve customers. Walk to the stock crates to restock.";
        if (IsRogue) return "Mouse aim, Left Click fire, R reload. Clear each wave to open the next.";
        return "WASD move, Space jump. Collect pickups, avoid red hazards, reach the green flag.";
    }
    /// <summary>0..1 progress through this level's mechanics (maps onto the creator's goal list).</summary>
    public static float Progress()
    {
        if (GameState.Won) return 1f;
        float xp = ExtraProgress(); if (xp >= 0f) return xp;
        if (IsFps) return EnemiesTotal > 0 ? Mathf.Clamp01((float)Kills / EnemiesTotal) : 0f;
        if (IsRacing) return TotalLaps > 0 ? Mathf.Clamp01((float)Lap / TotalLaps) : 0f;
        if (IsHorror) return ItemsTotal > 0 ? Mathf.Clamp01((float)Items / ItemsTotal) * 0.9f : 0f;
        if (IsRpg) return !QuestTaken ? 0f : 0.25f + (ItemsTotal > 0 ? 0.65f * Items / ItemsTotal : 0f);
        if (IsPuzzle) return PadsTotal > 0 ? Mathf.Clamp01((float)Pads / PadsTotal) * 0.99f : 0f;
        if (IsSurvival) return Mathf.Clamp01((FireBuilt ? 0.4f : 0f) + 0.6f * (1f - TimeLeft / 120f)) * 0.99f;
        if (IsAdventure) return HasKey ? 0.5f : Mathf.Min(0.3f, Items * 0.1f);
        if (IsSim) return CashGoal > 0 ? Mathf.Clamp01((float)Cash / CashGoal) * 0.99f : 0f;
        if (IsRogue) return WavesTotal > 0 ? Mathf.Clamp01((float)Wave / WavesTotal) * 0.99f : 0f;
        return Mathf.Min(0.6f, GameState.Coins * 0.06f);
    }
    public static int GoalIndex()
    {
        int n = BriefGoals == null ? 0 : BriefGoals.Length;
        if (n == 0) return 0;
        int i = Mathf.Min(n - 1, Mathf.FloorToInt(Progress() * n));
        if (i > _goalIdx) { for (int k = _goalIdx; k < i; k++) AchievementSystem.UnlockGoal(k); _goalIdx = i; }
        return _goalIdx;
    }
    static string GoalList()
    {
        var sb = new System.Text.StringBuilder();
        foreach (var g in BriefGoals) if (!string.IsNullOrEmpty(g)) sb.Append("- ").Append(g).Append("\n");
        return sb.ToString();
    }
    public static string Story()
    {
        if (!HasBrief) return CannedStory();
        string n = Name.ToUpper();
        string s = n + "\n\n" + (string.IsNullOrEmpty(BriefStory) ? "" : BriefStory.Trim() + "\n");
        if (!string.IsNullOrEmpty(BriefSetting)) s += "Where: " + BriefSetting.Trim() + "\n";
        if (!string.IsNullOrEmpty(BriefLoop)) s += "You: " + BriefLoop.Trim() + "\n";
        s += "\n" + Controls() + "\n";
        if (BriefGoals != null && BriefGoals.Length > 0) s += "\nGoals:\n" + GoalList();
        return s + "\nPress Start when ready.";
    }
    public static string Objective()
    {
        if (BriefGoals == null || BriefGoals.Length == 0) return CannedObjective();
        string mech = CannedObjective();
        if (mech.StartsWith("Objective: ")) mech = mech.Substring(11);
        int i = GoalIndex();
        return "Goal " + (i + 1) + "/" + BriefGoals.Length + ": " + BriefGoals[i] + "   (" + mech + ")";
    }
    public static string WinText()
    {
        string canned = CannedWinText();
        if (BriefGoals == null || BriefGoals.Length == 0) return canned;
        int nl = canned.IndexOf('\n');
        string stats = nl >= 0 ? canned.Substring(nl + 1) : "";
        return Name.ToUpper() + " - ALL GOALS COMPLETE\n" + GoalList() + stats;
    }
}
