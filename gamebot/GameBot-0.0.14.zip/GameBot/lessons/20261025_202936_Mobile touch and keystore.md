# Mobile touch and keystore

Tags: mobile touch android ios
Saved: 2026-10-25T20:29:36

Touch buttons >=48dp, Screen.safeArea, 30 fps mobile URP tier; Android .aab IL2CPP ARM64, back up keystore; iOS needs Mac+Xcode. Source: https://developer.android.com/google/play/requirements/target-sdk
