# STATE.md — Game Bot (ollama-web)
Last updated: 2026-11-21 ~4:20 PM America/Chicago

## Current goal
Sell-ready ASAP. 8 GB edition lock stays. No training/promotion. BUY_LIVE stays false. Do not sign or publish the app until Derrold says ship. Source version.json and GameBot-Setup.iss stay 0.0.13. Leave dist\release_0.0.13 alone.

## Last completed (this run, afternoon CT)
- Bring-your-own models: default stays Game Bot offline model (gamebot-trained). Settings can use other installed Ollama models, LM Studio/llama.cpp via a local OpenAI-compatible URL, or a user-entered cloud API key (OpenAI, Anthropic, OpenRouter, xAI). Keys in %LOCALAPPDATA%\GameBot\secrets via DPAPI; redacted in bug reports. Cloud note: prompts leave the PC. Unit tests passed. Live second-model chat on gamebot-r68-5080:latest replied "OK" in 43s; settings reset to gamebot-trained. No paid APIs used.
- Lighting/visuals: lower day sun/sky/post; foliage magenta fallback; starting HP 100; Build() now SaveScene after PolishLook so look values actually ship. Throwaway QA (private frames, not for the site): Royale sun 0.85 / sky 0.82, luma 0.576, magenta 0, start HP 100. Hop (brief darker=1, dusk) after SaveScene: sun 0.55 / sky 0.42, luma 0.153, magenta 0, start HP 100. Some TreeAndGrassPack trunks still log MAT_WHITE.
- AMD: 8 GB ctx cap 8192, RX 5000 cap 4096 (still below official spec), Vulkan device-lost retries at lower ctx with a clear message. Unit-tested only (this PC is NVIDIA).
- Unsigned 0.0.14-dev restaged (not signed, not published): dist\release_0.0.14-dev\GameBot-0.0.14-dev.zip, 2,823,909 bytes, 449 files, sha256 886992cc25d9ad16c2ce7aec5101784502bb65ac50396d74efa0bca38ea21a03.
- Site: https://gamebotstudio.com updated (features, FAQ, requirements). Commit b78c770827db507a9fac37314d1a044906abe650. Pages built 4:20 PM CT. Live page verified: BYO / lighting / AMD present, $99 unchanged, no $149, waitlist and Cloudflare analytics untouched.

## Do not re-check / do not touch
- Do not delete models or Documents\UnityProjects
- Do not route the signing key through the box or print it
- Checkout/price stay inactive; no auto-promote
- Keep 8 GB cap; do not raise settings for the 5080
- Do not sign or publish 0.0.13 or 0.0.14-dev until Derrold says ship
- Do not replace dist\release_0.0.13
- No game images in manuals, the site, or reports

## Key paths
- Live source: C:\Users\Derrold PC\ollama-web
- Site repo: https://github.com/Derrold/gamebotstudio (GitHub Pages → gamebotstudio.com)
