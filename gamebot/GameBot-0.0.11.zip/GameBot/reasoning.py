"""Reasoning path for messages that match no explicit Game Bot command.

Instead of falling back to a canned pipeline/stage reply, the model gets the game's context
(brief, packs, last build, available actions) and must do exactly one of:
  ANSWER  - reply conversationally / explain,
  ACTION  - map the message to one concrete change and ask the creator to confirm,
  CLARIFY - ask one specific question.
Private reasoning goes in <think>...</think> and is stripped before the creator sees the reply.
"""
from __future__ import annotations

import json
import re
from pathlib import Path

_PENDING: dict[str, str] = {}   # chat key -> confirmed-on-"yes" builder instruction
_REASONED: set[str] = set()      # chats whose last reply came from this path without an ACTION

_Q_RE = re.compile(r"^\s*(why|what|how|who|when|where|which|can you|could you|would you|do you|does|did|is|are|was|were|should|explain|tell me|help)\b", re.I)
_YES_RE = re.compile(r"^\s*(yes|yeah|yep|yup|sure|ok(ay)?|do it|go ahead|go for it|please do|sounds good|y)\b[\s!.,]*(please|thanks|do it)?[\s!.]*$", re.I)
_EXPLICIT_RE = re.compile(
    r"^\s*(please\s+)?(re-?build|build( it| the game)?|play|launch|run (it|the game)|status|progress|import\b|use my assets|my assets|"
    r"skip|ship|steam|new game|new chat|continue|resume|add (a|an|some|more)\b|put (a|an)\b)", re.I)
_BUG_RE = re.compile(r"\b(grey|gray) boxes?\b|\bfollows? (the )?(player|camera)\b|\bstuck\b|\bfalling\b|\bcrash(es|ed|ing)?\b|"
                     r"\bmissing (assets?|models?|textures?)\b|\bnot react", re.I)
_PILLAR_RE = re.compile(r"a few ways to make .{0,40}(hit harder|better)|destructible set pieces.{0,80}vehicles|"
                        r"upgrades between missions|destructible set pieces|grenade and melee", re.I | re.S)
_TOOLCALL_RE = re.compile(r"<tool_call>.*?(</tool_call>|$)|```json\s*\{\s*\"name\".*?```", re.I | re.S)


def is_question(text: str) -> bool:
    t = (text or "").strip()
    return t.endswith("?") or bool(_Q_RE.match(t))


def is_yes(text: str) -> bool:
    return bool(_YES_RE.match(text or ""))


def chat_key(root) -> str:
    return str(root).lower() if root else "_nogame"


def take_pending(root, text: str) -> str | None:
    """If the creator says yes to a proposed ACTION, return that instruction (and clear it)."""
    k = chat_key(root)
    if k in _PENDING and is_yes(text):
        return _PENDING.pop(k)
    if k in _PENDING and not is_yes(text):
        _PENDING.pop(k, None)   # any other reply cancels the proposal
    return None


def yes_after_reason(root, text: str) -> bool:
    """A bare "yes" answering a reasoning reply that proposed nothing concrete: reason again, don't run tools."""
    k = chat_key(root)
    hit = k in _REASONED and is_yes(text)
    _REASONED.discard(k)
    return hit


def should_reason(text: str, *, explicit_checks=()) -> bool:
    """True when the message is not an explicit command: route it to the reasoning reply."""
    t = (text or "").strip()
    if not t or t.startswith("SYSTEM NOTE"):
        return False
    if re.fullmatch(r"[\d\s.,)#-]+", t):           # numbered choices belong to intake / asset plan
        return False
    if is_yes(t) or re.fullmatch(r"\s*(no|nope|cancel|stop)\W*", t, re.I):
        return False
    if _EXPLICIT_RE.match(t):
        return False
    q = is_question(t)
    if not q and _BUG_RE.search(t):                  # bug reports keep the inspect_scene -> fix flow
        return False
    for chk in explicit_checks:
        try:
            if chk(t) and not q:
                return False
        except Exception:
            pass
    return True


def _read(p: Path, n: int) -> str:
    try:
        return p.read_text(encoding="utf-8", errors="replace").strip()[:n]
    except Exception:
        return ""


def game_context(root) -> str:
    if not root:
        return "No game is open in this chat yet. To start one the creator says e.g. \"make a sci-fi FPS called X\"."
    root = Path(root)
    lines = [f"Game: {root.name} (folder {root})"]
    try:
        b = json.loads((root / "Tools" / "game_brief.json").read_text(encoding="utf-8"))
        keep = {k: b[k] for k in ("title", "engine", "genre", "theme", "template", "pitch", "setting", "mechanics", "style") if k in b}
        lines.append("Brief: " + json.dumps(keep, ensure_ascii=False)[:700])
    except Exception:
        pass
    pitch = _read(root / "Pitch.md", 500)
    if pitch:
        lines.append("Pitch: " + re.sub(r"\s+", " ", pitch))
    for nm, n in (("ScenePlan.md", 500), ("GDD.md", 500)):
        txt = _read(root / "Docs" / nm, n) or _read(root / nm, n)
        if txt:
            lines.append(nm[:-3] + ": " + re.sub(r"\s+", " ", txt))
    summ = _read(root / "SESSION_SUMMARY.md", 600)
    if summ:
        lines.append("Session summary: " + re.sub(r"\s+", " ", summ))
    try:
        import asset_plan as _AP
        plan = _AP.load_plan(root)
        if plan:
            lines.append("Asset plan / owned packs: " + re.sub(r"\s+", " ", _AP.summary_lines(plan))[:700])
    except Exception:
        pass
    st = _read(root / "Builds" / "auto_unity_status.txt", 400)
    if st:
        lines.append("Last build: " + st.splitlines()[0][:200])
    else:
        lines.append("Last build: none yet")
    bugs = _read(root / "Bugs.md", 300)
    if bugs:
        lines.append("Bugs.md: " + re.sub(r"\s+", " ", bugs))
    return "\n".join(lines)


ACTIONS_TEXT = (
    "What Game Bot can actually do for this game (commands the creator can say):\n"
    "- \"rebuild\": re-run the Unity batch build -> Builds\\Windows\\<Game>.exe (scene from Tools\\Unity\\SceneBuilder*.cs, owned packs, Blender stand-ins).\n"
    "- \"play\": launch the last built exe.  \"status\": build progress.\n"
    "- \"use my assets\": scan and re-import owned Asset Store / Fab packs into the asset plan.\n"
    "- \"add a <prop/model>\": make a Blender model and import it.\n"
    "- gameplay/code changes (enemy AI, weapons, lighting, level layout, UI, audio): edit the C# scripts or scene builder, then rebuild.\n"
    "- bug reports: inspect the scene, find the cause, fix the script, rebuild.\n"
    "- ship prep: Steam/Epic store files and installer.\n"
    "How a build works: intake answers -> project scaffold + GDD/TaskBoard -> asset plan maps owned packs (stand-ins where a pack is missing) -> "
    "Unity runs headless, SceneBuilder places level/player/enemies/lights -> Windows exe in Builds\\Windows -> say \"play\"."
)

REASON_SYSTEM = (
    "You are Game Bot, a friendly, expert game developer and creative partner inside a desktop app that builds games for creators "
    "(Unity/Unreal, C#, level design, AI, game feel, lighting, assets). English only.\n"
    "First think privately inside <think>...</think>: what does the creator actually mean, what do you know about THEIR game from the "
    "context, and which single MODE fits. Then, after </think>, write only the reply the creator sees.\n"
    "MODES (pick exactly one):\n"
    "ANSWER - a question, opinion or chat. Answer it directly and properly: explain the why, give concrete specifics for their game. "
    "Off-topic questions: answer correctly and briefly. Use short paragraphs or a short list when it helps.\n"
    "ACTION - they want something changed. In 2-5 sentences say exactly what you would change in their game (which script/system, "
    "what behaviour or values) and why it fixes what they asked. Finish with a final line exactly in this form:\n"
    "ACTION: <one imperative instruction for the builder>\n"
    "CLARIFY - too vague to act on. Ask ONE specific question offering 2-3 concrete options.\n"
    "Interpret typos and odd wording charitably using the game context (e.g. 'enemys' means enemies, 'biuld' means build, 'sci fy' means sci-fi, 'gunz' means guns). "
    "If you are sure, proceed as if they said the intended words. If you are unsure, state your best guess and ask one question in the form: Did you mean X? (yes runs it).\n"
    "RULES: Nothing has been run yet, so never claim you changed, built or imported anything. Never reply with a generic feature list, "
    "pillars or build stages that don't answer the message. Don't copy earlier replies. Don't mention tools, SYSTEM notes or internal files "
    "you weren't shown. Don't tell the creator to do it themselves when Game Bot can do it.\n\n"
)


def _recent(messages, n=4, cut=500):
    out = []
    for m in reversed(messages or []):
        r = m.get("role")
        c = str(m.get("content") or "")
        if r not in ("user", "assistant") or not c.strip() or c.startswith("SYSTEM NOTE") or c.startswith("[KB]"):
            continue
        if r == "assistant" and (_PILLAR_RE.search(c) or "Which one first" in c or "<tool_call>" in c):
            continue                                   # don't let old canned replies be copied
        out.append({"role": r, "content": c[:cut]})
        if len(out) >= n + 1:
            break
    out.reverse()
    return out[:-1] if out and out[-1]["role"] == "user" else out   # last user msg is added separately


def split_reply(raw: str) -> tuple[str, str]:
    """Strip private reasoning; return (visible_reply, action_instruction)."""
    t = raw or ""
    t = re.sub(r"<think>.*?</think>", "", t, flags=re.S | re.I)
    t = _TOOLCALL_RE.sub("", t)
    if re.search(r"</think>", t, re.I):
        t = re.split(r"</think>", t, flags=re.I)[-1]
    if re.match(r"\s*<think>", t, re.I):          # unclosed think: no visible reply
        t = ""
    t = re.sub(r"^\s*(MODE\s*:\s*)?(ANSWER|ACTION|CLARIFY)\s*[-:]\s*", "", t.strip(), flags=re.I)
    action = ""
    m = re.search(r"^\s*ACTION\s*:\s*(.+)$", t, re.M | re.I) or re.search(r"\bACTION\s*:\s*(.+)$", t, re.I | re.S)
    if m:
        action = m.group(1).strip()
        t = (t[:m.start()] + t[m.end():]).strip()
        if re.match(r"(?i)(pick|choose|tell me|say|let me know|ask)\b", action):
            action = ""          # not a concrete change - it's really a question
    return t.strip(), action


def clarify_fallback(text: str, root) -> str:
    name = Path(root).name if root else "your game"
    return (f"I want to get this right for {name}. When you say \"{text.strip()[:120]}\", do you want me to "
            f"(1) change something in the game (tell me what should feel different), (2) explain how something works, "
            f"or (3) check or rebuild the current build?")


FEW_SHOT = [
    {"role": "user", "content": "(EXAMPLE ONLY - made-up game ExampleGame, a platformer) why is everything so slow"},
    {"role": "assistant", "content": "<think>Question about performance. Likely frame rate: many real-time lights, unbaked shadows, too many enemies. ANSWER.</think>"
        "Slowness in ExampleGame is most likely frame rate, not game speed. The usual causes in a Unity build like this are:\n"
        "- lots of real-time neon point lights casting shadows (each one re-renders the scene),\n"
        "- every enemy running its AI update every frame,\n"
        "- high-poly pack models with no LODs.\n"
        "The quickest win is turning shadows off on the small neon lights and baking the rest. If you want, tell me roughly what FPS you see and I'll make that change and rebuild."},
    {"role": "user", "content": "(EXAMPLE ONLY - ExampleGame) make the boss scarier"},
    {"role": "assistant", "content": "<think>Clear change request. Map to concrete edits: boss scale, red rim light, roar audio, phase 2 speed. ACTION.</think>"
        "I'd make the boss feel scarier in three ways: scale it up 1.5x so it towers over the player, give it a red rim light and a low roar when it first sees you, "
        "and add a second phase at half health where it moves 30% faster and calls in two minions.\n"
        "ACTION: Make the ExampleGame boss scarier: scale 1.5x, red rim light, roar on first sight, phase 2 at 50% HP (+30% speed, spawns 2 minions), then rebuild."},
    {"role": "user", "content": "(EXAMPLE ONLY - ExampleGame) it's weird"},
    {"role": "assistant", "content": "<think>Too vague to act on. CLARIFY with concrete options.</think>"
        "What feels weird - the controls (jump or movement feel), the camera (angle or follow speed), or how the level looks (scale, lighting)?"},
]


def _ask(chat_fn, msgs, temp):
    res = chat_fn(msgs, tools=False, extra_opts={"temperature": temp, "top_p": 0.9, "num_predict": 1500, "repeat_penalty": 1.15})
    return res, str((res.get("message") or {}).get("content") or "")


def reason_reply(messages, root, text: str, chat_fn) -> tuple[str, str]:
    """Run the reasoning call. chat_fn(msgs, tools=False, extra_opts=...) -> ollama response dict."""
    _topic = feedback_topic(text)
    if _topic and root:
        return feedback_reply(text, root, _topic)
    sys = REASON_SYSTEM + "GAME CONTEXT:\n" + game_context(root) + "\n\n" + ACTIONS_TEXT
    name = Path(root).name if root else "no game yet"
    msgs = ([{"role": "system", "content": sys}] + _recent(messages)
            + [{"role": "user", "content": f"(this game: {name}) {text}"}])
    reply, action = "", ""
    for temp in (0.6, 0.85):
        try:
            res, raw = _ask(chat_fn, msgs, temp)
            if res.get("gpu_paused"):
                return raw, ""
        except Exception:
            raw = ""
        reply, action = split_reply(raw)
        if reply and not _PILLAR_RE.search(reply):
            break
        msgs = msgs + [{"role": "assistant", "content": raw or "(empty)"},
                       {"role": "user", "content": "That is a generic list and does not answer my message. Think about what I actually asked and "
                                                   f"reply to it directly for {name}: answer it, propose one concrete change with an ACTION line, or ask one specific question. My message was: {text}"}]
        reply, action = "", ""
    if not reply:
        _REASONED.add(chat_key(root))
        return clarify_fallback(text, root), ""
    if has_false_claim(reply):          # nothing runs on this path, so any "Added/Done/Built" is a proposal
        reply = fix_false_claims(reply)
        if not action:
            action = f"{text.strip()} (as proposed: {re.sub(chr(10), ' ', reply)[:300]})"
    if action:
        _PENDING[chat_key(root)] = action
        if not reply.rstrip().endswith("?"):
            reply = reply.rstrip() + "\n\nWant me to go ahead? Say \"yes\" and I'll do it, or tell me what to change."
    else:
        _REASONED.add(chat_key(root))
    return reply, action


# ---------------------------------------------------------------- 0.0.8: no false "done" claims
_PAST = {"added": "add", "built": "build", "rebuilt": "rebuild", "fixed": "fix", "changed": "change", "updated": "update",
         "created": "create", "made": "make", "increased": "increase", "reduced": "reduce", "lowered": "lower",
         "raised": "raise", "removed": "remove", "replaced": "replace", "imported": "import", "tuned": "tune", "wrote": "write",
         "written": "write", "placed": "place", "moved": "move", "boosted": "boost", "adjusted": "adjust", "enabled": "enable",
         "disabled": "disable", "installed": "install", "generated": "generate", "turned": "turn", "swapped": "swap"}
_PV = "|".join(sorted(_PAST, key=len, reverse=True))
_CLAIM_RE = re.compile(rf"(?im)(^|(?<=[.!?]\s)|(?<=^\d\.\s)|(?<=^-\s))(?:i(?:'ve| have)?\s+(?:already\s+|just\s+)?)?({_PV})\b"
                       rf"|\b(?:has|have)\s+been\s+({_PV})\b|\b(?:it'?s|it is|that'?s|all)\s+done\b|^\s*done\b[.!:\- ]*", re.M)


def has_false_claim(text: str) -> bool:
    return bool(_CLAIM_RE.search(text or ""))


def fix_false_claims(text: str) -> str:
    """Nothing ran this turn: turn 'Added X / I've built Y / Done' into a proposal."""
    t = text or ""
    if not has_false_claim(t):
        return t

    def line_fix(line: str) -> str:
        m = re.match(rf"^(\s*(?:\d+[.)]|-|\*)\s+)(?:i(?:'ve| have)?\s+(?:already\s+|just\s+)?)?({_PV})\b", line, re.I)
        if m:   # list item: "1. Added ambient light" -> "1. Add ambient light"
            base = _PAST[m.group(2).lower()]
            return m.group(1) + base.capitalize() + line[m.end():]
        line = re.sub(r"^\s*done\b[.!:\- ]*", "", line, flags=re.I)
        line = re.sub(r"(?<=[.!?])\s+done\b[.!]*", "", line, flags=re.I)
        line = re.sub(r"\b(it'?s|it is|that'?s|all)\s+done\b", r"\1 ready to do", line, flags=re.I)
        line = re.sub(rf"\b(has|have)\s+been\s+({_PV})\b", lambda mm: "can be " + mm.group(2).lower(), line, flags=re.I)
        line = re.sub(rf"(^|(?<=[.!?]\s))(?:i(?:'ve| have)?\s+(?:already\s+|just\s+)?)?({_PV})\b",
                      lambda mm: mm.group(1) + "I can " + _PAST[mm.group(2).lower()], line, flags=re.I)
        return line

    out = "\n".join(line_fix(l) for l in t.split("\n")).strip()
    if 'say "yes"' not in out.lower():
        out += "\n\nNothing has been changed yet - say \"yes\" to do it."
    return out


# ---------------------------------------------------------------- 0.0.8: game-feel feedback
_FEEL_RE = re.compile(r"\b(feels?|is|are|seems?|looks?|sounds?|too|so|kinda|really)\s+(?:a bit\s+|too\s+|so\s+|very\s+|kind of\s+)?"
                      r"(weak|slow|floaty|boring|heavy|stiff|clunky|easy|hard|weak|underpowered|op|overpowered|dull|laggy|quiet|"
                      r"pathetic|bad|off|meh|lame|wimpy|unresponsive|sluggish|fast|dumb|stupid|annoying)\b", re.I)
_TOPICS = {
    "gun": re.compile(r"\b(gun|guns|weapon|weapons|rifle|pistol|shotgun|shooting|shots?|firing|blaster|ammo)\b", re.I),
    "move": re.compile(r"\b(movement|moving|walk(ing)?|run(ning)?|jump(ing|s)?|sprint(ing)?|controls?|player)\b", re.I),
    "enemy": re.compile(r"\b(enem(y|ies)|ai|bots?|monsters?|aliens?|zombies?|boss)\b", re.I),
}


_MAKE_RE = re.compile(r"\b(make|get)\s+(the\s+|my\s+|our\s+)?\w+(\s+\w+)?\s+(smarter|stronger|better|harder|tougher|scarier|"
                      r"deadlier|punchier|faster|snappier|more (aggressive|responsive|fun|powerful|challenging|intelligent))\b", re.I)


def feedback_topic(text: str) -> str:
    t = text or ""
    if not (_FEEL_RE.search(t) or _MAKE_RE.search(t)):
        return ""
    for k, rx in _TOPICS.items():
        if rx.search(t):
            return k
    return ""


def _gun_stats(root) -> dict:
    out = {}
    if not root:
        return out
    root = Path(root)
    srcs = list(root.glob("Tools/Unity/GunController.cs")) + list(root.glob("*Unity/Assets/Scripts/GunController.cs"))
    for p in srcs[:1]:
        s = _read(p, 4000)
        for k in ("damage", "fireRate", "reloadTime", "range"):
            m = re.search(rf"\b{k}\s*=\s*([\d.]+)f?", s)
            if m:
                out[k] = float(m.group(1))
    for p in list(root.glob("*Unity/Assets/Editor/SceneBuilder*.cs"))[:6]:   # per-genre overrides (gun.damage = 14)
        s = _read(p, 200000)
        for k in ("damage", "fireRate"):
            m = re.search(rf"gun\.{k}\s*=\s*([\d.]+)f?", s)
            if m:
                out[k] = float(m.group(1))
    return out


def feedback_reply(text: str, root, topic: str) -> tuple[str, str]:
    name = Path(root).name if root else "your game"
    if topic == "gun":
        st = _gun_stats(root)
        dmg, fr = st.get("damage"), st.get("fireRate")
        cur = []
        if dmg:
            cur.append(f"damage {dmg:g} per hit")
        if fr:
            cur.append(f"one shot every {fr:g}s (~{60 / fr:.0f} rounds/min)")
        nd = f"{dmg:g} -> {round(dmg * 1.4):g}" if dmg else "+40%"
        nf = f"{fr:g}s -> {fr * 0.85:.2f}s" if fr else "about 15% faster"
        lines = [f"Got it - the gun in {name} feels weak." + (f" Right now it does {' and '.join(cur)}." if cur else ""),
                 "Weak guns usually come from feedback more than numbers, so here's what I'd change:",
                 f"1. Damage: {nd}, so enemies drop in fewer hits.",
                 f"2. Fire rate: {nf} for a punchier rhythm.",
                 "3. Recoil: a small camera kick (about 1.5 degrees) with a quick recovery on every shot.",
                 "4. Muzzle flash: a brighter flash plus a short light pop at the muzzle.",
                 "5. Sound: a heavier shot sound with a low-end thump and slight pitch variation.",
                 "6. Hit feedback: hit markers, a hit sound, a small enemy flinch and impact sparks."]
        act = (f"Make the gun in {name} feel stronger: damage {nd}, fire rate {nf}, add camera recoil kick, brighter muzzle flash "
               f"with light pop, heavier shot sound with pitch variation, hit markers/hit sound/enemy flinch/impact sparks, then rebuild.")
    elif topic == "move":
        lines = [f"Got it - movement in {name} doesn't feel right. Here's what I'd tune:",
                 "1. Acceleration: reach full speed faster (about 0.1s) and stop quicker.",
                 "2. Jump: a little higher with stronger gravity on the way down, so it isn't floaty.",
                 "3. Air control: some steering mid-air.",
                 "4. Coyote time and jump buffering (0.1s each) so jumps never feel eaten.",
                 "5. Camera: a slight FOV kick when sprinting and a small head bob."]
        act = (f"Tune player movement in {name}: faster acceleration/deceleration, higher jump with stronger fall gravity, "
               f"air control, coyote time + jump buffer 0.1s, sprint FOV kick and head bob, then rebuild.")
    else:
        lines = [f"Got it - the enemies in {name} aren't working for you. Here's what I'd change:",
                 "1. Use cover: enemies duck behind props between bursts.",
                 "2. Flank: one enemy holds you in place while another circles round.",
                 "3. React: they flinch when hit and back off at low health.",
                 "4. Aim: a short wind-up before firing, so you can dodge but still feel pressure.",
                 "5. Numbers: group size and spawn rate tuned so fights ramp up."]
        act = (f"Improve enemy AI in {name}: cover use between bursts, flanking, hit flinch and retreat at low health, "
               f"aim wind-up before shots, tuned group size and spawn ramp, then rebuild.")
    _PENDING[chat_key(root)] = act
    reply = "\n".join(lines) + "\n\nWant me to do all of these? Say \"yes\", or name the numbers you want (for example \"just 1, 3 and 6\")."
    return reply, act
