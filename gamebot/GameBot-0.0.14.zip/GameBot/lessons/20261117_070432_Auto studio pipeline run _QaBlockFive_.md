# Auto studio pipeline run (QaBlockFive)

Tags: auto studio pipeline
Saved: 2026-11-17T07:04:32

run_auto_game_pipeline created 34 files under C:\Users\Derrold PC\Documents\GameProjects\QaBlockFive and UNITY 6000.6.5f1: background job started -> create QaBlockFiveUnity -> Puzzle game (gameplay template: puzzle; menu, settings, achievements, owned genre kit) ->. Next: check Builds\auto_unity_status.txt, then work TaskBoard 'Auto next actions' with tools.
