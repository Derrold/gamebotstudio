# NullReferenceException runtime fix

Tags: unity,fix,runtime
Saved: 2026-10-25T20:00:13

Read the stack top line in Player.log/Editor.log, find what was null (GetComponent/Find failed, destroyed object, Awake/Start order). Assign in the builder/inspector, add [RequireComponent], null-check with a clear log. Player.log is under LocalLow\<Company>\<Product> (read-only; never edit saves). Source: https://docs.unity3d.com/Manual/NullReferenceException.html
