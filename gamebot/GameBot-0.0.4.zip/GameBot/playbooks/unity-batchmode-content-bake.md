# Unity batchmode content bake (Builder-style executeMethod, generic)
Rebuild scenes/content from code so the bot never hand-edits scenes and every build is reproducible.

## Pattern
- One static Editor class with entry points: `Build()` (scenes from data), `Bake()` (lighting/NavMesh/occlusion), `BuildWindows()` (player build). Methods must be static, inside an Editor folder; namespaced calls use Namespace.Class.Method.
- Scenes built by code are OUTPUTS: edit the builder, not the .unity file (manual edits get overwritten).
- Inputs from data: ScriptableObjects, JSON/CSV in Assets\Data, or env vars (GAMEBOT_GAME_NAME, GAMEBOT_BUILD_DIR, ITEM_ID).

## Command
`& "<Unity.exe>" -batchmode -nographics -quit -projectPath "<proj>" -executeMethod SceneBuilder.Build -logFile "<proj>\Builds\bake.log"`
- New project: `-createProject "<proj>"` first (~20-60 s). Same editor version every time (config\gamebot.config.json unity_editor).
- Only one Unity instance per project: check Get-Process Unity / Temp\UnityLockfile before running; if the Editor has it open, report and stop (don't kill the creator's Editor).
- Exit code: call `EditorApplication.Exit(1)` on failure so scripts can detect it; BuildPipeline.BuildPlayer report.summary.result == Succeeded.

## Builder essentials
- EditorSceneManager.NewScene(NewSceneSetup.EmptyScene) -> create objects -> EditorSceneManager.SaveScene(scene, "Assets/Scenes/X.unity").
- EditorBuildSettings.scenes = new[]{ new EditorBuildSettingsScene(path, true) }.
- PlayerSettings.productName / companyName / bundleVersion set from data. Icons: PlayerSettings.SetIconsForTargetGroup.
- Lighting: Lightmapping.Bake() only for static content; NavMesh: NavMeshSurface.BuildNavMesh() (AI Navigation package).
- AssetDatabase.Refresh() after copying new scripts; scripts compile before -executeMethod runs.

## Log checks (automatic)
- grep `error CS` (compile), `Build succeeded`/`Build Failed`, `Exception`, `Aborting batchmode`. First error -> research_error -> patch -> re-run once -> teach_self.
- Status file pattern: write Builds\<job>_status.txt with RUNNING / DONE OK <exe> / DONE FAIL so chat turns return fast and later turns poll.

## Background jobs
- Long jobs (createProject + bake + build) run detached via Tools\auto_unity.ps1 (written by run_auto_game_pipeline). Poll the status file; never block the chat for minutes.
