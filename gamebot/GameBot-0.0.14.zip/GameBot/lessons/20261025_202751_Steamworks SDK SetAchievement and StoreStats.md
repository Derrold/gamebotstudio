# Steamworks SDK SetAchievement and StoreStats

Tags: steamworks, achievements, stats
Saved: 2026-10-25T20:27:51

To set achievements and store stats in Steamworks using the Unity API, follow these steps:

1. Define achievements in the Steamworks web portal under Stats & Achievements.
2. Use `SteamUserStats.SetAchievement("ACH_NAME")` to unlock an achievement.
3. Store player statistics with `SteamUserStats.SetStat("stat_name", value)` and then call `SteamUserStats.StoreStats()` to save changes.
4. Ensure the app is properly configured in steam_appid.txt for API access.
