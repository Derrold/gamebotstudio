# Pink magenta materials fix

Tags: unity,fix,urp,materials
Saved: 2026-10-25T20:00:10

Pink = shader not supported by URP or failed to compile. Convert: Edit > Rendering > Materials > Convert to URP, or set Shader.Find('Universal Render Pipeline/Lit') in builder code. In builds, make sure the shader is referenced by a material in a scene/Resources. Source: https://docs.unity3d.com/Manual/urp/upgrading-your-shaders.html
