﻿using System;
using System.Text.RegularExpressions;
using UnityEditor;
using UnityEngine;

// Game Bot "look" pass (pre-sale polish): sky, sun, ambient, fog and URP post-processing that follow the creator's art
// style from the brief ("moody and dark" -> dusk sky, low cool sun, dense fog, graded/vignetted image; otherwise a clean
// bright day). URP types are reached by reflection so this file still compiles in Built-in projects.
public static partial class SceneBuilder
{
    static bool DarkStyle()
    {
        var b = LoadBrief(); string s = b == null ? "" : ((b.style ?? "") + " " + (b.setting ?? "") + " " + (b.genre ?? "")).ToLower();
        return Regex.IsMatch(s, "dark|moody|night|gloom|horror|grim|eerie|creepy|spooky|haunt|noir|dusk|twilight|cursed|sinister|foggy|misty");
    }
    static Material LookAsset(Material m, string name)
    {
        System.IO.Directory.CreateDirectory("Assets/GameBot/Look"); string p = "Assets/GameBot/Look/" + name + ".mat";
        AssetDatabase.DeleteAsset(p); AssetDatabase.CreateAsset(m, p); return m;
    }
    static void SetParam(object comp, string field, object val)
    {
        try
        {
            var f = comp.GetType().GetField(field); if (f == null) return; var prm = f.GetValue(comp); if (prm == null) return;
            var vp = prm.GetType().GetProperty("value"); var t = vp.PropertyType;
            vp.SetValue(prm, t.IsEnum ? Enum.ToObject(t, val) : Convert.ChangeType(val, t));
            prm.GetType().GetProperty("overrideState").SetValue(prm, true);
        }
        catch (Exception e) { Debug.LogWarning("LOOK_PARAM " + field + " " + e.Message); }
    }
    static Type FindType(string full)
    {
        foreach (var a in AppDomain.CurrentDomain.GetAssemblies()) { var t = a.GetType(full); if (t != null) return t; }
        return null;
    }
    static void PolishLook()
    {
        bool urp = UnityEngine.Rendering.GraphicsSettings.currentRenderPipeline != null;
        bool dark = DarkStyle(); bool outdoor = _terr != null || RenderSettings.skybox != null;
        string mode = _mode ?? "";
        if (mode == "horror") { Debug.Log("LOOK skip sky (horror interior keeps its own lighting)"); }
        var sun = GameObject.Find("Directional Light"); var sl = sun ? sun.GetComponent<Light>() : null;
        if (outdoor && mode != "horror")
        {
            var sky = Shader.Find("Skybox/Procedural");
            if (sky)
            {
                var m = new Material(sky);
                if (dark) { m.SetFloat("_SunSize", 0.03f); m.SetFloat("_AtmosphereThickness", 0.55f); m.SetColor("_SkyTint", new Color(0.32f, 0.36f, 0.46f)); m.SetColor("_GroundColor", new Color(0.10f, 0.11f, 0.12f)); m.SetFloat("_Exposure", 0.42f); }
                else { m.SetFloat("_SunSize", 0.04f); m.SetFloat("_AtmosphereThickness", 0.9f); m.SetColor("_SkyTint", new Color(0.45f, 0.55f, 0.7f)); m.SetColor("_GroundColor", new Color(0.33f, 0.32f, 0.3f)); m.SetFloat("_Exposure", 1.05f); }
                RenderSettings.skybox = LookAsset(m, dark ? "GB_SkyDusk" : "GB_SkyDay");
            }
            if (sl)
            {
                sl.shadows = LightShadows.Soft; sl.shadowStrength = dark ? 0.75f : 0.85f;
                if (dark) { sl.intensity = 0.55f; sl.color = new Color(0.72f, 0.78f, 0.95f); sun.transform.rotation = Quaternion.Euler(14f, -50f, 0f); }
                else { sl.intensity = 1.2f; sl.color = new Color(1f, 0.95f, 0.86f); sun.transform.rotation = Quaternion.Euler(42f, -35f, 0f); }
                RenderSettings.sun = sl;
            }
            RenderSettings.ambientMode = UnityEngine.Rendering.AmbientMode.Trilight;
            if (dark) { RenderSettings.ambientSkyColor = new Color(0.20f, 0.23f, 0.30f); RenderSettings.ambientEquatorColor = new Color(0.13f, 0.14f, 0.16f); RenderSettings.ambientGroundColor = new Color(0.05f, 0.05f, 0.06f); }
            else { RenderSettings.ambientSkyColor = new Color(0.55f, 0.62f, 0.72f); RenderSettings.ambientEquatorColor = new Color(0.42f, 0.42f, 0.40f); RenderSettings.ambientGroundColor = new Color(0.2f, 0.18f, 0.15f); }
            RenderSettings.fog = true;
            if (dark) { RenderSettings.fogMode = FogMode.ExponentialSquared; RenderSettings.fogDensity = 0.014f; RenderSettings.fogColor = new Color(0.16f, 0.18f, 0.22f); }
            else { RenderSettings.fogMode = FogMode.Linear; RenderSettings.fogStartDistance = 70f; RenderSettings.fogEndDistance = 230f; RenderSettings.fogColor = new Color(0.66f, 0.73f, 0.8f); }
            RenderSettings.reflectionIntensity = dark ? 0.35f : 0.8f;
            var storm = GameObject.Find("StormWall"); if (storm) { var r = storm.GetComponent<Renderer>(); if (r && r.sharedMaterial) r.sharedMaterial.color = dark ? new Color(0.55f, 0.62f, 0.72f, 0.16f) : new Color(0.45f, 0.6f, 0.95f, 0.14f); }
            foreach (var l in UnityEngine.Object.FindObjectsByType<Light>(FindObjectsSortMode.None)) if (dark && l.type == LightType.Point && l.name == "LootGlow") { l.intensity = 3.5f; l.range = 6f; l.color = new Color(1f, 0.72f, 0.35f); }
        }
        if (!urp) { Debug.Log("LOOK built-in pipeline dark=" + dark + " (no URP post-processing)"); return; }
        // ---- URP post-processing (global volume) + camera post/AA
        var volT = FindType("UnityEngine.Rendering.Volume"); var profT = FindType("UnityEngine.Rendering.VolumeProfile");
        string ns = "UnityEngine.Rendering.Universal.";
        if (volT == null || profT == null) { Debug.LogWarning("LOOK no Volume type"); return; }
        System.IO.Directory.CreateDirectory("Assets/GameBot/Look"); string pp = "Assets/GameBot/Look/GB_Post.asset"; AssetDatabase.DeleteAsset(pp);
        var prof = ScriptableObject.CreateInstance(profT); AssetDatabase.CreateAsset(prof, pp);
        var add = profT.GetMethod("Add", new[] { typeof(Type), typeof(bool) });
        Func<string, object> comp = n => { var t = FindType(ns + n); if (t == null || add == null) return null; var c = add.Invoke(prof, new object[] { t, false }); if (c is UnityEngine.Object o) { o.hideFlags = HideFlags.HideInInspector | HideFlags.HideInHierarchy; AssetDatabase.AddObjectToAsset(o, prof); } return c; };
        var tm = comp("Tonemapping"); if (tm != null) SetParam(tm, "mode", 2); // ACES
        var ca = comp("ColorAdjustments");
        if (ca != null) { SetParam(ca, "postExposure", dark ? 0.15f : 0.1f); SetParam(ca, "contrast", dark ? 22f : 10f); SetParam(ca, "saturation", dark ? -18f : 8f); SetParam(ca, "colorFilter", dark ? new Color(0.9f, 0.95f, 1f) : Color.white); }
        var bl = comp("Bloom"); if (bl != null) { SetParam(bl, "threshold", 0.95f); SetParam(bl, "intensity", dark ? 0.9f : 0.35f); SetParam(bl, "scatter", 0.65f); }
        var vg = comp("Vignette"); if (vg != null) { SetParam(vg, "intensity", dark ? 0.34f : 0.18f); SetParam(vg, "smoothness", 0.45f); }
        if (dark) { var lgg = comp("ShadowsMidtonesHighlights"); if (lgg != null) { SetParam(lgg, "shadows", new Vector4(0.9f, 0.95f, 1.1f, -0.05f)); SetParam(lgg, "highlights", new Vector4(1.08f, 1.0f, 0.9f, 0f)); } }
        EditorUtility.SetDirty(prof); AssetDatabase.SaveAssets();
        var vgo = new GameObject("GB_PostVolume"); var vol = vgo.AddComponent(volT);
        volT.GetProperty("isGlobal")?.SetValue(vol, true); volT.GetField("priority")?.SetValue(vol, 10f);
        var spP = volT.GetProperty("sharedProfile"); if (spP != null) spP.SetValue(vol, prof);
        var camDataT = FindType(ns + "UniversalAdditionalCameraData");
        foreach (var cam in UnityEngine.Object.FindObjectsByType<Camera>(FindObjectsSortMode.None))
        {
            if (camDataT == null) break; var cd = cam.GetComponent(camDataT) ?? cam.gameObject.AddComponent(camDataT);
            camDataT.GetProperty("renderPostProcessing")?.SetValue(cd, true);
            var aa = camDataT.GetProperty("antialiasing"); if (aa != null) aa.SetValue(cd, Enum.ToObject(aa.PropertyType, 2)); // SMAA
            cam.allowHDR = true; if (outdoor) cam.farClipPlane = Mathf.Max(cam.farClipPlane, 600f);
        }
        Debug.Log("LOOK dark=" + dark + " outdoor=" + outdoor + " mode=" + mode + " post=" + (tm != null) + "/" + (ca != null) + "/" + (bl != null) + "/" + (vg != null) + " skybox=" + (RenderSettings.skybox ? RenderSettings.skybox.name : "none"));
    }
    // Last pass: anything that never went through Spawn()/FixMat (terrain-free props, LOD children...) gets the same
    // pipeline-safe material conversion, then the leftovers are logged as MAT_WHITE.
    static void FinalMatPass()
    {
        int n = 0; foreach (var r in UnityEngine.Object.FindObjectsByType<Renderer>(FindObjectsInactive.Include, FindObjectsSortMode.None))
        { if (r is ParticleSystemRenderer || r is LineRenderer || r is TrailRenderer || r.name == "StormWall") continue; FixMat(r); n++; }
        Debug.Log("FINAL_MATPASS renderers=" + n); LogMatConv();
    }
}
