﻿<#
 Game Bot updater - installs a new Game Bot package WITHOUT touching user data.
 Usage:  powershell -ExecutionPolicy Bypass -File update_gamebot.ps1 -Package <GameBot-Setup.exe | GameBot-product.zip | folder> [-InstallDir <dir>]
 User data (never deleted, backed up first, restored after, verified by hash):
   work\ (chats incl. work\chats\index.json, chat summaries, exports), summaries\, bug_reports\, notes\, lessons\,
   memory.json, license.json, config\gamebot.config.json, config\install_prefs.json, config\gpu_auto.json, config\*.user.json
 Documents\GameProjects is outside the install folder; the updater never writes there and checks it is unchanged.
 Program files are copied over the install; nothing in the install folder is deleted.
#>
param([Parameter(Mandatory=$true)][string]$Package, [string]$InstallDir = $PSScriptRoot, [string]$GameProjects = "")
$ErrorActionPreference = "Stop"
$UserDirs  = @("work", "summaries", "bug_reports", "notes", "lessons")
$UserFiles = @("memory.json", "license.json", "config\gamebot.config.json", "config\install_prefs.json", "config\gpu_auto.json")
function Log($m) { $l = "$(Get-Date -f 'yyyy-MM-dd HH:mm:ss') $m"; Write-Host $l; Add-Content -Path $script:LogFile -Value $l }
function Snapshot($dir) {
    if (-not (Test-Path $dir)) { return @{ n = 0; bytes = 0 } }
    $f = Get-ChildItem $dir -Recurse -File -Force -ErrorAction SilentlyContinue
    return @{ n = @($f).Count; bytes = ($f | Measure-Object Length -Sum).Sum }
}
$InstallDir = (Resolve-Path $InstallDir).Path
if (-not $GameProjects) { $GameProjects = Join-Path ([Environment]::GetFolderPath("MyDocuments")) "GameProjects" }
$ts = Get-Date -f "yyyyMMdd_HHmmss"
$BackupRoot = Join-Path $env:LOCALAPPDATA "GameBot\UserDataBackups\$ts"
New-Item -ItemType Directory -Force $BackupRoot | Out-Null
$script:LogFile = Join-Path $BackupRoot "update.log"
Log "Game Bot update: install=$InstallDir package=$Package"
Log "user-data backup -> $BackupRoot"

# 1) back up user data + hash manifest
$extra = @(Get-ChildItem (Join-Path $InstallDir "config") -Filter "*.user.json" -File -ErrorAction SilentlyContinue | ForEach-Object { "config\" + $_.Name })
$manifest = @()
foreach ($d in $UserDirs) {
    $src = Join-Path $InstallDir $d; if (-not (Test-Path $src)) { continue }
    robocopy $src (Join-Path $BackupRoot $d) /E /COPY:DAT /R:1 /W:1 /NFL /NDL /NJH /NJS /NP | Out-Null
    if ($LASTEXITCODE -ge 8) { Log "BACKUP FAILED for $d (robocopy $LASTEXITCODE) - update aborted, nothing changed"; exit 2 }
}
foreach ($f in ($UserFiles + $extra)) {
    $src = Join-Path $InstallDir $f; if (-not (Test-Path $src)) { continue }
    $dst = Join-Path $BackupRoot $f; New-Item -ItemType Directory -Force (Split-Path $dst) | Out-Null; Copy-Item $src $dst -Force
}
Get-ChildItem $BackupRoot -Recurse -File | Where-Object { $_.Name -ne "update.log" } | ForEach-Object {
    $manifest += [pscustomobject]@{ rel = $_.FullName.Substring($BackupRoot.Length + 1); sha = (Get-FileHash $_.FullName -Algorithm SHA256).Hash }
}
$manifest | ConvertTo-Json -Depth 3 | Set-Content (Join-Path $BackupRoot "manifest.json") -Encoding UTF8
Log "backed up $($manifest.Count) user files"
$gpBefore = Snapshot $GameProjects
Log "GameProjects before: $($gpBefore.n) files, $($gpBefore.bytes) bytes ($GameProjects)"

# 1b) back up the current PROGRAM files too, so a failed copy can be rolled back (review fix 1)
$ProgBak = Join-Path $BackupRoot "program"
$pxd = @(); foreach ($d in ($UserDirs + @("dist", "__pycache__", "sessions_archive"))) { $pxd += (Join-Path $InstallDir $d) }
$pxd += @(Get-ChildItem $InstallDir -Directory -Force -ErrorAction SilentlyContinue | Where-Object { $_.Name -like "_*" } | ForEach-Object { $_.FullName })
robocopy $InstallDir $ProgBak /E /COPY:DAT /R:1 /W:1 /NFL /NDL /NJH /NJS /NP /XD @pxd /XF *.log *.bak* | Out-Null
if ($LASTEXITCODE -ge 8) { Log "PROGRAM BACKUP FAILED (robocopy $LASTEXITCODE) - update aborted, nothing changed"; exit 2 }
Log "program files backed up -> $ProgBak"
function RollbackProgram($why) {
    Log "ROLLING BACK program files ($why)"
    robocopy $ProgBak $InstallDir /E /COPY:DAT /R:2 /W:2 /NFL /NDL /NJH /NJS /NP | Out-Null
    Log "rollback robocopy $LASTEXITCODE"
}

$gpDirs = @(); if (Test-Path $GameProjects) { $gpDirs = @(Get-ChildItem $GameProjects -Directory -Force | ForEach-Object { $_.Name }) }
$tmp = $null
if ($Package -match '\.exe$') {
    # 2+3) new Setup.exe: run it silently into the same folder (its own script also backs up/restores user data)
    Log "running setup $Package"
    $sp = Start-Process -FilePath $Package -ArgumentList @('/VERYSILENT', '/SUPPRESSMSGBOXES', '/NORESTART', '/SP-', "/DIR=`"$InstallDir`"") -Wait -PassThru
    $rc = if ($sp.ExitCode -eq 0) { 0 } else { 16 }
    Log "setup exit $($sp.ExitCode)"
} else {
# 2) unpack the new version to temp
$tmp = Join-Path $env:TEMP "GameBotUpdate_$ts"
if (Test-Path $Package -PathType Container) { $new = (Resolve-Path $Package).Path; $tmp = $null }
else { Expand-Archive -Path $Package -DestinationPath $tmp -Force; $new = $tmp
       $kids = @(Get-ChildItem $tmp -Force); if ($kids.Count -eq 1 -and $kids[0].PSIsContainer) { $new = $kids[0].FullName } }

# 3) copy program files only (user-data paths excluded, nothing deleted - no /MIR, no /PURGE)
$xd = @(); foreach ($d in $UserDirs) { $xd += (Join-Path $new $d) }
$xf = @(); foreach ($f in $UserFiles) { $xf += (Join-Path $new $f) }
$rargs = @($new, $InstallDir, "/E", "/COPY:DAT", "/R:1", "/W:1", "/NFL", "/NDL", "/NJH", "/NJS", "/NP", "/XD") + $xd + @("/XF") + $xf + @("*.user.json")
robocopy @rargs | Out-Null
$rc = $LASTEXITCODE
# new shipped lessons are welcome, but never overwrite ones that already exist
if (Test-Path (Join-Path $new "lessons")) { robocopy (Join-Path $new "lessons") (Join-Path $InstallDir "lessons") /E /XC /XN /XO /R:1 /W:1 /NFL /NDL /NJH /NJS /NP | Out-Null }
Log "program files copied (robocopy $rc)"
}

# 4) restore user data from the backup (user data always wins)
foreach ($m in $manifest) {
    $dst = Join-Path $InstallDir $m.rel; New-Item -ItemType Directory -Force (Split-Path $dst) | Out-Null
    Copy-Item (Join-Path $BackupRoot $m.rel) $dst -Force
}

# 5) verify
$bad = 0
foreach ($m in $manifest) {
    $p = Join-Path $InstallDir $m.rel
    if (-not (Test-Path $p) -or (Get-FileHash $p -Algorithm SHA256).Hash -ne $m.sha) { $bad++; Log "USER FILE CHANGED/MISSING: $($m.rel)" }
}
$gpAfter = Snapshot $GameProjects
Log "GameProjects after: $($gpAfter.n) files, $($gpAfter.bytes) bytes"
if ($gpAfter.n -lt $gpBefore.n) { $bad++; Log "GAMEPROJECTS LOST FILES" }
foreach ($g in $gpDirs) { if (-not (Test-Path (Join-Path $GameProjects $g))) { $bad++; Log "GAMEPROJECTS MISSING GAME: $g" } }
Log "chats index: $(if (Test-Path (Join-Path $InstallDir 'work\chats\index.json')) { 'kept' } else { 'none' })"
if ($tmp -and (Test-Path $tmp)) { Remove-Item $tmp -Recurse -Force -ErrorAction SilentlyContinue }
if ($rc -ge 8) {
    RollbackProgram "copy failed, code $rc"
    foreach ($m in $manifest) { $dst = Join-Path $InstallDir $m.rel; Copy-Item (Join-Path $BackupRoot $m.rel) $dst -Force -ErrorAction SilentlyContinue }
    Log "UPDATE FAILED copying program files (robocopy $rc). Previous version restored; user data intact; backup kept at $BackupRoot"; exit 3
}
if ($bad -gt 0) { Log "UPDATE VERIFY FAILED ($bad problems). Backup kept at $BackupRoot"; exit 4 }
Log "UPDATE OK - $($manifest.Count) user files verified, GameProjects untouched. Backup kept at $BackupRoot"
exit 0
