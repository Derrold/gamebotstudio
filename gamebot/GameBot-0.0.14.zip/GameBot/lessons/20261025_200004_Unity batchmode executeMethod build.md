# Unity batchmode executeMethod build

Tags: unity,build,batchmode
Saved: 2026-10-25T20:00:04

Run: & 'C:\Program Files\Unity\Hub\Editor\6000.6.5f1\Editor\Unity.exe' -batchmode -nographics -quit -projectPath <proj> -executeMethod Class.Method -logFile <log>. Method must be static, in an Assets/**/Editor folder. Fails if the project is open in the Editor (check Get-Process Unity; never kill it). Exception or EditorApplication.Exit(1) => exit code 1. Verify: exit 0 and log has no 'error CS'/'Exception'. Source: https://docs.unity3d.com/Manual/EditorCommandLineArguments.html
