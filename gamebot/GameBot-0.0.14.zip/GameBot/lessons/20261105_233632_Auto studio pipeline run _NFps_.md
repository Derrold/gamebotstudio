# Auto studio pipeline run (NFps)

Tags: auto studio pipeline
Saved: 2026-11-05T23:36:32

run_auto_game_pipeline created 32 files under C:\Users\ExtremeHybrid\Documents\GameProjects\NFps and UNITY 6000.6.5f1: background job started -> create NFpsUnity -> fps game (menu, settings, achievements, owned assets) -> Builds\Windows\NFps.exe. Status: Builds. Next: check Builds\auto_unity_status.txt, then work TaskBoard 'Auto next actions' with tools.
