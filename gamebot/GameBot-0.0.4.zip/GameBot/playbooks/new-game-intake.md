# New-game intake (ask FIRST, build after)
Game Bot asks these before it creates any folder, project, or build. One question per message, each with one or two lines of coaching. Code: intake.py (agent_core runs it before the model).

Always included (do NOT ask whether they want them — Game Bot always builds these): main + pause menus, full Settings (video / audio / controls), HUD, achievements, playable Windows build.

## Question spine (skip any the first message already answered)
1. Engine: **Unity or Unreal?** Ask first whenever both are installed. Nothing is created until the creator picks.
   - Unity: fastest builds, lighter on 8-12 GB GPUs, C#. A good fit for small 3D/2D games and platformers.
   - Unreal: top-end visuals, Blueprints/C++, heavier builds and disk.
2. **What is the game called?** Only take a title if the user said called / named / titled X. Never invent a title from "make a new fps" (that used to become NFps). "you pick" means Game Bot chooses one; it can be renamed later.
3. **Genre** — show the official top-19 list (from r30_genre_spec.ORDER) as a numbered list; accept number, name, or alias (fps=shooter, sim=simulation, br=battle royale, open world=open_world):
   1. Action  2. Adventure  3. RPG  4. Shooter / FPS  5. Strategy  6. Simulation  7. Sports  8. Racing  9. Fighting  10. Horror  11. Platformer  12. Puzzle  13. Open World  14. Survival  15. Sandbox  16. Stealth  17. Battle Royale  18. MOBA  19. MMORPG
4. **Core loop** — what the player does over and over (one line).
5. **Story / premise** — who you are, what's going on ("light" / "none" OK).
6. **Goals** — how you win (and lose if relevant).
7. **Setting / world** — where / when.
8. **Art style / tone** — realistic, stylized, low-poly, horror-dark, cute, cartoon, etc.
9. Template: Unity **3D (URP)** (recommended) or **3D (Built-in)**. Unreal: **Third Person / First Person / Blank**.
10. Desktop icon + installer after the build? yes -> Builds\\Installer\\<Name>_Windows.zip + Desktop\\<Name>.lnk.

Then run_auto_game_pipeline(name, engine, template, desktop_icon) with user_text that includes genre + loop + story + goals + setting + art/tone -> docs, legal, QA, store stubs, Unity batchmode create -> Builds\\Windows\\<Name>.exe.

## Progressive asset chat (after the build, one at a time)
Every top-19 genre has its own asset spine in intake.ASSETS (player/env/weapons/etc. as fits). Answers: a description -> make_asset (Blender headless); "my assets" -> coach owned-asset path; "free" -> CC0 fallback; "skip" -> next.

## Coaching: owned assets ("My Assets")
- Unity: Window > Package Manager > My Assets > Download > Import. Cache: %APPDATA%\\Unity\\Asset Store-5.x\\<Publisher>\\<Category>\\*.unitypackage.
- Unreal: Epic Games Launcher > Unreal Engine > Library (Fab) > Add to Project. Cache: C:\\ProgramData\\Epic\\EpicGamesLauncher\\VaultCache.

## Free fallbacks (CC0 unless noted; every pick gets an ATTRIBUTION.md row)
Kenney.nl, Quaternius, Poly Haven, ambientCG, OpenGameArt (check each license), Mixamo (animations, Adobe account).

## Human gates stay human
Store accounts/tax/bank, real AppIDs, age ratings, store review submit, Release click, purchases, large engine installs, public deploys, legal review.
