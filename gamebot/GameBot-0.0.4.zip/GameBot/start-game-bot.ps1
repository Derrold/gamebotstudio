# Game Bot live launcher - always uses gamebot-trained (current live)
Set-Location $PSScriptRoot
$env:OLLAMA_MODEL = 'gamebot-trained'
Start-Process -FilePath "$env:SystemRoot\System32\wscript.exe" -ArgumentList ('"' + (Join-Path $PSScriptRoot 'GameBot.vbs') + '"')