# Unity custom item / weapon pipeline (generic, any project)
Goal: add a new weapon/item/tool to ANY Unity project fully automatically: model -> data -> prefab -> registration -> shop/unlock -> baked scene -> verified build.

## 1. Data model (pick per project, detect first)
- Read the project before editing: list_files Assets\Scripts + Assets\Editor, search for existing registries (grep "ScriptableObject", "Registry", "Database", "Define(", "Register(").
- Preferred for new projects: `WeaponDef : ScriptableObject` (id, displayName, prefab, icon, damage, fireRate/cycle, magSize, reloadTime, recoil, range/falloff, ammoType, price, unlockRank, slot) + `ItemDatabase : ScriptableObject` holding a List<WeaponDef>.
- Code-defined registries (a static builder with calls like `Define("Name", stats...)`) are common in procedural projects: add ONE new line next to a similar existing entry; never rewrite the table.
- Prefab = visuals/behaviour (model, colliders, muzzle/attach points, animator). ScriptableObject = tunable shared data. Never duplicate stats inside prefabs.

## 2. Model
- make_asset (Blender headless) or CC0 intake -> FBX into Assets\Models\<Category>\<Id>\. Unity axes: export -Z forward, Y up, apply scale; scale 1 unit = 1 m. Pivot at grip/handle; muzzle as an empty named Muzzle.
- Import settings via AssetPostprocessor (OnPreprocessModel: globalScale, materialImportMode, generate colliders off).

## 3. Registration by Editor script (no hand clicking)
- Editor\ItemImporter.cs static method `CreateWeapon(string id)`: AssetDatabase.LoadAssetAtPath FBX -> PrefabUtility.SaveAsPrefabAsset -> ScriptableObject.CreateInstance<WeaponDef>() -> AssetDatabase.CreateAsset -> add to ItemDatabase -> EditorUtility.SetDirty + AssetDatabase.SaveAssets.
- Run in batchmode: `Unity.exe -batchmode -nographics -quit -projectPath <proj> -executeMethod ItemImporter.CreateFromEnv -logFile <log>` with env ITEM_ID / ITEM_JSON (see unity-batchmode-content-bake).
- Shop/progression: add unlock entry (rank/price) in the same commit; loadout/slot lists must include the new id or it never appears.

## 4. Safe text patching (when the registry is C# code)
- Backup first (file.bak_<timestamp>, verify size). Exact-needle insert AFTER a known existing entry; refuse if the needle is missing.
- Sanity gate before write: file must not shrink, keep `class`/`public static`, brace balance unchanged, preserve BOM + line endings (utf-8-sig, newline="").
- Write to .tmp, re-read and compare, then atomic replace. Print BACKUP/WROTE lines so failures can restore exactly what this run touched.
- Referenced symbols (ammo type, materials) must be defined BEFORE the inserted line (CS0103/CS0841 otherwise).

## 5. Bake + verify
- Batch compile/bake -> grep log for `error CS` -> on error restore this run's backups, research_error the first error, patch, retry once, teach_self.
- Play check: spawn item in a test scene via an Editor test or PlayMode test; fire/use once; log PASS/FAIL.
- Never touch player saves; new progression keys get a default + schema version (save-load-systems).

## 6. Balance
- Each weapon needs a role: range band, damage, handling, capacity, legality/availability. Put stat tables in Docs\Balance.csv and generate defs from it (content-pipeline-automation).
