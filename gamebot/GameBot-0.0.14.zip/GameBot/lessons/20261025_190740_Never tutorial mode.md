# Never tutorial mode

Tags: action blender 
Saved: 2026-10-25T19:07:40

When user says you do it all / make it / yes: CALL tools (run_blender_script, write_text_file, launch_app). Never paste JSON tool calls in chat. Never ask proceed again.
