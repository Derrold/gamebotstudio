"""Missing-packs fix (0.0.4 candidate): open/create the game's Unity project, fetch owned packs in the Editor,
rescan 'in My Assets but not downloaded', gate intents, short reprompt, placeholder offer, open-in-Unity intent,
Unity Hub registration, command phrases never become titles. Usage: python patch_assets.py <app dir> <new files dir>"""
import os, re, shutil, sys
from pathlib import Path

TAG = ".bak_assets_20261113"
D = Path(sys.argv[1]); NEW = Path(sys.argv[2])


def rd(p):
    with open(p, "r", encoding="utf-8-sig", newline="") as f:
        t = f.read()
    with open(p, "rb") as f:
        bom = f.read(3) == b"\xef\xbb\xbf"
    return t, ("\r\n" if "\r\n" in t else "\n"), bom


def wr(p, t, bom):
    with open(p, "w", encoding="utf-8-sig" if bom else "utf-8", newline="") as f:
        f.write(t)


def backup(p):
    b = p.with_name(p.name + TAG)
    if p.exists() and not b.exists():
        shutil.copy2(p, b)


def sub1(t, old, new, nl, label):
    o, n = old.replace("\n", nl), new.replace("\n", nl)
    if n in t:
        return t
    c = t.count(o)
    if c != 1:
        raise SystemExit(f"{label}: expected 1 match, found {c}")
    return t.replace(o, n)


def patch(name, edits):
    p = D / name
    t, nl, bom = rd(p)
    backup(p)
    for label, old, new in edits:
        t = sub1(t, old, new, nl, f"{name}:{label}")
    wr(p, t, bom)
    print("patched", name)


# ---------------------------------------------------------------- asset_plan.py
patch("asset_plan.py", [
    ("choicewords", '''    "placeholder": r"\\bplaceholders?\\b|''', '''    "placeholder": r"\\bplace ?holders?\\b|\\bcontinue\\b|'''),
    ("cachedirs", '''    base = Path(app) / "Unity"
    return [p for p in base.glob("Asset Store-5.x*") if p.is_dir()] if base.is_dir() else []
''', '''    base = Path(app) / "Unity"
    out = [p for p in base.glob("Asset Store-5.x*") if p.is_dir()] if base.is_dir() else []
    env = os.environ.get("ASSETSTORE_CACHE_PATH")  # Unity 6 custom Asset Store cache location
    if env and Path(env).is_dir() and Path(env) not in out:
        out.append(Path(env))
    return out
'''),
    ("unresolved", '''if ch.get(m["key"]) not in ("blender", "placeholder")]''', '''if ch.get(m["key"]) not in ("blender", "placeholder", "project")]'''),
    ("mq", '''    lines.append("1. Point you to free Asset Store packs for it (you download, then say \\"rescan\\")")
    lines.append("2. Make it in Blender and import it")
    lines.append("3. Use a simple placeholder for now")
    ex = miss[0]["label"]
    lines.append(f"Reply with a number or word for all of them (\\"2\\" / \\"blender\\"), or per item (\\"{ex} blender\\").")
    return "\\n".join(lines)
''', '''    lines.append("1. Free Asset Store packs: you add them to My Assets, then I open your Unity project and download + import them")
    lines.append("2. Make it in Blender and import it")
    lines.append("3. Use a simple placeholder for now")
    ex = miss[0]["label"]
    lines.append(f"Reply with a number or word for all of them (\\"2\\" / \\"blender\\"), or per item (\\"{ex} blender\\").")
    lines.append(PLACEHOLDER_OFFER)
    return "\\n".join(lines)


PLACEHOLDER_OFFER = 'Or say "continue" to continue with placeholders now and swap in packs later.'


def short_reprompt(plan: dict, title: str = "your game") -> str:
    """One or two lines instead of the whole list (for replies Game Bot didn't understand)."""
    miss = unresolved(plan)
    if not miss:
        return confirm_text(plan, title)
    names = ", ".join(m["label"] for m in miss[:6]) + (f" +{len(miss) - 6} more" if len(miss) > 6 else "")
    return (f"Still no pack for: {names}. Reply 1 (free Asset Store packs), 2 (Blender) or 3 (placeholder), "
            f"or say \\"open unity\\" or \\"help\\". " + PLACEHOLDER_OFFER)


def match_project_packs(plan: dict, names: list) -> list:
    """Needs already covered by a pack inside the game's Unity project (Packages / Assets folders)."""
    hits = []
    for m in unresolved(plan):
        spec = NEEDS.get(m["key"]) or EXTRA.get(m["key"])
        pat = spec[2] if spec else re.escape(m["label"])
        for n in names or []:
            if re.search(pat, _words(str(n))) or re.search(pat, str(n), re.I):
                plan.setdefault("choices", {})[m["key"]] = "project"
                plan.setdefault("in_project", {})[m["key"]] = str(n)
                hits.append((m["label"], str(n)))
                break
    return hits
'''),
    ("store_reply", '''    lines.append("Add one to My Assets, then in Unity open Window > Package Manager > My Assets and click Download. "
                 "Say \\"rescan\\" when it's downloaded and I'll pick it up. Or say \\"blender\\" or \\"placeholder\\" instead.")
    return "\\n".join(lines)
''', '''    lines.append("Click Add to My Assets on the ones you like (free packs only - nothing gets bought).")
    lines.append("Unity is opening your project. In Unity: Window > Package Manager > My Assets, then click Download and Import on each pack. Say rescan when done.")
    lines.append("While Unity is open I also download the packs from your My Assets myself, and the build imports them (progress shows in the build bar).")
    lines.append(PLACEHOLDER_OFFER)
    return "\\n".join(lines)
'''),
    ("summary", '''        elif c == "placeholder":
            out.append(f"- {m['label']}: placeholder (no pack)")
''', '''        elif c == "placeholder":
            out.append(f"- {m['label']}: placeholder (no pack)")
        elif c == "project":
            out.append(f"- {m['label']}: already in the Unity project ({(plan.get('in_project') or {}).get(m['key'], 'pack')})")
'''),
    ("choice_rescan", '''        plan = build_plan(plan.get("family") or "fps", brief, plan.get("template", ""), plan.get("choices"))
        save_plan(root, plan)
        if unresolved(plan):
            return "I scanned again. " + missing_question(plan, title)
''', '''        plan = build_plan(plan.get("family") or "fps", brief, plan.get("template", ""), plan.get("choices"))
        lines = ["I scanned again (Asset Store cache and the project's Packages folder)."]
        try:
            import asset_fetch as _af
            for lab, nm in match_project_packs(plan, _af.project_packages(root)):
                lines.append(f"{nm} is already in the {title} Unity project - using it for {lab}.")
            lines += _af.not_downloaded_lines(_af.not_downloaded(root, plan))
        except Exception:
            pass
        save_plan(root, plan)
        if unresolved(plan):
            return "\\n".join(lines + [short_reprompt(plan, title)])
'''),
    ("choice_prev", '''    if "you don't have a pack for" not in prev and "Asset Store searches" not in prev:''',
     '''    if not any(k in prev for k in ("you don't have a pack for", "Asset Store searches", "Still no pack for", "Unity is opening your project")):'''),
    ("choice_store", '''        if stores:
            return store_reply(plan, stores)
        if unresolved(plan):
            return missing_question(plan, title)
    try:''', '''        if stores:
            try:
                import asset_fetch as _af
                _om = _af.start_fetch(root, plan=plan)
            except Exception as e:
                _om = f"(couldn't open Unity: {e})"
            return store_reply(plan, stores) + "\\n\\n" + _om
        if unresolved(plan):
            return missing_question(plan, title)
    try:'''),
])

# ---------------------------------------------------------------- intake.py
p = D / "intake.py"
t, nl, bom = rd(p)
backup(p)
a = t.find("_GATE_HELP = (")  # re-run: replace the whole previously inserted block
if a < 0:
    a = t.find("def _asset_gate_reply(st, t):")
b = t.find(nl + nl + nl + "def _run_payload(st):")
if a < 0 or b < 0:
    raise SystemExit("intake: gate function not found")
GATE = '''_GATE_HELP = ("How this step works:\\n"
              "- 1 = free Asset Store packs: click Add to My Assets on the website, then I open your Unity project and "
              "download + import them (or you click Download and Import in Unity: Window > Package Manager > My Assets).\\n"
              "- 2 = I model it in Blender.\\n"
              "- 3 = a simple placeholder.\\n"
              "You can also say \\"open unity\\", \\"where do I download\\", \\"rescan\\" or \\"continue\\".")
_WHERE_DL = ("Packs you add on the website go to My Assets, but they aren't on this PC until they're downloaded. "
             "I'll open your game's Unity project and download + import them for you. If that doesn't start: "
             "in Unity open Window > Package Manager, pick My Assets on the left, select each pack, click Download, "
             "then Import. Downloads are saved in %APPDATA%\\\\Unity\\\\Asset Store-5.x. Say rescan when done.")
_CONTINUE_RX = re.compile(
    r"^\\s*(please\\s+)?(ok(ay)?[, ]+)?(continue|skip( it| them| all| that)?|go on|carry on|move on|keep going|just build( it)?|"
    r"build( it)? anyway|(use\\s+)?(a\\s+|the\\s+)?place ?holders?( for (now|all|everything|them|it))?( now| please| instead)?|"
    r"continue with place ?holders?.*|3)\\s*[.!]*\\s*$", re.I)


def _gate_root(st):
    from auto_studio import GAME_PROJECTS
    return Path(GAME_PROJECTS) / (_proj(st) or "NewGame")


def _gate_open(st, plan):
    try:
        import asset_fetch
        msg = asset_fetch.start_fetch(_gate_root(st), plan=plan, template=st.get("template"))
    except Exception as e:
        msg = f"(couldn't open Unity: {type(e).__name__}: {e})"
    st["fetch_started"] = True
    return msg


def _asset_gate_reply(st, t):
    from asset_plan import (parse_choices, unresolved, missing_question, store_reply, summary_lines, confirm_text,
                            CONFIRM_RX, short_reprompt, match_project_packs, PLACEHOLDER_OFFER)
    tl = (t or "").lower().strip()
    plan = st.get("asset_plan") or _gate_plan(st)

    def _go():
        try:  # a Game Bot-opened editor must close before the batchmode build can use the project
            import asset_fetch
            asset_fetch.finish(_gate_root(st), wait_s=60)
        except Exception:
            pass
        st["phase"] = "assets"
        st["ai"] = 0
        payload = _run_payload(st)
        payload["run"]["asset_choices"] = dict(plan.get("choices") or {})
        return payload

    if CONFIRM_RX.match(t or "") and not unresolved(plan):
        return _go()
    if _CONTINUE_RX.match(tl):
        plan.setdefault("choices", {}).update({m["key"]: "placeholder" for m in unresolved(plan)})
        st["asset_choices"] = dict(plan["choices"])
        return _go()
    if re.search(r"\\bhelp\\b|what do i do|i'?m stuck|\\bstuck\\b|confused|don'?t understand|what now", tl):
        return _GATE_HELP + "\\n\\n" + short_reprompt(plan, _disp(st))
    if re.search(r"\\bwhere\\b.{0,40}\\bdownload|\\bhow\\b.{0,40}\\bdownload|\\bwhere\\b.{0,30}\\b(packs?|assets?)\\b|didn'?t download|not downloaded", tl):
        return _WHERE_DL + "\\n" + PLACEHOLDER_OFFER
    try:
        import asset_fetch as _af
        _open = _af.wants_open_unity(t) or re.search(r"\\bopen\\b.{0,30}\\b(unity|project)\\b|\\bunity\\b.{0,10}\\bopen\\b", tl)
    except Exception:
        _open = False
    if _open:
        msg = _gate_open(st, plan)
        return (msg + "\\n\\n" + "Unity is opening your project. In Unity: Window > Package Manager > My Assets, then click "
                "Download and Import on each pack. Say rescan when done.\\n"
                "While Unity is open I also download the packs from your My Assets myself, and the build imports them (progress shows in the build bar).\\n"
                + PLACEHOLDER_OFFER)
    if re.search(r"\\b(rescan|re-scan|scan again|refresh|downloaded|got it|done|added( them)?|i added)\\b", tl):
        plan = _gate_plan(st, refresh=True)
        root = _gate_root(st)
        lines = ["I scanned again (Asset Store cache %APPDATA%\\\\Unity\\\\Asset Store-5.x and the project's Packages folder)."]
        nd = []
        try:
            import asset_fetch as _af
            for lab, nm in match_project_packs(plan, _af.project_packages(root)):
                lines.append(f"{nm} is already in the {_disp(st)} Unity project - using it for {lab}.")
            nd = _af.not_downloaded(root, plan)
            lines += _af.not_downloaded_lines(nd)
        except Exception:
            pass
        st["asset_choices"] = dict(plan.get("choices") or {})
        if not unresolved(plan):
            return "\\n".join(lines + [confirm_text(plan, _disp(st))])
        if nd:
            lines.append("Leave Unity open and I'll download them (the build imports them), or in Unity: Window > Package Manager > "
                         "My Assets, then click Download and Import on each pack. Say rescan when done.")
        elif not st.get("fetch_started"):
            lines.append("I don't see new packs yet. Say \\"open unity\\" and I'll open your project and pull them from My Assets.")
        lines.append(short_reprompt(plan, _disp(st)))
        return "\\n".join(lines)
    ch = parse_choices(t, plan)
    if not ch:
        from asset_plan import wants_assets, owned_list_text
        if wants_assets(t) or re.search(r"\\b(list|show|what)\\b.*\\b(assets?|packs?)\\b", tl):
            return owned_list_text() + "\\n\\nPacks I'll use for " + _disp(st) + ":\\n" + summary_lines(plan) + "\\n\\n" + short_reprompt(plan, _disp(st))
        return "Sorry, I didn't catch that. " + short_reprompt(plan, _disp(st))
    stores = [k for k, v in ch.items() if v == "store"]
    plan.setdefault("choices", {}).update({k: v for k, v in ch.items() if v != "store"})
    st["asset_choices"] = dict(plan["choices"])
    if stores:
        return store_reply(plan, stores) + "\\n\\n" + _gate_open(st, plan)
    if unresolved(plan):
        return "Got it. " + short_reprompt(plan, _disp(st))
    return "Got it. " + confirm_text(plan, _disp(st))'''
t = t[:a] + GATE.replace("\n", nl) + t[b:]
if not re.search(r"^from pathlib import .*\bPath\b", t, re.M):
    t = t.replace(nl + "import re" + nl, nl + "import re" + nl + "from pathlib import Path" + nl, 1)
edits = [
    ("openintent", '''    st = _active(messages)
    # Start / restart intake on a clear new-game ask.''', '''    st = _active(messages)
    # "open cod2 in unity" / "put cod2 in unity" / "make project in unity" / "open project" / "edit in unity":
    # open the existing game's Unity project. Never start intake or turn the phrase into a title.
    if not (st and st.get("phase") == "asset_gate"):
        try:
            import asset_fetch as _af
            if _af.wants_open_unity(t) and not is_new_game(t):
                pre = ""
                if st is not None and st.get("phase") == "intake":
                    st["phase"] = "idle"
                    pre = "OK - I stopped the new-game questions. "
                return pre + _af.open_reply(t, None)
        except Exception:
            pass
    # Start / restart intake on a clear new-game ask.'''),
    ("existing_offer", '''    if st["phase"] == "intake":
        a = st.get("asked")
''', '''    if st["phase"] == "intake":
        a = st.get("asked")
        if st.get("existing_offer"):
            ex = Path(st.pop("existing_offer"))
            if re.match(r"^\\s*(open|yes|yeah|yep|ok|okay|sure|y)\\b", t, re.I):
                st["phase"] = "idle"
                import asset_fetch as _af
                return "OK - I stopped the new-game questions. " + _af.open_project(ex)
            if re.match(r"^\\s*(new|keep|same|no|nope|n)\\b", t, re.I):
                st["title"] = ex.name
                st["_existing_ok"] = True
                return _question(st)
'''),
    ("titleguard", '''                    cand = re.sub(r"[^A-Za-z0-9 _-]", "", cand)[:40].strip()
                    st["title"] = None if _is_filler_title(cand) else cand
''', '''                    cand = re.sub(r"[^A-Za-z0-9 _-]", "", cand)[:40].strip()
                    st["title"] = None if (_is_filler_title(cand) or _is_command_title(cand)) else cand
                    if st["title"] and not st.get("_existing_ok"):
                        try:
                            import asset_fetch as _af
                            ex = _af.find_game(title=st["title"])
                        except Exception:
                            ex = None
                        if ex is not None and (any(ex.glob("*Unity")) or (ex / "Builds").is_dir()):
                            st["existing_offer"] = str(ex)
                            st["title"] = None
                            return (f"You already have a game called {ex.name} (Documents\\\\GameProjects\\\\{ex.name}). "
                                    f"Say \\"open\\" to open {ex.name} in Unity instead, \\"new\\" to keep making a new game "
                                    "with that name, or type a different name.")
'''),
    ("resume_markers", '''        if MARK in prev or "Asset question" in prev or "you don't have a pack for" in prev or "Asset Store searches" in prev:''',
     '''        if MARK in prev or "Asset question" in prev or "you don't have a pack for" in prev or "Asset Store searches" in prev \\
                or "Still no pack for" in prev or "Unity is opening your project" in prev:'''),
    ("cmdtitle", '''def _is_filler_title(nm: str) -> bool:''', '''_CMD_TITLE = re.compile(
    r"\\b(unity|project|projects|folder|editor|hub|placeholders?|rescan)\\b|^\\s*(open|put|edit|load|launch|help|continue|skip|"
    r"use|show|where|how|why|what|rebuild|play|run|close|delete|cancel|stop)\\b", re.I)


def _is_command_title(nm: str) -> bool:
    """'Put Cod2 In Unity' / 'open project' / 'use place holder' are commands, never game titles."""
    return bool(_CMD_TITLE.search(nm or ""))


def _is_filler_title(nm: str) -> bool:'''),
]
for label, old, new in edits:
    t = sub1(t, old, new, nl, "intake.py:" + label)
wr(p, t, bom)
print("patched intake.py")

# ---------------------------------------------------------------- auto_studio.py
patch("auto_studio.py", [
    ("hub_after_build", '''        return f"{root.name}: status says {head} but no {eng} process is running (job may have stopped) - last step: {last}"
    return f"{root.name}: {head}"
''', '''        return f"{root.name}: status says {head} but no {eng} process is running (job may have stopped) - last step: {last}"
    if head.startswith("DONE OK") and eng == "Unity":
        try:  # every built game shows up in Unity Hub's Projects list
            from asset_fetch import register_hub
            register_hub(unity_project_dir(root) or root / f"{root.name}Unity")
        except Exception:
            pass
    return f"{root.name}: {head}"
'''),
    ("rebuild_close", '''    if unity_job_running(root):
        return "a Unity build is already running - the next build picks this up"
    refresh_unity_tools(root)''', '''    if unity_job_running(root):
        return "a Unity build is already running - the next build picks this up"
    try:  # Unity can't open one project twice: close a Game Bot-opened editor, never the creator's own
        from asset_fetch import finish, editor_open, project_dir
        if editor_open(project_dir(root)) and not finish(root, wait_s=45):
            return "Unity is open on this project - save and close Unity, then say rebuild"
    except Exception:
        pass
    refresh_unity_tools(root)'''),
    ("pipeline_close", '''    if unity_job_running(root):
        return f"UNITY: a build for {nm} is already running - not starting a second one. {build_status(root)}"
''', '''    if unity_job_running(root):
        return f"UNITY: a build for {nm} is already running - not starting a second one. {build_status(root)}"
    try:
        from asset_fetch import finish, editor_open
        if editor_open(proj) and not finish(root, wait_s=60):
            return f"UNITY: {nm} is open in the Unity Editor - save and close Unity, then say rebuild."
    except Exception:
        pass
'''),
])

# ---------------------------------------------------------------- chat_store.py (build bar)
patch("chat_store.py", [
    ("scrub_case", '''r"^\\s*(ROOT |AUTO_PIPELINE|UNITY[ :_]|UNREAL[ :_]|KIT |''', '''r"^\\s*(ROOT |AUTO_PIPELINE|(?-i:UNITY[ :_]|UNREAL[ :_])|KIT |'''),
    ("bar", '''    return {
        "active": bool(running),
        "state": "run" if running else''', '''    try:  # owned packs downloading/importing inside Unity
        from asset_fetch import bar_state
        _fb = bar_state()
        if _fb and not running:
            return _fb
    except Exception:
        pass
    return {
        "active": bool(running),
        "state": "run" if running else'''),
])

# ---------------------------------------------------------------- new files
for f in ("asset_fetch.py",):
    backup(D / f)
    shutil.copy2(NEW / f, D / f)
(D / "unity_tools").mkdir(exist_ok=True)
backup(D / "unity_tools" / "GameBotAssetFetch.cs")
shutil.copy2(NEW / "GameBotAssetFetch.cs", D / "unity_tools" / "GameBotAssetFetch.cs")
print("copied asset_fetch.py + unity_tools/GameBotAssetFetch.cs")
