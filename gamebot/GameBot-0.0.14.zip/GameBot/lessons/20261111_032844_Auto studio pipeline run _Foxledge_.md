# Auto studio pipeline run (Foxledge)

Tags: auto studio pipeline
Saved: 2026-11-11T03:28:44

run_auto_game_pipeline created 33 files under C:\Users\ExtremeHybrid\Documents\GameProjects\Foxledge and UNITY 6000.6.5f1: background job started -> create FoxledgeUnity -> Platformer game (gameplay template: platformer; menu, settings, achievements, owned assets) . Next: check Builds\auto_unity_status.txt, then work TaskBoard 'Auto next actions' with tools.
