using UnityEngine;
/// <summary>Generic collectible for horror fuses, RPG relics, adventure key/treasure.</summary>
public class QuestItem : MonoBehaviour
{
    public string kind = "item";
    void Update() { transform.Rotate(0, 60f * Time.deltaTime, 0); transform.position += Vector3.up * Mathf.Sin(Time.time * 2f) * 0.002f; }
    void OnTriggerEnter(Collider o)
    {
        if (!o.CompareTag("Player")) return;
        if (GenreState.IsRpg && !GenreState.QuestTaken) return; // must accept quest first
        GenreState.Item(kind); Destroy(gameObject);
    }
}
