"""Scan already-owned Unity Asset Store / Epic Fab caches on this PC."""
from __future__ import annotations

import json
import os
import re
from pathlib import Path

def _unity_cache_dirs() -> list[Path]:
    out: list[Path] = []
    app = os.environ.get("APPDATA") or str(Path.home() / "AppData" / "Roaming")
    base = Path(app) / "Unity"
    if base.is_dir():
        out += [p for p in base.glob("Asset Store-5.x*") if p.is_dir()]
    return out


def _projects_root() -> Path:
    return Path.home() / "Documents" / "GameProjects"


# Unity's Asset Store cache drops a leading non-ASCII letter from some file names (e.g. a Cyrillic "C" in
# "Country House FREE" -> "ountry House FREE.unitypackage"). Repair the display name from a small vocabulary.
_NAME_VOCAB = set("""country castle city house home modern medieval simple stylized free forest fantasy military nature urban
village town character characters weapon weapons gun guns pack low poly lowpoly sci fi realistic rural farm cabin cottage
building buildings props prop tree trees terrain vehicle vehicles car cars apartment office street road ruins ruined
cartoon classic complete cute dark desert dungeon environment environments wooden wood stone rock rocks grass ground
animals animal zombie zombies soldier soldiers robot robots monster monsters creature creatures sword swords kit
interior exterior industrial post apocalyptic ultimate basic big small mega mini starter sample samples polygon
stylised hand painted handpainted old abandoned asian japanese chinese viking western cyber cyberpunk space station
""".split())


def _fix_pack_name(stem: str, vocab: set | None = None) -> str:
    s = (stem or "").strip()
    if not s or not s[0].islower():
        return s
    first = re.split(r"[\s_-]+", s, 1)[0]
    low = first.lower()
    words = (vocab or set()) | _NAME_VOCAB
    if low in words:
        return s[0].upper() + s[1:]
    for c in "ABCDEFGHIJKLMNOPQRSTUVWXYZ":
        if (c.lower() + low) in words:
            return c + s
    return s


def list_owned_assets(engine: str = "Unity", project: str | None = None, limit: int = 200) -> dict:
    """Return packs from local download caches (owned-and-downloaded, not account wishlist)."""
    res: dict = {"engine": engine, "packs": [], "sources": [], "project_packages": []}
    eng = (engine or "Unity").lower()
    if eng.startswith("unreal"):
        vc = Path(r"C:\ProgramData\Epic\EpicGamesLauncher\VaultCache")
        if vc.is_dir():
            res["sources"].append(str(vc))
            for d in sorted(vc.iterdir(), key=lambda p: p.stat().st_mtime, reverse=True):
                if d.is_dir():
                    name = re.sub(r"V\d+$", "", d.name)
                    res["packs"].append({"name": name, "publisher": "Epic/Fab", "size_mb": 0.0, "path": str(d)})
    else:
        for c in _unity_cache_dirs():
            res["sources"].append(str(c))
            found = sorted(c.rglob("*.unitypackage"), key=lambda p: p.stat().st_mtime, reverse=True)
            for f in found:
                rel = f.relative_to(c).parts
                pub = rel[0] if len(rel) > 1 else ""
                res["packs"].append({
                    "name": _fix_pack_name(f.stem),
                    "publisher": pub,
                    "size_mb": round(f.stat().st_size / 1048576, 1),
                    "path": str(f),
                })
        roots: list[Path] = []
        pr = _projects_root()
        if project and (pr / project).is_dir():
            roots = [pr / project]
        elif pr.is_dir():
            roots = [p for p in pr.iterdir() if p.is_dir()][:12]
        for r in roots:
            m = r / "Packages" / "manifest.json"
            try:
                deps = json.loads(m.read_text(encoding="utf-8")).get("dependencies", {})
                for k, v in list(deps.items())[:40]:
                    res["project_packages"].append({"project": r.name, "id": k, "ver": v})
            except Exception:
                pass
    if limit and len(res["packs"]) > limit:
        res["packs"] = res["packs"][:limit]
    return res


def _genre_keywords(genre: str) -> list[str]:
    g = (genre or "").lower().replace("-", "_")
    if "open_world" in g or "open world" in g:
        return ["environment", "terrain", "nature", "town", "city", "village", "building", "house", "road", "ruin",
                "apocalyp", "landscape", "tree", "forest", "vehicle", "car", "character", "survival", "prop", "open world"]
    if "sandbox" in g:
        return ["build", "craft", "block", "voxel", "prop", "terrain", "tool", "nature", "modular", "kit"]
    if "stealth" in g:
        return ["character", "guard", "interior", "building", "dark", "door", "office", "security", "city", "night"]
    if "battle" in g or g in ("br",):
        return ["weapon", "gun", "military", "soldier", "character", "terrain", "vehicle", "rifle", "island"]
    if "mmo" in g:
        return ["fantasy", "medieval", "character", "armor", "village", "sword", "castle", "rpg", "terrain"]
    if "moba" in g:
        return ["fantasy", "character", "tower", "vfx", "terrain", "hero", "spell", "minion"]
    if "strategy" in g:
        return ["building", "unit", "medieval", "terrain", "castle", "army", "village", "ui", "icon"]
    if "fighting" in g:
        return ["character", "animation", "arena", "vfx", "martial", "fighter", "combat"]
    if "sport" in g:
        return ["ball", "stadium", "field", "sport", "character", "football", "soccer", "basketball"]
    if "action" in g:
        return ["character", "weapon", "enemy", "vfx", "sword", "gun", "combat", "animation"]
    if any(k in g for k in ("platform", "platformer")):
        return ["character", "player", "platform", "tile", "2d", "nature", "terrain", "prop", "animal"]
    if any(k in g for k in ("fps", "shooter")):
        return ["weapon", "gun", "soldier", "character", "fps", "military", "vfx", "optic", "shotgun"]
    if "racing" in g or "race" in g:
        return ["vehicle", "car", "road", "track", "race", "sedan"]
    if "horror" in g:
        return ["creature", "monster", "dark", "horror", "zombie", "mansion", "apartment", "crossbow"]
    if "rpg" in g:
        return ["medieval", "weapon", "character", "fantasy", "sword", "armor", "rpg"]
    if "puzzle" in g:
        return ["prop", "block", "puzzle", "ui", "icon", "tile", "kit"]
    if "survival" in g:
        return ["nature", "terrain", "camp", "survival", "craft", "tree", "animal"]
    if "adventure" in g:
        return ["character", "nature", "terrain", "animal", "map", "prop", "adventure"]
    if any(k in g for k in ("sim", "management", "shop")):
        return ["prop", "building", "apartment", "tool", "interior", "shop", "furniture"]
    if "rogue" in g:
        return ["weapon", "dungeon", "character", "enemy", "loot", "gun", "low poly"]
    return []


_LOW_VALUE = ("shader", "icon", "skybox", "gui", "font")


def _extra_words(extra: str) -> list[str]:
    stop = {"with", "and", "the", "after", "from", "into", "that", "this", "your", "their", "empty", "small", "muted",
            "colors", "colours", "realistic", "gritty", "stylized", "defend", "scavenge", "craft", "survive", "days"}
    out = []
    for w in re.findall(r"[a-z]{4,}", (extra or "").lower()):
        w = w[:-1] if w.endswith("s") and len(w) > 4 else w
        if w not in stop and w not in out:
            out.append(w)
    return out[:20]


def order_packs(packs: list, genre: str = "", extra: str = "") -> tuple[list, bool]:
    """Genre (and brief-word) relevant packs first; generic shaders/icons last. Same order for list + number pick."""
    keys = _genre_keywords(genre)
    words = _extra_words(extra)
    if not keys and not words:
        return list(packs), False
    scored = []
    for p in packs:
        blob = f"{p.get('name','')} {p.get('publisher','')}".lower()
        s = 2 * sum(1 for k in keys if k in blob) + sum(1 for w in words if w in blob)
        if s == 0 and any(k in blob for k in _LOW_VALUE):
            s = -1
        scored.append((s, p))
    scored.sort(key=lambda x: (-x[0], x[1].get("name", "").lower()))
    return [p for _, p in scored], any(s > 0 for s, _ in scored)


def format_owned(res: dict, show: int = 15, genre: str = "", extra: str = "") -> str:
    packs = list(res.get("packs") or [])
    if not packs and not res.get("project_packages"):
        srcs = res.get("sources") or []
        return (
            "Owned-asset scan: no local downloads found.\n"
            + ("Checked: " + "; ".join(srcs) if srcs else "No Asset Store / VaultCache folder on this PC.")
            + "\nOwned in the store account is not the same as downloaded. "
              "Package Manager > My Assets (Unity) or Fab Library (Unreal) → Download, then ask me to scan again."
        )
    ordered, matched = order_packs(packs, genre, extra)
    note = f" (best matches for {genre.replace('_', ' ')} first)" if matched and genre else (" (best matches first)" if matched else "")
    show_n = max(1, int(show or 15))
    lines = [f"Owned-asset scan{note}: {len(packs)} downloaded pack(s). Showing {min(show_n, len(ordered))}:"]
    for i, p in enumerate(ordered[:show_n], 1):
        pub = p.get("publisher") or "?"
        mb = p.get("size_mb")
        mb_s = f" ({mb} MB)" if mb is not None else ""
        lines.append(f"{i}. {pub} - {p.get('name')}{mb_s}")
    pp = res.get("project_packages") or []
    if pp:
        lines.append(f"Also in project manifests: {len(pp)} package id(s) (e.g. {pp[0].get('id')}).")
    lines.append("Say a number or pack name to import into this project, or keep going (describe / free / skip).")
    if res.get("sources"):
        lines.append("Sources: " + "; ".join(res["sources"][:2]))
    return "\n".join(lines)


def scan_owned_assets(request: str = "") -> str:
    """Tool entry for chat / DISPATCH."""
    t = (request or "").lower()
    engine = "Unreal" if any(x in t for x in ("unreal", "fab", "ue5")) else "Unity"
    genre = ""
    for g in ("platformer", "fps", "shooter", "racing", "horror", "rpg"):
        if g in t:
            genre = g
            break
    project = None
    m = re.search(r"(?:for|project)\s+([A-Za-z0-9_-]{2,40})", request or "", re.I)
    if m:
        project = m.group(1)
    return format_owned(list_owned_assets(engine, project=project, limit=200), show=20, genre=genre)


if __name__ == "__main__":
    import sys
    print(scan_owned_assets(" ".join(sys.argv[1:]) or "unity platformer"))


def _find_unity_exe() -> Path | None:
    try:
        from auto_studio import find_unity
        return find_unity()
    except Exception:
        pass
    base = Path(r"C:\Program Files\Unity\Hub\Editor")
    if not base.is_dir():
        return None
    cands = sorted([p / "Editor" / "Unity.exe" for p in base.iterdir() if (p / "Editor" / "Unity.exe").exists()], reverse=True)
    return cands[0] if cands else None


def _safe(s: str) -> str:
    """Same folder naming as gamedev_core._safe_name (used when the project folder was created)."""
    try:
        from gamedev_core import _safe_name
        return _safe_name(s)
    except Exception:
        s = re.sub(r"[^A-Za-z0-9 _-]+", "", s or "").strip()
        return "".join(w[:1].upper() + w[1:] for w in s.split())[:40] or "NewGame"


def resolve_project_name(project: str | None, text: str = "") -> str | None:
    """Folder name under Documents\\GameProjects for a title the user/intake gave ("open world plus" -> OpenWorldPlus).
    A project the user typed ("import 7 for OpenWorldPlus") wins when that folder exists."""
    root = _projects_root()
    def _hit(name):
        if not name:
            return None
        for cand in (name, _safe(name)):
            if cand and (root / cand).is_dir():
                return cand
        return None
    m = re.search(r"(?:for|into|project)\s+[\"']?([A-Za-z0-9 _-]{2,40})", text or "", re.I)
    if m:
        typed = m.group(1).strip()
        words = typed.split()
        for k in range(len(words), 0, -1):  # "OpenWorldPlus please" / "open world plus"
            h = _hit(" ".join(words[:k]))
            if h:
                return h
    h = _hit((project or "").strip())
    if h:
        return h
    if project and project.strip():
        return _safe(project.strip())  # name it the way the pipeline would (error message shows the real folder)
    cur = root / ".current"
    if cur.is_file():
        c = cur.read_text(encoding="utf-8").strip()
        if c:
            return _hit(c) or c
    notes = Path(__file__).resolve().parent / "notes" / "current_game.txt"
    if notes.is_file():
        raw = notes.read_text(encoding="utf-8").strip()
        if raw:
            return Path(raw).name
    try:
        roots = sorted([p for p in root.iterdir() if p.is_dir()], key=lambda p: p.stat().st_mtime, reverse=True)
        return roots[0].name if roots else None
    except Exception:
        return None


def _unity_project_for(name: str) -> Path | None:
    root = _projects_root() / name
    if not root.is_dir():
        return None
    # Prefer <Name>Unity subfolder if present
    for c in [root / f"{name}Unity", root / "Unity", root]:
        if (c / "Assets").is_dir() and (c / "ProjectSettings").is_dir():
            return c
    # any *Unity folder
    for c in root.iterdir():
        if c.is_dir() and (c / "Assets").is_dir() and (c / "ProjectSettings").is_dir():
            return c
    return None


def resolve_pack(query: str, engine: str = "Unity", genre: str = "", extra: str = "") -> dict | None:
    """Resolve a pack by 1-based list number or fuzzy name from owned scan (same order as format_owned)."""
    res = list_owned_assets(engine, limit=200)
    packs = list(res.get("packs") or [])
    ordered, _ = order_packs(packs, genre, extra)
    q = (query or "").strip()
    if not q:
        return None
    if q.isdigit():
        i = int(q)
        if 1 <= i <= len(ordered):
            return ordered[i - 1]
    ql = q.lower().strip(" .!?\"'")
    toks = _pack_tokens(ql)
    if not toks:
        return None
    for p in ordered:
        name = (p.get("name") or "").lower()
        if name and (ql == name or (len(name) >= 6 and name in ql)):
            return p
    # every meaningful word must start a whole word in the pack name ("cliff", "nature ess") - never a substring like "eat"
    for p in ordered:
        name = (p.get("name") or "").lower()
        if all(re.search(r"(?<![a-z0-9])" + re.escape(w), name) for w in toks):
            return p
    for p in ordered:
        blob = f"{p.get('publisher','')} {p.get('name','')}".lower()
        if all(re.search(r"(?<![a-z0-9])" + re.escape(w), blob) for w in toks):
            return p
    return None


_PACK_STOP = {"the", "a", "an", "and", "of", "for", "pack", "packs", "asset", "assets", "please", "pls", "one", "that",
              "it", "my", "owned", "some", "free", "eta", "eat", "status", "progress", "update", "stuck", "working"}


def _pack_tokens(q: str) -> list:
    """Meaningful words of a pack query (>=3 letters, not filler/status words)."""
    return [w for w in re.findall(r"[a-z0-9]+", (q or "").lower()) if len(w) >= 3 and w not in _PACK_STOP]


def append_attribution(project: str, pack: dict, note: str = "owned Asset Store import") -> Path | None:
    root = _projects_root() / project
    att = root / "ATTRIBUTION.md"
    if not att.is_file():
        att.write_text(f"# {project} - asset attribution & licences\n\n| asset | file(s) | source URL | author | licence | date | notes |\n|---|---|---|---|---|---|---|\n", encoding="utf-8")
    from datetime import datetime
    today = datetime.now().strftime("%Y-%m-%d")
    row = f"| {pack.get('name')} | {pack.get('path')} | Unity Asset Store (local cache) | {pack.get('publisher') or '?'} | owned/imported | {today} | {note} ({pack.get('size_mb')} MB) |\n"
    txt = att.read_text(encoding="utf-8", errors="replace")
    if pack.get("name") and pack["name"] in txt:
        return att
    with att.open("a", encoding="utf-8") as f:
        f.write(row)
    return att


PENDING_IMPORTS: list = []  # pack names waiting for a running Unity build (shown in /api/progress)
ASK_WHICH_PACK = ("Which pack should I import? Reply with its number from the list below (e.g. \"7\") "
                  "or part of its name.")


def _status_write(root: Path, head: str, line: str) -> None:
    try:
        from datetime import datetime
        st = root / "Builds" / "auto_unity_status.txt"
        st.parent.mkdir(parents=True, exist_ok=True)
        st.write_text(f"{head}\n--- log ---\n{datetime.now():%H:%M:%S} {line}\n", encoding="utf-8")
    except Exception:
        pass


def _bg_build_running(proj: str) -> bool:
    try:
        from auto_studio import unity_job_running
        return unity_job_running(_projects_root() / proj)
    except Exception:
        return False


def import_owned_asset(request: str = "", project: str | None = None, pack: str | None = None,
                       engine: str = "Unity", genre: str = "", rebuild: bool = True, extra: str = "",
                       _queued: bool = False) -> str:
    """Import a downloaded .unitypackage into the active Unity project via batchmode ImportPackage."""
    import subprocess
    import os
    text = " ".join(x for x in [request, pack] if x).strip()
    # parse "import 1 for TrailFox" / "3" / "Stylized Player"
    proj = resolve_project_name(project, text)
    if not proj:
        return "IMPORT FAIL: no project name. Say e.g. 'import 1 for TrailFox'."
    # strip project clause from query for pack resolve
    q = re.sub(r"(?:for|into|project)\s+[\"']?[A-Za-z0-9 _-]{2,40}", "", text, flags=re.I).strip()
    q = re.sub(r"^\s*(?:please\s+)?(import|use|pick|choose|add)\b\s*", "", q, flags=re.I).strip()
    q = re.sub(r"^(?:(?:it|that|one|a|an|the|some|my|owned)\s*)*(?:packs?|assets?|package)?\s*(?:please|pls)?\s*[.!?]*$", "", q, flags=re.I).strip()
    if not q:
        return ASK_WHICH_PACK
    try:
        from agent_core import wants_status as _ws
        if _ws(q):
            return ASK_WHICH_PACK  # a status word is never a pack pick
    except Exception:
        pass
    if not q.isdigit() and not _pack_tokens(q):
        return ASK_WHICH_PACK
    hit = resolve_pack(q, engine=engine, genre=genre, extra=extra)
    if not hit:
        return (f"I couldn't find an owned pack matching \"{q}\". "
                "Reply with a number from the list (e.g. \"7\") or part of a pack name.")
    pkg = Path(hit["path"])
    if not pkg.is_file():
        return f"IMPORT FAIL: file missing: {pkg}"
    # skip multi-GB
    if hit.get("size_mb", 0) and hit["size_mb"] > 400:
        return f"IMPORT SKIP: {hit.get('name')} is {hit.get('size_mb')} MB (>400). Pick a smaller pack."
    # A background create/build job is running: queue this import (never block chat for minutes)
    if not _queued and _bg_build_running(proj):
        import threading
        label = hit.get("name") or pkg.stem
        PENDING_IMPORTS.append(label)

        def _later():
            try:
                import_owned_asset(request=request, project=proj, pack=pack, engine=engine, genre=genre,
                                   rebuild=rebuild, extra=extra, _queued=True)
            finally:
                try:
                    PENDING_IMPORTS.remove(label)
                except ValueError:
                    pass
        threading.Thread(target=_later, daemon=True, name=f"owned-import-{label}").start()
        return (f"IMPORT QUEUED: {hit.get('publisher')} - {label} ({hit.get('size_mb')} MB)\n"
                f"A Unity build for {proj} is running right now, so I queued this pack. It imports into "
                f"Assets\\Art\\Imports and the game rebuilds automatically as soon as that build finishes. "
                "Say \"progress\" any time to check; we can keep going meanwhile.")
    # Never race the background create/build job: wait for DONE/FAIL (max 15 min)
    try:
        import time as _t
        _st = _projects_root() / proj / "Builds" / "auto_unity_status.txt"
        _t0 = _t.time()
        while _bg_build_running(proj) and _t.time() - _t0 < 900:
            _t.sleep(10)
    except Exception:
        pass
    uproj = _unity_project_for(proj)
    if not uproj:
        return f"IMPORT FAIL: Unity project not found under Documents\\GameProjects\\{proj}"
    unity = _find_unity_exe()
    if not unity:
        return "IMPORT FAIL: Unity Editor not installed."
    # ensure SceneBuilder with ImportOwnedPackage exists in project
    editor = uproj / "Assets" / "Editor"
    editor.mkdir(parents=True, exist_ok=True)
    full_sb = Path(__file__).resolve().parent / "unity_fullgame" / "SceneBuilder.cs"
    if full_sb.is_file():
        (editor / "SceneBuilder.cs").write_text(full_sb.read_text(encoding="utf-8"), encoding="utf-8")
    root = _projects_root() / proj
    # Reliable extract: unpack .unitypackage (gzip tar) into Assets/Art/Imports/<name>
    try:
        from extract_unitypackage import extract_unitypackage
        folder = re.sub(r"[^A-Za-z0-9_-]+", "_", hit.get("name") or pkg.stem)[:60]
        ext = extract_unitypackage(pkg, uproj / "Assets", folder_name=folder)
        assets_root = uproj / "Assets"
        import shutil
        for doomed in list(assets_root.rglob("*")):
            if not doomed.is_dir():
                continue
            low = str(doomed).lower().replace("\\", "/")
            if low.endswith("/standard assets/effects") or "/editor/imageeffects" in low or low.endswith("/imageeffects"):
                shutil.rmtree(doomed, ignore_errors=True)
    except Exception as e:
        ext = {"ok": False, "error": str(e), "files": 0}
    env = os.environ.copy()
    env["GAMEBOT_IMPORT_PACKAGE"] = str(pkg)
    build_dir = root / "Builds" / "Windows"
    env["GAMEBOT_BUILD_DIR"] = str(build_dir)
    env["GAMEBOT_GAME_NAME"] = proj
    log = root / "Builds" / "import.log"
    log.parent.mkdir(parents=True, exist_ok=True)
    method = "SceneBuilder.BuildWindows" if rebuild else "SceneBuilder.Build"
    args = [
        str(unity), "-batchmode", "-nographics", "-quit",
        "-projectPath", str(uproj),
        "-executeMethod", method,
        "-logFile", str(log),
    ]
    _status_write(root, "RUNNING", f"importing owned pack {hit.get('name')} + {'rebuild Windows player' if rebuild else 'scene build'}")
    try:
        import gpu_guard
        gpu_guard.before_unity()
    except Exception:
        pass
    try:
        proc = subprocess.run(args, env=env, timeout=3600, creationflags=0x08000000)
    except subprocess.TimeoutExpired:
        _status_write(root, "FAIL import timed out", f"{hit.get('name')} - see Builds\\import.log")
        return f"IMPORT FAIL: Unity timed out. See {log}"
    append_attribution(proj, hit, note=f"batchmode {method}")
    # mark taskboard
    tb = root / "Docs" / "TaskBoard.md"
    if tb.is_file():
        txt = tb.read_text(encoding="utf-8", errors="replace")
        marker = f"- [x] Imported owned pack: {hit.get('name')}"
        if marker not in txt:
            with tb.open("a", encoding="utf-8") as f:
                f.write(f"\n{marker}\n")
    status = root / "Builds" / "auto_unity_status.txt"
    exe = None
    if build_dir.is_dir():
        exes = [e for e in build_dir.glob("*.exe") if not e.name.lower().startswith(("unitycrashhandler", "crashreport"))]
        exe = str(exes[0]) if exes else None
    if proc.returncode != 0:
        _status_write(root, f"FAIL import exit {proc.returncode}", f"{hit.get('name')} - see Builds\\import.log")
    if proc.returncode == 0:
        if rebuild:
            _status_write(root, f"DONE OK {exe or ''}", f"imported {hit.get('name')}")
        else:
            _status_write(root, "DONE OK (import, no rebuild)", f"imported {hit.get('name')}")
        return (
            f"IMPORT OK: {hit.get('publisher')} - {hit.get('name')} ({hit.get('size_mb')} MB)\n"+ f"extract_files={ext.get('files')} folder={ext.get('folder')}\n"
            f"into {uproj}\\Assets (Art/Imports)\n"
            f"ATTRIBUTION.md updated.\n"
            f"Unity exit={proc.returncode} method={method}\n"
            + (f"Rebuild exe: {exe}\n" if exe else "")
            + f"Log: {log}"
        )
    return (
        f"IMPORT FAIL: Unity exit {proc.returncode} for {hit.get('name')}.\n"
        f"Log: {log}\nPackage: {pkg}"
    )


def import_owned_asset_tool(request: str = "", project: str = "") -> str:
    """Tool entry for chat / DISPATCH."""
    t = request or ""
    engine = "Unreal" if re.search(r"unreal|fab|ue5", t, re.I) else "Unity"
    genre = ""
    for g in ("platformer", "fps", "shooter", "racing", "horror", "rpg", "puzzle", "survival", "adventure", "sim", "roguelike"):
        if g in t.lower():
            genre = g
            break
    rebuild = not re.search(r"\bno[- ]?rebuild\b", t, re.I)
    proj = resolve_project_name((project or "").strip() or None, t)
    return import_owned_asset(request=t, project=proj, engine=engine, genre=genre, rebuild=rebuild)
