# Performance profiling (Unity)
Sources: https://docs.unity3d.com/Manual/Profiler.html | https://docs.unity.com/en-us/engine/6000.0/manual/analysis/profiler/standalone-process | https://docs.unity.com/en-us/engine/6000.6/script-reference/unityengine/frametimingmanager | https://docs.unity3d.com/Manual/FrameDebugger.html | https://docs.unity3d.com/Packages/com.unity.memoryprofiler@1.1/manual/index.html

See fps-performance-passes.md for the repeatable FPS pass procedure (always do a pass before/after any perf change).

## Workflow
1. Measure in a Development Build (standalone), not the Editor (Editor adds overhead and lies). Attach Profiler (Autoconnect Profiler) or use Standalone Profiler process.
2. Find bound: FrameTimingManager cpuFrameTime vs gpuFrameTime. CPU main thread > GPU -> CPU bound.
3. CPU: Profiler Hierarchy sort by Self ms; look for scripts Update, Physics.Simulate, Animator, GC.Alloc (enable Call Stacks rather than Deep Profile).
4. GPU/render: Frame Debugger (draw calls, shadow passes - this is how the 393/441 grass shadow caster draws were found), Rendering stats (SetPass calls, batches, tris).
5. Memory: Memory Profiler snapshots; texture sizes, duplicate assets.
6. Fix one thing, re-run the same FPS pass, log result.

## Budgets (ms per frame)
- 60 fps = 16.7 ms; 90 = 11.1; 120 = 8.3; Steam Deck 30-40 fps = 33-25 ms. Aim main thread <70% of budget for headroom.

## Common fixes
- Shadows (distance, cascades, casters), foliage density/distance, LOD bias, draw calls (static batching, GPU instancing, SRP Batcher compatible shaders), overdraw, GC (pool, avoid LINQ/strings in Update), physics layer matrix, AI staggering, upscalers (FSR2/DLSS) for GPU-bound.
