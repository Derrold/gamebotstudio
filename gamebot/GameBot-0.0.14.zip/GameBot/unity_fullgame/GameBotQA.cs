using System.Collections;
using UnityEngine;
using UnityEngine.SceneManagement;

/// <summary>QA hooks for automated E2E: -gbplay (skip menu), -gbshot <png> (capture after delay, then quit), -gbdrive (hold throttle), -gbfire (hold fire).</summary>
public class GameBotQA : MonoBehaviour
{
    public static bool AutoDrive, AutoFire, Bright, EnemyCam; public static string Focus, StatsPath;
    static int StartHealth = -1;
    [RuntimeInitializeOnLoadMethod(RuntimeInitializeLoadType.AfterSceneLoad)]
    static void Boot()
    {
        var args = System.Environment.GetCommandLineArgs();
        string shot = null; bool play = false; Bright = false;
        for (int i = 0; i < args.Length; i++)
        {
            if (args[i] == "-gbplay") play = true;
            if (args[i] == "-gbdrive") AutoDrive = true;
            if (args[i] == "-gbfire") AutoFire = true;
            if (args[i] == "-gbbright") Bright = true;
            if (args[i] == "-gbenemy") EnemyCam = true;
            if (args[i] == "-gbnofog") RenderSettings.fog = false;
            if (args[i] == "-gbfocus" && i + 1 < args.Length) Focus = args[i + 1];
            if (args[i] == "-gbshot" && i + 1 < args.Length) shot = args[i + 1];
            if (args[i] == "-gbstats" && i + 1 < args.Length) StatsPath = args[i + 1];
        }
        if (!play && shot == null && string.IsNullOrEmpty(StatsPath)) return;
        var go = new GameObject("GameBotQA"); DontDestroyOnLoad(go);
        go.AddComponent<GameBotQA>().StartCoroutine(Run(play, shot));
    }
    static string DressInfo()
    {
        var d = GameObject.Find("OwnedAssetDressing"); if (d == null) return "dress=none";
        int on = 0, all = 0; foreach (var r in d.GetComponentsInChildren<Renderer>(true)) { all++; if (r.enabled && r.gameObject.activeInHierarchy) on++; }
        var c = Camera.main; var fl = GameObject.Find("Flashlight"); return "fog=" + RenderSettings.fog + ":" + RenderSettings.fogColor + ":" + RenderSettings.fogDensity + " amb=" + RenderSettings.ambientLight + " flash=" + (fl ? fl.GetComponent<Light>().enabled + "@" + fl.transform.position.ToString("0.0") : "none") + " dress_renderers=" + on + "/" + all + (c ? " cam=" + c.transform.position.ToString("0.0") : "");
    }
    static string WorldInfo()
    {
        int src = FindObjectsByType<AudioSource>(FindObjectsSortMode.None).Length, lis = FindObjectsByType<AudioListener>(FindObjectsSortMode.None).Length;
        int en = 0, skin = 0, anim = 0; foreach (var e in FindObjectsByType<GbEnemyAnim>(FindObjectsSortMode.None)) { en++; if (e.GetComponentInChildren<SkinnedMeshRenderer>()) skin++; var a = e.GetComponentInChildren<Animator>(); if (a && a.runtimeAnimatorController) anim++; }
        int trees = 0, bld = 0, cover = 0, bl = 0; foreach (var t in FindObjectsByType<Transform>(FindObjectsSortMode.None)) { var n = t.name; if (n.StartsWith("Tree_")) trees++; else if (n.StartsWith("Building_")) bld++; else if (n.StartsWith("Cover_")) cover++; else if (n.StartsWith("Blender_")) bl++; }
        var tr = Terrain.activeTerrain; var gm = Camera.main ? Camera.main.transform.Find("ViewGun/Muzzle") : null;
        string gunFwd = gm ? Vector3.Dot(gm.position - Camera.main.transform.Find("ViewGun").position, Camera.main.transform.forward).ToString("0.000") : "none";
        var au = FindAnyObjectByType<GbAudio>();
        return "terrain=" + (tr ? "yes layers=" + tr.terrainData.terrainLayers.Length + " grass=" + tr.terrainData.detailPrototypes.Length : "no") + " trees=" + trees + " buildings=" + bld + " cover=" + cover + " blender_models=" + bl +
            " untextured=" + Untex() + " enemies=" + en + " skinned=" + skin + " animated=" + anim + " audio_sources=" + src + " audio_playing=" + _playing + " listeners=" + lis + " gun_muzzle_fwd=" + gunFwd +
            (au ? " clips fire=" + (au.fire ? au.fire.name : "-") + " reload=" + (au.reload ? au.reload.name : "-") + " hit=" + (au.hit ? au.hit.name : "-") + " enemy=" + (au.enemy ? au.enemy.name : "-") + " ambient=" + (au.ambient ? au.ambient.name : "-") : " gbaudio=none");
    }
    static string Untex()
    {
        int cu = 0, ca = 0, eu = 0, ea = 0;
        foreach (var r in FindObjectsByType<Renderer>(FindObjectsSortMode.None))
        {
            var root = r.transform; bool cov = false, en = false; while (root) { if (root.name.StartsWith("Cover_")) cov = true; if (root.name.StartsWith("Enemy_")) en = true; root = root.parent; }
            if (!cov && !en) continue; bool tex = false; foreach (var m in r.sharedMaterials) if (m && (m.mainTexture || (m.HasProperty("_BaseMap") && m.GetTexture("_BaseMap")))) tex = true;
            if (cov) { ca++; if (!tex) cu++; } if (en) { ea++; if (!tex) eu++; }
        }
        return "cover:" + cu + "/" + ca + ",enemy:" + eu + "/" + ea;
    }
    static int _playing;
    static IEnumerator Run(bool play, string shot)
    {
        if (play && SceneManager.GetActiveScene().buildIndex == 0) { MainMenuUI.InMenu = false; GameState.ResetRun(); SceneManager.LoadScene(1); yield return null; }
        yield return null;
        StartHealth = GenreState.Health;
        yield return new WaitForSecondsRealtime(7f);
        if (Bright)
        {
            RenderSettings.fog = false; RenderSettings.ambientMode = UnityEngine.Rendering.AmbientMode.Flat; RenderSettings.ambientLight = new Color(0.55f, 0.55f, 0.58f);
            var lg = new GameObject("QA_Light").AddComponent<Light>(); lg.type = LightType.Directional; lg.intensity = 1.1f; lg.shadows = LightShadows.None; lg.transform.rotation = Quaternion.Euler(60, 30, 0);
            yield return new WaitForSecondsRealtime(0.5f);
        }
        if (EnemyCam)
        {
            // QA close-up: stand 4 m from the nearest enemy and look at it (proves real character models, not capsules)
            var cam = Camera.main; GbEnemyAnim best = null; float bd = float.MaxValue;
            foreach (var e in FindObjectsByType<GbEnemyAnim>(FindObjectsSortMode.None)) { float d = cam ? (e.transform.position - cam.transform.position).sqrMagnitude : 0; if (d < bd) { bd = d; best = e; } }
            if (cam && best)
            {
                foreach (var e in FindObjectsByType<GbEnemyAnim>(FindObjectsSortMode.None)) e.enabled = false;
                var pl = cam.transform.root; var cc = pl.GetComponent<CharacterController>(); if (cc) cc.enabled = false;
                foreach (var mb in pl.GetComponentsInChildren<MonoBehaviour>()) if (!(mb is GameBotQA)) mb.enabled = false;
                var ep = best.transform.position; var dir = cam.transform.position - ep; dir.y = 0; if (dir.sqrMagnitude < 0.01f) dir = Vector3.forward;
                var pos = ep + dir.normalized * 3.2f; var tr = Terrain.activeTerrain; if (tr) pos.y = tr.SampleHeight(pos) + tr.transform.position.y + 1.0f; else pos.y = ep.y + 1f;
                pl.position = pos; var look = (ep + Vector3.up * 0.9f) - cam.transform.position; look.y = 0; pl.rotation = Quaternion.LookRotation(look.normalized);
                cam.transform.rotation = Quaternion.LookRotation((ep + Vector3.up * 0.9f) - cam.transform.position);
                yield return new WaitForSecondsRealtime(0.4f);
            }
        }
        if (!string.IsNullOrEmpty(Focus))
        {
            // QA close-up of the nearest object whose name starts with Focus (e.g. Blender_helicopter, Cover_, Building_)
            var cam = Camera.main; Transform best = null; float bd = float.MaxValue;
            foreach (var t in FindObjectsByType<Transform>(FindObjectsSortMode.None)) if (t.name.StartsWith(Focus) && cam) { float d = (t.position - cam.transform.position).sqrMagnitude; if (d < bd) { bd = d; best = t; } }
            if (cam && best)
            {
                var rs = best.GetComponentsInChildren<Renderer>(); var b = rs.Length > 0 ? rs[0].bounds : new Bounds(best.position, Vector3.one); foreach (var r in rs) b.Encapsulate(r.bounds);
                var pl = cam.transform.root; var cc = pl.GetComponent<CharacterController>(); if (cc) cc.enabled = false;
                foreach (var mb in pl.GetComponentsInChildren<MonoBehaviour>()) if (!(mb is GameBotQA)) mb.enabled = false;
                var dir = cam.transform.position - b.center; dir.y = 0; if (dir.sqrMagnitude < 0.01f) dir = Vector3.back;
                float dist = Mathf.Max(3.5f, b.extents.magnitude * 2.2f); var pos = b.center + dir.normalized * dist; var tr = Terrain.activeTerrain; float gy = tr ? tr.SampleHeight(pos) + tr.transform.position.y : 0f; pos.y = Mathf.Max(gy + 1.6f, b.center.y + dist * 0.55f); // elevated so nearby cover does not block the view
                pl.position = pos; cam.transform.position = pos; cam.transform.rotation = Quaternion.LookRotation(b.center - pos);
                yield return new WaitForSecondsRealtime(0.4f);
            }
        }
        int playing = 0; foreach (var a in FindObjectsByType<AudioSource>(FindObjectsSortMode.None)) if (a.isPlaying) playing++;
        _playing = playing;
        if (!string.IsNullOrEmpty(StatsPath) || shot != null)
        {
            if (!string.IsNullOrEmpty(StatsPath)) { WriteFrameStats(StatsPath); yield return new WaitForEndOfFrame(); }
        }
        if (shot != null)
        {
            ScreenCapture.CaptureScreenshot(shot);
            yield return new WaitForSecondsRealtime(1.5f);
            System.IO.File.WriteAllText(shot + ".txt", "start_health=" + StartHealth + " mode=" + GenreState.Mode + " family=" + GenreState.Family + " kills=" + GenreState.Kills + "/" + GenreState.EnemiesTotal +
                " ammo=" + GenreState.Ammo + "/" + GenreState.Reserve + " lap=" + GenreState.Lap + " next_cp=" + GenreState.NextCheckpoint +
                "/" + GenreState.CheckpointCount + " speed=" + GenreState.SpeedKmh.ToString("0") + " coins=" + GameState.Coins + " items=" + GenreState.Items + "/" + GenreState.ItemsTotal + " pads=" + GenreState.Pads + "/" + GenreState.PadsTotal + " level=" + GenreState.Level + " hunger=" + GenreState.Hunger.ToString("0") + " cash=" + GenreState.Cash + " stock=" + GenreState.Stock + " wave=" + GenreState.Wave + "/" + GenreState.WavesTotal + " battery=" + GenreState.Battery.ToString("0") + " lives=" + GameState.Lives + " health=" + GenreState.Health + " p1=" + GenreState.P1Hp + " p2=" + GenreState.P2Hp + " quartz=" + GenreState.Quartz + " points=" + GenreState.PointsOwned + "/" + GenreState.PointsTotal + " towers=" + GenreState.TowersDown + " score=" + GenreState.ScoreUs + ":" + GenreState.ScoreThem + " placed=" + GenreState.Placed + " detection=" + GenreState.Detection.ToString("0.00") + " alarms=" + GenreState.Alarms + " alive=" + GenreState.Alive + " storm=" + GenreState.StormRadius.ToString("0") + " quests=" + GenreState.QuestsDone + " objective=\"" + GenreState.Objective() + "\"" + " viewgun=" + (Camera.main && Camera.main.transform.Find("ViewGun") ? "yes" : "no") + " " + DressInfo() + " " + WorldInfo());
            Application.Quit();
        }
        else if (!string.IsNullOrEmpty(StatsPath)) Application.Quit();
    }
    static void WriteFrameStats(string path)
    {
        try
        {
            var cam = Camera.main;
            int w = cam ? cam.pixelWidth : Screen.width, h = cam ? cam.pixelHeight : Screen.height;
            if (w < 8 || h < 8) { System.IO.File.WriteAllText(path, "{\"error\":\"no camera\"}"); return; }
            var rt = new RenderTexture(w, h, 24);
            var prev = cam.targetTexture; cam.targetTexture = rt; cam.Render();
            var prevActive = RenderTexture.active; RenderTexture.active = rt;
            var tex = new Texture2D(w, h, TextureFormat.RGB24, false);
            tex.ReadPixels(new Rect(0, 0, w, h), 0, 0); tex.Apply();
            cam.targetTexture = prev; RenderTexture.active = prevActive;
            var pix = tex.GetPixels();
            double luma = 0; int magenta = 0, clipped = 0, n = pix.Length;
            for (int i = 0; i < n; i++)
            {
                var c = pix[i];
                float y = 0.2126f * c.r + 0.7152f * c.g + 0.0722f * c.b;
                luma += y;
                if (c.r > 0.7f && c.b > 0.7f && c.g < 0.35f) magenta++;
                if (c.r > 0.97f && c.g > 0.97f && c.b > 0.97f) clipped++;
            }
            Object.Destroy(tex); if (rt) rt.Release();
            var sun = GameObject.Find("Directional Light"); var sl = sun ? sun.GetComponent<Light>() : null;
            float skyExp = -1f; var sky = RenderSettings.skybox; if (sky && sky.HasProperty("_Exposure")) skyExp = sky.GetFloat("_Exposure");
            string json = "{"
                + "\"start_health\":" + StartHealth + ","
                + "\"health\":" + GenreState.Health + ","
                + "\"max_health\":" + GenreState.MaxHealth + ","
                + "\"mean_luma\":" + (luma / n).ToString("0.000", System.Globalization.CultureInfo.InvariantCulture) + ","
                + "\"pct_magenta\":" + (100.0 * magenta / n).ToString("0.000", System.Globalization.CultureInfo.InvariantCulture) + ","
                + "\"pct_clipped_white\":" + (100.0 * clipped / n).ToString("0.000", System.Globalization.CultureInfo.InvariantCulture) + ","
                + "\"sun_intensity\":" + (sl ? sl.intensity.ToString("0.000", System.Globalization.CultureInfo.InvariantCulture) : "-1") + ","
                + "\"sky_exposure\":" + skyExp.ToString("0.000", System.Globalization.CultureInfo.InvariantCulture) + ","
                + "\"pixels\":" + n + ","
                + "\"mode\":\"" + GenreState.Mode + "\",\"family\":\"" + GenreState.Family + "\""
                + "}";
            System.IO.Directory.CreateDirectory(System.IO.Path.GetDirectoryName(path));
            System.IO.File.WriteAllText(path, json);
        }
        catch (System.Exception e) { try { System.IO.File.WriteAllText(path, "{\"error\":\"" + e.Message.Replace("\"", "'") + "\"}"); } catch { } }
    }
}
