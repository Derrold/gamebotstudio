# Solo AAA studio pipeline

Tags: aaa,pipeline,design
Saved: 2026-10-25T20:00:18

Pitch -> GDD -> vertical slice -> production -> polish -> certify/build, with gates in aaa-production-checklist.md. Start with make_game_scaffold (Documents\GameProjects\<Name>), fill GDD, build scenes from Editor builder scripts, assets from bpy factory scripts. Honest: AAA needs time/compute/assets; progress = files + passing builds, never fake shipping.
