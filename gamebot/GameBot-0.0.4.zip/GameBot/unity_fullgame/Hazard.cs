﻿using UnityEngine;

public class Hazard : MonoBehaviour
{
    void OnTriggerEnter(Collider other)
    {
        if (!other.CompareTag("Player")) return;
        var p = other.GetComponent<GamePlayer>();
        if (p != null) p.Respawn();
    }
}
