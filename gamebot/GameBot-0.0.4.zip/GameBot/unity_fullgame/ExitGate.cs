using UnityEngine;
/// <summary>Win trigger that needs a condition: horror (all fuses), adventure (key opens door, shrine wins).</summary>
public class ExitGate : MonoBehaviour
{
    public bool isDoor; // adventure door: opens with key
    void Update()
    {
        if (isDoor && GenreState.HasKey && transform.localScale.y > 0.05f) { transform.localScale = Vector3.Lerp(transform.localScale, new Vector3(transform.localScale.x, 0.01f, transform.localScale.z), Time.deltaTime * 2f); if (transform.localScale.y < 0.06f) { var c = GetComponent<Collider>(); if (c) c.enabled = false; } }
    }
    void OnTriggerEnter(Collider o)
    {
        if (isDoor || !o.CompareTag("Player")) return;
        if (GenreState.IsHorror && GenreState.Items >= GenreState.ItemsTotal) { AchievementSystem.Unlock("escape"); if (GameState.Deaths == 0) AchievementSystem.Unlock("no_death"); GenreState.Win(); }
        if (GenreState.IsStealth && GenreState.Items >= GenreState.ItemsTotal) { AchievementSystem.Unlock("extracted"); GenreState.Win(); }
        if (GenreState.IsStealth && GenreState.Items < GenreState.ItemsTotal) GameHUD.Flash("Extraction locked - grab all intel first");
        if (GenreState.IsAdventure && GenreState.HasKey) { AchievementSystem.Unlock("shrine"); GenreState.Win(); }
    }
}
