# Auto studio pipeline run (ZzRx6600Moba)

Tags: auto studio pipeline
Saved: 2026-11-13T13:15:55

run_auto_game_pipeline created 34 files under C:\Users\ExtremeHybrid\Documents\GameProjects\ZzRx6600Moba and UNITY 6000.6.5f1: background job started -> create ZzRx6600MobaUnity -> MOBA game (gameplay template: moba; menu, settings, achievements, owned genre kit) -> Bu. Next: check Builds\auto_unity_status.txt, then work TaskBoard 'Auto next actions' with tools.
