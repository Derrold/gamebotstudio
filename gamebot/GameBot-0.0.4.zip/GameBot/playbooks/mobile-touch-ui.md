# Mobile: touch UI, performance, store (deepens store-steam-epic-mobile)
Sources: https://docs.unity3d.com/Manual/android-BuildProcess.html | https://docs.unity3d.com/Manual/iphone-BuildProcess.html | https://developer.android.com/google/play/requirements/target-sdk | https://developer.apple.com/design/human-interface-guidelines/ | https://docs.unity3d.com/Packages/com.unity.inputsystem@1.11/manual/OnScreen.html

## Touch UI
- On-screen sticks/buttons (Input System OnScreenStick/OnScreenButton); thumb zones bottom-left move, bottom-right look/fire; buttons >= 9 mm (~48dp Android / 44pt iOS).
- Safe area (Screen.safeArea) for notches; UI scale for tablets vs phones; tap-to-ADS, drag-to-look with sensitivity slider; optional gyro aim.
- Simplify HUD; big readable fonts; portrait vs landscape lock.

## Performance on mobile
- URP mobile asset: no SSAO, shadows 1 cascade short distance, MSAA 2x or FXAA, render scale 0.7-0.85, texture ASTC compression, max 100-300k tris visible, few realtime lights, 30 fps target with thermal headroom; Adaptive Performance package.

## Builds
- Android: IL2CPP, ARM64, .aab, target API per Google Play current requirement (check link yearly), keystore (back it up! losing = can't update), Play Console internal testing track.
- iOS: needs a Mac + Xcode, Apple Developer account ($99/yr), TestFlight, App Store review.

## Store policy
- Weapons/hunting OK with proper age rating (IARC questionnaire), no real gun brand ads without license; privacy nutrition labels (iOS), Data safety form (Play). Human-only: accounts, payments, submission.
