# Lighting & post-processing (URP)
Sources: https://docs.unity3d.com/Packages/com.unity.render-pipelines.universal@17.0/manual/lighting.html | https://docs.unity3d.com/Manual/Lightmapping.html | https://docs.unity3d.com/Packages/com.unity.render-pipelines.universal@17.0/manual/integration-with-post-processing.html | https://docs.unity3d.com/Manual/LightProbes.html

## Baked vs realtime
- Day/night games: sun must be realtime directional; use realtime shadows with cascades; ambient from gradient/skybox updated by script; baked GI only for static interiors that ignore time of day (or mixed with Shadowmask) - Cabin interiors can use baked + light probes.
- Static scenes: bake lightmaps (Progressive GPU), light probes for dynamic objects, reflection probes for wet/metal.

## Day/night
- Hour drives sun rotation, intensity, color (warm dawn/dusk), ambient intensity, fog density/color by weather; cache originals (sunI0, amb0, fogD0) and lerp from them; legal shooting hours tie into Cal rules.
- Night: moonlight low intensity blue, raise exposure slightly, flashlight spot (no shadows on Low).

## URP shadows
- Depth/normal bias to fix acne/peter-panning. Small objects/grass: shadows off.

## Post FX (Volume)
- Global Volume: Tonemapping ACES/Neutral, Color Adjustments, Bloom (low), Vignette (subtle), Depth of Field (ADS only), Motion Blur default OFF (comfort), Film grain optional.

## Verify
- Screenshot set per hour (dawn/noon/dusk/night) and weather; no banding; fps pass per preset.
