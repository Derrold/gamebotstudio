using UnityEngine;
/// <summary>Goal mouth trigger: ball entering counts for the attacking side.</summary>
public class SportsGoal : MonoBehaviour
{
    public bool countsForUs;
    void OnTriggerEnter(Collider o) { if (o.attachedRigidbody && o.name == "Ball" && SportsMatch.I) SportsMatch.I.Goal(countsForUs); }
}
