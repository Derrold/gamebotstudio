﻿# Physics / NavMesh / AI
Layers + collision matrix; NavMesh bake; simple FSM/Behavior Tree for NPCs; never block main thread with pathfinding spikes.
