"""Persist Game Bot chats and a running per-game summary. Inject the summary into model context."""
from __future__ import annotations

import json
import os
import re
import shutil
import uuid
from datetime import datetime
from pathlib import Path

ROOT = Path(__file__).resolve().parent
CHATS = ROOT / "work" / "chats"
SUMMARY_TAG = "[GAME SUMMARY]"
GAMEPROJECTS = Path.home() / "Documents" / "GameProjects"

# (label, pct, keywords matched against the latest status/log line)
_STEPS = (
    ("Done", 100, ("done ok", "done.")),
    ("Build failed", 100, ("done fail", "build failed")),
    ("Building exe", 85, ("build scene", "windows player", "building exe", "build player", "build exit", "build.exe")),
    ("Compiling shaders", 65, ("shader", "compiling shader", "compile shaders")),
    ("Importing assets", 45, ("import", "kit ", "blender asset", "genre kit", "unitypackage", "owned pack", "prefabs")),
    ("Creating project", 20, ("queued", "createproject", "create project", "template", "creating project")),
)


def _now() -> str:
    return datetime.now().strftime("%Y-%m-%d %I:%M %p").replace(" 0", " ")


_SID_RX = re.compile(r"[A-Za-z0-9][A-Za-z0-9_-]{0,79}")


def valid_sid(sid: str) -> bool:
    """Chat ids are letters/digits/_/- only (no dots, slashes or '..'), max 80, never starting with _ or -."""
    return bool(_SID_RX.fullmatch(sid or ""))


def _safe_sid(sid: str) -> str:
    """Reject (never strip-and-accept) anything that is not a plain chat id - '..' or 'a/../b' must never map to a folder."""
    s = (sid or "").strip()
    if not valid_sid(s):
        return ""
    try:
        if (CHATS / s).resolve().parent != CHATS.resolve():
            return ""
    except Exception:
        return ""
    return s


def _dir(sid: str) -> Path:
    s = _safe_sid(sid)
    if not s:
        raise ValueError("invalid chat id")
    return CHATS / s


def _index_path() -> Path:
    return CHATS / "index.json"


def _load_index() -> list[dict]:
    """index.json, else its .bak, else rebuilt from the chat folders - a corrupt index never empties the menu."""
    p = _index_path()
    for cand in (p, p.with_name(p.name + ".bak")):
        try:
            data = json.loads(cand.read_text(encoding="utf-8"))
            if isinstance(data, list):
                return data
        except Exception:
            continue
    if not p.exists():
        return []
    try:  # keep the broken file for support, then rebuild rows from the folders on disk
        shutil.copyfile(p, p.with_name(f"index.corrupt-{datetime.now().strftime('%Y%m%d_%H%M%S')}.json"))
    except Exception:
        pass
    rows = []
    try:
        for d in CHATS.iterdir():
            if d.is_dir() and valid_sid(d.name) and (d / "messages.json").is_file():
                meta = {}
                try:
                    meta = json.loads((d / "chat_meta.json").read_text(encoding="utf-8"))
                except Exception:
                    pass
                rows.append({"id": d.name, "title": meta.get("title") or d.name, "game": meta.get("game") or "",
                             "engine": meta.get("engine") or "", "game_root": meta.get("game_root") or "", "updated": ""})
    except Exception:
        pass
    return rows


def _save_index(rows: list[dict]) -> None:
    CHATS.mkdir(parents=True, exist_ok=True)
    _write(_index_path(), json.dumps(rows, indent=2, ensure_ascii=False))


def _norm_game(name: str) -> str:
    return re.sub(r"[^a-z0-9]+", "", (name or "").lower())


def _deleted_path() -> Path:
    return CHATS / "deleted.json"


def _load_deleted() -> set[str]:
    try:
        data = json.loads(_deleted_path().read_text(encoding="utf-8"))
        return set(data) if isinstance(data, list) else set()
    except Exception:
        return set()


def _save_deleted(keys: set[str]) -> None:
    CHATS.mkdir(parents=True, exist_ok=True)
    _write(_deleted_path(), json.dumps(sorted(keys), indent=2))


def _pretty_title(game: str = "", root: Path | None = None, bits: dict | None = None) -> str:
    bits = bits if bits is not None else {}
    # Only use intake title when it refers to this same game; never retitle some other chat.
    if bits.get("title") and (not game or _norm_game(bits["title"]) == _norm_game(game)):
        return str(bits["title"]).strip()
    if not bits and game:
        ib = _intake_bits()
        if ib.get("title") and _norm_game(ib["title"]) == _norm_game(game):
            return str(ib["title"]).strip()
    folder = root if root is not None else (GAMEPROJECTS / game if game else None)
    if folder and (folder / "Docs" / "Pitch.md").is_file():
        pitch = _read(folder / "Docs" / "Pitch.md", 1600)
        m = re.search(r"##\s*Title\s*\n+([^\n#]+)", pitch, re.I)
        if m and m.group(1).strip():
            return m.group(1).strip()
    return (game or "").strip()


def find_chat_for_game(game: str, title: str = "") -> str:
    keys = {_norm_game(game), _norm_game(title)} - {""}
    if not keys:
        return ""
    for row in _load_index():
        if {_norm_game(row.get("game") or ""), _norm_game(row.get("title") or "")} & keys:
            return str(row.get("id") or "")
    return ""



def current_game_root(messages: list[dict] | None = None) -> Path | None:
    """The game this chat is already about, if one exists on disk."""
    try:
        from auto_studio import resolve_project
        root = resolve_project("")
        if root and root.is_dir() and ((root / "Docs").is_dir() or (root / "Builds").is_dir()):
            return root
    except Exception:
        pass
    name = _project_name(messages)
    if name:
        folder = GAMEPROJECTS / name
        if folder.is_dir():
            return folder
    cur = GAMEPROJECTS / ".current"
    try:
        n = cur.read_text(encoding="utf-8").strip()
        folder = GAMEPROJECTS / n
        if n and folder.is_dir():
            return folder
    except Exception:
        pass
    return None


def find_game_exe(root: Path | None) -> Path | None:
    if not root:
        return None
    folder = root / "Builds" / "Windows"
    preferred = folder / f"{root.name}.exe"
    if preferred.is_file():
        return preferred
    if not folder.is_dir():
        return None
    for pth in sorted(folder.glob("*.exe")):
        n = pth.name.lower()
        if "dontship" in n or "donotship" in n or "crashhandler" in n or "unitycrash" in n:
            continue
        return pth
    return None


def wants_play_demo(text: str) -> bool:
    t = (text or "").strip()
    if not t:
        return False
    # A "make/create a demo game" request is new work, not a launch.
    if re.search(r"\b(make|create|build|design|start)\b.{0,30}\b(demo|game)\b", t, re.I) and not re.search(
            r"\b(show|play|run|launch|open)\b", t, re.I):
        return False
    return bool(re.search(
        r"\b((show|see|watch)\s+(me\s+)?(a\s+|the\s+)?demo|"
        r"play(\s+(it|the\s+game|the\s+build))?|"
        r"run(\s+(it|the\s+game|the\s+build|the\s+exe))?|"
        r"launch(\s+(it|the\s+game|the\s+build))?|"
        r"start\s+the\s+game|open\s+the\s+(game|build|exe)|"
        r"play\s+cod\s*sucks)\b",
        t, re.I,
    ))


def wants_resume(text: str) -> bool:
    return bool(re.match(
        r"^\s*(where were we|where are we|where did we leave off|catch me up|"
        r"remind me( where we (left off|are|were))?|"
        r"what('?s| is) (the )?(status|progress))\s*[?.!]?\s*$",
        text or "", re.I,
    ))


def launch_game_demo(root: Path | None = None, messages: list[dict] | None = None) -> str:
    root = root or current_game_root(messages)
    title = _pretty_title(game=root.name, root=root) if root else "this game"
    if not root:
        return "I don't have an existing game in this chat to launch yet."
    exe = find_game_exe(root)
    if not exe:
        try:
            from auto_studio import build_status
            status = build_status(root) or ""
        except Exception:
            status = ""
        u = status.upper()
        if "RUNNING" in u or "QUEUED" in u:
            return f"The {title} build is still in progress, so there's no playable exe yet. I'll keep you posted."
        if "DONE FAIL" in u:
            return f"The last {title} build failed, so I don't have a working exe to launch. I can rebuild it if you want."
        return f"I don't have a built Windows exe for {title} yet (looked in Builds\\Windows). I can start a build if you want."
    try:
        import subprocess
        flags = getattr(subprocess, "DETACHED_PROCESS", 0) | getattr(subprocess, "CREATE_NEW_PROCESS_GROUP", 0)
        subprocess.Popen([str(exe)], cwd=str(exe.parent), shell=False, close_fds=True, creationflags=flags)
    except Exception as e:
        return f"I found the {title} build at {exe}, but couldn't launch it: {e}"
    return f"Launching {title} now. The playable build is {exe}."


def resume_reply(root: Path | None = None, messages: list[dict] | None = None) -> str:
    root = root or current_game_root(messages)
    if not root:
        return "This chat doesn't have a saved game yet. Tell me the title and whether you want Unity or Unreal when you're ready to start."
    title = _pretty_title(game=root.name, root=root) or root.name
    try:
        from auto_studio import build_status
        status = build_status(root) or ""
    except Exception:
        status = ""
    bits = _intake_bits()
    engine = bits.get("engine") or ""
    if not engine:
        pitch = _read(root / "Docs" / "Pitch.md", 1200)
        m = re.search(r"Engine:\s*([^\n|]+)", pitch)
        if m:
            engine = m.group(1).strip()
    genre = bits.get("genre") or bits.get("loop") or ""
    if not genre:
        pitch = _read(root / "Docs" / "Pitch.md", 1600)
        m = re.search(r"Genre:\s*([^\n|]+)", pitch)
        if m:
            genre = m.group(1).strip()
    exe = find_game_exe(root)
    u = status.upper()
    if "DONE OK" in u:
        build_line = (
            f"The Windows player build finished successfully (DONE OK)"
            + (f" at {exe}" if exe else "")
            + ". The player build is not running."
        )
    elif "DONE FAIL" in u:
        build_line = f"The last Windows player build failed. The player build is not running. {status}"
    elif "RUNNING" in u or "QUEUED" in u:
        build_line = f"The Windows player build is still in progress: {status}"
    else:
        build_line = _format_build_status(status)
    bits_loop = bits.get("loop") or ""
    what = ", ".join(x for x in (engine or None, genre or None, bits_loop or None) if x)
    nxt = _next_actions(_read(root / "Docs" / "TaskBoard.md", 4000), status)
    next_plain = ""
    if nxt:
        # Turn the first unchecked item into a short plain sentence.
        first = re.sub(r"^- \[ \]\s*", "", nxt.splitlines()[0]).strip()
        if first:
            next_plain = " Next up: " + first.rstrip(".") + "."
    mid = f" ({what})" if what else ""
    return f"We're on {title}{mid}. {build_line}{next_plain}"


_RAW_MARKERS = (
    "INTAKE_REQUIRED",
    "Ask the creator now:",
    "SYSTEM NOTE:",
    "PROJECT_EXISTS:",
    "Do NOT call run_auto_game_pipeline",
    "no project created yet",
    "FULL automatic studio setup",
    "tool_calls",
)


_INTERNAL_LINE = re.compile(
    r"^\s*(ROOT |AUTO_PIPELINE|(?-i:UNITY[ :_]|UNREAL[ :_])|KIT |extract_files=|into .*\\Assets|ATTRIBUTION\.md updated|"
    r"Unity exit=|Log: |Rebuild exe: |SYSTEM NOTE|\[KB\]|ASSET_PLAN|files: |Human gates|created: \[|Package: |tool_calls|<\|)", re.I)


def scrub_internal(text: str) -> str:
    """Drop tool/log lines from a reply; turn 'IMPORT OK: pub - Pack (12 MB)' into 'Imported Pack.'"""
    out = []
    for l in (text or "").splitlines():
        m = re.match(r"^\s*IMPORT OK:\s*(?:.+? - )?(.+?)(?: \([\d.]+ MB\))?\s*$", l)
        if m:
            out.append(f"Imported {m.group(1)}.")
            continue
        if _INTERNAL_LINE.match(l):
            continue
        out.append(l)
    return re.sub(r"\n{3,}", "\n\n", "\n".join(out)).strip()


def chat_game_root(messages: list[dict] | None = None) -> Path | None:
    """The game THIS chat is about: the current project, but only if earlier turns in this chat talked about it.
    A brand-new chat is never treated as an existing game chat."""
    root = current_game_root(messages)
    if not root:
        return None
    names = {root.name.lower(), (_pretty_title(game=root.name, root=root) or "").lower()} - {""}
    _nk = {re.sub(r"[^a-z0-9]+", "", n) for n in names} - {""}
    for m in (messages or [])[:-1]:
        role = m.get("role")
        c = str(m.get("content") or "").lower()
        _cn = re.sub(r"[^a-z0-9]+", "", c)
        if role == "assistant" and (any(n in c for n in names) or any(k in _cn for k in _nk)):
            return root
        if role == "tool" and str(root).lower() in c:
            return root
    return None


def looks_like_internal_text(text: str) -> bool:
    t = text or ""
    if any(m in t for m in _RAW_MARKERS):
        return True
    if t.strip().startswith("ROOT ") or t.strip().startswith("UNITY:"):
        return True
    return False


def sanitize_user_answer(text: str, messages: list[dict] | None = None) -> str:
    """Never show raw tool / intake / prompt text to the creator."""
    t = (text or "").strip()
    if not t:
        return text
    t2 = scrub_internal(t)
    if t2 and not looks_like_internal_text(t2):
        return text if t2 == t else t2
    root = current_game_root(messages)
    last_user = ""
    for m in reversed(messages or []):
        if m.get("role") == "user" and not str(m.get("content") or "").startswith("SYSTEM NOTE"):
            last_user = str(m.get("content") or "")
            break
    if root and wants_play_demo(last_user):
        return launch_game_demo(root, messages)
    if root:
        return resume_reply(root, messages)
    return "Before I create a new game I need a few basics in plain terms: Unity or Unreal, the title, and the genre."


def _write(path: Path, text: str) -> None:
    """Crash-safe write: temp file + fsync + os.replace, keeping the previous version as <name>.bak."""
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_name(f".{path.name}.{uuid.uuid4().hex[:8]}.tmp")
    with open(tmp, "w", encoding="utf-8") as f:
        f.write(text)
        f.flush()
        try:
            os.fsync(f.fileno())
        except OSError:
            pass
    if path.exists():
        try:
            shutil.copyfile(path, path.with_name(path.name + ".bak"))
        except Exception:
            pass
    for i in range(5):
        try:
            os.replace(tmp, path)
            return
        except PermissionError:  # Windows: a reader has the file open for a moment
            import time as _t
            _t.sleep(0.05 * (i + 1))
    os.replace(tmp, path)


def stored_game_root(sid: str) -> Path | None:
    """The game folder this chat was linked to (stored per chat; never inferred from global 'current game')."""
    s = _safe_sid(sid)
    if not s:
        return None
    row = next((r for r in _load_index() if r.get("id") == s), None) or {}
    gr = str(row.get("game_root") or "")
    if not gr:
        try:
            gr = str(json.loads((CHATS / s / "chat_meta.json").read_text(encoding="utf-8")).get("game_root") or "")
        except Exception:
            gr = ""
    if gr and Path(gr).is_dir():
        return Path(gr)
    return None


def ui_messages(messages: list[dict]) -> list[dict]:
    """User/assistant lines that belong in the chat pane (no system, tools, or SYSTEM NOTEs)."""
    out = []
    for m in messages or []:
        role = m.get("role")
        text = str(m.get("content") or "")
        if role not in ("user", "assistant"):
            continue
        if not text.strip():
            continue
        if text.startswith("SYSTEM NOTE") or text.startswith(SUMMARY_TAG) or text.startswith("[SESSION STATE]"):
            continue
        out.append({"role": role, "content": text})
    return out


def _title_from_messages(messages: list[dict], fallback: str = "") -> str:
    try:
        import intake
        st = getattr(intake, "_LAST", {}).get("st") or {}
        if st.get("title"):
            return str(st["title"]).strip()
    except Exception:
        pass
    for m in messages or []:
        if m.get("role") == "user":
            t = " ".join(str(m.get("content") or "").split())
            if t and not t.startswith("SYSTEM NOTE"):
                return (t[:48] + "…") if len(t) > 48 else t
    return fallback or "New chat"


def _project_name(messages: list[dict] = None) -> str:
    try:
        from auto_studio import resolve_project
        root = resolve_project("")
        if root:
            return root.name
    except Exception:
        pass
    try:
        import intake
        st = getattr(intake, "_LAST", {}).get("st") or {}
        t = re.sub(r"[^A-Za-z0-9]+", "", str(st.get("title") or ""))
        if t:
            return t
    except Exception:
        pass
    cur = GAMEPROJECTS / ".current"
    try:
        name = cur.read_text(encoding="utf-8").strip()
        if name:
            return name
    except Exception:
        pass
    return ""


def list_chats() -> list[dict]:
    seed_from_projects()
    rows = _load_index()
    changed = False
    for row in rows:
        pretty = _pretty_title(game=row.get("game") or "")
        if pretty and row.get("title") != pretty:
            row["title"] = pretty
            changed = True
        if pretty and not row.get("game"):
            row["game"] = pretty
            changed = True
    if changed:
        _save_index(rows)
    rows.sort(key=lambda r: r.get("updated") or "", reverse=True)
    return rows



def merge_full_messages(sid: str, messages: list[dict]) -> None:
    """Append messages to work/chats/<sid>/messages_full.json (never remove). Used for recall after a trim."""
    sid = _safe_sid(sid)
    if not sid:
        return
    path = _dir(sid) / "messages_full.json"
    full = []
    if path.is_file():
        try:
            data = json.loads(path.read_text(encoding="utf-8"))
            if isinstance(data, list):
                full = data
        except Exception:
            full = []
    have = {(m.get("role"), str(m.get("content") or "")) for m in full}
    changed = not path.is_file()
    for m in messages or []:
        if not isinstance(m, dict) or not m.get("role"):
            continue
        content = str(m.get("content") or "")
        if content.startswith("[RECALL]"):
            continue
        row = {k: m[k] for k in m if k in ("role", "content", "tool_calls") and m[k] not in (None, "", [])}
        key = (row.get("role"), str(row.get("content") or ""))
        if not str(row.get("content") or "").strip() and "tool_calls" not in row:
            continue
        if key in have:
            continue
        full.append(row)
        have.add(key)
        changed = True
    if changed:
        _write(path, json.dumps(full, ensure_ascii=False, indent=2))


def load_chat(sid: str) -> dict | None:
    sid = _safe_sid(sid)
    if not sid:
        return None
    mp = _dir(sid) / "messages.json"
    if not mp.is_file():
        return None
    try:
        messages = json.loads(mp.read_text(encoding="utf-8"))
        if not isinstance(messages, list):
            return None
    except Exception:
        return None
    summary = ""
    sp = _dir(sid) / "summary.md"
    if sp.is_file():
        try:
            summary = sp.read_text(encoding="utf-8")
        except Exception:
            summary = ""
    root = stored_game_root(sid)
    if not summary:
        summary = build_summary(sid, messages, root=root) if root else ""
    try:
        if root:
            summary = write_summary(sid, messages, root=root) or summary
    except Exception:
        pass
    messages = inject_summary(messages, sid=sid, summary=summary)
    meta = next((r for r in _load_index() if r.get("id") == sid), {}) or {}
    return {"session_id": sid, "messages": messages, "summary": summary,
            "title": meta.get("title") or _title_from_messages(messages),
            "game": meta.get("game") or "", "engine": meta.get("engine") or ""}


def is_deleted(sid: str) -> bool:
    s = _safe_sid(sid)
    return bool(s) and _norm_game(s) in _load_deleted() and not (CHATS / s).is_dir()


def save_messages(sid: str, messages: list[dict], title: str = "", game_root: Path | None = None) -> None:
    sid = _safe_sid(sid)
    if not sid:
        return
    if is_deleted(sid):
        return  # a turn that finishes after the chat was deleted must not bring it back (restore is explicit)
    payload = []
    for m in messages or []:
        row = {k: m[k] for k in m if k in ("role", "content", "tool_calls") and m[k] not in (None, "", [])}
        if "role" in row:
            payload.append(row)
    _write(_dir(sid) / "messages.json", json.dumps(payload, ensure_ascii=False, indent=2))
    try:
        merge_full_messages(sid, payload)
    except Exception:
        pass
    old_row = next((r for r in _load_index() if r.get("id") == sid), None) or {}
    root = Path(game_root) if game_root else stored_game_root(sid)
    if root is None:
        try:
            root = chat_game_root(messages)  # only links when this chat's own turns talk about that game
        except Exception:
            root = None
    inferred = root.name if root else _project_name(messages)
    # If the caller already named this chat and it is not the current project, keep that name.
    if title and inferred and _norm_game(title) != _norm_game(inferred) and _norm_game(_pretty_title(game=inferred) or "") != _norm_game(title):
        game = title
    else:
        game = inferred or title or ""
    engine = ""
    try:
        import intake
        st = getattr(intake, "_LAST", {}).get("st") or {}
        engine = str(st.get("engine") or "")
        if not title and st.get("title") and (not game or _norm_game(st["title"]) == _norm_game(game)):
            title = str(st["title"])
    except Exception:
        pass
    if not engine and game:
        pitch = _read(GAMEPROJECTS / game / "Docs" / "Pitch.md", 800)
        m = re.search(r"Engine:\s*([^\n|]+)", pitch)
        if m:
            engine = m.group(1).strip()
    pretty = _pretty_title(game=game)
    if pretty and (not title or _norm_game(pretty) == _norm_game(game) or _norm_game(pretty) == _norm_game(title)):
        title = pretty
    title = title or _title_from_messages(messages, game or "New chat")
    # Revive a previously deleted game chat if the user starts talking about it again.
    gone = _load_deleted()
    if gone & {_norm_game(game), _norm_game(title)}:
        gone -= {_norm_game(game), _norm_game(title)}
        _save_deleted(gone)
    rows = [r for r in _load_index() if r.get("id") != sid]
    row = {"id": sid, "title": title, "game": game or title, "engine": engine or old_row.get("engine") or "",
           "game_root": str(root) if root else (old_row.get("game_root") or ""), "updated": _now()}
    rows.append(row)
    _save_index(rows)
    try:
        _write(_dir(sid) / "chat_meta.json", json.dumps(row, indent=2, ensure_ascii=False))
    except Exception:
        pass


def adopt_game_chat(sid: str, messages: list[dict]) -> str:
    """Keep one chat per game: merge this session into the existing game chat when present."""
    sid = _safe_sid(sid)
    game = _project_name(messages)
    title = _pretty_title(game=game)
    other = _safe_sid(find_chat_for_game(game, title))
    if not sid or not other or other == sid:
        return sid
    # fix5: only merge when THIS session is actually about that game. A brand-new chat ("make a new fps game")
    # used to be merged into whatever game was current (.current / newest project) and wrote into its chat.
    def _norm(x):
        return re.sub(r"[^a-z0-9]+", "", str(x or "").lower())
    blob = _norm(" ".join(str(m.get("content") or "") for m in (messages or []) if m.get("role") in ("user", "assistant")))
    keys = {k for k in (_norm(game), _norm(title)) if len(k) >= 3}
    if not keys or not any(k in blob for k in keys):
        return sid
    dest_path = _dir(other) / "messages.json"
    dest = []
    if dest_path.is_file():
        try:
            dest = json.loads(dest_path.read_text(encoding="utf-8"))
            if not isinstance(dest, list):
                dest = []
        except Exception:
            dest = []
    have = {(m.get("role"), str(m.get("content") or "")) for m in dest}
    for m in messages or []:
        key = (m.get("role"), str(m.get("content") or ""))
        if m.get("role") in ("user", "assistant") and str(m.get("content") or "").strip() and key not in have:
            dest.append(m)
            have.add(key)
    _write(dest_path, json.dumps([
        {k: m[k] for k in m if k in ("role", "content", "tool_calls") and m[k] not in (None, "", [])}
        for m in dest if m.get("role")
    ], ensure_ascii=False, indent=2))
    # Drop the duplicate session folder/index row, but do not mark the game deleted.
    rows = [r for r in _load_index() if r.get("id") != sid]
    _save_index(rows)
    _to_trash(sid, {"id": sid, "merged_into": other})
    return other


def delete_chat(sid: str) -> bool:
    """Remove a chat from the menu and disk. Does not delete the game project."""
    sid = _safe_sid(sid)
    if not sid:
        return False
    rows = _load_index()
    row = next((r for r in rows if r.get("id") == sid), None)
    if row is None and not _dir(sid).is_dir():
        return False
    _save_index([r for r in rows if r.get("id") != sid])
    gone = _load_deleted()
    if row:
        for k in (row.get("id"), row.get("game"), row.get("title")):
            if k:
                gone.add(_norm_game(str(k)))
    gone.add(_norm_game(sid))
    _save_deleted(gone)
    _to_trash(sid, row or {"id": sid})
    return True


TRASH = CHATS / "_trash"


def _to_trash(sid: str, row: dict) -> Path | None:
    """Move a chat folder to work/chats/_trash/<sid>__<time> (restorable) instead of deleting it."""
    src = _dir(sid)
    if not src.is_dir():
        return None
    TRASH.mkdir(parents=True, exist_ok=True)
    dst = TRASH / f"{sid}__{datetime.now().strftime('%Y%m%d_%H%M%S')}_{uuid.uuid4().hex[:4]}"
    try:
        (src / "_row.json").write_text(json.dumps(row or {}, indent=2, ensure_ascii=False), encoding="utf-8")
    except Exception:
        pass
    shutil.move(str(src), str(dst))
    return dst


def list_trash() -> list[dict]:
    out = []
    if TRASH.is_dir():
        for d in sorted(TRASH.iterdir(), reverse=True):
            if d.is_dir() and "__" in d.name:
                try:
                    row = json.loads((d / "_row.json").read_text(encoding="utf-8"))
                except Exception:
                    row = {}
                out.append({"id": d.name.split("__")[0], "folder": d.name, "title": row.get("title") or "", "game": row.get("game") or ""})
    return out


def restore_chat(sid: str) -> bool:
    """Bring the newest trashed copy of a chat back into the menu."""
    sid = _safe_sid(sid)
    if not sid or _dir(sid).exists() or not TRASH.is_dir():
        return False
    cands = sorted((d for d in TRASH.iterdir() if d.is_dir() and d.name.split("__")[0] == sid), reverse=True)
    if not cands:
        return False
    src = cands[0]
    try:
        row = json.loads((src / "_row.json").read_text(encoding="utf-8"))
    except Exception:
        row = {}
    shutil.move(str(src), str(_dir(sid)))
    gone = _load_deleted()
    gone -= {_norm_game(sid), _norm_game(str(row.get("game") or "")), _norm_game(str(row.get("title") or ""))}
    _save_deleted(gone)
    rows = [r for r in _load_index() if r.get("id") != sid]
    rows.append({"id": sid, "title": row.get("title") or sid, "game": row.get("game") or "", "engine": row.get("engine") or "",
                 "game_root": row.get("game_root") or "", "updated": _now()})
    _save_index(rows)
    return True


def inject_summary(messages: list[dict], sid: str = "", summary: str = "") -> list[dict]:
    text = (summary or "").strip() or build_summary(sid, messages)
    if not text:
        return messages
    block = text if text.startswith(SUMMARY_TAG) else (SUMMARY_TAG + "\n" + text)
    kept = [m for m in messages if not (m.get("role") == "system" and str(m.get("content") or "").startswith(SUMMARY_TAG))]
    # Keep the main system prompt first, then the summary, then the rest.
    if kept and kept[0].get("role") == "system":
        kept = [kept[0], {"role": "system", "content": block}] + kept[1:]
    else:
        kept = [{"role": "system", "content": block}] + kept
    if messages is not kept:
        messages[:] = kept
    return messages


def _intake_bits() -> dict:
    try:
        import intake
        st = getattr(intake, "_LAST", {}).get("st") or {}
    except Exception:
        st = {}
    keys = ("title", "engine", "genre", "loop", "story", "goals", "setting", "style", "template")
    return {k: st.get(k) for k in keys if st.get(k) not in (None, "")}


def _read(path: Path, limit: int = 2500) -> str:
    try:
        return path.read_text(encoding="utf-8", errors="ignore")[:limit]
    except Exception:
        return ""


def _next_actions(taskboard: str, status: str = "") -> str:
    done_ok = "DONE OK" in (status or "").upper()
    lines = []
    for line in (taskboard or "").splitlines():
        s = line.strip()
        if not s.startswith("- [ ]"):
            continue
        low = s.lower()
        # If the player build already finished, do not keep "verify status / still running" as next.
        if done_ok and ("auto_unity_status" in low or "says done ok" in low or "verify builds" in low):
            continue
        lines.append(s)
        if len(lines) >= 6:
            break
    return "\n".join(lines)


def _format_build_status(status: str) -> str:
    s = (status or "").strip() or "no build started yet"
    u = s.upper()
    if "DONE OK" in u:
        return f"FINISHED: {s}. The player build is not running."
    if "DONE FAIL" in u:
        return f"FAILED: {s}. The player build is not running."
    if "RUNNING" in u or "QUEUED" in u:
        return f"IN PROGRESS: {s}"
    return s


def _summary_needs_build_refresh(summary: str, status: str) -> bool:
    sm = (summary or "").upper()
    st = (status or "").upper()
    if not st:
        return False
    if "DONE OK" in st or "DONE FAIL" in st:
        if "PLAYER BUILD RUNNING" in sm or re.search(r"BUILD RUNNING", sm):
            return True
        if "FINISHED:" not in sm or "NOT RUNNING" not in sm:
            return True
        if "DONE OK" in st and "DONE OK" not in sm:
            return True
    if ("RUNNING" in st or "QUEUED" in st) and "IN PROGRESS:" not in sm:
        return True
    return False


def _assets_from(root: Path | None) -> str:
    if not root:
        return ""
    text = _read(root / "ATTRIBUTION.md", 4000)
    names = []
    for line in text.splitlines():
        if line.startswith("|") and "asset" not in line.lower() and "---" not in line:
            cols = [c.strip() for c in line.strip("|").split("|")]
            if cols and cols[0] and cols[0] not in names:
                names.append(cols[0])
    return ", ".join(names[:16])


def build_summary(sid: str = "", messages: list[dict] | None = None, root: Path | None = None) -> str:
    bits = _intake_bits()
    try:
        from auto_studio import resolve_project, build_status
        if root is None:
            root = resolve_project("")
        status = build_status(root) if root else ""
    except Exception:
        status = ""
    name = _pretty_title(game=(root.name if root else ""), root=root, bits=bits) or (root.name if root else "") or _project_name(messages) or "unspecified"
    engine = bits.get("engine") or ""
    if root and not engine:
        pitch = _read(root / "Docs" / "Pitch.md", 1200)
        m = re.search(r"Engine:\s*([^\n|]+)", pitch)
        if m:
            engine = m.group(1).strip()
    intake_lines = []
    labels = [("title", "Title"), ("engine", "Engine"), ("genre", "Genre"), ("loop", "Core loop"),
              ("story", "Story"), ("goals", "Goals"), ("setting", "Setting"), ("style", "Art / tone"),
              ("template", "Template")]
    for k, lab in labels:
        if bits.get(k):
            intake_lines.append(f"- {lab}: {bits[k]}")
    if root and not intake_lines:
        pitch = _read(root / "Docs" / "Pitch.md", 2000)
        for key, lab in (("## Title", "Title"), ("## Core loop", "Core loop"), ("## Story", "Story"),
                         ("## Goals", "Goals"), ("## Setting", "Setting"), ("## Art", "Art / tone")):
            if key.lower() in pitch.lower():
                chunk = pitch.split(key, 1)[-1] if key in pitch else ""
                # try case-insensitive
                if not chunk:
                    idx = pitch.lower().find(key.lower())
                    if idx >= 0:
                        chunk = pitch[idx + len(key):]
                line = " ".join((chunk.split("##", 1)[0] if chunk else "").split())[:240]
                if line:
                    intake_lines.append(f"- {lab}: {line}")
        if engine:
            intake_lines.insert(0, f"- Engine: {engine}")
    assets = _assets_from(root)
    nxt = _next_actions(_read(root / "Docs" / "TaskBoard.md", 4000) if root else "", status)
    # Recent design decisions from chat (last few user/assistant lines)
    recent = []
    done_ok = "DONE OK" in (status or "").upper()
    for m in ui_messages(messages or [])[-8:]:
        preview = " ".join(str(m.get("content") or "").split())[:220]
        if not preview:
            continue
        low = preview.lower()
        if looks_like_internal_text(preview):
            continue
        if done_ok and "build running" in low and "not running" not in low:
            continue
        recent.append(f"- {m['role']}: {preview}")
    facts = (
        "CURRENT FACTS (trust these over earlier assistant messages in this chat):\n"
        f"- Game title: {name}\n"
        f"- Engine: {engine or 'not chosen yet'}\n"
        f"- Build status: {_format_build_status(status)}\n"
    )
    if done_ok:
        facts += "- The Windows player already finished successfully. Do not say the build is still running. Do not start new-game intake; this game already exists.\n"
    parts = [
        facts.strip(),
        f"Game title: {name}",
        f"Engine: {engine or 'not chosen yet'}",
        "Intake answers:\n" + ("\n".join(intake_lines) if intake_lines else "- (none stored yet)"),
        "Design decisions:\n" + ("\n".join(recent) if recent else "- (see intake and project docs)"),
        "Assets chosen: " + (assets or "(none recorded yet)"),
        "Build status: " + _format_build_status(status),
        "What's next:\n" + (nxt or "- Continue the current request in this chat"),
        "Updated: " + _now(),
    ]
    return "\n\n".join(parts)


def write_summary(sid: str, messages: list[dict], root: Path | None = None) -> str:
    if root is None and sid:
        root = stored_game_root(sid) or chat_game_root(messages)
    text = build_summary(sid, messages, root=root)
    sid = _safe_sid(sid)
    if sid:
        _write(_dir(sid) / "summary.md", text)
    if root is None:
        root = stored_game_root(sid) if sid else None  # never the global "current game" (review fix 3)
    if root:
        title = _pretty_title(game=root.name, root=root) or root.name
        body = f"# {title} - session summary\n\n" + text + "\n"
        _write(root / "Docs" / "SESSION_SUMMARY.md", body)
    inject_summary(messages, sid=sid, summary=text)
    return text


def refresh_build_in_summaries() -> None:
    """When a build finishes, rewrite any summary that still says the player build is running."""
    try:
        from auto_studio import build_status, resolve_project
    except Exception:
        return
    current = None
    try:
        current = resolve_project("")
    except Exception:
        current = None
    for row in _load_index():
        sid = _safe_sid(row.get("id") or "")
        game = row.get("game") or ""
        folder = GAMEPROJECTS / game if game else None
        if not folder or not folder.is_dir():
            folder = current
        if not folder or not sid:
            continue
        try:
            status = build_status(folder)
        except Exception:
            continue
        old = ""
        for path in (_dir(sid) / "summary.md", folder / "Docs" / "SESSION_SUMMARY.md"):
            if path.is_file():
                old += "\n" + _read(path, 8000)
        if not _summary_needs_build_refresh(old, status):
            continue
        msgs = []
        mp = _dir(sid) / "messages.json"
        if mp.is_file():
            try:
                loaded = json.loads(mp.read_text(encoding="utf-8"))
                if isinstance(loaded, list):
                    msgs = loaded
            except Exception:
                msgs = []
        try:
            write_summary(sid, msgs, root=folder)
        except Exception:
            pass



def seed_from_projects() -> None:
    """Ensure a reopenable chat exists for each GameProjects title (summary even if history is missing)."""
    if not GAMEPROJECTS.is_dir():
        return
    rows = _load_index()
    deleted = _load_deleted()
    by_game = {_norm_game(r.get("game") or "") or _norm_game(r.get("title") or ""): r for r in rows}
    for d in GAMEPROJECTS.iterdir():
        if not d.is_dir() or d.name.startswith(".") or d.name.lower() in ("exports",):
            continue
        if not (d / "Docs").is_dir() and not (d / "Builds").is_dir():
            continue
        pretty = _pretty_title(game=d.name, root=d)
        key = _norm_game(d.name) or _norm_game(pretty)
        if key in deleted or _norm_game(pretty) in deleted:
            continue
        if key in by_game:
            # Refresh on-disk summary for the existing chat.
            sid = _safe_sid(by_game[key].get("id") or "")
            if sid:
                mp = _dir(sid) / "messages.json"
                msgs = []
                if mp.is_file():
                    try:
                        msgs = json.loads(mp.read_text(encoding="utf-8"))
                    except Exception:
                        msgs = []
                if not (d / "Docs" / "SESSION_SUMMARY.md").is_file():
                    try:
                        write_summary(sid, msgs if isinstance(msgs, list) else [], root=d)
                    except Exception:
                        pass
            continue
        sid = "game-" + re.sub(r"[^a-z0-9]+", "", d.name.lower())[:40]
        if not sid or any(r.get("id") == sid for r in rows):
            sid = "game-" + uuid.uuid4().hex[:10]
        # Minimal session so it can be reopened; inject_summary fills context.
        try:
            from agent_core import new_session
            messages = new_session()
        except Exception:
            messages = []
        try:
            write_summary(sid, messages, root=d)
            save_messages(sid, messages, title=pretty or d.name, game_root=d)
        except Exception:
            # If agent_core isn't ready yet, still record a stub row + summary file.
            _write(_dir(sid) / "summary.md", f"Game title: {pretty or d.name}\nEngine: unknown\n")
            save_messages(sid, messages or [{"role": "system", "content": "Game Bot"}], title=pretty or d.name, game_root=d)


def classify_step(text: str) -> tuple[str, int]:
    t = (text or "").lower()
    for label, pct, keys in _STEPS:
        if any(k in t for k in keys):
            return label, pct
    if "running" in t or "working" in t or "thinking" in t:
        return "Working", 50
    if "idle" in t or not t.strip():
        return "Ready", 0
    return "Working", 50


def _elapsed_from_status_file() -> int:
    try:
        from auto_studio import resolve_project, _status_file
        root = resolve_project("")
        if not root:
            return 0
        st = _status_file(root)
        if not st.is_file():
            return 0
        lines = st.read_text(encoding="utf-8", errors="ignore").splitlines()
        first = ""
        for line in lines:
            if re.match(r"\d{2}:\d{2}:\d{2}\s", line.strip()):
                first = line.strip()[:8]
                break
        if not first:
            return 0
        day = datetime.fromtimestamp(st.stat().st_mtime).date()
        start = datetime.strptime(f"{day.isoformat()} {first}", "%Y-%m-%d %H:%M:%S")
        return max(0, int((datetime.now() - start).total_seconds()))
    except Exception:
        return 0


def progress_bar() -> dict:
    """Structured status for the pinned work bar."""
    import time as _t
    try:
        refresh_build_in_summaries()
    except Exception:
        pass
    busy = False
    turn_status = ""
    turn_elapsed = 0
    try:
        from agent_core import _TURN, unity_bg_status, progress_report
        busy = bool(_TURN.get("busy"))
        turn_status = str(_TURN.get("status") or "")
        if busy:
            turn_elapsed = int(_t.time() - float(_TURN.get("since") or _t.time()))
        bg = unity_bg_status() or ""
        report = progress_report()
    except Exception:
        bg, report = "", ""
    try:
        from auto_studio import build_status, resolve_project
        root = resolve_project("")
        status = build_status(root) if root else ""
        project = root.name if root else ""
    except Exception:
        status, project, root = "", "", None

    blob = " ".join(x for x in (turn_status, bg, status, report) if x)
    running = bool(busy or (bg and "RUNNING" in bg) or (status and "RUNNING" in status))
    step, pct = classify_step(blob if running or "DONE" in blob.upper() else "")
    _sm = re.search(r"Compiling shaders: (\d+)/(\d+)", blob)
    if running and _sm:
        step, pct = "Compiling shaders", 75 + int(20 * int(_sm.group(1)) / max(1, int(_sm.group(2))))
    elif running and "Compiling shaders" in blob:
        step, pct = "Compiling shaders", 75
    if running and step == "Ready":
        step, pct = ("Working" if busy else "Building exe"), (40 if busy else 80)
    if not running and ("DONE OK" in (status or "").upper() or "DONE OK" in (report or "").upper()):
        step, pct = "Done", 100
    elif not running and "DONE FAIL" in (status or "").upper():
        step, pct = "Build failed", 100
    elif not running and not busy:
        step, pct = "Ready", 0

    elapsed = turn_elapsed
    if running and (bg or "RUNNING" in (status or "")):
        file_elapsed = _elapsed_from_status_file()
        if file_elapsed > elapsed:
            elapsed = file_elapsed
    detail = (turn_status or bg or status or report or "Game Bot is idle").strip()
    if step == "Ready" and not running:
        # Keep last build in the detail line when idle.
        detail = (status or report or "Game Bot is idle").strip()
        if detail.lower().startswith("idle."):
            detail = detail[5:].strip() or "Game Bot is idle"
    try:  # owned packs downloading/importing inside Unity
        from asset_fetch import bar_state
        _fb = bar_state()
        if _fb and not running:
            return _fb
    except Exception:
        pass
    return {
        "active": bool(running),
        "state": "run" if running else ("done" if step in ("Done", "Build failed") and "DONE" in blob.upper() else "idle"),
        "step": step,
        "pct": pct if running or step in ("Done", "Build failed") else 0,
        "elapsed_s": elapsed if running else 0,
        "detail": detail[:240],
        "project": project,
        "ai_paused": _gpu_status() if running else "",
    }


def _gpu_status() -> str:
    try:
        import gpu_guard
        return gpu_guard.status_line()
    except Exception:
        return ""
