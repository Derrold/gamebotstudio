"""Headless Unreal 5.8.4 compile smoke test. No visible editor window."""
from __future__ import annotations

import json
import os
import subprocess
import time
from pathlib import Path

# CREATE_NEW_PROCESS_GROUP | CREATE_NO_WINDOW
_HIDDEN = 0x00000200 | 0x08000000


def find_editor():
    from auto_studio import find_unreal
    return find_unreal()


def engine_root(ed: Path | None = None) -> Path | None:
    ed = ed or find_editor()
    if not ed:
        return None
    return ed.parents[3]  # .../UE_5.8


def engine_version(ed: Path | None = None) -> tuple[int, int, int] | None:
    root = engine_root(ed)
    if not root:
        return None
    p = root / "Engine" / "Build" / "Build.version"
    if not p.is_file():
        return None
    try:
        data = json.loads(p.read_text(encoding="utf-8-sig"))
        return (int(data["MajorVersion"]), int(data["MinorVersion"]), int(data["PatchVersion"]))
    except Exception:
        return None


def editor_cmd(ed: Path | None = None) -> Path | None:
    ed = ed or find_editor()
    if not ed:
        return None
    cmd = ed.parent / "UnrealEditor-Cmd.exe"
    return cmd if cmd.is_file() else None


def write_min_project(root: Path, name: str = "UeSmoke") -> Path:
    """Blueprint-only stub project so CompileAllBlueprints has something to load."""
    root = Path(root)
    root.mkdir(parents=True, exist_ok=True)
    (root / "Content").mkdir(parents=True, exist_ok=True)
    (root / "Config").mkdir(parents=True, exist_ok=True)
    (root / "Builds").mkdir(parents=True, exist_ok=True)
    uproj = root / f"{name}.uproject"
    uproj.write_text(
        json.dumps(
            {
                "FileVersion": 3,
                "EngineAssociation": "5.8",
                "Category": "Game Bot",
                "Description": "Game Bot headless compile smoke",
                "Modules": [],
                "Plugins": [],
            },
            indent=2,
        )
        + "\n",
        encoding="utf-8",
    )
    (root / "Config" / "DefaultEngine.ini").write_text(
        "[/Script/EngineSettings.GameMapsSettings]\n"
        "EditorStartupMap=/Engine/Maps/Templates/Template_Default\n"
        "GameDefaultMap=/Engine/Maps/Templates/Template_Default\n",
        encoding="utf-8",
    )
    (root / "Config" / "DefaultGame.ini").write_text(
        "[/Script/EngineSettings.GeneralProjectSettings]\n"
        f"ProjectName={name}\n"
        "Description=Game Bot headless compile smoke\n",
        encoding="utf-8",
    )
    return uproj


def run_headless_compile(root: Path, name: str = "UeSmoke", timeout_s: int = 900) -> dict:
    """Run UnrealEditor-Cmd -run=CompileAllBlueprints with no visible window."""
    rec: dict = {"ok": False}
    ed = find_editor()
    rec["editor"] = str(ed) if ed else None
    ver = engine_version(ed)
    rec["version"] = list(ver) if ver else None
    cmd = editor_cmd(ed)
    rec["cmd"] = str(cmd) if cmd else None
    if not cmd:
        rec["error"] = "UnrealEditor-Cmd.exe not found"
        return rec
    if ver != (5, 8, 4):
        rec["error"] = f"expected Unreal 5.8.4, found {ver}"
        return rec
    uproj = write_min_project(root, name)
    log = Path(root) / "Builds" / "ue_compile.log"
    log.parent.mkdir(parents=True, exist_ok=True)
    rec["uproject"] = str(uproj)
    rec["log"] = str(log)
    args = [
        str(cmd),
        str(uproj),
        "-run=CompileAllBlueprints",
        "-unattended",
        "-nop4",
        "-nosplash",
        "-nullrhi",
        "-stdout",
        f"-abslog={log}",
    ]
    rec["args"] = args
    t0 = time.time()
    try:
        p = subprocess.run(
            args,
            cwd=str(root),
            timeout=timeout_s,
            creationflags=_HIDDEN,
            close_fds=True,
            stdin=subprocess.DEVNULL,
            stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT,
            text=True,
            encoding="utf-8",
            errors="replace",
        )
        rec["exit"] = p.returncode
        rec["secs"] = round(time.time() - t0, 1)
        out = p.stdout or ""
        rec["stdout_tail"] = out[-4000:]
    except subprocess.TimeoutExpired as e:
        rec["exit"] = None
        rec["secs"] = round(time.time() - t0, 1)
        rec["error"] = f"timeout after {timeout_s}s"
        rec["stdout_tail"] = (e.stdout or "")[-4000:] if isinstance(e.stdout, str) else ""
        return rec
    except Exception as e:
        rec["error"] = f"{type(e).__name__}: {e}"
        rec["secs"] = round(time.time() - t0, 1)
        return rec
    log_txt = ""
    if log.is_file():
        try:
            log_txt = log.read_text(encoding="utf-8", errors="replace")
        except Exception:
            log_txt = ""
    rec["log_tail"] = log_txt[-4000:]
    blob = (out + "\n" + log_txt).lower()
    rec["ok"] = rec.get("exit") == 0 and "fatal error" not in blob
    return rec


if __name__ == "__main__":
    dest = Path(__file__).resolve().parent / "work" / "ue_compile_0013" / "UeSmoke"
    rec = run_headless_compile(dest)
    print(json.dumps({k: rec.get(k) for k in ("ok", "version", "exit", "secs", "error", "cmd", "uproject", "log")}, indent=2))
    if rec.get("stdout_tail"):
        print("--- stdout tail ---")
        print(rec["stdout_tail"][-2000:])
    if rec.get("log_tail"):
        print("--- log tail ---")
        print(rec["log_tail"][-2000:])
    raise SystemExit(0 if rec.get("ok") else 1)
