using UnityEngine;
/// <summary>MMORPG hero: hotbar abilities (1 Strike, 2 Firebolt, 3 Heal), nearest-in-front targeting, level scaling, world chat feed.</summary>
public class MmoPlayer : MonoBehaviour
{
    float[] cd = new float[3]; static readonly float[] CD = { 0.8f, 3f, 10f }; string[] chat = new string[5]; float nextChat = 4f;
    static readonly string[] Lines = { "Kaelith: LFG Treant run, need tank", "Brom: anyone selling wolf pelts?", "Ysra: herbs spawn by the north pond", "Thorn: gz on the level up!", "Mira: WTB firebolt tome", "Odo: Warden Hale gives good xp", "Lune: treant hits hard, bring heals" };
    void Update()
    {
        if (GameState.Won || GameState.Lost || PauseMenu.IsPaused || MainMenuUI.InMenu) return;
        GenreState.MaxHealth = 100 + (GenreState.Level - 1) * 25; if (GenreState.Health > GenreState.MaxHealth) GenreState.Health = GenreState.MaxHealth;
        if (Time.time - GenreState.LastHurt > 5f && Random.value < Time.deltaTime * 6f) GenreState.Health = Mathf.Min(GenreState.MaxHealth, GenreState.Health + 1);
        for (int i = 0; i < 3; i++) cd[i] -= Time.deltaTime;
        if ((Input.GetKeyDown(KeyCode.Alpha1) || Input.GetMouseButtonDown(0) || GameBotQA.AutoFire) && cd[0] <= 0) Use(0);
        if (Input.GetKeyDown(KeyCode.Alpha2) && cd[1] <= 0) Use(1);
        if (Input.GetKeyDown(KeyCode.Alpha3) && cd[2] <= 0) Use(2);
        if (Time.timeSinceLevelLoad > nextChat) { nextChat = Time.timeSinceLevelLoad + Random.Range(6f, 12f); for (int i = 0; i < chat.Length - 1; i++) chat[i] = chat[i + 1]; chat[chat.Length - 1] = "[World] " + Lines[Random.Range(0, Lines.Length)]; }
    }
    void Use(int i)
    {
        if (i == 2) { cd[2] = CD[2]; GenreState.Health = Mathf.Min(GenreState.MaxHealth, GenreState.Health + 45); GameHUD.Flash("Heal +45"); return; }
        float range = i == 0 ? 3.2f : 24f; MmoMob best = null; float bd = range;
        foreach (var m in FindObjectsByType<MmoMob>(FindObjectsSortMode.None)) { if (!m.Alive) continue; Vector3 to = m.transform.position - transform.position; to.y = 0; if (to.magnitude < bd && Vector3.Angle(transform.forward, to) < (i == 0 ? 80 : 30)) { bd = to.magnitude; best = m; } }
        cd[i] = CD[i]; if (!best) return;
        int dmg = i == 0 ? 14 + GenreState.Level * 4 : 26 + GenreState.Level * 6; best.Hit(dmg);
        if (i == 1) { var fx = GameObject.CreatePrimitive(PrimitiveType.Sphere); Destroy(fx.GetComponent<Collider>()); fx.transform.position = best.transform.position + Vector3.up; fx.transform.localScale = Vector3.one * 0.9f; fx.GetComponent<Renderer>().material.color = new Color(1f, 0.45f, 0.1f); Destroy(fx, 0.2f); }
    }
    void OnGUI()
    {
        if (MainMenuUI.InMenu) return; var s = new GUIStyle(GUI.skin.box) { fontSize = 17 }; string[] n = { "1 Strike", "2 Firebolt", "3 Heal" };
        for (int i = 0; i < 3; i++) GUI.Box(new Rect(Screen.width / 2 - 255 + i * 170, Screen.height - 62, 160, 46), n[i] + (cd[i] > 0 ? " " + cd[i].ToString("0.0") : ""), s);
        var c = new GUIStyle(GUI.skin.label) { fontSize = 15 }; for (int i = 0; i < chat.Length; i++) if (chat[i] != null) GUI.Label(new Rect(16, Screen.height - 200 + i * 22, 600, 22), chat[i], c);
        GUI.Label(new Rect(16, 72, 700, 26), "HP " + GenreState.Health + "/" + GenreState.MaxHealth + "   Gold " + GenreState.Gold, new GUIStyle(GUI.skin.label) { fontSize = 20 });
    }
}
