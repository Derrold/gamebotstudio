﻿# Game Bot — ready checklist (smoke tomorrow)

## Tonight — ready
- [x] Automatic studio SYSTEM + run_auto_game_pipeline wired
- [x] AlphaMax/personal scrubbed (private plugin opt-in only)
- [x] 64 playbooks + index + product-safety/onboarding
- [x] config/gamebot.config.json
- [x] README.md + REQUIREMENTS.txt
- [x] dist/GameBot-product.zip (~0.84 MB, 200+ files, no personal archive)
- [x] Desktop "Game Bot" shortcut + start-game-bot.ps1
- [x] http://127.0.0.1:7870/ health OK (qwen-fast)

## Tomorrow smoke
1. Open Game Bot
2. Prompt: Make a game called SmokeTest01 — tiny 3D prototype, Unity.
3. Confirm folder under projects_root + Docs + tools acting (not a tutorial)
4. Delete SmokeTest01 when done
5. Note any stalls for patch
