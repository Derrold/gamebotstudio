# Pricing and wishlists

Tags: monetization steam store pricing
Saved: 2026-10-25T20:29:36

Research comparable prices via firefox_search; premium default; EA only if fun now; Coming Soon page early; no spam/fake reviews. Source: https://partner.steamgames.com/doc/store/pricing
