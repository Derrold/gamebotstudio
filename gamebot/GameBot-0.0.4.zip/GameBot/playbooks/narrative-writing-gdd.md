# Narrative, writing, GDD
Sources: https://www.gamedeveloper.com/design | https://github.com/inkle/ink | https://docs.unity3d.com/Packages/com.unity.localization@1.5/manual/index.html

## GDD sections (Docs\GDD.md - make_game_scaffold creates skeleton)
1. Pitch (1 sentence + 1 paragraph), target player, comps (2-3 similar games), USP.
2. Pillars (3): e.g.
3. Core loop (minute-to-minute), session loop (hunt day), meta loop (season, progression).
5. Content list: maps/regions, species, weapons, gear, challenges - with counts.
6. UX flow: boot -> legal -> main menu -> profile -> loadout -> hunt -> results.
7. Art direction (refs, palette), audio direction.
8. Tech: engine/version (Unity 6000.6), render pipeline (URP), platforms, perf targets.
9. Monetization, scope/milestones (vertical slice -> alpha -> beta -> release), risks.

## Tone bible
- Voice (e.g. respectful, knowledgeable, dry humor), vocabulary list, banned tropes, sample lines (tutorial, warden, results screen). Keep UI text short.
- RidgeRunnerSlice: write its own pitch/pillars/tone in Documents\GameProjects\RidgeRunnerSlice\Docs before production.

## Writing workflow
- Strings in localization tables from day one (Unity Localization), no hard-coded UI text. Story/dialogue in ink/Yarn if branching.
- Lore for hunting: real regulations-like flavor but fictionalized where needed;
