using UnityEngine;
/// <summary>Bush / shadow cover for stealth.</summary>
public class CoverZone : MonoBehaviour
{
    void OnTriggerEnter(Collider o) { if (o.CompareTag("Player")) GenreState.InCover = true; }
    void OnTriggerExit(Collider o) { if (o.CompareTag("Player")) GenreState.InCover = false; }
}
