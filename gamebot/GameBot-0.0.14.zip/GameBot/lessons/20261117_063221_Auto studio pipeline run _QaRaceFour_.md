# Auto studio pipeline run (QaRaceFour)

Tags: auto studio pipeline
Saved: 2026-11-17T06:32:21

run_auto_game_pipeline created 34 files under C:\Users\Derrold PC\Documents\GameProjects\QaRaceFour and UNITY 6000.6.5f1: background job started -> create QaRaceFourUnity -> Racing game (gameplay template: racing; menu, settings, achievements, owned genre kit) -> . Next: check Builds\auto_unity_status.txt, then work TaskBoard 'Auto next actions' with tools.
