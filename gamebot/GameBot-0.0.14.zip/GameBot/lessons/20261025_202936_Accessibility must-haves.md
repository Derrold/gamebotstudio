# Accessibility must-haves

Tags: accessibility
Saved: 2026-10-25T20:29:36

Remapping (Input System rebinding), subtitles/captions for key sounds, UI scale, colorblind-safe (no color-only info), FOV/headbob/shake/motion blur toggles, separate volume sliders. Source: https://gameaccessibilityguidelines.com/
