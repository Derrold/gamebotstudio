using System.Collections.Generic;
using System.IO;
using System.Text;
using UnityEditor;
using UnityEditor.SceneManagement;
using UnityEngine;

// Game Bot scene inspector: dumps a scene's GameObject tree to JSON (batchmode: -executeMethod SceneInspector.Dump).
// Env: GAMEBOT_INSPECT_SCENE (default Assets/Scenes/Game.unity), GAMEBOT_INSPECT_OUT (default ../Builds/scene_inspect.json).
public static class SceneInspector
{
    static readonly HashSet<string> PrimMeshes = new HashSet<string> { "Cube", "Plane", "Sphere", "Capsule", "Cylinder", "Quad" };
    static string J(string s) => "\"" + (s ?? "").Replace("\\", "\\\\").Replace("\"", "\\\"").Replace("\n", " ").Replace("\r", " ") + "\"";
    static string V(Vector3 v) => "[" + v.x.ToString("0.##", System.Globalization.CultureInfo.InvariantCulture) + "," + v.y.ToString("0.##", System.Globalization.CultureInfo.InvariantCulture) + "," + v.z.ToString("0.##", System.Globalization.CultureInfo.InvariantCulture) + "]";
    static string PathOf(Transform t) { var sb = new List<string>(); while (t != null) { sb.Insert(0, t.name); t = t.parent; } return string.Join("/", sb); }
    static string PackOf(string assetPath)
    {
        if (string.IsNullOrEmpty(assetPath)) return "";
        var p = assetPath.Replace("\\", "/");
        if (p.StartsWith("Assets/Art/Imports/")) { var parts = p.Split('/'); return parts.Length > 3 ? parts[3] : ""; }
        if (p.StartsWith("Assets/")) { var parts = p.Split('/'); return parts.Length > 2 ? parts[1] : ""; }
        if (p.Contains("unity default resources") || p.StartsWith("Library/")) return "(unity builtin)";
        return p;
    }

    [MenuItem("GameBot/Inspect Scene")]
    public static void Dump()
    {
        string scenePath = System.Environment.GetEnvironmentVariable("GAMEBOT_INSPECT_SCENE");
        if (string.IsNullOrEmpty(scenePath)) scenePath = "Assets/Scenes/Game.unity";
        string outPath = System.Environment.GetEnvironmentVariable("GAMEBOT_INSPECT_OUT");
        if (string.IsNullOrEmpty(outPath)) outPath = Path.GetFullPath("../Builds/scene_inspect.json");
        if (!File.Exists(scenePath)) { File.WriteAllText(outPath, "{\"ok\":false,\"error\":" + J("scene not found: " + scenePath) + "}"); Debug.LogError("INSPECT_FAIL " + scenePath); return; }
        var scene = EditorSceneManager.OpenScene(scenePath, OpenSceneMode.Single);
        Transform player = null, cam = null;
        var all = new List<Transform>();
        foreach (var r in scene.GetRootGameObjects()) all.AddRange(r.GetComponentsInChildren<Transform>(true));
        foreach (var t in all) { if (player == null && t.parent == null && (t.CompareTag("Player") || t.name == "Player" || t.name == "PlayerCar")) player = t; }
        foreach (var t in all) { if (player == null && (t.CompareTag("Player") || t.name == "Player" || t.name == "PlayerCar")) player = t; }
        var mc = Camera.main; if (mc == null) foreach (var t in all) if (t.GetComponent<Camera>()) { mc = t.GetComponent<Camera>(); break; }
        if (mc) cam = mc.transform;
        var objs = new StringBuilder(); var warn = new List<string>(); var packs = new Dictionary<string, int>(); var prefabs = new Dictionary<string, int>();
        int rendTotal = 0, rendPrim = 0, rendPack = 0, missing = 0; bool first = true;
        var playerKids = new List<string>(); var camKids = new List<string>();
        foreach (var t in all)
        {
            var go = t.gameObject;
            bool underP = player && t != player && t.IsChildOf(player), underC = cam && t != cam && t.IsChildOf(cam);
            var comps = new List<string>(); var scripts = new List<string>(); var cols = new List<string>();
            foreach (var c in go.GetComponents<Component>())
            {
                if (c == null) { comps.Add("(Missing Script)"); missing++; continue; }
                var n = c.GetType().Name; if (n == "Transform") continue; comps.Add(n);
                if (c is MonoBehaviour) scripts.Add(n);
                if (c is BoxCollider bc) cols.Add("Box" + (bc.isTrigger ? "(trigger)" : "") + " size=" + V(Vector3.Scale(bc.size, t.lossyScale)));
                else if (c is SphereCollider sc) cols.Add("Sphere" + (sc.isTrigger ? "(trigger)" : "") + " r=" + sc.radius);
                else if (c is CapsuleCollider cc) cols.Add("Capsule" + (cc.isTrigger ? "(trigger)" : "") + " h=" + cc.height);
                else if (c is MeshCollider mcol) cols.Add("Mesh" + (mcol.isTrigger ? "(trigger)" : "") + " " + (mcol.sharedMesh ? mcol.sharedMesh.name : ""));
                else if (c is CharacterController ch) cols.Add("CharacterController h=" + ch.height);
            }
            string mesh = "", meshPath = "", pack = "", mats = ""; bool prim = false; Vector3 bsize = Vector3.zero; bool rendOn = false;
            var mr = go.GetComponent<Renderer>();
            if (mr)
            {
                rendOn = mr.enabled && go.activeInHierarchy; bsize = mr.bounds.size;
                Mesh m = null; var mf = go.GetComponent<MeshFilter>(); if (mf) m = mf.sharedMesh; var smr = mr as SkinnedMeshRenderer; if (smr) m = smr.sharedMesh;
                if (m) { mesh = m.name; meshPath = AssetDatabase.GetAssetPath(m); }
                pack = PackOf(meshPath);
                prim = m != null && PrimMeshes.Contains(m.name) && (pack == "(unity builtin)" || meshPath == "" || meshPath.Contains("unity default"));
                var ml = new List<string>(); foreach (var x in mr.sharedMaterials) ml.Add(x ? x.name : "null"); mats = string.Join(",", ml);
                if (rendOn && !(mr is LineRenderer) && !(mr is ParticleSystemRenderer))
                {
                    rendTotal++;
                    if (prim) rendPrim++;
                    else if (pack != "" && pack != "(unity builtin)") { rendPack++; packs[pack] = (packs.ContainsKey(pack) ? packs[pack] : 0) + 1; var src = meshPath; prefabs[src] = (prefabs.ContainsKey(src) ? prefabs[src] : 0) + 1; }
                }
            }
            string path = PathOf(t);
            if (underP && t.parent == player) playerKids.Add(t.name);
            if (underC && t.parent == cam) camKids.Add(t.name);
            if ((underP || underC) && mr && rendOn)
            {
                float big = Mathf.Max(bsize.x, bsize.y, bsize.z);
                string low = (t.name + " " + mesh + " " + meshPath).ToLower();
                bool looksEnv = System.Text.RegularExpressions.Regex.IsMatch(low, "wall|floor|fort|ceiling|roof|building|house|terrain|tile|fence|gate|door");
                bool allowed = System.Text.RegularExpressions.Regex.IsMatch(path, "ViewGun|CharacterVisual|CarVisual|Flashlight|MuzzleFlash|Tracer|HeldBlock|Weapon");
                if (looksEnv || (!allowed && big > 2.6f) || (underC && !allowed && big > 1.2f))
                    warn.Add("FOLLOWS_" + (underC ? "CAMERA" : "PLAYER") + ": '" + path + "' mesh=" + mesh + " (" + PackOf(meshPath) + ") size=" + V(bsize) + " is parented under the " + (underC ? "camera" : "player") + " so it moves with them");
            }
            if (!first) objs.Append(",\n"); first = false;
            objs.Append("{\"path\":" + J(path) + ",\"name\":" + J(t.name) + ",\"parent\":" + J(t.parent ? t.parent.name : "") + ",\"active\":" + (go.activeInHierarchy ? "true" : "false") +
                ",\"pos\":" + V(t.position) + ",\"local\":" + V(t.localPosition) + ",\"scale\":" + V(t.lossyScale) +
                ",\"components\":[" + string.Join(",", comps.ConvertAll(J)) + "],\"scripts\":[" + string.Join(",", scripts.ConvertAll(J)) + "],\"colliders\":[" + string.Join(",", cols.ConvertAll(J)) + "]" +
                (mr ? ",\"renderer\":{\"on\":" + (rendOn ? "true" : "false") + ",\"mesh\":" + J(mesh) + ",\"mesh_asset\":" + J(meshPath) + ",\"pack\":" + J(pack) + ",\"primitive\":" + (prim ? "true" : "false") + ",\"bounds\":" + V(bsize) + ",\"materials\":" + J(mats) + "}" : "") +
                ",\"under_player\":" + (underP ? "true" : "false") + ",\"under_camera\":" + (underC ? "true" : "false") + "}");
        }
        if (rendTotal > 0 && rendPack == 0) warn.Add("PRIMITIVES_ONLY: " + rendPrim + "/" + rendTotal + " visible renderers are Unity primitives; no owned-pack meshes are placed");
        if (missing > 0) warn.Add("MISSING_SCRIPTS: " + missing + " components reference scripts that no longer exist");
        var pk = new List<string>(); foreach (var kv in packs) pk.Add(J(kv.Key) + ":" + kv.Value);
        var pf = new List<string>(); foreach (var kv in prefabs) pf.Add(J(kv.Key) + ":" + kv.Value);
        string json = "{\"ok\":true,\"scene\":" + J(scenePath) + ",\"objects_count\":" + all.Count +
            ",\"player\":" + J(player ? PathOf(player) : "") + ",\"camera\":" + J(cam ? PathOf(cam) : "") +
            ",\"player_children\":[" + string.Join(",", playerKids.ConvertAll(J)) + "],\"camera_children\":[" + string.Join(",", camKids.ConvertAll(J)) + "]" +
            ",\"renderers\":{\"visible\":" + rendTotal + ",\"primitive\":" + rendPrim + ",\"pack\":" + rendPack + "},\"packs\":{" + string.Join(",", pk) + "},\"pack_meshes\":{" + string.Join(",", pf) + "}" +
            ",\"warnings\":[" + string.Join(",", warn.ConvertAll(J)) + "],\n\"objects\":[\n" + objs + "\n]}";
        Directory.CreateDirectory(Path.GetDirectoryName(outPath));
        File.WriteAllText(outPath, json);
        Debug.Log("INSPECT_OK " + outPath + " objects=" + all.Count + " warnings=" + warn.Count);
    }
}
