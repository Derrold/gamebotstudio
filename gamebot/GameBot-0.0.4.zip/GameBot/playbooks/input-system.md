# Input (Unity Input System + legacy fallback)
- New projects: Input System package (com.unity.inputsystem); Player Settings > Active Input Handling = Both during migration, then Input System only. Code guarded with #if ENABLE_INPUT_SYSTEM / ENABLE_LEGACY_INPUT_MANAGER (auto pipeline templates already do this).
- One .inputactions asset: maps Gameplay / UI / Menu. Actions: Move (Vector2), Look (Vector2), Jump, Interact, Fire, Aim, Reload, Pause, Submit, Cancel. Bind keyboard+mouse AND gamepad from day one.
- PlayerInput component (Invoke C# events) or generated C# wrapper class; switch maps on pause.
- Rebinding: InputActionRebindingExtensions.PerformInteractiveRebinding, save overrides with SaveBindingOverridesAsJson to settings; reset button.
- Glyphs: show device-correct prompts (keyboard vs Xbox vs PlayStation vs Steam Deck) from the current control scheme; one helper for all key hints.
- Steam Input: works via gamepad API; Steam Deck default layout must cover every action (steam-deck-verified).
- Accessibility: hold-to-toggle options, sensitivity + invert Y, dead zones, no required simultaneous presses.
- Mobile: on-screen stick + buttons (mobile-touch-ui).
