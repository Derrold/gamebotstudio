using UnityEngine;
/// <summary>Puzzle pad: glows when a PushBlock sits on it; all pads filled = solved.</summary>
public class PressurePad : MonoBehaviour
{
    public bool lit; Renderer r;
    void Start() { r = GetComponent<Renderer>(); }
    void Update()
    {
        bool on = false;
        foreach (var c in Physics.OverlapBox(transform.position + Vector3.up * 0.8f, new Vector3(0.6f, 0.6f, 0.6f))) if (c.GetComponent<PushBlock>()) on = true;
        if (on != lit)
        {
            lit = on; GenreState.Pads += on ? 1 : -1; if (on) AchievementSystem.Unlock("pad_first");
            if (r) r.material.color = on ? Color.green : new Color(0.2f, 0.5f, 1f);
            if (GenreState.IsPuzzle && GenreState.Pads >= GenreState.PadsTotal && GenreState.PadsTotal > 0) { AchievementSystem.Unlock("solved"); GenreState.Win(); }
        }
    }
}
