# Quests, objectives, dialogue, achievements
Sources: https://docs.unity3d.com/Manual/class-ScriptableObject.html | https://github.com/inkle/ink (ink narrative scripting, MIT) | https://yarnspinner.dev/ | https://partner.steamgames.com/doc/features/achievements

## Objective system (optional, light)
- Objective data: id, title, description, conditions (event + count), reward, prerequisites. Event bus: OnHarvest(species, score), OnShot(hit,organ), OnDayEnd, OnPurchase.

## Hunting-season goals
- Season goals per Cal phase: 'Tag a buck during archery', 'Pattern a buck with trail cams', 'Ethical shot: heart/lung only', 'Recover a deer by blood trail'.
- map each to a Steam achievement API name later (steamworks-sdk-integration.md).

## Dialogue
- Small: JSON/ScriptableObject lines with speaker + choices. Bigger: ink or Yarn Spinner (both have Unity integrations). Localize strings via Unity Localization package.
- Warden/NPC barks: short context lines, voice optional.

## Achievements design
- 20-50 achievements; mix of progression, skill, exploration, fun; avoid grindy 'kill 10,000'; no missable-only without warning; icons 256x256 (locked/unlocked).
