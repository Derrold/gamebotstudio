# GDD and tone bible

Tags: gdd narrative writing
Saved: 2026-10-25T20:29:36

GDD.md: pitch, 3 pillars, core/session/meta loops, mechanics->scripts, content counts, UX flow, art/audio, tech+perf targets, milestones, risks; tone bible with sample lines; strings in Localization tables. Playbook narrative-writing-gdd.
