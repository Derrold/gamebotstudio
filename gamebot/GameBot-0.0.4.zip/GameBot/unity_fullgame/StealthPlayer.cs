using UnityEngine;
/// <summary>Stealth player: crouch (C/Ctrl) slows you and lowers your profile; detection decays when unseen; bushes give cover.</summary>
public class StealthPlayer : MonoBehaviour
{
    public static Vector3 Spawn; GamePlayer gp; Transform cam; float baseSpeed, camY; bool ghost = true;
    void Start() { Spawn = transform.position; gp = GetComponent<GamePlayer>(); baseSpeed = gp ? gp.speed : 6; var c = GetComponentInChildren<Camera>(); if (c) { cam = c.transform; camY = cam.localPosition.y; } }
    void Update()
    {
        if (GameState.Won || GameState.Lost || PauseMenu.IsPaused || MainMenuUI.InMenu) return;
        GenreState.Crouched = Input.GetKey(KeyCode.C) || Input.GetKey(KeyCode.LeftControl);
        if (gp) gp.speed = GenreState.Crouched ? baseSpeed * 0.45f : baseSpeed * 0.8f;
        if (cam) { var lp = cam.localPosition; lp.y = Mathf.Lerp(lp.y, GenreState.Crouched ? camY - 0.7f : camY, Time.deltaTime * 8f); cam.localPosition = lp; }
        GenreState.Detection = Mathf.Max(0, GenreState.Detection - Time.deltaTime * 0.25f);
        if (GenreState.Alarms > 0) ghost = false;
        if (GenreState.Items >= GenreState.ItemsTotal && ghost) AchievementSystem.Unlock("ghost");
    }
}
