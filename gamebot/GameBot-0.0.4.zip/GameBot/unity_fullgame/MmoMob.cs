using UnityEngine;
/// <summary>MMORPG mob: aggro, chase with leash, melee, respawn timer, XP + gold + quest credit. Boss = Ancient Treant.</summary>
public class MmoMob : MonoBehaviour
{
    public string kind = "wolf"; public int maxHp = 40, dmg = 6, xp = 35, gold = 4; public float aggro = 9f, speed = 3.4f, respawn = 14f;
    int hp; Vector3 home; Transform p; float nextHit; float deadUntil = -1; Renderer[] rs; Collider[] cs;
    public bool Alive => deadUntil < 0;
    void Start() { hp = maxHp; home = transform.position; var g = GameObject.FindGameObjectWithTag("Player"); if (g) p = g.transform; rs = GetComponentsInChildren<Renderer>(); cs = GetComponentsInChildren<Collider>(); }
    public void Hit(int d)
    {
        if (!Alive) return; hp -= d; if (hp > 0) return;
        GenreState.AddXp(xp); GenreState.Gold += gold; GenreState.Kills++; AchievementSystem.Unlock("first_kill");
        if (kind == "wolf") GenreState.WolvesKilled++; if (kind == "boss") { GenreState.BossDown = true; AchievementSystem.Unlock("treant"); }
        GenreState.MmoQuestCheck(); GameHUD.Flash("+" + xp + " XP  +" + gold + " gold");
        if (kind == "boss") { gameObject.SetActive(false); return; }
        deadUntil = Time.time + respawn; Show(false);
    }
    void Show(bool on) { foreach (var r in rs) if (r && r.name != "SelectRing") r.enabled = on; foreach (var c in cs) if (c) c.enabled = on; }
    void Update()
    {
        if (deadUntil > 0) { if (Time.time >= deadUntil) { deadUntil = -1; hp = maxHp; transform.position = home; Show(true); } return; }
        if (!p || GameState.Won || GameState.Lost || PauseMenu.IsPaused || MainMenuUI.InMenu) return;
        Vector3 to = p.position - transform.position; to.y = 0; float dh = (transform.position - home).magnitude;
        if (to.magnitude < aggro && dh < aggro * 2.5f)
        {
            transform.rotation = Quaternion.LookRotation(to);
            if (to.magnitude > (kind == "boss" ? 3f : 1.6f)) transform.position += to.normalized * speed * Time.deltaTime;
            else if (Time.time >= nextHit) { nextHit = Time.time + (kind == "boss" ? 1.6f : 1.1f); GbCombat.HurtPlayer(dmg); }
        }
        else if (dh > 0.5f) transform.position = Vector3.MoveTowards(transform.position, home, speed * Time.deltaTime);
    }
    void OnGUI()
    {
        if (MainMenuUI.InMenu || !Alive) return; var cam = Camera.main; if (!cam) return; var sp = cam.WorldToScreenPoint(transform.position + Vector3.up * (kind == "boss" ? 6f : 1.8f)); if (sp.z < 0 || sp.z > 40) return;
        GUI.Label(new Rect(sp.x - 60, Screen.height - sp.y - 18, 120, 20), kind == "boss" ? "Ancient Treant" : kind == "wolf" ? "Grey Wolf" : "Wild Boar", new GUIStyle(GUI.skin.label) { alignment = TextAnchor.MiddleCenter });
        GUI.color = Color.black; GUI.DrawTexture(new Rect(sp.x - 30, Screen.height - sp.y, 60, 6), Texture2D.whiteTexture); GUI.color = Color.red; GUI.DrawTexture(new Rect(sp.x - 29, Screen.height - sp.y + 1, 58f * hp / maxHp, 4), Texture2D.whiteTexture); GUI.color = Color.white;
    }
}
