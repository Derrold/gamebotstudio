"""Auto-pick Game Bot edition + GPUs for fastest productive local LLM."""
from __future__ import annotations

import json
import os
import re
import subprocess
from pathlib import Path

ROOT = Path(__file__).resolve().parent
EDITIONS_DIR = ROOT / "config" / "editions"
STATE_PATH = ROOT / "config" / "gpu_auto.json"

# Approx VRAM needed (MiB free) to run each edition comfortably
NEED_FREE_MIB = {
    "12gb": 9500,  # qwen2.5:14b ~9GB + headroom
    "8gb": 5500,   # 7B + larger ctx
}


def _nvidia_gpus() -> list[dict]:
    try:
        out = subprocess.check_output(
            [
                "nvidia-smi",
                "--query-gpu=index,name,memory.total,memory.free",
                "--format=csv,noheader,nounits",
            ],
            text=True,
            timeout=15,
            stderr=subprocess.DEVNULL,
         creationflags=0x08000000)
    except Exception:
        return []
    gpus = []
    for line in out.strip().splitlines():
        parts = [p.strip() for p in line.split(",")]
        if len(parts) < 4:
            continue
        try:
            gpus.append(
                {
                    "index": int(parts[0]),
                    "name": parts[1],
                    "total_mib": float(parts[2]),
                    "free_mib": float(parts[3]),
                }
            )
        except ValueError:
            continue
    return gpus


def _best_edition_for_free(free_mib: float) -> str:
    if free_mib >= NEED_FREE_MIB["12gb"]:
        return "12gb"
    # 8GB is the minimum edition (6GB/4GB retired); below 8GB free it may spill to RAM / be slow
    return "8gb"


def choose_gpus_and_edition(gpus: list[dict] | None = None) -> dict:
    """Pick edition + which GPU indices give the fastest useful run.

    Rules:
    1. Prefer a SINGLE GPU that can run the best edition (lower latency than multi-GPU split).
    2. If no single GPU has enough free VRAM for 12gb but two+ combined do, use those GPUs for 12gb.
    3. Otherwise use the single GPU with the most free VRAM and the best edition it can hold.
    4. Never prefer a nearly-full big card over a freer smaller card that fits the same (or better) edition.
    """
    gpus = list(gpus if gpus is not None else _nvidia_gpus())
    if not gpus:
        return {
            "edition": "8gb",
            "cuda_visible": "",
            "reason": "no nvidia-smi GPUs â€” default 8gb (CPU/unknown)",
            "gpus": [],
            "mode": "unknown",
        }

    # Rank single-GPU options by (edition rank, free_mib)
    rank = {"12gb": 3, "8gb": 2}
    singles = []
    for g in gpus:
        ed = _best_edition_for_free(g["free_mib"])
        singles.append((rank[ed], g["free_mib"], g, ed))
    singles.sort(reverse=True)
    best_rank, best_free, best_g, best_ed = singles[0]

    total_free = sum(g["free_mib"] for g in gpus)
    # Multi-GPU only if it unlocks a BETTER edition than the best single GPU
    if best_rank < rank["12gb"] and total_free >= NEED_FREE_MIB["12gb"] and len(gpus) >= 2:
        # Use all GPUs that contribute meaningful free (>512 MiB)
        idxs = [str(g["index"]) for g in gpus if g["free_mib"] >= 512]
        if len(idxs) >= 2:
            return {
                "edition": "12gb",
                "cuda_visible": ",".join(idxs),
                "reason": f"multi-GPU for 14B: free totals {total_free:.0f} MiB across {idxs}",
                "gpus": gpus,
                "mode": "multi",
            }

    return {
        "edition": best_ed,
        "cuda_visible": str(best_g["index"]),
        "reason": (
            f"single GPU {best_g['index']} ({best_g['name']}) "
            f"free {best_g['free_mib']:.0f} MiB â†’ {best_ed}"
        ),
        "gpus": gpus,
        "mode": "single",
    }


def _drop_stale_cuda_visible(gpus: list[dict]) -> str:
    """A CUDA_VISIBLE_DEVICES pointing at GPU indices that don't exist hides every GPU and silently
    drops Ollama/llama.cpp to CPU. Remove such stale values so normal auto-detection works."""
    cur = os.environ.get("CUDA_VISIBLE_DEVICES")
    if cur is None or not gpus:
        return ""
    have = {str(g["index"]) for g in gpus}
    want = [x.strip() for x in cur.split(",") if x.strip()]
    if not want or any(x not in have for x in want if x.isdigit()):
        os.environ.pop("CUDA_VISIBLE_DEVICES", None)
        return f"dropped stale CUDA_VISIBLE_DEVICES={cur!r} (GPUs present: {sorted(have)})"
    return ""


def apply_auto_gpu() -> dict:
    """Detect GPUs, set env for edition + CUDA_VISIBLE_DEVICES, persist state."""
    _stale = _drop_stale_cuda_visible(_nvidia_gpus())
    # Allow explicit override for debugging only
    if os.environ.get("GAMEBOT_EDITION_LOCK"):
        eid = os.environ["GAMEBOT_EDITION_LOCK"].strip().lower()
        if eid not in ("8gb", "12gb"):
            # LOCK=1 style flag: honour GAMEBOT_EDITION, default 12gb
            eid = (os.environ.get("GAMEBOT_EDITION") or "12gb").strip().lower()
            if eid not in ("8gb", "12gb"):
                eid = "12gb" if eid.startswith("12") else "8gb"
        decision = {
            "edition": eid,
            "cuda_visible": os.environ.get("CUDA_VISIBLE_DEVICES", ""),
            "reason": f"locked by GAMEBOT_EDITION_LOCK={eid}",
            "gpus": _nvidia_gpus(),
            "mode": "locked",
        }
    else:
        decision = choose_gpus_and_edition()

    if _stale:
        decision["stale_fix"] = _stale
    os.environ["GAMEBOT_EDITION"] = decision["edition"]
    # Clear any stale model override so editions.load_edition wins
    if decision.get("cuda_visible") != "":
        os.environ["CUDA_VISIBLE_DEVICES"] = decision["cuda_visible"]
    # If empty cuda_visible (unknown), leave CUDA_VISIBLE_DEVICES unset

    try:
        STATE_PATH.parent.mkdir(parents=True, exist_ok=True)
        STATE_PATH.write_text(json.dumps(decision, indent=2, default=str), encoding="utf-8")
    except Exception:
        pass
    return decision


def install_edition() -> str:
    """Model to download for this PC, from TOTAL VRAM (same rule as the installer). '' = no NVIDIA GPU."""
    gpus = _nvidia_gpus()
    if not gpus:
        return ""
    for g in gpus:
        g["free_mib"] = g["total_mib"]
    return choose_gpus_and_edition(gpus)["edition"]


if __name__ == "__main__":
    print(json.dumps(apply_auto_gpu(), indent=2, default=str))