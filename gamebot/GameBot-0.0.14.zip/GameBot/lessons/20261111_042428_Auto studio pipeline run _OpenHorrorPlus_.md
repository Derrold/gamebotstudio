# Auto studio pipeline run (OpenHorrorPlus)

Tags: auto studio pipeline
Saved: 2026-11-11T04:24:28

run_auto_game_pipeline created 33 files under C:\Users\ExtremeHybrid\Documents\GameProjects\OpenHorrorPlus and UNITY 6000.6.5f1: background job started -> create OpenHorrorPlusUnity -> Horror game (gameplay template: horror; menu, settings, achievements, owned assets) ->. Next: check Builds\auto_unity_status.txt, then work TaskBoard 'Auto next actions' with tools.
