using UnityEngine;

public class GameHUD : MonoBehaviour
{
    float introUntil;
    static string flashMsg; static float flashUntil;
    public static void Flash(string m) { flashMsg = m; flashUntil = Time.unscaledTime + 3f; }
    void Start()
    {
        GameSettings.LoadAndApply();
        AchievementSystem.Load();
        MainMenuUI.InMenu = false;
        if (!GameState.IntroShown) { introUntil = Time.unscaledTime + 5f; GameState.IntroShown = true; }
    }
    static void Bar(Rect r, float v, Color c) { GUI.color = Color.black; GUI.DrawTexture(r, Texture2D.whiteTexture); GUI.color = c; GUI.DrawTexture(new Rect(r.x + 2, r.y + 2, (r.width - 4) * Mathf.Clamp01(v), r.height - 4), Texture2D.whiteTexture); GUI.color = Color.white; }
    static string ExtraLine()
    {
        if (GenreState.IsAction) return "Health: " + GenreState.Health + "   Lives: " + GameState.Lives + "   Raiders: " + GenreState.Kills + "/" + GenreState.EnemiesTotal + "   Best combo: x" + GenreState.Combo;
        if (GenreState.IsFighting) return "Round " + GenreState.Round + "   You " + GenreState.P1Wins + " : " + GenreState.P2Wins + " Rival";
        if (GenreState.IsStrategy) return "Quartz: " + GenreState.Quartz + "   Points: " + GenreState.PointsOwned + "/" + GenreState.PointsTotal + "   Units trained: " + GenreState.Units + "   Raid " + GenreState.WaveNo + " (next in " + Mathf.Max(0, Mathf.CeilToInt(GenreState.NextWave - Time.timeSinceLevelLoad)) + "s)";
        if (GenreState.IsMoba) return "Hero Lv " + GenreState.Level + "   XP " + GenreState.Xp + "/" + (GenreState.Level * 100) + "   HP " + GenreState.Health + "/" + GenreState.MaxHealth + "   Towers down " + GenreState.TowersDown + "/" + GenreState.EnemyTowers;
        if (GenreState.IsSports) return "SCORE  " + GenreState.ScoreUs + " : " + GenreState.ScoreThem + "   Time " + Mathf.CeilToInt(GenreState.MatchTime) + "s";
        if (GenreState.IsSandbox) return "Blocks: " + GenreState.Blocks + "   Placed: " + GenreState.Placed + "   Height: " + GenreState.MaxHeight + "/10   Material " + (GenreState.BlockType + 1) + "   Lives: " + GameState.Lives;
        if (GenreState.IsStealth) return "Intel: " + GenreState.Items + "/" + GenreState.ItemsTotal + "   Alarms: " + GenreState.Alarms + "/3" + (GenreState.Crouched ? "   [CROUCHED]" : "") + (GenreState.InCover ? "   [IN COVER]" : "");
        if (GenreState.IsBR) return "HP " + GenreState.Health + "/" + GenreState.MaxHealth + "   Alive: " + (GenreState.Alive + 1) + "   Kills: " + GenreState.Kills + "   Storm r=" + Mathf.RoundToInt(GenreState.StormRadius) + "m phase " + (GenreState.Phase + 1);
        if (GenreState.IsMmo) return "Level " + GenreState.Level + "   XP " + GenreState.Xp + "/" + (GenreState.Level * 100) + "   Quests " + GenreState.QuestsDone + "/" + GenreState.QuestsTotal + "   Lives: " + GameState.Lives;
        return "";
    }
    void OnGUI()
    {
        var s = new GUIStyle(GUI.skin.label) { fontSize = 22 };
        var big = new GUIStyle(GUI.skin.label) { fontSize = 34, fontStyle = FontStyle.Bold, alignment = TextAnchor.LowerRight };
        if (GenreState.IsFps)
        {
            GUI.Label(new Rect(16, 12, 900, 30), "Health: " + GenreState.Health + "   Lives: " + GameState.Lives + "   Kills: " + GenreState.Kills + "/" + GenreState.EnemiesTotal, s);
            GUI.Label(new Rect(Screen.width - 340, Screen.height - 70, 320, 50), (GunController.Reloading ? "RELOADING " : "") + GenreState.Ammo + " / " + GenreState.Reserve, big);
            // crosshair
            float cx = Screen.width / 2f, cy = Screen.height / 2f;
            GUI.DrawTexture(new Rect(cx - 10, cy - 1, 20, 2), Texture2D.whiteTexture);
            GUI.DrawTexture(new Rect(cx - 1, cy - 10, 2, 20), Texture2D.whiteTexture);
        }
        else if (GenreState.IsRacing)
        {
            GUI.Label(new Rect(16, 12, 900, 30), "Lap: " + Mathf.Min(GenreState.Lap + 1, GenreState.TotalLaps) + "/" + GenreState.TotalLaps +
                "   Time: " + GenreState.RaceTime.ToString("0.00") + "s   Best lap: " + (GenreState.BestLap < 0 ? "--" : GenreState.BestLap.ToString("0.00") + "s"), s);
            GUI.Label(new Rect(Screen.width - 340, Screen.height - 70, 320, 50), Mathf.RoundToInt(GenreState.SpeedKmh) + " km/h", big);
        }
        else if (GenreState.Family != "platformer")
        {
            string m = GenreState.Family, line = "Lives: " + GameState.Lives + "   ";
            if (m == "horror") line += "Battery: " + Mathf.RoundToInt(GenreState.Battery) + "%" + (FlashlightController.On ? "" : " (off)") + "   Fuses: " + GenreState.Items + "/" + GenreState.ItemsTotal;
            if (m == "rpg") line += "Level " + GenreState.Level + "   XP " + GenreState.Xp + "/" + (GenreState.Level * 100) + "   Relics: " + GenreState.Items + "/" + GenreState.ItemsTotal;
            if (m == "puzzle") line += "Pads: " + GenreState.Pads + "/" + GenreState.PadsTotal + "   (R = reset room)";
            if (m == "survival") line += "Hunger: " + Mathf.RoundToInt(GenreState.Hunger) + "   Wood: " + GenreState.Wood + "   Food: " + GenreState.Food + "   Dawn in " + Mathf.CeilToInt(GenreState.TimeLeft) + "s";
            if (m == "adventure") line += "Key: " + (GenreState.HasKey ? "YES" : "no") + "   Treasures: " + GenreState.Items + (ObjectiveMarker.Target ? "   Marker: " + Mathf.RoundToInt(Vector3.Distance(Camera.main ? Camera.main.transform.position : Vector3.zero, ObjectiveMarker.Target.position)) + "m" : "");
            if (m == "sim") line = "Cash: $" + GenreState.Cash + " / $" + GenreState.CashGoal + "   Stock: " + GenreState.Stock + "   Sales: " + GenreState.Sales + (ShopCounter.Serving ? "   [SERVING]" : "");
            if (m == "roguelike")
            {
                line = "PERMADEATH   Wave " + GenreState.Wave + "/" + GenreState.WavesTotal + "   Hostiles: " + GenreState.Alive + "   Health: " + GenreState.Health + "   Kills: " + GenreState.Kills;
                GUI.Label(new Rect(Screen.width - 340, Screen.height - 70, 320, 50), (GunController.Reloading ? "RELOADING " : "") + GenreState.Ammo + " / " + GenreState.Reserve, big);
                float cx = Screen.width / 2f, cy = Screen.height / 2f;
                GUI.DrawTexture(new Rect(cx - 10, cy - 1, 20, 2), Texture2D.whiteTexture); GUI.DrawTexture(new Rect(cx - 1, cy - 10, 2, 20), Texture2D.whiteTexture);
            }
            if (GenreState.IsExtra) line = ExtraLine();
            GUI.Label(new Rect(16, 12, 1200, 30), line, s);
            if (GenreState.IsBR || GenreState.IsSandbox) { float cx = Screen.width / 2f, cy = Screen.height / 2f; GUI.DrawTexture(new Rect(cx - 10, cy - 1, 20, 2), Texture2D.whiteTexture); GUI.DrawTexture(new Rect(cx - 1, cy - 10, 2, 20), Texture2D.whiteTexture); }
            if (GenreState.IsBR) GUI.Label(new Rect(Screen.width - 340, Screen.height - 70, 320, 50), (GunController.Reloading ? "RELOADING " : "") + GenreState.Ammo + " / " + GenreState.Reserve, big);
            if (GenreState.IsFighting) { Bar(new Rect(40, 80, Screen.width / 2f - 80, 22), GenreState.P1Hp / 100f, new Color(0.2f, 0.8f, 1f)); Bar(new Rect(Screen.width / 2f + 40, 80, Screen.width / 2f - 80, 22), GenreState.P2Hp / 100f, new Color(1f, 0.3f, 0.2f)); GUI.Label(new Rect(Screen.width / 2f - 30, 74, 60, 34), Mathf.CeilToInt(GenreState.RoundTime).ToString(), new GUIStyle(big) { alignment = TextAnchor.MiddleCenter }); }
            if (GenreState.IsStealth) Bar(new Rect(Screen.width / 2f - 150, 80, 300, 16), GenreState.Detection, Color.Lerp(Color.yellow, Color.red, GenreState.Detection));
            if (m == "horror" && GenreState.Fear > 0.05f) { var old = GUI.color; GUI.color = new Color(0.6f, 0, 0, GenreState.Fear * 0.45f); GUI.DrawTexture(new Rect(0, 0, Screen.width, Screen.height), Texture2D.whiteTexture); GUI.color = old; }
        }
        else
            GUI.Label(new Rect(16, 12, 700, 30), "Lives: " + GameState.Lives + "   Coins: " + GameState.Coins + "   Deaths: " + GameState.Deaths, s);
        GUI.Label(new Rect(16, 42, 1100, 30), GenreState.Objective(), s);
        if (flashMsg != null && Time.unscaledTime < flashUntil)
            GUI.Box(new Rect(Screen.width/2 - 300, Screen.height - 140, 600, 44), flashMsg, new GUIStyle(GUI.skin.box) { fontSize = 20, alignment = TextAnchor.MiddleCenter });
        var toast = AchievementSystem.Toast;
        if (toast != null)
        {
            var t = new GUIStyle(GUI.skin.box) { fontSize = 20, alignment = TextAnchor.MiddleCenter };
            GUI.Box(new Rect(Screen.width/2 - 220, 80, 440, 48), toast, t);
        }
        if (Time.unscaledTime < introUntil)
        {
            var box = new GUIStyle(GUI.skin.box) { fontSize = 20, alignment = TextAnchor.MiddleCenter };
            GUI.Box(new Rect(Screen.width*0.15f, Screen.height*0.2f, Screen.width*0.7f, 260), GenreState.Story() + "\n" + GameSettings.KeyPause + " = pause", box);
        }
    }
}
