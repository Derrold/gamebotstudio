"""New-game intake for Game Bot: ask engine / title / genre / loop / story / goals /
setting / art-tone / template / desktop icon BEFORE anything is created, then
progressive asset questions (one at a time) after the build.
Spine: playbooks/new-game-intake.md. Top-19 genres: r30_genre_spec.ORDER."""
from __future__ import annotations

import re

from auto_studio import find_unity, find_unreal, wants_auto_game
from gamedev_core import _trim_name, _safe_name

_STATE: dict = {}
_LAST: dict = {"st": None}
MARK = "Intake step"

# Official top-19 from r30_genre_spec.ORDER (ship/train genres; not full 25).
TOP19 = [
    "action", "adventure", "rpg", "shooter", "strategy", "simulation", "sports",
    "racing", "fighting", "horror", "platformer", "puzzle", "open_world",
    "survival", "sandbox", "stealth", "battle_royale", "moba", "mmorpg",
]
TOP19_LABELS = {
    "action": "Action",
    "adventure": "Adventure",
    "rpg": "RPG",
    "shooter": "Shooter / FPS",
    "strategy": "Strategy",
    "simulation": "Simulation",
    "sports": "Sports",
    "racing": "Racing",
    "fighting": "Fighting",
    "horror": "Horror",
    "platformer": "Platformer",
    "puzzle": "Puzzle",
    "open_world": "Open World",
    "survival": "Survival",
    "sandbox": "Sandbox",
    "stealth": "Stealth",
    "battle_royale": "Battle Royale",
    "moba": "MOBA",
    "mmorpg": "MMORPG",
}
# alias -> official id
GENRE_ALIAS = {
    "action": "action", "hack and slash": "action", "brawler": "action",
    "adventure": "adventure", "narrative": "adventure",
    "rpg": "rpg", "role playing": "rpg", "role-playing": "rpg", "jrpg": "rpg", "arpg": "rpg",
    "shooter": "shooter", "fps": "shooter", "tps": "shooter", "first person shooter": "shooter",
    "third person shooter": "shooter", "gun": "shooter",
    "strategy": "strategy", "rts": "strategy", "tactics": "strategy", "4x": "strategy",
    "simulation": "simulation", "sim": "simulation", "simulator": "simulation",
    "farming": "simulation", "management": "simulation", "tycoon": "simulation",
    "sports": "sports", "soccer": "sports", "football": "sports", "basketball": "sports",
    "racing": "racing", "racer": "racing", "kart": "racing", "driving": "racing", "drift": "racing",
    "fighting": "fighting", "fighter": "fighting", "beat em up": "fighting", "brawler fight": "fighting",
    "horror": "horror", "scary": "horror", "survival horror": "horror",
    "platformer": "platformer", "platform": "platformer", "side scroller": "platformer",
    "puzzle": "puzzle", "puzzler": "puzzle",
    "open_world": "open_world", "open world": "open_world", "openworld": "open_world",
    "survival": "survival", "crafting": "survival",
    "sandbox": "sandbox", "voxel": "sandbox", "minecraft": "sandbox", "creative": "sandbox",
    "stealth": "stealth", "sneak": "stealth", "assassin": "stealth", "heist": "stealth",
    "battle_royale": "battle_royale", "battle royale": "battle_royale", "br": "battle_royale",
    "fortnite": "battle_royale", "pubg": "battle_royale",
    "moba": "moba", "league": "moba", "dota": "moba",
    "mmorpg": "mmorpg", "mmo": "mmorpg",
}

_JUNK_TITLE = frozenset({
    "new", "a", "an", "the", "my", "small", "big", "tiny", "little", "cool", "fun",
    "3d", "2d", "game", "games", "prototype", "slice", "vertical", "simple", "basic",
    "quick", "test", "demo", "me", "another", "some", "one", "this", "that",
    *TOP19, "fps", "tps", "sim", "simulator", "racer", "puzzler", "platform",
    "open", "world", "battle", "royale", "role", "playing",
})

# Words that alone are not a title ("a game", "new one"). Genre words are NOT here: at the title step
# "Horror Racer" / "Open World Plus" / "Survival" are real titles.
_FILLER_TITLE = frozenset({
    "new", "a", "an", "the", "my", "game", "games", "prototype", "test", "demo", "me", "another", "some",
    "one", "this", "that", "it", "idk", "untitled", "name", "title", "called",
})


def _is_filler_title(nm: str) -> bool:
    if (nm or "").strip() == "NewGame":
        return True
    parts = re.sub(r"[^a-z0-9]+", " ", (nm or "").lower()).split()
    return (not parts) or all(p in _FILLER_TITLE for p in parts)


_DEFAULT_ASSETS = [
    ("hero", "the main character"),
    ("environment", "the environment kit (ground, walls, props)"),
    ("pickups", "pickups / props"),
    ("enemies", "enemies or NPCs"),
    ("ui", "the UI style (menus, HUD)"),
    ("audio", "music + sound effects"),
]

ASSETS = {
    "action": [
        ("hero", "the player fighter / hero look"),
        ("weapons", "weapons / melee kit"),
        ("enemies", "enemy waves / bosses"),
        ("arena", "arena / level kit"),
        ("vfx", "hit / combo VFX"),
        ("audio", "combat music + SFX"),
    ],
    "adventure": [
        ("hero", "the adventurer character"),
        ("environment", "overworld / path kit"),
        ("landmarks", "landmarks / interactables"),
        ("npcs", "story NPCs"),
        ("ui", "adventure HUD / journal"),
        ("audio", "explore music + SFX"),
    ],
    "rpg": [
        ("hero", "the hero character"),
        ("environment", "town / dungeon kit"),
        ("enemies", "enemies / monsters"),
        ("items", "weapons / loot icons"),
        ("ui", "RPG menus / inventory HUD"),
        ("audio", "music + combat SFX"),
    ],
    "shooter": [
        ("characters", "characters - player arms/body and enemy soldiers or creatures"),
        ("weapons", "weapons (pistol, rifle, shotgun, melee...)"),
        ("environment", "the environment kit (walls, crates, cover, doors)"),
        ("vfx", "VFX (muzzle flash, impacts, explosions)"),
        ("audio", "audio (gunshots, footsteps, music)"),
    ],
    "strategy": [
        ("units", "unit / troop look"),
        ("buildings", "base / building kit"),
        ("map", "map / terrain kit"),
        ("ui", "RTS / tactics UI"),
        ("audio", "strategy music + SFX"),
    ],
    "simulation": [
        ("building", "building / shop / workplace kit"),
        ("furniture", "props / tools / furniture"),
        ("npcs", "customers / NPCs / workers"),
        ("ui", "management UI"),
        ("audio", "ambience + work SFX"),
    ],
    "sports": [
        ("athletes", "player / athlete look"),
        ("field", "field / court / stadium kit"),
        ("ball", "ball / puck / equipment"),
        ("ui", "scoreboard / sports HUD"),
        ("audio", "crowd + whistle + music"),
    ],
    "racing": [
        ("vehicle", "the player vehicle (car, bike, hovercraft)"),
        ("track", "the track / road kit"),
        ("props", "trackside props (barriers, signs, trees)"),
        ("ui", "racing HUD (speed, lap, place)"),
        ("audio", "engine + music"),
    ],
    "fighting": [
        ("fighters", "fighter characters"),
        ("stage", "arena / stage kit"),
        ("vfx", "hit sparks / supers VFX"),
        ("ui", "health bars / round UI"),
        ("audio", "fight music + impact SFX"),
    ],
    "horror": [
        ("player", "the player / survivor look"),
        ("environment", "the dark environment kit"),
        ("creature", "the threat / creature"),
        ("props", "horror props (lights, doors, notes)"),
        ("audio", "ambience + stingers"),
    ],
    "platformer": [
        ("player", "the player character (e.g. robot, fox, knight, blob)"),
        ("tileset", "the platform / tileset look (floating islands, grassy blocks, sci-fi panels, candy)"),
        ("collectible", "collectibles (coins, gems, stars, feathers)"),
        ("hazard", "enemies or hazards (spikes, slimes, saw blades, birds)"),
        ("sky", "the sky / background mood (sunny, sunset, night, space)"),
        ("audio", "music + jump / land / collect sounds"),
    ],
    "puzzle": [
        ("blocks", "puzzle blocks / pieces look"),
        ("board", "board / room kit"),
        ("ui", "puzzle UI"),
        ("audio", "solve / fail sounds"),
    ],
    "open_world": [
        ("hero", "the player character"),
        ("world", "world biomes / terrain kit"),
        ("landmarks", "points of interest / outposts"),
        ("vehicles", "vehicles / traversal"),
        ("npcs", "world NPCs / wildlife"),
        ("ui", "map / compass HUD"),
        ("audio", "overworld music + ambience"),
    ],
    "survival": [
        ("player", "the survivor character"),
        ("environment", "camp / wilderness kit"),
        ("resources", "gatherable resources"),
        ("threats", "threats / wildlife"),
        ("ui", "survival HUD (hunger/health)"),
        ("audio", "ambience + craft SFX"),
    ],
    "sandbox": [
        ("avatar", "the player avatar"),
        ("blocks", "build blocks / materials"),
        ("tools", "build / dig tools"),
        ("world", "world / biome look"),
        ("ui", "creative / inventory UI"),
        ("audio", "build + world ambience"),
    ],
    "stealth": [
        ("agent", "the infiltrator / agent look"),
        ("environment", "facility / city stealth kit"),
        ("guards", "guards / cameras"),
        ("gadgets", "gadgets / distractions"),
        ("ui", "detection / suspicion HUD"),
        ("audio", "stealth ambience + alerts"),
    ],
    "battle_royale": [
        ("characters", "playable character / skins"),
        ("weapons", "loot weapons"),
        ("map", "BR map / POIs"),
        ("vehicles", "vehicles / mobility"),
        ("ui", "zone / squad HUD"),
        ("audio", "combat music + zone SFX"),
    ],
    "moba": [
        ("heroes", "hero roster look"),
        ("lane", "lane / tower / jungle kit"),
        ("minions", "minions / creeps"),
        ("ui", "ability bar / shop UI"),
        ("audio", "match music + ability SFX"),
    ],
    "mmorpg": [
        ("hero", "player character / classes"),
        ("zones", "zone / city / dungeon kit"),
        ("mobs", "mobs / bosses"),
        ("gear", "gear / loot icons"),
        ("ui", "quest / bag / chat UI"),
        ("audio", "zone music + combat SFX"),
    ],
}
ASSETS["fps"] = ASSETS["shooter"]
ASSETS["sim"] = ASSETS["simulation"]
ASSETS["simulator"] = ASSETS["simulation"]
ASSETS["management"] = ASSETS["simulation"]
ASSETS["default"] = _DEFAULT_ASSETS

FALLBACKS = ("Free CC0 fallbacks I can use: Kenney.nl (kits for most genres), Quaternius (characters/animals), "
             "Poly Haven + ambientCG (textures, HDRI skies), OpenGameArt (check each license), Mixamo (character animations). "
             "Every pick gets an ATTRIBUTION.md row.")

_NEW_RE = re.compile(
    r"\b(make|build|create|start|prototype|design)\b[^.?!]{0,60}\b("
    r"game|platformer|shooter|fps|rpg|racer|racing game|puzzler|puzzle game|"
    r"roguelike|metroidvania|horror game|survival game|sim|simulator|"
    r"action game|adventure game|strategy game|sports game|fighting game|"
    r"sandbox|stealth|moba|mmorpg|battle royale|open world"
    r")\b",
    re.I,
)


def is_new_game(t):
    t = (t or "").strip()
    if not t or re.match(r"^\s*(how|what|which|why|when|where|explain|tell me|should)\b", t, re.I):
        return False
    return bool(wants_auto_game(t) or _NEW_RE.search(t))


def _key(messages):
    return id(messages[0]) if messages else 0


def _engines():
    u, r = None, None
    try:
        u = find_unity()
    except Exception:
        pass
    try:
        r = find_unreal()
    except Exception:
        pass
    return u, r


def _parse_engine(t):
    t = t.lower()
    if re.search(r"\bunreal\b|\bue ?5\b|\bue\b", t):
        return "Unreal"
    if re.search(r"\bunity\b", t):
        return "Unity"
    return None


def _is_junk_title(nm: str) -> bool:
    if not nm or nm == "NewGame":
        return True
    parts = re.sub(r"[^a-z0-9]+", " ", nm.lower()).split()
    if not parts:
        return True
    return all(p in _JUNK_TITLE for p in parts)


def _explicit_title(text: str):
    """Only accept a title the user clearly said called/named/titled X."""
    m = re.search(r"(?:called|named|titled)\s+[\"']?([A-Za-z0-9 _-]{2,40})", text or "", re.I)
    if not m:
        return None
    nm = _trim_name(m.group(1))
    if _is_filler_title(nm):
        return None
    return nm


def _genre_hits(t):
    tl = (t or "").strip().lower()
    if not tl:
        return []
    found = []
    taken = []
    for alias in sorted(GENRE_ALIAS.keys(), key=len, reverse=True):
        for m in re.finditer(r"\b" + re.escape(alias) + r"\b", tl):
            if any(a <= m.start() < b for a, b in taken):
                continue  # "survival horror" already claimed these chars
            taken.append((m.start(), m.end()))
            found.append((m.start(), GENRE_ALIAS[alias]))
    hits = []
    for _, g in sorted(found):
        if g not in hits:
            hits.append(g)
    return hits


def _parse_genre(t, allow_multi_default: bool = False):
    tl = (t or "").strip().lower()
    if not tl:
        return None
    # numbered pick from the top-19 list
    m = re.match(r"^\s*(\d{1,2})\s*[.)]?\s*$", tl)
    if m:
        n = int(m.group(1))
        if 1 <= n <= len(TOP19):
            return TOP19[n - 1]
    hits = _genre_hits(tl)
    if not hits:
        return None
    if len(hits) == 1:
        return hits[0]
    # Multiple matches: only on an explicit answer to the genre question, take the one named first.
    if not allow_multi_default:
        return None
    return hits[0]


def _parse_template(t, engine):
    tl = t.lower()
    if engine == "Unreal":
        if "third" in tl:
            return "Third Person"
        if "first" in tl:
            return "First Person"
        if "blank" in tl:
            return "Blank"
        return None
    if "urp" in tl or "universal" in tl:
        return "3D (URP)"
    if "built" in tl or "builtin" in tl or "standard" in tl:
        return "3D (Built-in)"
    return None


def _yesno(t):
    tl = t.strip().lower()
    if re.match(r"^(y|yes|yeah|yep|sure|ok|okay|please|do it)\b", tl):
        return True
    if re.match(r"^(n|no|nope|skip|nah|don't|dont)\b", tl):
        return False
    return None


def _free_text(t, min_len=2):
    t = (t or "").strip()
    if len(t) < min_len:
        return None
    if re.match(r"^\s*(cancel|stop|never ?mind)\b", t, re.I):
        return None
    return t[:400]


def _you_pick_title(st):
    g = st.get("genre") or "game"
    label = TOP19_LABELS.get(g, g).replace(" / ", "").replace(" ", "")
    return "Sky" + label[:18]


def _genre_list_text():
    lines = [f"{i}. {TOP19_LABELS[g]}" for i, g in enumerate(TOP19, 1)]
    return "\n".join(lines)


def _question(st):
    u, r = _engines()
    # Step number = which question this is (re-asking the same question keeps its number).
    n = 1
    for _k in ("engine", "title", "genre", "loop", "story", "goals", "setting", "style", "template"):
        if not st.get(_k):
            break
        n += 1
    st["qn"] = n
    head = f"{MARK} {n} - "
    if not st["engine"]:
        st["asked"] = "engine"
        both = u and r
        return (head + "Before I create anything: which engine - Unity or Unreal?\n"
                + ("Both are installed on this PC" if both else "Installed: " + ("Unity" if u else "") + (" Unreal" if r else ""))
                + (f" (Unity {u.parent.parent.name}, Unreal {r.parents[3].name}).\n" if both else ".\n")
                + "- Unity: fastest builds, lighter on an 8-12 GB GPU, C# - quickest path to a playable Windows build.\n"
                  "- Unreal: top-end visuals, Blueprints/C++, heavier builds and disk.\n"
                  "Reply \"Unity\" or \"Unreal\". Nothing is created or built until you pick.")
    if not st["title"]:
        st["asked"] = "title"
        return head + "What is the game called? (Say \"you pick\" and I'll choose one; you can rename later.)"
    if not st["genre"]:
        st["asked"] = "genre"
        hint = st.get("genre_hint") or []
        hint_txt = ("You mentioned " + ", ".join(TOP19_LABELS.get(g, g) for g in hint) + " - pick the MAIN one.\n") if hint else ""
        return (head + "What genre? " + hint_txt + "Reply with a number or name from the top 19:\n"
                + _genre_list_text()
                + "\n(Aliases OK: fps=shooter, sim=simulation, br=battle royale, open world=open_world.)")
    if not st.get("loop"):
        st["asked"] = "loop"
        return (head + f"Core loop for {_disp(st)}: what does the player do over and over? "
                "One line (e.g. \"raid in, loot, extract\" or \"jump platforms to the flag\").")
    if not st.get("story"):
        st["asked"] = "story"
        return (head + "Story / premise: who is the player, and what's going on? "
                "(A short paragraph is fine; say \"light\" or \"none\" for minimal story.)")
    if not st.get("goals"):
        st["asked"] = "goals"
        return (head + "Goals: how do you win (and lose, if that matters)? "
                "e.g. reach the exit / extract with loot / beat the final boss.")
    if not st.get("setting"):
        st["asked"] = "setting"
        return (head + "Setting / world: where and when does it take place? "
                "(city, island, space station, fantasy kingdom, near-future…)")
    if not st.get("style"):
        st["asked"] = "style"
        return (head + "Art style / tone: e.g. realistic, stylized, low-poly, pixel, horror-dark, cute, cartoon. "
                "One short phrase is enough.")
    if not st["template"]:
        st["asked"] = "template"
        if st["engine"] == "Unreal":
            return head + "Unreal template: Third Person, First Person, or Blank?"
        return (head + f"Unity template for {_disp(st)}: 3D (URP) - nicer lighting, post-processing, recommended; "
                "or 3D (Built-in) - simplest, fastest build. Reply \"URP\" or \"Built-in\".")
    if st["icon"] is None:
        st["asked"] = "icon"
        return (head + "After the Windows build, should I also make a zip installer and put a Desktop icon for "
                f"{_disp(st)} on this PC? (yes/no)\n"
                "Always included (I won't ask): main+pause menus, full Settings (video/audio/controls), "
                "HUD, achievements, and a playable Windows build.")
    st["asked"] = None
    return None


def _disp(st):
    """Title as shown to the creator: 'open world plus two' -> 'Open World Plus Two' (typed casing kept otherwise)."""
    t = re.sub(r"\s+", " ", (st.get("title") or "").strip())
    if t and (t == t.lower() or t == t.upper()):
        t = " ".join(w[:1].upper() + w[1:].lower() for w in t.split())
    return t or "your game"


def _brief_words(st):
    return " ".join(str(st.get(k) or "") for k in ("loop", "setting", "story"))


def _proj(st):
    """Folder name the pipeline created for this title (open world plus -> OpenWorldPlus)."""
    return _safe_name(st.get("title") or "") if st.get("title") else None


def _asset_spine(genre):
    g = genre or ""
    if g in ASSETS:
        return ASSETS[g]
    alias = GENRE_ALIAS.get(g.lower())
    if alias and alias in ASSETS:
        return ASSETS[alias]
    return ASSETS["default"]


def _asset_q(st):
    spine = _asset_spine(st.get("genre"))
    i = st.get("ai", 0)
    if i >= len(spine):
        st["phase"] = "idle"
        return ("Asset pass done for now. Next on the TaskBoard: polish menus/settings, playtest, iterate. "
                "Ask for any change anytime.")
    _, label = spine[i]
    eng = st["engine"]
    store = ("Unity Asset Store (Package Manager > My Assets)" if eng == "Unity" else "Fab / Epic Launcher Library")
    owned_line = ""
    if i == 0:
        try:
            from owned_assets import list_owned_assets
            n = len(list_owned_assets(eng or "Unity", project=_proj(st), limit=500).get("packs") or [])
            if n:
                owned_line = (
                    f"\nI already see {n} downloaded owned pack(s) on this PC — say \"my assets\" and I'll list them "
                    f"(matched to this genre when I can)."
                )
        except Exception:
            owned_line = ""
    return (f"Asset question {i + 1}/{len(spine)} for {_disp(st)}: what about {label}?\n"
            f"- Describe it and I'll model it in Blender and drop it in, or\n"
            f"- say \"my assets\" if you already own something on the {store}, or\n"
            f"- say \"free\" for a CC0 pick (Kenney, Quaternius, Poly Haven), or \"skip\"."
            + owned_line)


def _asset_q_next(st, i):
    st["ai"] = i + 1
    return _asset_q(st)


def _free_pick(st, key, label):
    """'free' = actually fetch a CC0 model into the project + Unity Assets, or say plainly that we couldn't."""
    try:
        from pathlib import Path as _P
        import shutil as _sh
        from cc0_fetch import fetch_cc0_model
        from auto_studio import GAME_PROJECTS, unity_project_dir, queue_unity_rebuild
        root = GAME_PROJECTS / (_proj(st) or "")
        if not root.is_dir():
            return f"Couldn't fetch a CC0 {label}: project folder {root} not found. Nothing was downloaded."
        extra = re.findall(r"[a-z]{4,}", " ".join([st.get("setting") or "", st.get("loop") or ""]).lower())
        r = fetch_cc0_model(key, label, root, extra)
        if not r.get("ok"):
            return r.get("msg") or f"Couldn't fetch a CC0 {label}."
        up = unity_project_dir(root)
        where = "Unity project not created yet - the next build copies Art\\CC0 into Assets\\Art\\Imports\\CC0."
        if up:
            src = root / "Art" / "CC0" / r["id"]
            dst = up / "Assets" / "Art" / "Imports" / "CC0" / r["id"]
            _sh.copytree(src, dst, dirs_exist_ok=True)
            where = f"Copied into {dst}. " + queue_unity_rebuild(root)
        return f"{r['msg']}\nLicence CC0, logged in ATTRIBUTION.md. {where}"
    except Exception as e:
        return f"Couldn't fetch a CC0 {label} ({type(e).__name__}: {e}). Nothing was downloaded."


ASK_WHICH = ("Which pack should I import? Reply with its number from the list below (e.g. \"7\") "
             "or part of its name.")


def _coach_my_assets(st):
    try:
        from owned_assets import list_owned_assets, format_owned
        scan = format_owned(
            list_owned_assets(st.get("engine") or "Unity", project=_proj(st), limit=200),
            show=20,
            genre=st.get("genre") or "",
            extra=_brief_words(st),
        )
    except Exception as e:
        scan = f"(owned-asset scan failed: {e})"
    if (st.get("engine") or "") == "Unreal":
        how = (
            "How to add more: Epic Games Launcher > Unreal Engine > Library (Fab) > Add to Project for "
            f"Documents\\GameProjects\\{_proj(st)}. Cache: C:\\ProgramData\\Epic\\EpicGamesLauncher\\VaultCache."
        )
    else:
        how = (
            "How to add more: Unity > Window > Package Manager > My Assets > Download > Import. "
            "Downloaded packs live in %APPDATA%\\Unity\\Asset Store-5.x. "
            "Say a pack name/number and I'll import it in batchmode + ATTRIBUTION.md."
        )
    return scan + "\n\n" + how


def _new_state(text, messages=None):
    title = _explicit_title(text)
    return {
        "_sys": messages[0] if messages else None,
        "phase": "intake",
        "req": text,
        "engine": _parse_engine(text),
        "title": title,
        "genre": None,  # always asked (top-19 list); the opener only gives a hint
        "genre_hint": _genre_hits(text),
        "loop": None,
        "story": None,
        "goals": None,
        "setting": None,
        "style": None,
        "template": None,
        "icon": None,
        "asked": None,
        "qn": 0,
        "ai": 0,
    }


def _active(messages):
    if _LAST["st"] is None and messages:
        _LAST["st"] = _load_state(messages)
    st = _STATE.get(_key(messages))
    if st is not None and messages and st.get("_sys") is not messages[0]:
        st = None  # id() reused by a new session
    if st is None and _LAST["st"] is not None:
        prev = next((m.get("content") or "" for m in reversed(messages[:-1]) if m.get("role") == "assistant"), "")
        if MARK in prev or "Asset question" in prev or "you don't have a pack for" in prev or "Asset Store searches" in prev:
            st = _LAST["st"]
            _STATE[_key(messages)] = st
            st["_sys"] = messages[0] if messages else None
    return st


def tool_gate():
    """Block a model-initiated run_auto_game_pipeline while intake is unfinished."""
    st = _LAST["st"]
    if st is not None and st.get("phase") == "intake":
        return ("INTAKE REQUIRED - nothing was created. New games start with intake: ask engine, "
                "'What is the game called?', top-19 genre, core loop, story, goals, setting, art/tone, "
                "template, then desktop icon — and wait for each reply.")
    return None


def _gate_plan(st, refresh=False):
    from asset_plan import build_plan, catalog
    from auto_studio import builder_family
    if refresh:
        catalog(refresh=True)
    brief = {"display_title": _disp(st), "loop": st.get("loop") or "", "story": st.get("story") or "",
             "goals": st.get("goals") or "", "setting": st.get("setting") or "", "style": st.get("style") or ""}
    plan = build_plan(builder_family(st.get("genre") or ""), brief, st.get("template") or "", st.get("asset_choices") or {})
    st["asset_plan"] = plan
    return plan


def _asset_gate(st):
    """Before the build: name every needed thing the creator has no pack for, and wait for their pick."""
    if (st.get("engine") or "Unity") != "Unity":
        return None
    try:
        from asset_plan import missing_question, confirm_text
        plan = _gate_plan(st)
        # review fix 5: even when every need has a pack, show the picks and wait for "build"
        return missing_question(plan, _disp(st)) or confirm_text(plan, _disp(st))
    except Exception:
        return None


def _asset_gate_reply(st, t):
    from asset_plan import parse_choices, unresolved, missing_question, store_reply, summary_lines, confirm_text, CONFIRM_RX
    tl = t.lower()
    plan = st.get("asset_plan") or _gate_plan(st)
    if CONFIRM_RX.match(t or "") and not unresolved(plan):
        st["phase"] = "assets"
        st["ai"] = 0
        payload = _run_payload(st)
        payload["run"]["asset_choices"] = dict(plan.get("choices") or {})
        return payload
    if re.search(r"\b(rescan|scan again|refresh|downloaded|got it|done)\b", tl):
        plan = _gate_plan(st, refresh=True)
        if unresolved(plan):
            return "I scanned again. " + missing_question(plan, _disp(st))
        return "I scanned again. " + confirm_text(plan, _disp(st))
    else:
        ch = parse_choices(t, plan)
        if not ch:
            from asset_plan import wants_assets, owned_list_text
            if wants_assets(t) or re.search(r"\b(list|show|what)\b.*\b(assets?|packs?)\b", tl):
                return owned_list_text() + "\n\nPacks I'll use for " + _disp(st) + ":\n" + summary_lines(plan) + "\n\n" + missing_question(plan, _disp(st))
            return "Sorry, I didn't catch that. " + missing_question(plan, _disp(st))
        stores = [k for k, v in ch.items() if v == "store"]
        plan.setdefault("choices", {}).update({k: v for k, v in ch.items() if v != "store"})
        st["asset_choices"] = dict(plan["choices"])
        if stores:
            return store_reply(plan, stores)
        if unresolved(plan):
            return missing_question(plan, _disp(st))
        return "Got it. " + confirm_text(plan, _disp(st))
    st["phase"] = "assets"
    st["ai"] = 0
    payload = _run_payload(st)
    payload["run"]["asset_choices"] = dict(plan.get("choices") or {})
    return payload


def _run_payload(st):
    bits = [
        f"request: {st['req']}",
        f"engine {st['engine']}",
        f"genre {st['genre']}",
        f"template {st['template']}",
    ]
    if st.get("loop"):
        bits.append(f"core loop: {st['loop']}")
    if st.get("story"):
        bits.append(f"story: {st['story']}")
    if st.get("goals"):
        bits.append(f"goals: {st['goals']}")
    if st.get("setting"):
        bits.append(f"setting: {st['setting']}")
    if st.get("style"):
        bits.append(f"art/tone: {st['style']}")
    # Always-built features (not asked)
    bits.append("always include: main+pause menus, full Settings (video/audio/controls), HUD, achievements, playable Windows build")
    tpl = None
    if st["engine"] == "Unity" and st["template"] == "3D (URP)":
        tpl = "urp"
    return {
        "run": {
            "user_text": " | ".join(bits),
            "name": st["title"],
            "engine": st["engine"],
            "template": tpl,
            "desktop_icon": bool(st["icon"]),
            "genre": st["genre"],
            "asset_choices": dict(st.get("asset_choices") or {}),
            "brief": {
                "display_title": _disp(st),
                "loop": st.get("loop") or "",
                "story": st.get("story") or "",
                "goals": st.get("goals") or "",
                "setting": st.get("setting") or "",
                "style": st.get("style") or "",
            },
        },
        "followup": _post_build_hint(st),
    }


def _post_build_hint(st):
    """Unity builds already mapped every need to an owned pack (asset gate), so don't re-ask per asset."""
    if st.get("asset_plan") is not None and (st.get("engine") or "Unity") == "Unity":
        st["phase"] = "idle"  # the chat is now a game chat; agent_core routes assets / play / changes
        return ("While it builds: say \"list all assets\" to see your packs, \"use <pack name>\" to swap one in, "
                "or tell me what to change. Say \"play\" when it's ready.")
    return _asset_q(st)


def _state_file():
    from pathlib import Path
    return Path(__file__).resolve().parent / "work" / "intake_state.json"


def _save_state():
    """Keep the in-progress intake on disk so a backend restart (update, crash) resumes it instead of starting over."""
    try:
        import json, time
        st = _LAST.get("st")
        f = _state_file()
        if st is None:
            return
        f.parent.mkdir(parents=True, exist_ok=True)
        f.write_text(json.dumps({"saved": time.time(), "st": {k: v for k, v in st.items() if k != "_sys"}}, default=str), encoding="utf-8")
    except Exception:
        pass


def _load_state(messages):
    try:
        import json, time
        d = json.loads(_state_file().read_text(encoding="utf-8"))
        st = d.get("st") or {}
        if time.time() - float(d.get("saved") or 0) > 7 * 86400 or st.get("phase") in (None, "idle"):
            return None
        req = (st.get("req") or "").strip()
        if req and not any((m.get("role") == "user" and (m.get("content") or "").strip() == req) for m in messages):
            return None  # saved intake belongs to another chat
        return st
    except Exception:
        return None


def step(messages, text):
    try:
        return _step_impl(messages, text)
    finally:
        _save_state()


def _step_impl(messages, text):
    """Return None (not intake), str (reply without the model), or dict {'run': kwargs} / {'asset': text}."""
    t = (text or "").strip()
    if not t or t.startswith("SYSTEM NOTE"):
        return None
    st = _active(messages)
    # Start / restart intake on a clear new-game ask. Title only from called/named/titled —
    # never invent NFps from "make a new fps".
    if is_new_game(t) and (st is None or st["phase"] != "intake" or _explicit_title(t)):
        st = _new_state(t, messages)
        _STATE[_key(messages)] = st
        _LAST["st"] = st
    try:
        from asset_plan import wants_assets as _wa
        _is_asset_talk = _wa(t)
    except Exception:
        _is_asset_talk = False
    if (st is None or st["phase"] == "idle") and not _is_asset_talk and len(t) <= 80 and not t.endswith("?") and (
            _parse_engine(t) or _parse_template(t, "Unity")) and not re.search(
                r"\b(open|fix|error|rebuild|build log|existing)\b", t, re.I):
        # bare engine/template answer with no game request yet ("Unity, 3D URP")
        st = _new_state(t, messages)
        st["title"] = None
        st["template"] = _parse_template(t, st["engine"] or "Unity")
        _STATE[_key(messages)] = st
        _LAST["st"] = st
    if st is None or st["phase"] == "idle":
        return None
    _LAST["st"] = st
    if re.match(r"^\s*(cancel|stop|never ?mind|forget it)\b", t, re.I):
        st["phase"] = "idle"
        return "OK - intake cancelled, nothing was created."

    if st["phase"] == "intake":
        a = st.get("asked")
        if _is_asset_talk and t != st["req"]:
            # "i have assets in unity" / "list all assets" mid-intake: show the real packs, never take it as an answer.
            try:
                from asset_plan import owned_list_text as _olt
                _q0 = _question(st) or ""
                return (_olt(full=bool(re.search(r"\ball\b", t, re.I))) + "\n\nI'll map these packs to the game right after the questions. "
                        + re.sub(r"^Intake step \d+ - ", "", _q0))
            except Exception:
                pass
        if a and t != st["req"]:
            if a == "engine":
                st["engine"] = _parse_engine(t) or (
                    ("Unity" if t.strip() == "1" else "Unreal") if t.strip() in ("1", "2") else None)
            elif a == "title":
                if re.search(r"you pick|any|whatever|dunno|don't know|dont know|idk", t, re.I):
                    st["title"] = _you_pick_title(st)
                else:
                    cand = re.sub(r"^\s*(it'?s|its|call it|called|named|title is|the title is)\s+", "", t, flags=re.I)
                    cand = re.sub(r"[^A-Za-z0-9 _-]", "", cand)[:40].strip()
                    st["title"] = None if _is_filler_title(cand) else cand
            elif a == "genre":
                st["genre"] = _parse_genre(t, allow_multi_default=True)
                if not st["genre"] and _yesno(t) and len(st.get("genre_hint") or []) == 1:
                    st["genre"] = st["genre_hint"][0]
            elif a == "loop":
                st["loop"] = _free_text(t)
            elif a == "story":
                st["story"] = _free_text(t)
            elif a == "goals":
                st["goals"] = _free_text(t)
            elif a == "setting":
                st["setting"] = _free_text(t)
            elif a == "style":
                st["style"] = _free_text(t)
            elif a == "template":
                st["template"] = _parse_template(t, st["engine"]) or (
                    {"1": "3D (URP)", "2": "3D (Built-in)"}.get(t.strip()) if st["engine"] == "Unity" else None)
            elif a == "icon":
                st["icon"] = _yesno(t)
            # Extra answers in the same line: only engine+template on the engine step ("Unity URP").
            # NEVER infer genre from a title/story answer ("open world plus", "Racing Ashes") and
            # never infer template from free text ("I built a ..." is not Built-in).
            if a == "engine" and st["engine"] and not st["template"]:
                st["template"] = _parse_template(t, st["engine"])
            et = _explicit_title(t)
            if et and not st["title"]:
                st["title"] = et
        q = _question(st)
        if q:
            if a and st.get("asked") == a and t != st["req"]:
                q = "Sorry, I didn't catch that. " + q
            return q
        st["phase"] = "assets"
        st["ai"] = 0
        gate = _asset_gate(st)
        if gate:
            st["phase"] = "asset_gate"
            return gate
        return _run_payload(st)

    if st["phase"] == "asset_gate":
        return _asset_gate_reply(st, t)

    if st["phase"] == "assets":
        spine = _asset_spine(st.get("genre"))
        i = st.get("ai", 0)
        key, label = spine[min(i, len(spine) - 1)]
        tl = t.lower()
        try:
            from asset_plan import wants_assets as _wa2, assets_reply as _ar
            if _wa2(t) and not re.match(r"^\s*\d{1,3}\s*$", t):
                from auto_studio import GAME_PROJECTS as _GP
                _root = _GP / (_proj(st) or "")
                return _ar(_root if _root.is_dir() else None, t, _disp(st))
        except Exception:
            pass
        if t.endswith("?") and not re.search(r"asset|model|download|kenney|free", tl):
            return None  # off-topic question: let the model answer; asset spine resumes next time
        # Lone engine / tool words ("unity", "unreal", "blender", "in unity") are NOT an engine pick, a new game,
        # or a rebuild. Answer here so the model can't re-call the pipeline with an invented request.
        if re.fullmatch(r"\s*(?:(?:in|use|with|using|the|for)\s+)?(unity|unreal|ue ?5|ue|blender|unity engine|unreal engine)"
                        r"(?:\s+(?:engine|please|pls))?\s*[.!]*\s*", tl):
            w = re.sub(r"\s+", " ", tl).strip(" .!")
            if "blender" in w:
                tip = f"Describe the {label} (e.g. \"a rusted radio tower\") and I'll model it in Blender and drop it into the Unity project."
            else:
                tip = (f"{_disp(st)} is already a {st.get('engine') or 'Unity'} project - nothing new was started or rebuilt. "
                       f"For owned {st.get('engine') or 'Unity'} packs say \"my assets\" (then a number).")
            return tip + "\n\n" + _asset_q(st)
        if re.search(r"my assets|asset store|assets?\s+from\s+unity|already (own|have|bought)|\bfab\b|owned packs?", tl) and not re.search(r"^\s*\d+\s*$", t):
            st["awaiting_pack"] = True
            return _coach_my_assets(st) + "\n\n(Still on asset question for " + label + " — say a pack number/name to import, or free/skip/describe.)"
        if st.get("awaiting_pack") or re.match(r"^\s*\d{1,3}\s*$", t) or re.search(r"\b(import|use|pick)\b|assets?\s+from\s+unity|my assets|asset store", tl):
            try:
                from owned_assets import import_owned_asset
                msg = import_owned_asset(
                    request=t,
                    project=_proj(st),
                    engine=st.get("engine") or "Unity",
                    genre=st.get("genre") or "",
                    rebuild=True,
                    extra=_brief_words(st),
                )
            except Exception as e:
                msg = f"Import failed: {e}"
            st["awaiting_pack"] = False
            if msg.startswith(("IMPORT OK", "IMPORT SKIP", "IMPORT QUEUED")):
                st["ai"] = i + 1
                return msg + "\n\n" + _asset_q(st)
            if msg.startswith("Which pack should I import"):
                st["awaiting_pack"] = True
                return (msg + "\n\n" + _coach_my_assets(st)
                        + "\n\n(Still on asset question for " + label
                        + " - say a pack number/name to import, or free/skip/describe.)")
            if msg.startswith("I couldn't find an owned pack"):
                # Bare "import" / "assets from unity" -> coach owned packs, NEVER Blender
                if re.search(r"^(import|assets?\s+from\s+unity|my assets|asset store)\b", tl) or re.fullmatch(r"\s*(import|my assets|assets? from unity)\s*", t, re.I):
                    st["awaiting_pack"] = True
                    return (ASK_WHICH + "\n\n" + _coach_my_assets(st)
                            + "\n\n(Still on asset question for " + label
                            + " - say a pack number/name to import, or free/skip/describe.)")
                pass  # fall through to describe/blender only for a real description that failed resolve
            else:
                return msg + "\n\n" + _coach_my_assets(st)
        if re.match(r"^\s*(free|cc0|kenney|fallback|you pick|any)\b", tl):
            st["awaiting_pack"] = False
            return _free_pick(st, key, label) + "\n\n" + _asset_q_next(st, i)
        if _yesno(t) is False or re.match(r"^\s*(skip|next|later)\b", tl):
            st["ai"] = i + 1
            st["awaiting_pack"] = False
            return "Skipped. " + _asset_q(st)
        if _parse_engine(t) and len(t) < 40 and not re.search(r"\b(new|another|make|build|create)\b", tl):
            return ("Noted - the engine is already set to " + (st.get("engine") or "Unity") + "; nothing was restarted.\n\n" + _asset_q(st))
        try:
            from owned_assets import resolve_pack, import_owned_asset
            hit = resolve_pack(t, engine=st.get("engine") or "Unity", genre=st.get("genre") or "", extra=_brief_words(st))
            if hit and len(t) < 80:
                msg = import_owned_asset(request=t, project=_proj(st), engine=st.get("engine") or "Unity",
                                         genre=st.get("genre") or "", rebuild=True, extra=_brief_words(st))
                st["ai"] = i + 1
                st["awaiting_pack"] = False
                return msg + "\n\n" + _asset_q(st)
        except Exception:
            pass
        # Never send owned-pack import phrases to Blender as "make a import model"
        if re.search(r"\b(import|my assets|asset store|assets?\s+from\s+unity|owned packs?)\b", tl):
            st["awaiting_pack"] = True
            return _coach_my_assets(st) + "\n\n(Still on asset question for " + label + " - say a pack number/name to import, or free/skip/describe.)"
        st["ai"] = i + 1
        st["awaiting_pack"] = False
        desc = re.sub(r"^\s*(an?|the|some)\s+", "", t, flags=re.I)[:80].strip()
        return {"asset": f"make a {desc} model for {_proj(st)}", "project": _proj(st), "followup": _asset_q(st)}
