# Complete game builder - master index (Game Bot)
Use search_playbooks/read_playbook with these names. Order = pipeline. START with auto-studio-mode (run_auto_game_pipeline does phases 0-2 setup automatically). For each phase: read playbooks -> act with tools -> verify -> teach_self.

## 0. Studio operating rules
- auto-studio-mode, product-safety, onboarding-new-buyer, self-learn-loop, aaa-solo-studio, aaa-production-checklist, game-dev-fundamentals, debug-fix-playbook, git-lfs-project-hygiene

## 1. Concept & pre-production
- game-design, narrative-writing-gdd, websites-and-concept-art (concept art), monetization-store-pages (market/price research early)

## 2. Vertical slice (prove the fun)
- unity-workflow (or unreal-workflow), camera-cinemachine, physics-vehicles, ai-npc-navigation, models-and-ui, assets-pipeline, asset-intake, turnkey-assets-stores-gaps (getting assets), unity-batchmode-content-bake, input-system, save-load-systems, automated-playtest-runner

## 3. Production (content + systems)
- animation-rigging, vfx-particles-shaders, terrain-worldbuilding, lighting-postfx, inventory-crafting-progression, quest-objectives-dialogue, content-pipeline-automation, multiplayer-netcode (decision: usually no), community-modding (optional, post-1.0), unity-custom-item-weapon-pipeline, dialogue-localization, addressables-content-update

## 4. Polish, performance, QA
- performance-profiling, fps-performance-passes, qa-test-plans, accessibility, legal-notices-and-menus (settings/menus/legal), analytics-telemetry (opt-in or none), steam-deck-verified, automated-playtest-runner

## 5. Ship
- ship-build-installer-desktop (build, installer, desktop icon), steamworks-sdk-integration, store-steam-epic-mobile, steam-store-marketing, epic-eos-overview, mobile-touch-ui, websites-and-concept-art (game website), trailer-capture-checklist, pricing-wishlist-launch-week

## 6. Live / post-launch
- qa-test-plans (patch regression), community-modding, monetization-store-pages (DLC), fps-performance-passes (each patch), customer-support-patch-notes, addressables-content-update


## Human-only steps (never fake)
- Steam Direct fee, Steamworks/Epic tax+bank interviews, real App IDs/EOS IDs, age-rating submission, store review submit, the final Release/Go Live click, Apple/Google developer accounts, any public posting.

## More studio gaps
audio-mixer, localization-dialog, accessibility-ux, git-lfs-project-hygiene, ci-player-builds, mobile-iap-privacy, physics-navmesh-ai, qa-regression-checklist, analytics-privacy-first, marketing-store-page-copy

