# Self-teaching rule

After a user correction ("do it like this", "wrong", "better"):
1. Call teach_self with a short title and the corrected procedure.
3. At the start of hard tasks, call list_lessons or read_lesson for matching tags.
4. Never invent that you learned something without calling teach_self.
