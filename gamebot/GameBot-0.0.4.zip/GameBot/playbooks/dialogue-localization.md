# Dialogue + localization (deep)
## Dialogue tech choice
- Barks/short lines: ScriptableObject DialogueLine {id, speakerId, textKey, audioClip, conditions}. Event bus triggers barks with cooldowns.
- Branching: ink (inkle, MIT; ink-unity-integration) or Yarn Spinner (MIT). Store scripts in Assets\Dialogue\*.ink|*.yarn; compile in batchmode as part of the content bake.
- Variables shared with game state through one adapter (QuestState <-> ink variables); save the story state JSON in SaveData.
- UI: typewriter text with skip, speaker name + portrait, choices navigable by gamepad, auto-advance option, log/backlog screen.

## Localization (Unity Localization package com.unity.localization)
- All player-facing text in String Tables from day one (no literal strings in UI). Keys: area.screen.element (menu.main.play).
- Smart Strings for plurals/variables: "{count:plural:1 item|{} items}". Avoid string concatenation; allow word order changes.
- Fonts: TextMeshPro font assets with fallback chains (Latin, Cyrillic, CJK via Noto Sans CJK, OFL license -> ATTRIBUTION.md). Test 30-40% longer German/Russian text; auto-size or wrap.
- Export/import CSV (Localization > Import/Export CSV) for translators; machine translation only as placeholder marked [MT] and never shipped without review (human gate if paying translators).
- Locale selection: system language default, settings override, saved in settings.
- Store page languages on Steam must match what is actually shipped (Interface / Full Audio / Subtitles).
- Pseudo-localization pass (accented, +40% length) in QA to catch hardcoded strings and clipping.
- Right-to-left (Arabic/Hebrew) needs RTL text shaping plugin; scope it explicitly.
