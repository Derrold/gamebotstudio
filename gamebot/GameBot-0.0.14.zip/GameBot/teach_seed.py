"""Seed generic lessons for the sellable Game Bot (run once after deploy)."""
from learn_tools import teach_self
L = [
 ("Auto studio pipeline", "New game request -> run_auto_game_pipeline immediately: GDD, TaskBoard, legal, QA, site, ship prep, Unity background job (Builds\\auto_unity_status.txt). Never ask permission; report real paths and human gates.", "auto studio pipeline"),
 ("Custom item/weapon pipeline", "Model (make_asset) -> ScriptableObject def + prefab -> Editor script registration -> unlock/shop entry -> batchmode bake -> grep 'error CS' -> restore backups on failure. Patch code registries with exact-needle insert, backup + sanity gate + atomic replace, keep BOM.", "unity weapon item pipeline"),
 ("Batchmode content bake", "Scenes are outputs of a static Editor builder run with -batchmode -nographics -quit -executeMethod; one Unity per project; status file RUNNING/DONE OK/DONE FAIL; first error -> research_error -> patch -> retry once.", "unity batchmode bake"),
 ("Product safety", "Never invent AppIDs/EOS IDs (PLACEHOLDER_*), never exfiltrate, never spend, never click Release/submit, never touch folders outside projects_root or real saves. Back up before editing.", "safety product gates"),
 ("Buyer onboarding", "Paths come from config\\gamebot.config.json (auto-detected Unity 6000.x, Blender, %USERPROFILE%\\Documents\\GameProjects). If no name given, scaffold a working title and proceed.", "onboarding config"),
 ("FPS pass method", "Same build, same spot, same preset; vsync 0, uncapped; warm-up 3 s, record 10-30 s; FrameTimingManager cpu/gpu ms; log to Docs\\QA\\fps_passes.md; 60 fps recommended spec, Steam Deck 30-40.", "fps performance"),
]
for t, l, g in L:
    print(teach_self(t, l, g)[:80])
