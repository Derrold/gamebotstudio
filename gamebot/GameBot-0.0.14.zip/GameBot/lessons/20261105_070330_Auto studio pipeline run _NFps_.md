# Auto studio pipeline run (NFps)

Tags: auto studio pipeline
Saved: 2026-11-05T07:03:30

run_auto_game_pipeline created 1 files under C:\Users\ExtremeHybrid\Documents\GameProjects\NFps and UNITY 6000.6.5f1: background job started -> create NFpsUnity -> Assets/Scenes/Slice01.unity (grey-box, player, goal, HUD) -> Builds\Windows\NFps.exe. Status: Bu. Next: check Builds\auto_unity_status.txt, then work TaskBoard 'Auto next actions' with tools.
