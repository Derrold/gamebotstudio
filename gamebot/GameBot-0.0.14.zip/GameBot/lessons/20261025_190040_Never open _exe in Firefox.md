# Never open .exe in Firefox

Tags: blender launch apps
Saved: 2026-10-25T19:00:40

Local apps like Blender must use launch_app with full Windows path. open_url/firefox_open on c/Program Files/... causes Server Not Found. Blender 5.2 path: the Blender path from config.json (auto-detected). When user says do it all/yes, act with tools — don't re-ask permission.
