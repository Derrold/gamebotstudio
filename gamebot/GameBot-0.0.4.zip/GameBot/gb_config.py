"""Game Bot buyer config: reads config/gamebot.config.json and exports GAMEBOT_* env defaults.
Empty values are auto-detected by the modules that use them. Nothing here is machine- or owner-specific."""
from __future__ import annotations

import json
import os
from pathlib import Path

ROOT = Path(__file__).resolve().parent
CONFIG_PATH = ROOT / "config" / "gamebot.config.json"
EXAMPLE = ROOT / "config" / "gamebot.config.example.json"
_ENV = {"projects_root": "GAMEBOT_PROJECTS", "unity_editor": "GAMEBOT_UNITY", "blender": "GAMEBOT_BLENDER",
        "company_name": "GAMEBOT_COMPANY", "default_engine": "GAMEBOT_ENGINE"}


def load() -> dict:
    cfg: dict = {}
    for p in (EXAMPLE, CONFIG_PATH):
        try:
            cfg.update(json.loads(p.read_text(encoding="utf-8-sig")))
        except Exception:
            pass
    return cfg


def apply() -> dict:
    cfg = load()
    for k, env in _ENV.items():
        v = str(cfg.get(k) or "").strip()
        if v:
            os.environ.setdefault(env, os.path.expandvars(v))
    return cfg


def ensure_config() -> str:
    """First run: write config.json with detected paths so the buyer can see/edit them."""
    if CONFIG_PATH.exists():
        return f"config: {CONFIG_PATH}"
    cfg = load()
    try:
        from pc_tools import BLENDER
        from auto_studio import find_unity
        cfg["projects_root"] = cfg.get("projects_root") or "%USERPROFILE%/Documents/GameProjects"
        cfg["blender"] = cfg.get("blender") or (str(BLENDER) if Path(BLENDER).exists() else "")
        u = find_unity()
        cfg["unity_editor"] = cfg.get("unity_editor") or (str(u) if u else "")
    except Exception:
        pass
    CONFIG_PATH.parent.mkdir(parents=True, exist_ok=True)
    CONFIG_PATH.write_text(json.dumps(cfg, indent=2), encoding="utf-8")
    return f"config written: {CONFIG_PATH}"


CONFIG = apply()
