using UnityEngine;
/// <summary>Survival loop: hunger drains, C crafts campfire from 5 wood, survive the timer to win; starving kills.</summary>
public class SurvivalController : MonoBehaviour
{
    void Update()
    {
        if (GameState.Won || GameState.Lost || PauseMenu.IsPaused || MainMenuUI.InMenu) return;
        GenreState.Hunger -= (GenreState.FireBuilt ? 0.8f : 1.6f) * Time.deltaTime;
        GenreState.TimeLeft -= Time.deltaTime;
        if (Input.GetKeyDown(KeyCode.C) && !GenreState.FireBuilt && GenreState.Wood >= 5)
        {
            GenreState.Wood -= 5; GenreState.FireBuilt = true; AchievementSystem.Unlock("fire_built");
            var f = GameObject.CreatePrimitive(PrimitiveType.Cylinder); f.name = "Campfire"; f.transform.position = transform.position + transform.forward * 2f; f.transform.localScale = new Vector3(1.2f, 0.2f, 1.2f);
            f.GetComponent<Renderer>().material.color = new Color(1f, 0.4f, 0.1f);
            var l = new GameObject("FireLight").AddComponent<Light>(); l.transform.position = f.transform.position + Vector3.up; l.color = new Color(1f, 0.55f, 0.2f); l.range = 14; l.intensity = 5;
        }
        if (GenreState.Hunger <= 0) { GenreState.Hunger = 60; var gp = GetComponent<GamePlayer>(); if (gp) gp.Respawn(); }
        if (GenreState.TimeLeft <= 0) { if (GenreState.FireBuilt) { AchievementSystem.Unlock("survived"); GenreState.Win(); } else { GenreState.TimeLeft = 30; GameHUD.Flash("The cold bites. Build a fire!"); var gp = GetComponent<GamePlayer>(); if (gp) gp.Respawn(); } }
    }
}
