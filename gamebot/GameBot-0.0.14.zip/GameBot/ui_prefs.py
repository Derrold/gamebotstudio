from pathlib import Path
import json
import os

ROOT = Path(__file__).resolve().parent
PREFS_PATH = ROOT / "work" / "ui_prefs.json"
ALLOWED = ("en", "es", "fr", "de", "pt")
DEFAULT = "en"

# Chat/agent replies stay English. The selector only changes UI chrome.
CHAT_NOTE = {
    "en": "Chat with Game Bot is in English.",
    "es": "El chat con Game Bot es en inglés.",
    "fr": "Le chat avec Game Bot est en anglais.",
    "de": "Der Chat mit Game Bot ist auf Englisch.",
    "pt": "O chat com o Game Bot é em inglês.",
}


def _load() -> dict:
    try:
        if PREFS_PATH.is_file():
            return json.loads(PREFS_PATH.read_text(encoding="utf-8"))
    except Exception:
        pass
    return {}


def _save(data: dict) -> None:
    PREFS_PATH.parent.mkdir(parents=True, exist_ok=True)
    PREFS_PATH.write_text(json.dumps(data, indent=2) + "\n", encoding="utf-8")


def get_language() -> str:
    env = (os.environ.get("GAMEBOT_LANG") or "").strip().lower()
    if env in ALLOWED:
        return env
    lang = str(_load().get("language") or "").strip().lower()
    return lang if lang in ALLOWED else DEFAULT


def set_language(lang: str) -> str:
    code = (lang or "").strip().lower()
    if code not in ALLOWED:
        return get_language()
    data = _load()
    data["language"] = code
    _save(data)
    return code


def language_info(lang: str | None = None) -> dict:
    code = (lang or get_language()).strip().lower()
    if code not in ALLOWED:
        code = DEFAULT
    return {
        "language": code,
        "allowed": list(ALLOWED),
        "chat_note": CHAT_NOTE.get(code, CHAT_NOTE[DEFAULT]),
        "chat_in_english": True,
    }
