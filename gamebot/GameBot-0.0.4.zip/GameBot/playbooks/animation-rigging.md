# Animation & rigging (Game Bot)
Sources: https://docs.unity3d.com/Manual/AnimationOverview.html | https://docs.unity3d.com/Manual/ConfiguringtheAvatar.html | https://helpx.adobe.com/creative-cloud/faq/mixamo-faq.html | https://dev.epicgames.com/documentation/en-us/unreal-engine/control-rig-in-unreal-engine | https://docs.blender.org/manual/en/latest/animation/armatures/index.html

## Rig types
- Humanoid (bipeds: hunters, NPC people): Unity Rig tab -> Animation Type = Humanoid -> Configure Avatar (bone mapping, T-pose). Enables retargeting between characters.
- Generic (animals: deer, turkey, dogs; props; weapons): Animation Type = Generic, set Root node. No retargeting across skeletons; author clips per skeleton.
- Legacy: avoid for new work.
- Quadruped deer: Blender armature (spine chain, neck, head, 4 legs with IK, tail, ears). never rename existing bones without grepping scripts.

## Blender -> FBX export rules
- Apply scale (Ctrl+A) and rotation; units metric, scale 1.0; Forward -Z / Up Y; Add Leaf Bones OFF; Bake Animation ON; NLA strips or Actions -> separate clips.
- One FBX per character + separate @clip FBX files (Deer@walk.fbx) or one FBX with multiple takes.
- Test: import, check Rig tab errors, play clip in Inspector preview.

## Mixamo caveats
- Free auto-rig + clips for humanoids only (no quadrupeds). Check Adobe terms; keep ATTRIBUTION.md note. Upload T-pose, export FBX for Unity, 30 fps, skin once + 'without skin' for clips. Root motion: 'In Place' variants for code-driven movement.

## Unity Animator
- Animator Controller: layers (base locomotion, upper-body aim/reload with Avatar Mask), parameters (Speed float, Alert trigger, Dead bool).
- Blend Trees for walk/trot/run by Speed. Transitions: short exit time off for responsiveness.
- Root motion vs in-place: AI on NavMesh -> in-place clips + agent velocity drives Speed (or OnAnimatorMove to sync).
- Animation events for footsteps/SFX (Sfx.cs) and reload sounds.
- Animation Rigging package (Two Bone IK, Multi-Aim) for head look-at and weapon hands: https://docs.unity3d.com/Packages/com.unity.animation.rigging@1.3/manual/index.html
- Performance: Animator Culling Mode = Cull Update Transforms for distant animals; reduce animators on far LOD.

## First-person arms (FPArms.cs pattern)
- Separate arms+weapon rig on its own layer/camera; clips: idle, ADS, fire, reload, bolt/pump cycle, inspect. Keep weapon root offsets data-driven per WeaponDef.

## Unreal overview
- Skeleton + Skeletal Mesh + Animation Blueprint (state machine) ; Control Rig for in-engine rigging/procedural IK; IK Retargeter for clip retarget. Unreal not installed here - plan only.

## Verify
- Clip imports without errors, Avatar valid (green), correct facing, no foot sliding at target speed, events fire. Log fixes via teach_self.
