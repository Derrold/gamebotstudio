# Community & modding (optional)
Sources: https://partner.steamgames.com/doc/features/workshop | https://partner.steamgames.com/doc/marketing/event_tools | https://partner.steamgames.com/doc/community_moderation

## When to expose modding
- Only after 1.0 is stable. Cheapest path: data-driven files (JSON/CSV) the game already reads - e.g. weapon defs (Builder G() style), Gfx tuning file (Gfx.Tun) already parses key=value. Load mods from %USERPROFILE%\Documents\<Game>\Mods, validate & clamp values, never execute code.
- Next: custom FBX/texture loading at runtime (glTFast), or Addressables-based mod kits. Steam Workshop for distribution (ISteamUGC).
- Risks: support load, save corruption (version your data), legal (mods using copyrighted brands).

## Community
- Steam community hub, announcements (Steam event tools), Discord (moderation rules), bug report form linked from main menu, changelogs every patch, roadmap honesty.
- Game Bot drafts posts/changelogs locally; the creator approves and posts (never auto-post).
