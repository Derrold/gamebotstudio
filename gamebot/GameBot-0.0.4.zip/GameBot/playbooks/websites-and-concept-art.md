# Game websites + concept art

Action playbook for Game Bot.

## Concept art pipeline
1. Brief: mood, era, camera, palette, hero subject.
2. Generate or paint stills (local image tools / Blender greyscale blockout → paintover). Save under `Art\Concept\<game>\<slug>\`.
3. Produce sheet: key art, character/prop turns, environment, UI mood, logo explorations.
4. Lock style guide (palette hex, fonts, logo clearspace) → feed UI + marketing.
5. Export web sizes: hero 1920×1080, OG 1200×630, logo PNG/SVG, favicon ICO via `scripts\png_to_ico.py`.

## Marketing site (static, shippable)
Minimum pages: Home · Features · Gallery · Presskit · Support · Legal (EULA/Privacy).
Stack options (prefer local/unlimited): plain HTML/CSS in `websites\<game>\`, or static generator; host later (GitHub Pages, Netlify, own domain).
Home needs: key art, trailer embed slot, wishlist/Steam CTA, short pitch, screenshots.
Presskit: logo zip, screenshots, fact sheet, contact email.
Legal pages: reuse same EULA/Privacy text as in-game.

## Wire to Game Bot tools
- Create folder `<projects_root>\<Name>\Docs\Site\index.html` + assets.
- Concept PNGs → `websites\<game>\img\`.
- Desktop shortcut optional via `scripts\make_desktop_shortcut.ps1` pointing at index or published URL.
- teach_self after each shipped site revision.
