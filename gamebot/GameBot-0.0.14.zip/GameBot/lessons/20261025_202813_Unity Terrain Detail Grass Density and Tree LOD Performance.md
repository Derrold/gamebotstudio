# Unity Terrain Detail Grass Density and Tree LOD Performance

Tags: Unity Terrain Grass Density Tree LOD Performance
Saved: 2026-10-25T20:28:13

To optimize Unity terrain detail grass density and tree LOD for better performance, follow the official documentation on docs.unity3d.com. Ensure to set appropriate density and distance values for detail meshes and configure LOD settings for trees to balance visual quality and performance.
