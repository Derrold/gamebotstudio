﻿using UnityEngine;

/// <summary>Ordered checkpoint gate. Index 0 = start/finish line.</summary>
public class RaceCheckpoint : MonoBehaviour
{
    public int index;
    void OnTriggerEnter(Collider o)
    {
        var car = o.GetComponentInParent<CarController>(); if (car == null) return;
        if (index != GenreState.NextCheckpoint) return;
        car.resetPos = transform.position; car.resetRot = transform.rotation;
        GenreState.NextCheckpoint = (index + 1) % GenreState.CheckpointCount;
        if (index == 0)
        {
            {
                float lt = Time.time - GenreState.LapStart;
                if (GenreState.BestLap < 0 || lt < GenreState.BestLap) GenreState.BestLap = lt;
                GenreState.Lap++;
                AchievementSystem.NotifyLap(GenreState.Lap, lt);
                if (GenreState.Lap >= GenreState.TotalLaps) GenreState.Win();
            }
            GenreState.LapStart = Time.time;
        }
    }
}



