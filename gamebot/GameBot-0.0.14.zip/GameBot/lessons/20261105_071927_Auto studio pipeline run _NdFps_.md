# Auto studio pipeline run (NdFps)

Tags: auto studio pipeline
Saved: 2026-11-05T07:19:27

run_auto_game_pipeline created 32 files under C:\Users\ExtremeHybrid\Documents\GameProjects\NdFps and UNITY 6000.6.5f1: background job started -> create NdFpsUnity -> Assets/Scenes/Slice01.unity (grey-box, player, goal, HUD) -> Builds\Windows\NdFps.exe. Status: . Next: check Builds\auto_unity_status.txt, then work TaskBoard 'Auto next actions' with tools.
