# Auto studio pipeline run (ShopKeep)

Tags: auto studio pipeline
Saved: 2026-11-05T09:32:30

run_auto_game_pipeline created 32 files under C:\Users\ExtremeHybrid\Documents\GameProjects\ShopKeep and UNITY 6000.6.5f1: background job started -> create ShopKeepUnity -> Assets/Scenes/Slice01.unity (grey-box, player, goal, HUD) -> Builds\Windows\ShopKeep.exe. St. Next: check Builds\auto_unity_status.txt, then work TaskBoard 'Auto next actions' with tools.
