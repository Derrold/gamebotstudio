# Auto studio pipeline run (QaRoyaleTwoInUnity)

Tags: auto studio pipeline
Saved: 2026-11-17T05:45:04

run_auto_game_pipeline created 34 files under C:\Users\Derrold PC\Documents\GameProjects\QaRoyaleTwoInUnity and UNITY 6000.6.5f1: background job started -> create QaRoyaleTwoInUnityUnity -> Battle Royale game (gameplay template: battle_royale; menu, settings, achievements. Next: check Builds\auto_unity_status.txt, then work TaskBoard 'Auto next actions' with tools.
