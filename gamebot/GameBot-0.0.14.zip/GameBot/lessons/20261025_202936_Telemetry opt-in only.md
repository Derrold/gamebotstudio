# Telemetry opt-in only

Tags: analytics privacy
Saved: 2026-10-25T20:29:36

Default no telemetry for local-first games; if added: consent first (Unity Analytics StartDataCollection after opt-in), privacy policy update, few events. Source: https://docs.unity.com/ugs/en-us/manual/analytics/manual/overview
