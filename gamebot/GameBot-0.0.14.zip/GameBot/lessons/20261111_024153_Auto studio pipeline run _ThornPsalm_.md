# Auto studio pipeline run (ThornPsalm)

Tags: auto studio pipeline
Saved: 2026-11-11T02:41:53

run_auto_game_pipeline created 33 files under C:\Users\ExtremeHybrid\Documents\GameProjects\ThornPsalm and UNITY 6000.6.5f1: background job started -> create ThornPsalmUnity -> RPG game (gameplay template: rpg; menu, settings, achievements, owned assets) -> Builds\Wi. Next: check Builds\auto_unity_status.txt, then work TaskBoard 'Auto next actions' with tools.
