# Steamworks SDK integration (Unity)
Sources: https://partner.steamgames.com/doc/sdk/api | https://partner.steamgames.com/doc/api/steam_api | https://partner.steamgames.com/doc/features/achievements | https://partner.steamgames.com/doc/features/achievements/stats_guide | https://steamworks.github.io/ (Steamworks.NET) | https://wiki.facepunch.com/steamworks/ (Facepunch.Steamworks) | https://partner.steamgames.com/doc/features/overlay | https://partner.steamgames.com/doc/features/cloud

## Pick a wrapper
- Steamworks.NET (C# 1:1 API, MIT) or Facepunch.Steamworks (friendlier C#). Install via package/UPM git URL. Ships steam_api64.dll in Plugins.

## Init pattern (Steamworks.NET)
- On boot (singleton DontDestroyOnLoad SteamManager): if (SteamAPI.RestartAppIfNecessary(new AppId_t(APPID))) { Application.Quit(); return; }  then ok = SteamAPI.Init(); if !ok -> run without Steam features (log, don't crash in dev).
- Every frame: SteamAPI.RunCallbacks(). On quit: SteamAPI.Shutdown().
- APPID: ONLY the real App ID from the Steamworks partner dashboard (the creator provides). NEVER invent one. App 480 (Spacewar) only for local sample testing.
- steam_appid.txt: next to the .exe during dev, contains only the App ID; DO NOT ship it (exclude from depot / installer).
- Init fails when: Steam not running, no app id, different user/admin context, account doesn't own app, app not configured.

## Achievements & stats
- Define in Steamworks > Stats & Achievements (API names like ACH_FIRST_BUCK), publish.
- Code: SteamUserStats.SetAchievement("ACH_FIRST_BUCK"); SteamUserStats.StoreStats();  stats: SetStat("deer_harvested", n) + StoreStats. Progress: IndicateAchievementProgress. SDK 1.61+ loads stats automatically (RequestCurrentStats no longer needed). Batch StoreStats (end of hunt), don't call every frame.
- Test reset: SteamUserStats.ResetAllStats(true) in dev only.

## Other features
- Overlay: works with DX11/12/Vulkan; pause game on GameOverlayActivated callback.
- Steam Cloud: Auto-Cloud (configure paths in Steamworks, e.g. PlayerPrefs registry not supported -> move saves to files in Application.persistentDataPath first) or ISteamRemoteStorage.
- Rich presence, screenshots, Steam Input (controllers/Deck), leaderboards.

## Verify
- Dev build launched from Steam (or with steam_appid.txt) shows overlay (Shift+Tab), achievement unlocks, then relock via reset.
