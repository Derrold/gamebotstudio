| genre | title | intake | menus | settings | assets | DONE OK | notes |
|---|---|---|---|---|---|---|---|
| platformer | TrailFox | Y | Y | Y | Y | Y | prior E2E; packs on disk |
| fps | IronSight | Y | Y | Y | Y | Y | DONE OK; ShotGun + Gun Icons imported |
| racing | RidgeRush | Y | Y | Y | Y | Y | RUNNING |
| horror | QuietHalls | Y | Y | Y | Y | Y | RUNNING |
| rpg | EmberQuest | Y | Y | Y | Y | Y | RUNNING |
| puzzle | BlockShift | Y | Y | Y | Y | Y | RUNNING |
| survival | CampForge | Y | Y | Y | Y | Y | RUNNING |
| adventure | MapWalker | Y | Y | Y | Y | Y | RUNNING |
| sim | ShopKeep | Y | Y | Y | Y | Y | RUNNING |
| roguelike | DieAgain | Y | Y | Y | Y | Y | RUNNING |