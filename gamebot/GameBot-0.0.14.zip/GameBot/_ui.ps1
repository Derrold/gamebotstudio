param([string]$Action="shot",[string]$Text="",[string]$Out="C:\Users\ExtremeHybrid\ollama-web\_ui_shot.png")
Add-Type -AssemblyName System.Windows.Forms,System.Drawing
Add-Type @"
using System; using System.Runtime.InteropServices;
public class W { [DllImport("user32.dll")] public static extern bool SetForegroundWindow(IntPtr h);
 [DllImport("user32.dll")] public static extern bool ShowWindow(IntPtr h,int c);
 [DllImport("user32.dll")] public static extern bool GetWindowRect(IntPtr h,out RECT r);
 [DllImport("user32.dll")] public static extern bool SetCursorPos(int x,int y);
 [DllImport("user32.dll")] public static extern void mouse_event(int f,int x,int y,int d,int e);
 [StructLayout(LayoutKind.Sequential)] public struct RECT { public int L,T,R,B; } }
"@
function Win { Get-Process | ? { $_.MainWindowTitle -eq 'Game Bot' } | Select -First 1 }
$p = Win
if (-not $p) { "NO WINDOW"; exit 1 }
$h = $p.MainWindowHandle
[W]::ShowWindow($h,9) | Out-Null; [W]::SetForegroundWindow($h) | Out-Null; Start-Sleep -Milliseconds 400
$r = New-Object W+RECT; [W]::GetWindowRect($h,[ref]$r) | Out-Null
"win pid=$($p.Id) rect=$($r.L),$($r.T),$($r.R),$($r.B)"
if ($Action -eq "click") { $xy=$Text.Split(','); [W]::SetCursorPos($r.L+[int]$xy[0],$r.T+[int]$xy[1]); Start-Sleep -Milliseconds 150; [W]::mouse_event(2,0,0,0,0); [W]::mouse_event(4,0,0,0,0); "clicked" }
if ($Action -eq "type") { [System.Windows.Forms.SendKeys]::SendWait(($Text -replace '([+^%~(){}\[\]])','{$1}')); Start-Sleep -Milliseconds 300; [System.Windows.Forms.SendKeys]::SendWait("{ENTER}"); "typed+enter" }
Start-Sleep -Milliseconds 500
$w=$r.R-$r.L; $hh=$r.B-$r.T
$bmp = New-Object Drawing.Bitmap $w,$hh; $g=[Drawing.Graphics]::FromImage($bmp); $g.CopyFromScreen($r.L,$r.T,0,0,$bmp.Size); $bmp.Save($Out); "shot $Out"
