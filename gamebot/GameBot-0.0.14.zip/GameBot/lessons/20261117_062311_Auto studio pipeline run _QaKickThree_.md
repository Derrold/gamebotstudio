# Auto studio pipeline run (QaKickThree)

Tags: auto studio pipeline
Saved: 2026-11-17T06:23:11

run_auto_game_pipeline created 34 files under C:\Users\Derrold PC\Documents\GameProjects\QaKickThree and UNITY 6000.6.5f1: background job started -> create QaKickThreeUnity -> Sports game (gameplay template: sports; menu, settings, achievements, owned genre kit) ->. Next: check Builds\auto_unity_status.txt, then work TaskBoard 'Auto next actions' with tools.
