# Auto studio pipeline run (NightWatch)

Tags: auto studio pipeline
Saved: 2026-11-05T10:37:04

run_auto_game_pipeline created 32 files under C:\Users\ExtremeHybrid\Documents\GameProjects\NightWatch and UNITY 6000.6.5f1: background job started -> create NightWatchUnity -> horror game (menu, settings, achievements, owned assets) -> Builds\Windows\NightWatch.exe.. Next: check Builds\auto_unity_status.txt, then work TaskBoard 'Auto next actions' with tools.
