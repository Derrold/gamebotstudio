# Blender Python FBX export for Unity

Tags: blender unity fbx
Saved: 2026-10-25T20:07:13

To export a model from Blender to Unity, use bpy.ops.export_scene.fbx with parameters such as axis_forward='-Z', axis_up='Y' and apply_scale_options='FBX_SCALE_UNITS'. This ensures the model has correct size and orientation when used in Unity.
