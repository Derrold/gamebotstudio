using UnityEngine;
/// <summary>MOBA hero: right-click move/attack (or WASD), Q shockwave, E heal, respawn at base; follow camera; minion waves for both teams.</summary>
public class MobaHero : MonoBehaviour
{
    public GameObject allyMinionTpl, enemyMinionTpl; public Transform allyBase, enemyBase; public float waveEvery = 22f;
    public float respawnAt = -1; RtsUnit unit; Camera cam; float qCd, eCd; float nextWave = 3f; Vector3 spawn;
    void Start() { unit = GetComponent<RtsUnit>(); cam = Camera.main; spawn = transform.position; Cursor.lockState = CursorLockMode.None; Cursor.visible = true; GenreState.EnemyTowers = 0; foreach (var u in FindObjectsByType<RtsUnit>(FindObjectsSortMode.None)) if (u.team == 1 && u.kind == "tower") GenreState.EnemyTowers++; }
    public void Died() { respawnAt = Time.time + 6f; transform.position = new Vector3(0, -50, 0); GameState.Deaths++; GameHUD.Flash("You were slain - respawning in 6s"); }
    void Update()
    {
        if (GameState.Won || GameState.Lost || PauseMenu.IsPaused || MainMenuUI.InMenu) return;
        Cursor.lockState = CursorLockMode.None; Cursor.visible = true;
        if (Time.timeSinceLevelLoad >= nextWave) { nextWave = Time.timeSinceLevelLoad + waveEvery; Wave(allyMinionTpl, allyBase, enemyBase); Wave(enemyMinionTpl, enemyBase, allyBase); }
        if (respawnAt > 0) { if (Time.time >= respawnAt) { respawnAt = -1; transform.position = spawn; } return; }
        unit.dmg = 10 + GenreState.Level * 4; unit.maxHp = 220 + GenreState.Level * 40;
        if (Input.GetMouseButtonDown(1) && Physics.Raycast(cam.ScreenPointToRay(Input.mousePosition), out var hit, 500f)) { var en = hit.collider.GetComponentInParent<RtsUnit>(); unit.moveTo = en && en.team == 1 ? en.transform.position : hit.point; unit.attackMove = en != null; }
        Vector3 mv = new Vector3((Input.GetKey(KeyCode.D) ? 1 : 0) - (Input.GetKey(KeyCode.A) ? 1 : 0), 0, (Input.GetKey(KeyCode.W) ? 1 : 0) - (Input.GetKey(KeyCode.S) ? 1 : 0));
        if (mv.sqrMagnitude > 0) { unit.moveTo = transform.position + mv.normalized * 2f; unit.attackMove = false; }
        qCd -= Time.deltaTime; eCd -= Time.deltaTime; GenreState.SkillCd = Mathf.Max(0, qCd); GenreState.HealCd = Mathf.Max(0, eCd);
        if (Input.GetKeyDown(KeyCode.Q) && qCd <= 0)
        {
            qCd = 6f; int hits = 0; foreach (var u in GbCombat.All.ToArray()) if (u != null && !u.Dead && u.Team == 1 && u.Tr && Vector3.Distance(u.Tr.position, transform.position) < 7f) { u.Damage(45 + GenreState.Level * 10, 0); hits++; }
            var fx = GameObject.CreatePrimitive(PrimitiveType.Sphere); Destroy(fx.GetComponent<Collider>()); fx.transform.position = transform.position; fx.transform.localScale = Vector3.one * 14f; fx.GetComponent<Renderer>().material.color = new Color(0.3f, 0.6f, 1f); Destroy(fx, 0.15f);
            if (hits >= 3) AchievementSystem.Unlock("shockwave_3");
        }
        if (Input.GetKeyDown(KeyCode.E) && eCd <= 0) { eCd = 12f; unit.hp = Mathf.Min(unit.maxHp, unit.hp + 120); GameHUD.Flash("Healed"); }
        GenreState.Health = unit.hp; GenreState.MaxHealth = unit.maxHp;
    }
    void Wave(GameObject tpl, Transform from, Transform to)
    {
        if (!tpl || !from || !to) return;
        for (int i = 0; i < 4; i++) { var m = Instantiate(tpl, from.position + new Vector3(i * 1.3f - 2f, 0, (to.position.z > from.position.z ? 8 : -8)), Quaternion.identity); m.SetActive(true); var u = m.GetComponent<RtsUnit>(); u.hasLane = true; u.lanePush = to.position; }
    }
    void LateUpdate() { if (cam && respawnAt < 0) { cam.transform.position = Vector3.Lerp(cam.transform.position, transform.position + new Vector3(0, 26f, -15f), Time.deltaTime * 5f); cam.transform.rotation = Quaternion.Euler(60, 0, 0); } }
    void OnGUI()
    {
        if (MainMenuUI.InMenu) return; var s = new GUIStyle(GUI.skin.box) { fontSize = 18 };
        GUI.Box(new Rect(16, Screen.height - 64, 200, 48), "Q Shockwave " + (qCd > 0 ? Mathf.CeilToInt(qCd) + "s" : "READY"), s);
        GUI.Box(new Rect(226, Screen.height - 64, 180, 48), "E Heal " + (eCd > 0 ? Mathf.CeilToInt(eCd) + "s" : "READY"), s);
        if (respawnAt > 0) GUI.Box(new Rect(Screen.width / 2 - 150, Screen.height / 2 - 30, 300, 60), "Respawning in " + Mathf.CeilToInt(respawnAt - Time.time) + "s", s);
    }
}
