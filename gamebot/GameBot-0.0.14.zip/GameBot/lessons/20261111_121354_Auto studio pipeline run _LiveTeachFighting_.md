# Auto studio pipeline run (LiveTeachFighting)

Tags: auto studio pipeline
Saved: 2026-11-11T12:13:54

run_auto_game_pipeline created 33 files under C:\Users\ExtremeHybrid\Documents\GameProjects\LiveTeachFighting and UNITY 6000.6.5f1: background job started -> create LiveTeachFightingUnity -> Fighting game (gameplay template: fighting; menu, settings, achievements, owned gen. Next: check Builds\auto_unity_status.txt, then work TaskBoard 'Auto next actions' with tools.
