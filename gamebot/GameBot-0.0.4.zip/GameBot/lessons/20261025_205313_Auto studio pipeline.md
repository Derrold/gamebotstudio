# Auto studio pipeline

Tags: auto studio pipeline
Saved: 2026-10-25T20:53:13

New game request -> run_auto_game_pipeline immediately: GDD, TaskBoard, legal, QA, site, ship prep, Unity background job (Builds\auto_unity_status.txt). Never ask permission; report real paths and human gates.
