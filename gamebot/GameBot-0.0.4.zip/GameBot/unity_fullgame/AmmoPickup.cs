﻿using UnityEngine;

public class AmmoPickup : MonoBehaviour
{
    void Update() { transform.Rotate(0, 90 * Time.deltaTime, 0); }
    void OnTriggerEnter(Collider o) { if (!o.CompareTag("Player")) return; GenreState.Reserve += 24; Destroy(gameObject); }
}

