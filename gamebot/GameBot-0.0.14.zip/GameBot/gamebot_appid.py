"""Windows AppUserModelID and window-icon branding for Game Bot.

The installer shortcut System.AppUserModel.ID, the branded GameBot.exe
launcher, and the pywebview process must all use AUMID so the taskbar
groups under the Game Bot desktop icon instead of a generic Python icon.
"""
from __future__ import annotations

import ctypes
import os
import sys
from ctypes import POINTER, byref, c_ulong, c_void_p, c_wchar_p, sizeof, wintypes
from pathlib import Path

AUMID = "AlphaMaxStudios.GameBot"
DISPLAY_NAME = "Game Bot"
ICON_REL = Path("icons") / "game-bot-site.ico"
# Taskbar / title-bar sizes requested for the shared .ico
ICON_SIZES = (16, 24, 32, 48, 256)

ROOT = Path(__file__).resolve().parent


def icon_path() -> Path:
    raw = os.environ.get("GAMEBOT_ICON", "")
    if raw:
        p = Path(raw)
        if p.is_file():
            return p
    p = ROOT / ICON_REL
    return p


def launcher_path() -> Path:
    exe = ROOT / "GameBot.exe"
    return exe if exe.is_file() else Path(sys.executable)


def set_current_aumid(aumid: str = AUMID) -> bool:
    """Call SetCurrentProcessExplicitAppUserModelID before any window is created."""
    if sys.platform != "win32":
        return False
    try:
        shell32 = ctypes.windll.shell32
        shell32.SetCurrentProcessExplicitAppUserModelID.argtypes = [c_wchar_p]
        shell32.SetCurrentProcessExplicitAppUserModelID.restype = ctypes.HRESULT
        hr = shell32.SetCurrentProcessExplicitAppUserModelID(str(aumid))
        return int(hr) == 0
    except Exception:
        return False


def get_current_aumid() -> str | None:
    if sys.platform != "win32":
        return None
    try:
        shell32 = ctypes.windll.shell32
        ole32 = ctypes.windll.ole32
        ptr = c_wchar_p()
        shell32.GetCurrentProcessExplicitAppUserModelID.argtypes = [POINTER(c_wchar_p)]
        shell32.GetCurrentProcessExplicitAppUserModelID.restype = ctypes.HRESULT
        hr = shell32.GetCurrentProcessExplicitAppUserModelID(byref(ptr))
        if int(hr) != 0 or not ptr.value:
            return None
        val = str(ptr.value)
        ole32.CoTaskMemFree(ptr)
        return val
    except Exception:
        return None


# --- Win32 helpers for icon + window property store ---

IMAGE_ICON = 1
LR_LOADFROMFILE = 0x0010
WM_SETICON = 0x0080
ICON_SMALL = 0
ICON_BIG = 1
GCLP_HICON = -14
GCLP_HICONSM = -34
SM_CXSMICON = 49
SM_CYSMICON = 50
SM_CXICON = 11
SM_CYICON = 12
GA_ROOT = 2


def _user32():
    u = ctypes.windll.user32
    u.LoadImageW.argtypes = [wintypes.HINSTANCE, c_wchar_p, wintypes.UINT, ctypes.c_int, ctypes.c_int, wintypes.UINT]
    u.LoadImageW.restype = wintypes.HANDLE
    u.SendMessageW.argtypes = [wintypes.HWND, wintypes.UINT, wintypes.WPARAM, wintypes.LPARAM]
    u.SendMessageW.restype = wintypes.LPARAM
    # PostMessageW: never block the WebView UI thread (SendMessage to this hwnd from a
    # shown-hook or another thread can deadlock the desktop window).
    u.PostMessageW.argtypes = [wintypes.HWND, wintypes.UINT, wintypes.WPARAM, wintypes.LPARAM]
    u.PostMessageW.restype = wintypes.BOOL
    u.GetWindowThreadProcessId.argtypes = [wintypes.HWND, POINTER(wintypes.DWORD)]
    u.GetWindowThreadProcessId.restype = wintypes.DWORD
    u.IsWindowVisible.argtypes = [wintypes.HWND]
    u.IsWindowVisible.restype = wintypes.BOOL
    u.GetWindowTextW.argtypes = [wintypes.HWND, c_wchar_p, ctypes.c_int]
    u.GetWindowTextW.restype = ctypes.c_int
    u.GetAncestor.argtypes = [wintypes.HWND, wintypes.UINT]
    u.GetAncestor.restype = wintypes.HWND
    return u


def _load_icon(path: Path, size: int):
    u = _user32()
    handle = u.LoadImageW(None, str(path), IMAGE_ICON, int(size), int(size), LR_LOADFROMFILE)
    return handle or None


def _icon_sizes_for_window(hwnd: int) -> tuple[int, int]:
    u = _user32()
    try:
        u.GetDpiForWindow.argtypes = [wintypes.HWND]
        u.GetDpiForWindow.restype = wintypes.UINT
        dpi = int(u.GetDpiForWindow(hwnd) or 96)
    except Exception:
        dpi = 96
    scale = max(dpi, 96) / 96.0
    small = 16 if scale < 1.4 else 24
    big = 32 if scale < 1.4 else 48
    try:
        cx_sm = int(u.GetSystemMetrics(SM_CXSMICON) or 0)
        cx = int(u.GetSystemMetrics(SM_CXICON) or 0)
        if cx_sm in ICON_SIZES:
            small = cx_sm
        if cx in ICON_SIZES:
            big = cx
    except Exception:
        pass
    return small, big


def apply_window_icons(hwnd: int, ico: Path | None = None) -> bool:
    """Set WM_SETICON and the class icons from the multi-size .ico."""
    if sys.platform != "win32" or not hwnd:
        return False
    path = ico or icon_path()
    if not path.is_file():
        return False
    u = _user32()
    small, big = _icon_sizes_for_window(hwnd)
    h_small = _load_icon(path, small)
    h_big = _load_icon(path, big)
    if not h_small and not h_big:
        return False
    if h_small:
        u.PostMessageW(hwnd, WM_SETICON, ICON_SMALL, h_small)
    if h_big:
        u.PostMessageW(hwnd, WM_SETICON, ICON_BIG, h_big)
    try:
        if sizeof(c_void_p) == 8:
            setter = u.SetClassLongPtrW
            setter.argtypes = [wintypes.HWND, ctypes.c_int, ctypes.c_longlong]
            setter.restype = ctypes.c_longlong
        else:
            setter = u.SetClassLongW
            setter.argtypes = [wintypes.HWND, ctypes.c_int, ctypes.c_long]
            setter.restype = ctypes.c_ulong
        if h_big:
            setter(hwnd, GCLP_HICON, h_big)
        if h_small:
            setter(hwnd, GCLP_HICONSM, h_small)
    except Exception:
        pass
    return True


# PROPERTYKEY / PROPVARIANT / IPropertyStore via vtable
class _GUID(ctypes.Structure):
    _fields_ = [
        ("Data1", ctypes.c_uint32),
        ("Data2", ctypes.c_uint16),
        ("Data3", ctypes.c_uint16),
        ("Data4", ctypes.c_ubyte * 8),
    ]


class _PROPERTYKEY(ctypes.Structure):
    _fields_ = [("fmtid", _GUID), ("pid", ctypes.c_uint32)]


class _PROPVARIANT(ctypes.Structure):
    _fields_ = [
        ("vt", ctypes.c_ushort),
        ("wReserved1", ctypes.c_ushort),
        ("wReserved2", ctypes.c_ushort),
        ("wReserved3", ctypes.c_ushort),
        ("pwszVal", c_void_p),
        ("pad", ctypes.c_uint64),
    ]


def _guid(s: str) -> _GUID:
    g = _GUID()
    ctypes.windll.ole32.CLSIDFromString.argtypes = [c_wchar_p, POINTER(_GUID)]
    ctypes.windll.ole32.CLSIDFromString.restype = ctypes.HRESULT
    hr = ctypes.windll.ole32.CLSIDFromString(s, byref(g))
    if int(hr) != 0:
        raise OSError(f"CLSIDFromString {s} hr={hr}")
    return g


def _vtbl(punk: c_void_p, index: int, *types):
    p = ctypes.cast(punk, POINTER(c_void_p))
    vtbl = ctypes.cast(p[0], POINTER(c_void_p))
    return ctypes.WINFUNCTYPE(*types)(vtbl[index])


_PKEY_FMTID = "{9F4C2855-9F79-4B39-A8D0-E1D42DE1D5F3}"
# pid 5 = System.AppUserModel.ID
# pid 2 = System.AppUserModel.RelaunchCommand
# pid 3 = System.AppUserModel.RelaunchIconResource
# pid 4 = System.AppUserModel.RelaunchDisplayNameResource
_PID_RELAUNCH_CMD = 2
_PID_RELAUNCH_ICON = 3
_PID_RELAUNCH_NAME = 4
_PID_AUMID = 5


VT_LPWSTR = 31


def _prop_from_string(value: str) -> _PROPVARIANT:
    """Build a VT_LPWSTR PROPVARIANT without InitPropVariantFromString (missing on some Windows)."""
    pv = _PROPVARIANT()
    pv.vt = VT_LPWSTR
    ole32 = ctypes.windll.ole32
    ole32.CoTaskMemAlloc.restype = c_void_p
    ole32.CoTaskMemAlloc.argtypes = [ctypes.c_size_t]
    n = (len(value) + 1) * ctypes.sizeof(ctypes.c_wchar)
    ptr = ole32.CoTaskMemAlloc(n)
    if not ptr:
        raise MemoryError("CoTaskMemAlloc")
    buf = ctypes.create_unicode_buffer(value)
    ctypes.memmove(ptr, buf, n)
    pv.pwszVal = ptr
    return pv


def _set_store_string(store: c_void_p, pid: int, value: str) -> int:
    key = _PROPERTYKEY()
    key.fmtid = _guid(_PKEY_FMTID)
    key.pid = pid
    pv = _prop_from_string(value)
    SetValue = _vtbl(
        store,
        6,
        ctypes.HRESULT,
        c_void_p,
        POINTER(_PROPERTYKEY),
        POINTER(_PROPVARIANT),
    )
    hr = SetValue(store, byref(key), byref(pv))
    ctypes.windll.ole32.PropVariantClear.argtypes = [POINTER(_PROPVARIANT)]
    ctypes.windll.ole32.PropVariantClear(byref(pv))
    return int(hr)


def apply_window_aumid_props(hwnd: int, aumid: str = AUMID) -> bool:
    """Stamp the window property store so the taskbar uses our AUMID and icon."""
    if sys.platform != "win32" or not hwnd:
        return False
    ole32 = ctypes.windll.ole32
    shell32 = ctypes.windll.shell32
    try:
        ole32.CoInitialize(None)
    except Exception:
        pass
    iid = _guid("{886D8EEB-8CF2-4446-8D02-CDBA1DBDCF99}")
    store = c_void_p()
    shell32.SHGetPropertyStoreForWindow.argtypes = [wintypes.HWND, POINTER(_GUID), POINTER(c_void_p)]
    shell32.SHGetPropertyStoreForWindow.restype = ctypes.HRESULT
    hr = shell32.SHGetPropertyStoreForWindow(hwnd, byref(iid), byref(store))
    if int(hr) != 0 or not store.value:
        return False
    ok = True
    ico = icon_path()
    exe = launcher_path()
    values = [
        (_PID_AUMID, aumid),
        (_PID_RELAUNCH_CMD, f'"{exe}"'),
        (_PID_RELAUNCH_NAME, DISPLAY_NAME),
    ]
    if ico.is_file():
        values.append((_PID_RELAUNCH_ICON, f"{ico},0"))
    elif exe.is_file():
        values.append((_PID_RELAUNCH_ICON, f"{exe},0"))
    for pid, val in values:
        if _set_store_string(store, pid, val) != 0:
            ok = False
    Commit = _vtbl(store, 7, ctypes.HRESULT, c_void_p)
    if int(Commit(store)) != 0:
        ok = False
    Release = _vtbl(store, 2, c_ulong, c_void_p)
    Release(store)
    return ok


def hwnd_from_native(window) -> int | None:
    native = getattr(window, "native", None)
    if native is None:
        return None
    handle = getattr(native, "Handle", None)
    if handle is None:
        handle = getattr(native, "handle", None)
    if handle is None:
        return None
    try:
        return int(handle.ToInt64())
    except Exception:
        try:
            return int(handle)
        except Exception:
            return None


def find_process_hwnd(title: str = DISPLAY_NAME) -> int | None:
    if sys.platform != "win32":
        return None
    u = _user32()
    pid = os.getpid()
    found: list[int] = []
    WNDENUMPROC = ctypes.WINFUNCTYPE(wintypes.BOOL, wintypes.HWND, wintypes.LPARAM)

    def _enum(hwnd, _lparam):
        if not u.IsWindowVisible(hwnd):
            return True
        cpid = wintypes.DWORD()
        u.GetWindowThreadProcessId(hwnd, byref(cpid))
        if int(cpid.value) != pid:
            return True
        buf = ctypes.create_unicode_buffer(512)
        u.GetWindowTextW(hwnd, buf, 512)
        text = buf.value or ""
        if title.lower() in text.lower() or not found:
            found.append(int(hwnd))
        return True

    cb = WNDENUMPROC(_enum)
    u.EnumWindows(cb, 0)
    # Prefer a title match
    for hwnd in found:
        buf = ctypes.create_unicode_buffer(512)
        u.GetWindowTextW(hwnd, buf, 512)
        if title.lower() in (buf.value or "").lower():
            return hwnd
    return found[0] if found else None


def apply_winforms_icon(window, ico: Path | None = None) -> bool:
    path = ico or icon_path()
    if not path.is_file():
        return False
    native = getattr(window, "native", None)
    if native is None:
        return False
    try:
        # pywebview WinForms + pythonnet
        from System.Drawing import Icon as WinIcon  # type: ignore
        native.Icon = WinIcon(str(path))
        if hasattr(native, "ShowIcon"):
            native.ShowIcon = True
        return True
    except Exception:
        return False


def apply_window_branding(window=None, hwnd: int | None = None) -> dict:
    """Apply AUMID props + multi-size icons to the Game Bot window."""
    info = {"hwnd": None, "icons": False, "props": False, "winforms": False, "aumid": get_current_aumid()}
    if hwnd is None and window is not None:
        hwnd = hwnd_from_native(window)
        info["winforms"] = apply_winforms_icon(window)
    if hwnd is None:
        hwnd = find_process_hwnd()
    if not hwnd:
        return info
    # If we received a child handle, promote to the root owner
    try:
        root = int(_user32().GetAncestor(hwnd, GA_ROOT) or hwnd)
        hwnd = root or hwnd
    except Exception:
        pass
    info["hwnd"] = int(hwnd)
    info["icons"] = apply_window_icons(hwnd)
    info["props"] = apply_window_aumid_props(hwnd)
    return info


def ico_sizes(path: Path | None = None) -> list[tuple[int, int, int]]:
    """Return (width, height, bpp) entries from a .ico file."""
    import struct
    p = path or icon_path()
    data = Path(p).read_bytes()
    if data[:4] != b"\x00\x00\x01\x00":
        return []
    n = struct.unpack_from("<H", data, 4)[0]
    out = []
    for i in range(n):
        off = 6 + i * 16
        w, h, _colors, _res, _planes, bpp, _nbytes, _imgoff = struct.unpack_from("<BBBBHHII", data, off)
        out.append((w or 256, h or 256, bpp))
    return out
