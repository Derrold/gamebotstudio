"""Game Bot UI - local chat with Context meter + live working status."""
from __future__ import annotations

import os
import threading
import time
import traceback
import uuid

import license_bind
license_bind.enforce()
from editions import load_edition
_ED = load_edition()
from flask import Flask, jsonify, render_template, request

from agent_core import (
    MODEL, _TURN, new_session, progress_report, run_turn, shutdown_tools,
    unity_bg_status, wants_status,
)
import session_hygiene as SH
import chat_store

app = Flask(__name__)
app.config["TEMPLATES_AUTO_RELOAD"] = True
app.jinja_env.auto_reload = True
SESSIONS: dict[str, list] = {}
LOCK = threading.Lock()


@app.get("/")
def index():
    return render_template("index.html", model=MODEL)


_RUN = threading.Lock()          # one model turn at a time (Ollama + Unity are single-job)
_QUEUE: list = []                # (sid, text) sent while a turn was running - run in order, never dropped
_QSEQ = {"n": 0, "last_sid": ""}  # bumps when a queued turn finishes so the UI reloads that chat


def _bad_sid(sid: str) -> bool:
    return bool(sid) and not chat_store.valid_sid(sid)


@app.post("/api/chat")
def api_chat():
    data = request.get_json(force=True, silent=True) or {}
    text = (data.get("message") or "").strip()
    sid = (data.get("session_id") or "").strip() or str(uuid.uuid4())
    if not text:
        return jsonify({"error": "empty"}), 400
    if _bad_sid(sid):
        return jsonify({"error": "invalid chat id"}), 400

    # Status / eta while a turn is running: answer from live progress, never start a second model turn.
    if wants_status(text):
        with LOCK:
            msgs = list(SESSIONS.get(sid) or [])
        return jsonify({
            "session_id": sid,
            "answer": progress_report(),
            "events": [],
            "model": MODEL,
            "status_only": True,
            "context": SH.meter(msgs) if msgs else SH.meter([]),
        })
    if not _RUN.acquire(blocking=False):
        with LOCK:
            _QUEUE.append((sid, text))
            n = len(_QUEUE)
        return jsonify({
            "session_id": sid,
            "answer": (f"Got it - I'm still working on the last request, so I queued this (#{n} in line). "
                       "I'll start it as soon as the current job finishes and the reply will appear in this chat.\n" + progress_report()),
            "events": [],
            "model": MODEL,
            "status_only": True,
            "queued": n,
        })
    try:
        payload, code = _turn(sid, text)
    finally:
        _RUN.release()
        _kick_queue()
    return jsonify(payload), code


def _kick_queue() -> None:
    with LOCK:
        if not _QUEUE:
            return
    threading.Thread(target=_drain_queue, daemon=True).start()


def _drain_queue() -> None:
    while True:
        if not _RUN.acquire(blocking=False):
            return  # another turn is running; it drains when it finishes
        try:
            with LOCK:
                if not _QUEUE:
                    return
                qsid, qtext = _QUEUE.pop(0)
            if chat_store.is_deleted(qsid):
                continue
            try:
                _turn(qsid, qtext)
            except Exception as e:
                print("queued turn failed:", e, flush=True)
            _QSEQ["n"] += 1
            _QSEQ["last_sid"] = qsid
        finally:
            _RUN.release()


def _hygiene_reply(sid: str, messages: list, text: str):
    """Ask-before-clean (review fix 7): answers a pending clean-up question without a model turn."""
    try:
        if SH.pending(sid) and SH.is_yes(text):
            new, report = SH.clean(messages, sid=sid)
            SH.clear_pending(sid)
            return new, report
        if SH.pending(sid) and SH.is_no(text):
            return messages, SH.decline(sid, messages)
        if SH.wants_cleanup(text):
            SH._ASK.setdefault(sid, {"pending": False, "snooze_until": 0.0})["pending"] = True
            return messages, SH.proposal(messages) + "\n\nSay yes to clean up, or no to keep everything."
    except Exception as e:
        print("hygiene:", e, flush=True)
    return None


def _turn(sid: str, text: str):
    with LOCK:
        if sid not in SESSIONS:
            # backend restarted (update, crash, reboot): pick the saved chat back up instead of starting over
            try:
                saved = chat_store.load_chat(sid)
            except Exception:
                saved = None
            SESSIONS[sid] = (saved or {}).get("messages") or new_session()
        messages = list(SESSIONS[sid])

    events: list[dict] = []

    def on_event(ev: dict) -> None:
        events.append(ev)

    hy = _hygiene_reply(sid, messages, text)
    if hy is not None:
        messages, answer = hy
        messages = list(messages) + [{"role": "user", "content": text}, {"role": "assistant", "content": answer}]
        try:
            chat_store.save_messages(sid, messages)
        except Exception:
            pass
        with LOCK:
            SESSIONS[sid] = messages
        return {"session_id": sid, "answer": answer, "events": [], "model": MODEL, "context": SH.meter(messages)}, 200

    messages.append({"role": "user", "content": text})
    SH._LIVE["sid"] = sid
    SH._LIVE["messages"] = messages
    SH._LIVE["last_user"] = text
    try:
        chat_store.save_messages(sid, messages)
    except Exception:
        pass
    try:
        messages, answer = run_turn(messages, on_event=on_event)
        try:
            ask = SH.after_turn(sid, messages)
            if ask:
                answer = (answer or "").rstrip() + "\n\n" + ask + "\n\nSay yes to clean up, or no to keep everything."
                if messages and messages[-1].get("role") == "assistant":
                    messages[-1] = dict(messages[-1], content=answer)
        except Exception as e:
            print("after_turn:", e, flush=True)
        try:
            old = sid
            sid = chat_store.adopt_game_chat(sid, messages) or sid
            if sid != old:
                with LOCK:
                    SESSIONS.pop(old, None)
            chat_store.write_summary(sid, messages)
            chat_store.save_messages(sid, messages)
        except Exception:
            pass
        with LOCK:
            SESSIONS[sid] = messages
        SH._LIVE["messages"] = messages
        return {
            "session_id": sid,
            "answer": answer if (answer or "").strip() else (progress_report() or "Started - check Working status."),
            "events": events,
            "model": MODEL,
            "context": SH.meter(messages),
        }, 200
    except Exception as e:
        err = f"{type(e).__name__}: {e}"
        tb = traceback.format_exc()
        print(tb, flush=True)
        ref = time.strftime("%Y%m%d_%H%M%S")
        try:
            (__import__("pathlib").Path(__file__).resolve().parent / "app_err_live.log").write_text(f"ref {ref}\n" + tb, encoding="utf-8")
        except Exception:
            pass
        low = err.lower() + " " + repr(e).lower()
        if str(e).startswith("Model server failed to start:") or "urlerror" in low or "10061" in low or "connection refused" in low:
            friendly = str(e) if str(e).startswith("Model server failed to start:") else f"Model server failed to start: {err}"
            return {"session_id": sid, "answer": friendly, "events": events, "model": MODEL}, 200
        return {
            "session_id": sid,
            "error": f"Something went wrong ({type(e).__name__}). Your chat is saved. If it keeps happening, press Report a bug (error ref {ref}).",
            "events": events,
            "model": MODEL,
        }, 500


@app.get("/api/progress")
def api_progress():
    busy = bool(_TURN.get("busy"))
    try:
        bar = chat_store.progress_bar()
    except Exception:
        bar = {}
    return jsonify({
        "busy": busy,
        "status": _TURN.get("status", "") if busy else "",
        "elapsed": int(time.time() - float(_TURN.get("since") or time.time())) if busy else 0,
        "bg": (unity_bg_status() if not busy else ""),
        "report": progress_report(),
        "bar": bar,
        "queued": len(_QUEUE),
        "queue_done": _QSEQ["n"],
        "queue_last_sid": _QSEQ["last_sid"],
    })


@app.get("/api/chats")
def api_chats():
    try:
        chats = chat_store.list_chats()
    except Exception as e:
        chats = []
        print("list_chats:", e, flush=True)
    return jsonify({"chats": chats})


@app.get("/api/chats/<sid>")
def api_chat_load(sid):
    if _bad_sid(sid):
        return jsonify({"error": "invalid chat id"}), 400
    data = chat_store.load_chat(sid)
    if not data:
        return jsonify({"error": "not found"}), 404
    with LOCK:
        SESSIONS[sid] = data["messages"]
    return jsonify({
        "session_id": sid,
        "messages": chat_store.ui_messages(data["messages"]),
        "summary": data.get("summary") or "",
        "title": data.get("title") or "",
        "game": data.get("game") or "",
        "engine": data.get("engine") or "",
    })


@app.delete("/api/chats/<sid>")
def api_chat_delete(sid):
    if _bad_sid(sid):
        return jsonify({"error": "invalid chat id"}), 400
    with LOCK:
        queued = any(q[0] == sid for q in _QUEUE)
    if queued or (_RUN.locked() and SH._LIVE.get("sid") == sid):
        return jsonify({"error": "busy", "message": "Game Bot is still working in this chat. Wait for it to finish, then delete."}), 409
    if not chat_store.delete_chat(sid):
        return jsonify({"error": "not found"}), 404
    with LOCK:
        SESSIONS.pop(sid, None)
    return jsonify({"ok": True, "session_id": sid, "trash": True,
                    "message": "Moved to trash (work/chats/_trash). It can be restored; your game folder is not touched."})


@app.post("/api/chats/<sid>/restore")
def api_chat_restore(sid):
    if _bad_sid(sid):
        return jsonify({"error": "invalid chat id"}), 400
    ok = chat_store.restore_chat(sid)
    return (jsonify({"ok": True, "session_id": sid}) if ok else (jsonify({"error": "not in trash"}), 404))


@app.get("/api/context")
def api_context():
    sid = (request.args.get("session_id") or "").strip()
    if _bad_sid(sid):
        sid = ""
    with LOCK:
        msgs = list(SESSIONS.get(sid) or [])
    if not msgs:
        msgs = new_session()
    try:
        pending = SH.pending(sid)
    except Exception:
        pending = False
    return jsonify(SH.meter(msgs) | {"pending": pending})


@app.post("/api/new")
def api_new():
    sid = str(uuid.uuid4())
    with LOCK:
        SESSIONS[sid] = new_session()
    return jsonify({"session_id": sid})


@app.post("/api/bug_report")
def api_bug_report():
    import gb_support
    data = request.get_json(force=True, silent=True) or {}
    sid = (data.get("session_id") or "").strip()
    if _bad_sid(sid):
        sid = ""
    desc = (data.get("description") or "").strip()[:5000]
    with LOCK:
        msgs = list(SESSIONS.get(sid) or [])
    if not msgs and sid:
        try:
            msgs = (chat_store.load_chat(sid) or {}).get("messages") or []
        except Exception:
            msgs = []
    try:
        r = gb_support.save_bug_report(desc, sid, msgs, include_chat=data.get("include_chat", True) is not False)
        return jsonify({"ok": True} | r)
    except Exception as e:
        return jsonify({"ok": False, "error": f"{type(e).__name__}: {e}"}), 500


@app.post("/api/bug_report/email")
def api_bug_email():
    import gb_support
    data = request.get_json(force=True, silent=True) or {}
    return jsonify(gb_support.open_bug_email(str(data.get("id") or "")))


@app.post("/api/bug_report/send")
def api_bug_send():
    import gb_support
    data = request.get_json(force=True, silent=True) or {}
    return jsonify(gb_support.send_bug_email(str(data.get("id") or "")))


@app.get("/api/bug_report/preview")
def api_bug_preview():
    import gb_support
    return jsonify(gb_support.preview_bug_report(str(request.args.get("id") or "")))


@app.post("/api/bug_report/discard")
def api_bug_discard():
    import gb_support
    data = request.get_json(force=True, silent=True) or {}
    return jsonify(gb_support.discard_bug_report(str(data.get("id") or "")))


@app.get("/api/bug_reports")
def api_bug_reports():
    import gb_support
    return jsonify({"reports": gb_support.list_bug_reports()})


@app.get("/api/hang_reports/pending")
def api_hang_pending():
    import gb_support
    return jsonify({"reports": gb_support.pending_hang_reports()})


@app.post("/api/hang_report/ack")
def api_hang_ack():
    import gb_support
    data = request.get_json(force=True, silent=True) or {}
    return jsonify(gb_support.ack_hang_report(str(data.get("key") or ""), str(data.get("state") or "prompted")))


@app.post("/api/hang_report/create")
def api_hang_create():
    import gb_support
    data = request.get_json(force=True, silent=True) or {}
    try:
        r = gb_support.create_hang_bug_report(str(data.get("key") or ""))
        return jsonify(r), (200 if r.get("ok") else 404)
    except Exception as e:
        return jsonify({"ok": False, "error": f"{type(e).__name__}: {e}"}), 500


@app.get("/api/update/check")
def api_update_check():
    import gb_support
    return jsonify(gb_support.check_update(force=request.args.get("force") == "1") | {"last": gb_support.last_update()})


@app.post("/api/update/install")
def api_update_install():
    import gb_support
    if _TURN.get("busy") or _RUN.locked() or _QUEUE:
        return jsonify({"ok": False, "message": "Game Bot is busy - install the update when the current job finishes."})
    return jsonify(gb_support.install_update())


@app.get("/api/health")
def health():
    return jsonify({"ok": True, "model": MODEL})


def main():
    try:
        import gb_support
        gb_support.check_update_async()  # update check on launch (shown as a banner in the window)
    except Exception:
        pass
    try:
        from ollama_ensure import ensure_ollama
        ensure_ollama(timeout=30)
    except Exception:
        pass
    try:
        from werkzeug.serving import make_server
        srv = make_server("127.0.0.1", int(os.environ.get("GAMEBOT_PORT", "7870")), app, threaded=True)
        try:
            srv.socket.set_inheritable(False)
        except Exception:
            pass
        srv.serve_forever()
    finally:
        shutdown_tools()


if __name__ == "__main__":
    main()
