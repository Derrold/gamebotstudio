# Auto studio pipeline run (DragonIsleRoyale)

Tags: auto studio pipeline
Saved: 2026-11-13T10:43:10

run_auto_game_pipeline created 34 files under C:\Users\ExtremeHybrid\Documents\GameProjects\DragonIsleRoyale and UNITY 6000.6.5f1: background job started -> create DragonIsleRoyaleUnity -> Battle Royale game (gameplay template: battle_royale; menu, settings, achievements, . Next: check Builds\auto_unity_status.txt, then work TaskBoard 'Auto next actions' with tools.
