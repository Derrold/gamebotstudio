# Batchmode content bake

Tags: unity batchmode bake
Saved: 2026-10-25T20:53:13

Scenes are outputs of a static Editor builder run with -batchmode -nographics -quit -executeMethod; one Unity per project; status file RUNNING/DONE OK/DONE FAIL; first error -> research_error -> patch -> retry once.
