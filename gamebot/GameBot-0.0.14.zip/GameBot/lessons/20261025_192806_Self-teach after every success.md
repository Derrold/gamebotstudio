# Self-teach after every success

Tags: learning
Saved: 2026-10-25T19:28:06

After any successful multi-step job, call teach_self with a reusable lesson (title + what tools/paths worked). After user corrects you, teach_self the correction immediately.
