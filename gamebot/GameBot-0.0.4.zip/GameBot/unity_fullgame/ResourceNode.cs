using UnityEngine;
/// <summary>Survival gatherable: wood (tree) or food (bush). Regrows after a while.</summary>
public class ResourceNode : MonoBehaviour
{
    public string kind = "wood"; float back; Renderer[] rs; Collider col;
    void Start() { rs = GetComponentsInChildren<Renderer>(); col = GetComponent<Collider>(); }
    void OnTriggerEnter(Collider o)
    {
        if (!o.CompareTag("Player") || back > Time.time) return;
        if (kind == "wood") GenreState.Wood++; else { GenreState.Food++; GenreState.Hunger = Mathf.Min(100, GenreState.Hunger + 30); }
        back = Time.time + 25f; foreach (var r in rs) r.enabled = false;
    }
    void Update() { if (back > 0 && Time.time > back) { back = 0; foreach (var r in rs) r.enabled = true; } }
}
