# Accessibility (beyond legal-menus)
Sources: https://gameaccessibilityguidelines.com/ | https://learn.microsoft.com/en-us/gaming/accessibility/guidelines | https://docs.unity3d.com/Packages/com.unity.inputsystem@1.11/manual/ActionBindings.html | https://partner.steamgames.com/doc/store/accessibility

## Must-haves (cheap, high value)
- Full input remapping (Unity Input System interactive rebinding; save overrides JSON); controller + KB/M; hold vs toggle for ADS/sprint/crouch.
- Subtitles + captions for important sounds (deer snort, grunt, shot direction) with size/background options.
- UI scale slider (80-150%), text size, high-contrast HUD option.
- Colorblind support: never color-only info (blood trail also shape/shine; map markers with icons); optional filter modes (protan/deutan/tritan).
- Comfort: FOV slider, head-bob off, camera shake slider, motion blur off, screen flash reduction.
- Difficulty/assist: aim assist (controller), ballistic helpers (range finder), slower deer alert, skip/redo tutorial (Tutorial.cs).
- Audio: separate volume sliders (master/music/sfx/ambience/voice), mono audio, visual indicator for sound direction.

## Steam store
- Steam accessibility tags section in store page; list features honestly.

## Verify
- Play 15 min with each: controller only, subtitles on, 150% UI at 1280x800, colorblind sim; record in Docs/QA.
