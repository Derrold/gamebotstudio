﻿# Mobile IAP + privacy
StoreKit/Google Billing via Unity IAP; privacy policy URL required; ATT/consent where needed; human gate for store console setup.
