# Auto studio pipeline run (OpenWorldPlus)

Tags: auto studio pipeline
Saved: 2026-11-06T00:32:49

run_auto_game_pipeline created 1 files under C:\Users\ExtremeHybrid\Documents\GameProjects\OpenWorldPlus and UNITY 6000.6.5f1: background job started -> create OpenWorldPlusUnity -> survival game (menu, settings, achievements, owned assets) -> Builds\Windows\OpenWorldP. Next: check Builds\auto_unity_status.txt, then work TaskBoard 'Auto next actions' with tools.
