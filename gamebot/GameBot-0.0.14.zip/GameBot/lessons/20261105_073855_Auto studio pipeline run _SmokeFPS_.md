# Auto studio pipeline run (SmokeFPS)

Tags: auto studio pipeline
Saved: 2026-11-05T07:38:55

run_auto_game_pipeline created 32 files under C:\Users\ExtremeHybrid\Documents\GameProjects\SmokeFPS and UNITY 6000.6.5f1: background job started -> create SmokeFPSUnity -> Assets/Scenes/Slice01.unity (grey-box, player, goal, HUD) -> Builds\Windows\SmokeFPS.exe. St. Next: check Builds\auto_unity_status.txt, then work TaskBoard 'Auto next actions' with tools.
