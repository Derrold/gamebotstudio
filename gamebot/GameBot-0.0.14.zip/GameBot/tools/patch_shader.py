"""0.0.3: show Unity shader-compile / import / player-build progress in status + work bar; shader progress counts as activity."""
import sys, shutil
from pathlib import Path

TAG = ".bak_shader_20261113"

def rd(p):
    with open(p, encoding="utf-8-sig", newline="") as fh:
        b = fh.read()
    nl = "\r\n" if "\r\n" in b else "\n"
    return b.replace("\r\n", "\n"), nl, p.read_bytes()[:3] == b"\xef\xbb\xbf"

def wr(p, t, nl, bom):
    if not Path(str(p) + TAG).exists():
        shutil.copy2(p, str(p) + TAG)
    with open(p, "w", encoding="utf-8-sig" if bom else "utf-8", newline="") as fh:
        fh.write(t.replace("\n", nl))

def sub1(t, old, new, name, marker=None):
    if (marker or new) in t:
        return t
    n = t.count(old)
    if n != 1:
        raise SystemExit(f"{name}: expected 1 match, found {n}: {old[:80]!r}")
    return t.replace(old, new)

ACTIVITY = r'''
SHADER_NOTE = "(first build is slow, this is normal)"
_ACT_RX = [
    ("shader", re.compile(r'^Compiling shader "(.+?)"')),
    ("ready", re.compile(r"\[\s*\d+s\]\s+(\d+)\s*/\s*(\d+)\s+variants ready")),
    ("left", re.compile(r"(\d+)\s+of\s+(\d+)\s+variants left")),
    ("start", re.compile(r"(\d+)\s+variants, starting compilation")),
    ("importing", re.compile(r"^Importing 'GUID: \w+ - Path: (.+?)' with importer")),
    ("imported", re.compile(r"^Imported 'GUID")),
    ("scripts", re.compile(r"\[ScriptCompilation\] Requested script compilation|Starting script compilation")),
    ("player", re.compile(r"^BuildPlayer: start building target")),
    ("bee", re.compile(r"^\[\s*(\d+)/(\d+)\s+\d+s\]\s+(\S+)")),
]


def build_log_activity(root: Path | None = None, log: Path | None = None) -> str:
    """What Unity is doing right now, read from the end of Builds\\build.log ('' if unknown).
    e.g. 'Compiling shaders: 83/2304 (first build is slow, this is normal) - Universal Render Pipeline/Lit'."""
    try:
        log = log or (Path(root) / "Builds" / "build.log")
        with open(log, "rb") as fh:
            fh.seek(0, 2)
            size = fh.tell()
            fh.seek(max(0, size - 262144))
            lines = fh.read().decode("utf-8", "replace").splitlines()
    except Exception:
        return ""
    last: dict = {}
    for i, raw in enumerate(lines):
        s = raw.strip() if not raw.startswith(("Importing", "Imported", "Compiling", "BuildPlayer", "[")) else raw
        for kind, rx in _ACT_RX:
            m = rx.search(s)
            if m:
                last[kind] = (i, m)
                break
    if not last:
        return ""
    kind, (idx, m) = max(last.items(), key=lambda kv: kv[1][0])
    name = last.get("shader", (-1, None))[1]
    sname = f" - {name.group(1)}" if name else ""
    if kind in ("ready", "left", "start", "shader"):
        prog = None
        for k in ("ready", "left", "start"):
            if k in last and last[k][0] > last.get("shader", (-1, None))[0]:
                if prog is None or last[k][0] > prog[0]:
                    prog = (last[k][0], k, last[k][1])
        if prog:
            k, pm = prog[1], prog[2]
            if k == "ready":
                done, total = int(pm.group(1)), int(pm.group(2))
            elif k == "left":
                total = int(pm.group(2)); done = max(0, total - int(pm.group(1)))
            else:
                done, total = 0, int(pm.group(1))
            return f"Compiling shaders: {done}/{total} {SHADER_NOTE}{sname}"
        return f"Compiling shaders {SHADER_NOTE}{sname}"
    if kind == "importing":
        return f"Importing {m.group(1)}"
    if kind == "imported":
        p = last.get("importing", (-1, None))[1]
        return "Importing assets" + (f" (just finished {p.group(1)})" if p else "")
    if kind == "scripts":
        return "Compiling scripts for the player build"
    if kind == "player":
        return "Building the Windows player"
    if kind == "bee":
        return f"Building the Windows player: step {m.group(1)}/{m.group(2)} ({m.group(3)})"
    return ""


def _log_age(root: Path) -> int:
    try:
        import time as _t
        return int(_t.time() - (Path(root) / "Builds" / "build.log").stat().st_mtime)
    except Exception:
        return -1

'''

def main(d):
    d = Path(d)
    p = d / "auto_studio.py"; t, nl, bom = rd(p)
    t = sub1(t, "\ndef build_status(", ACTIVITY + "\ndef build_status(", "activity fn", marker="def build_log_activity")
    old = '''            return f"{eng} build RUNNING for {root.name} ({int(_t.time() - st.stat().st_mtime)}s since last step): {last or head}"\n'''
    new = '''            act = build_log_activity(root) if eng == "Unity" else ""
            if act:
                age = _log_age(root)
                return f"{eng} build RUNNING for {root.name}: {act}" + (f" (log updated {age}s ago)" if age >= 0 else "")
            return f"{eng} build RUNNING for {root.name} ({int(_t.time() - st.stat().st_mtime)}s since last step): {last or head}"\n'''
    t = sub1(t, old, new, "build_status running")
    # watchdog: shader progress = activity; longer quiet limit while compiling shaders
    t = sub1(t, '''$hung = $false; $impKey = ""; $impStill = 0\n''', '''$hung = $false; $impKey = ""; $impStill = 0; $varKey = ""; $inShader = $false\n''', "init varKey")
    old = '''    $tl = Get-Content -LiteralPath $blog -Tail 400 -ErrorAction SilentlyContinue | Where-Object { $_ -match "^(Importing|Imported) 'GUID" } | Select-Object -Last 1\n'''
    new = '''    $t4 = @(Get-Content -LiteralPath $blog -Tail 400 -ErrorAction SilentlyContinue)
    $tl = $t4 | Where-Object { $_ -match "^(Importing|Imported) 'GUID" } | Select-Object -Last 1
    # shader compile progress ("[266s] 83 / 2304 variants ready") is activity: never a hang while the count moves
    $sv = $t4 | Where-Object { $_ -match "variants ready|variants left|variants, starting compilation|^Compiling shader " } | Select-Object -Last 1
    $la = $t4 | Where-Object { $_ -match "^(Importing|Imported) 'GUID|variants ready|variants left|variants, starting compilation|^Compiling shader " } | Select-Object -Last 1
    $inShader = [bool]($la -and $la -notmatch "^(Importing|Imported) 'GUID")
    if ($sv -and $sv.Trim() -ne $varKey) { $varKey = $sv.Trim(); $still = 0 }\n'''
    t = sub1(t, old, new, "shader tail")
    t = sub1(t, '''    if ($still -ge 360 -or $impStill -ge 180) { $hung = $true; break }\n''',
             '''    $quiet = if ($inShader) { 1200 } else { 360 }  # big shaders print progress rarely
    if ($still -ge $quiet -or $impStill -ge 180) { $hung = $true; break }\n''', "quiet limit")
    wr(p, t, nl, bom)

    p = d / "chat_store.py"; t, nl, bom = rd(p)
    old = '''    if running and step == "Ready":\n'''
    new = '''    _sm = re.search(r"Compiling shaders: (\\d+)/(\\d+)", blob)
    if running and _sm:
        step, pct = "Compiling shaders", 75 + int(20 * int(_sm.group(1)) / max(1, int(_sm.group(2))))
    elif running and "Compiling shaders" in blob:
        step, pct = "Compiling shaders", 75
    if running and step == "Ready":\n'''
    t = sub1(t, old, new, "progress_bar shader step")
    wr(p, t, nl, bom)
    print("patched", d)

if __name__ == "__main__":
    for x in sys.argv[1:]:
        main(x)
