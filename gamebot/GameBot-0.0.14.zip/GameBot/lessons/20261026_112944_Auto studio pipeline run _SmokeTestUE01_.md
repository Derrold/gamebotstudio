# Auto studio pipeline run (SmokeTestUE01)

Tags: auto studio pipeline
Saved: 2026-10-26T11:29:44

run_auto_game_pipeline created 32 files under C:\Users\ExtremeHybrid\Documents\GameProjects\SmokeTestUE01 and UNREAL: created C:\Users\ExtremeHybrid\Documents\GameProjects\SmokeTestUE01\SmokeTestUE01.uproject from TP_FirstPersonBP; launched UnrealEditor.exe. Next: check Builds\auto_unity_status.txt, then work TaskBoard 'Auto next actions' with tools.
