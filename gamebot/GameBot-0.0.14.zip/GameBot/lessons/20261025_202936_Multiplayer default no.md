# Multiplayer default no

Tags: netcode multiplayer
Saved: 2026-10-25T20:29:36

only add netcode (NGO + Relay/Steam/EOS) if the creator asks; prefer leaderboards/achievements. Source: https://docs-multiplayer.unity3d.com/netcode/current/about/
