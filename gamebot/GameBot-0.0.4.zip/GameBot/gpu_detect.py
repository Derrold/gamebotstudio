# Copyright (c) 2026 Alphamax Studios. All rights reserved. Proprietary software - licensed, not sold. Use requires a valid Game Bot license on one PC (see EULA.md). Copying, sharing, reselling, redistributing, reverse engineering, or bypassing license checks is prohibited.
"""GPU vendor + VRAM detection for Game Bot (stdlib only; used by Setup, PC info and the agent).

Order: NVIDIA via nvidia-smi (preferred when present) -> AMD/other via the Windows display-class registry
(HardwareInformation.qwMemorySize = real 64-bit dedicated VRAM) -> Win32_VideoController AdapterRAM
(uint32, caps at ~4 GB, so it is only a floor). No ROCm/CUDA required.
"""
from __future__ import annotations

import os
import subprocess
import sys

IS_WIN = os.name == "nt"
NO_WINDOW = 0x08000000 if IS_WIN else 0
EDITION_12GB_MIN_GB = 11.0        # same threshold as the original NVIDIA path (>= 11 GiB -> 12gb)
AMD_USABLE_MIN_GB = 3.5           # below this (APU iGPU carve-outs) treat as CPU mode
_DISPLAY_CLASS = r"SYSTEM\CurrentControlSet\Control\Class\{4d36e968-e325-11ce-bfc1-08002be10318}"
_VENDOR_IDS = {"10de": "nvidia", "1002": "amd", "1022": "amd", "8086": "intel"}
_cache: dict | None = None


def _vendor_of(name: str, pnp: str = "") -> str:
    p = (pnp or "").lower()
    for vid, v in _VENDOR_IDS.items():
        if f"ven_{vid}" in p:
            return v
    n = (name or "").lower()
    if "nvidia" in n or "geforce" in n or "quadro" in n or "rtx" in n:
        return "nvidia"
    if "amd" in n or "radeon" in n or "ati " in n:
        return "amd"
    if "intel" in n:
        return "intel"
    return "unknown"


def nvidia_gpus() -> list[dict]:
    """[{index, name, vram_gb}] from nvidia-smi, [] when no NVIDIA driver."""
    try:
        out = subprocess.check_output(["nvidia-smi", "--query-gpu=index,name,memory.total", "--format=csv,noheader,nounits"],
                                      text=True, timeout=15, stderr=subprocess.DEVNULL, creationflags=NO_WINDOW)
    except Exception:
        return []
    gpus = []
    for line in out.strip().splitlines():
        try:
            idx, rest = line.split(",", 1)
            name, mem = [x.strip() for x in rest.rsplit(",", 1)]
            gpus.append({"index": int(idx), "name": name, "vram_gb": round(float(mem) / 1024, 1),
                         "vendor": "nvidia", "source": "nvidia-smi"})
        except Exception:
            continue
    return gpus


def _registry_adapters() -> list[dict]:
    """Display adapters from the registry; qwMemorySize is the accurate 64-bit dedicated VRAM."""
    if not IS_WIN:
        return []
    try:
        import winreg
    except Exception:
        return []
    found = []
    try:
        root = winreg.OpenKey(winreg.HKEY_LOCAL_MACHINE, _DISPLAY_CLASS)
    except OSError:
        return []
    i = 0
    while True:
        try:
            sub = winreg.EnumKey(root, i)
        except OSError:
            break
        i += 1
        if not sub.isdigit():
            continue
        try:
            k = winreg.OpenKey(root, sub)
        except OSError:
            continue

        def val(n):
            try:
                return winreg.QueryValueEx(k, n)[0]
            except OSError:
                return None
        name = val("DriverDesc") or val("HardwareInformation.AdapterString") or ""
        if isinstance(name, bytes):
            name = name.decode("utf-16-le", "ignore").strip("\x00")
        if not name or "basic display" in name.lower() or "remote" in name.lower():
            continue
        mem = val("HardwareInformation.qwMemorySize")
        src = "registry qwMemorySize"
        if mem is None:
            mem = val("HardwareInformation.MemorySize")
            src = "registry MemorySize"
            if isinstance(mem, bytes):
                mem = int.from_bytes(mem[:8], "little") if mem else None
        try:
            gb = round(int(mem) / (1024 ** 3), 1) if mem else 0.0
        except Exception:
            gb = 0.0
        found.append({"name": str(name).strip(), "vram_gb": gb, "source": src,
                      "vendor": _vendor_of(name, str(val("MatchingDeviceId") or ""))})
    return found


def _cim_adapters() -> list[dict]:
    """Fallback: Win32_VideoController. AdapterRAM is uint32 (caps ~4 GB) so treat VRAM as a floor."""
    if not IS_WIN:
        return []
    ps = ("Get-CimInstance Win32_VideoController | ForEach-Object { "
          "'{0}|{1}|{2}' -f $_.Name, $_.AdapterRAM, $_.PNPDeviceID }")
    try:
        out = subprocess.check_output(["powershell", "-NoProfile", "-NonInteractive", "-Command", ps], text=True,
                                      timeout=30, stderr=subprocess.DEVNULL, creationflags=NO_WINDOW)
    except Exception:
        return []
    res = []
    for line in out.strip().splitlines():
        parts = line.split("|")
        if len(parts) < 3 or not parts[0].strip():
            continue
        try:
            gb = round(int(parts[1] or 0) / (1024 ** 3), 1)
        except Exception:
            gb = 0.0
        res.append({"name": parts[0].strip(), "vram_gb": gb, "vendor": _vendor_of(parts[0], parts[2]),
                    "source": "Win32_VideoController AdapterRAM (caps at 4GB)"})
    return res


def windows_adapters() -> list[dict]:
    """All display adapters with best-effort VRAM (registry first, CIM fills in missing ones)."""
    reg = _registry_adapters()
    cim = _cim_adapters()
    names = {a["name"].lower() for a in reg}
    out = list(reg)
    for a in cim:
        if a["name"].lower() not in names:
            out.append(a)
        else:  # keep the larger reading if registry had no size
            for r in out:
                if r["name"].lower() == a["name"].lower() and r["vram_gb"] <= 0 < a["vram_gb"]:
                    r.update(vram_gb=a["vram_gb"], source=a["source"])
    return out


def _edition(gb: float) -> str:
    return "12gb" if gb >= EDITION_12GB_MIN_GB else "8gb"


def detect(refresh: bool = False) -> dict:
    """Best GPU for the local model. NVIDIA preferred when present; else biggest AMD; else CPU mode.
    Returns {vendor, name, vram_gb, edition, source, nvidia_count, adapters}."""
    global _cache
    if _cache is not None and not refresh:
        return _cache
    nv = nvidia_gpus()
    if nv:
        best = max(nv, key=lambda g: (g["vram_gb"], g["name"]))
        _cache = {"vendor": "nvidia", "name": best["name"], "vram_gb": best["vram_gb"], "edition": _edition(best["vram_gb"]),
                  "source": "nvidia-smi", "nvidia_count": len(nv), "adapters": nv}
        return _cache
    ads = windows_adapters()
    amd = [a for a in ads if a["vendor"] == "amd" and a["vram_gb"] >= AMD_USABLE_MIN_GB]
    if amd:
        best = max(amd, key=lambda g: g["vram_gb"])
        _cache = {"vendor": "amd", "name": best["name"], "vram_gb": best["vram_gb"], "edition": _edition(best["vram_gb"]),
                  "source": best["source"], "nvidia_count": 0, "adapters": ads}
        return _cache
    _cache = {"vendor": "", "name": "", "vram_gb": 0, "edition": "8gb", "source": "none", "nvidia_count": 0, "adapters": ads}
    return _cache


def nvidia_count() -> int:
    """Cheap check used at agent start (nvidia-smi only, no registry/CIM)."""
    return len(nvidia_gpus())


if __name__ == "__main__":
    import json
    json.dump(detect(), sys.stdout, indent=2)
    print()


def system_ram_gb() -> float:
    """Total physical RAM in GB (Windows API; psutil fallback)."""
    try:
        import ctypes
        class M(ctypes.Structure):
            _fields_ = [("l", ctypes.c_ulong), ("ml", ctypes.c_ulong), ("t", ctypes.c_ulonglong), ("a", ctypes.c_ulonglong),
                        ("tp", ctypes.c_ulonglong), ("ap", ctypes.c_ulonglong), ("tv", ctypes.c_ulonglong), ("av", ctypes.c_ulonglong), ("e", ctypes.c_ulonglong)]
        m = M(); m.l = ctypes.sizeof(M)
        ctypes.windll.kernel32.GlobalMemoryStatusEx(ctypes.byref(m))
        return round(m.t / 1024**3, 1)
    except Exception:
        try:
            import psutil; return round(psutil.virtual_memory().total / 1024**3, 1)
        except Exception:
            return 0.0


def kv_budget(vram_gb: float | None = None, ram_gb: float | None = None) -> dict:
    """KV/RAM budget: VRAM < 16 GB -> spill KV to half of system RAM, ctx sized to that budget."""
    if vram_gb is None: vram_gb = float(detect().get("vram_gb") or 0)
    if ram_gb is None: ram_gb = system_ram_gb()
    if vram_gb >= 16:
        return {"kv_spill": False, "system_ram_gb": ram_gb, "kv_ram_budget_gb": 0, "num_ctx": 16384}
    half = round(ram_gb / 2, 1)
    ctx = 16384 if half >= 24 else 12288 if half >= 12 else 8192 if half >= 6 else 4096
    return {"kv_spill": True, "system_ram_gb": ram_gb, "kv_ram_budget_gb": half, "num_ctx": ctx}


def session_budget(vram_gb: float | None = None, ram_gb: float | None = None) -> dict:
    """Context-meter budget for chat sessions (see session_hygiene.session_budget for the formula)."""
    import session_hygiene
    if vram_gb is None: vram_gb = float(detect().get("vram_gb") or 0)
    if ram_gb is None: ram_gb = system_ram_gb()
    return session_hygiene.session_budget(vram_gb, ram_gb, kv_budget(vram_gb, ram_gb)["num_ctx"])
