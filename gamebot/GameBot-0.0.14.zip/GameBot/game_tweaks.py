"""Deterministic follow-up tweaks: darker, boss, faster player, weather, time of day, colors, extra level, undo.

Writes Tools/game_brief.json fields and queues a Unity rebuild so the next
build actually changes lighting, spawns a boss, or raises GamePlayer.speed.
'More enemies' stays in more_enemies.py (after platformer is in that genre list).
"""
from __future__ import annotations

import json
import re
from pathlib import Path

_DARKER_RE = re.compile(
    r"\b((make\s+(it\s+|the\s+(game|level|scene|world|lighting|lights?)\s+)?(much\s+|a\s+bit\s+|even\s+)?darker)"
    r"|(too\s+bright|darker\s+(please|lighting|lights?|look|mood|atmosphere))"
    r"|(more\s+dark|darker\s+mood|turn\s+(the\s+)?lights?\s+down)"
    r"|(lower\s+(the\s+)?(light|brightness|exposure)))\b",
    re.I,
)
_BOSS_RE = re.compile(
    r"\b((add|spawn|place|put|include|create)\s+(a\s+|an\s+|the\s+)?(final\s+|end\s+)?boss"
    r"|(final\s+boss|end[\s-]?boss|boss\s+(fight|enemy|character))"
    r"|need\s+a\s+boss)\b",
    re.I,
)
_FASTER_RE = re.compile(
    r"\b((make\s+(the\s+)?(player|character|hero|me)\s+(move\s+)?(much\s+|a\s+(bit|little)\s+)?faster)"
    r"|((player|character|hero|move(ment)?)\s+(speed|is)\s+(up|faster|higher|increase))"
    r"|(faster\s+(player|character|hero|movement|move))"
    r"|(increase|raise|boost)\s+(the\s+)?(player|character|hero|move(ment)?)\s+speed"
    r"|(player\s+faster|speed\s+up\s+(the\s+)?player))\b",
    re.I,
)

_DEFAULT_SPEED = 7.0
_SPEED_MULT = 1.5
_SPEED_CAP = 16.0

_WEATHER_RE = re.compile(
    r"\b((make\s+it\s+)?(rainy|raining|foggy|stormy|misty)|"
    r"(add|set|change)\s+(the\s+)?(weather|rain|fog|storm)|"
    r"(set\s+)?weather\s+(to\s+)?(rain|fog|storm|clear|sunny)|"
    r"(start|make)\s+(a\s+)?(rain|fog|storm)|"
    r"make\s+it\s+(rain|fog|storm)|clear\s+(the\s+)?(sky|weather)|make\s+it\s+(sunny|clear))\b",
    re.I,
)
_TOD_RE = re.compile(
    r"\b((make\s+it\s+|set\s+(the\s+)?(time\s+of\s+day\s+to\s+)?)"
    r"(night(?:time)?|midnight|sunset|dusk|dawn|morning|noon|daytime|day)\b|"
    r"time\s+of\s+day\s+(to\s+)?(night|sunset|dusk|dawn|day|morning|noon)|"
    r"change\s+(the\s+)?(time\s+of\s+day|lighting\s+to\s+night))\b",
    re.I,
)
_COLOR_RE = re.compile(
    r"\b((change|set|make|paint|tint)\s+(the\s+)?(game|scene|world|colors?|colour|sky|palette)\s+"
    r"(all\s+|more\s+|to\s+)?(blue|red|green|orange|gold|purple|violet|pink|yellow)\b|"
    r"(blue|red|green|orange|purple|pink)\s+and\s+(orange|blue|red|green|gold|purple|pink)|"
    r"make\s+it\s+all\s+(blue|red|green|orange|purple|pink|yellow))\b",
    re.I,
)
_LEVEL_RE = re.compile(
    r"\b((add|create|make)\s+(a\s+|an\s+|another\s+|one\s+more\s+)?(new\s+)?(level|stage|area|map)\b|"
    r"another\s+level|one\s+more\s+level)\b",
    re.I,
)
_UNDO_RE = re.compile(
    r"^\s*(please\s+)?(undo( that| this| the last change| the change)?|put it back|revert( that| that change)?|go back)\s*[.!?]?\s*$",
    re.I,
)


def _weather_value(text: str) -> str | None:
    t = (text or "").lower()
    if re.search(r"\b(stormy|storm)\b", t):
        return "storm"
    if re.search(r"\b(rainy|raining|rain)\b", t):
        return "rain"
    if re.search(r"\b(foggy|fog|misty|mist)\b", t):
        return "fog"
    if re.search(r"\b(sunny|clear)\b", t):
        return "clear"
    if _WEATHER_RE.search(text or ""):
        return "fog"
    return None


def _tod_value(text: str) -> str | None:
    t = (text or "").lower()
    if re.search(r"\b(nighttime|night|midnight)\b", t):
        return "night"
    if re.search(r"\b(sunset|dusk|evening)\b", t):
        return "sunset"
    if re.search(r"\b(dawn|morning)\b", t):
        return "dawn"
    if re.search(r"\b(daytime|noon|day)\b", t) and _TOD_RE.search(text or ""):
        return "day"
    return None


def _color_value(text: str) -> str | None:
    if not _COLOR_RE.search(text or ""):
        return None
    t = (text or "").lower()
    found = [c for c in ("blue", "red", "green", "orange", "gold", "purple", "violet", "pink", "yellow") if c in t]
    return " and ".join(found) if found else None


def wants_darker(text: str) -> bool:
    return bool(_DARKER_RE.search(text or ""))


def wants_boss(text: str) -> bool:
    return bool(_BOSS_RE.search(text or ""))


def wants_faster(text: str) -> bool:
    return bool(_FASTER_RE.search(text or ""))


def wants_weather(text: str) -> bool:
    return bool(_WEATHER_RE.search(text or ""))


def wants_tod(text: str) -> bool:
    return bool(_TOD_RE.search(text or ""))


def wants_colors(text: str) -> bool:
    return bool(_COLOR_RE.search(text or ""))


def wants_level(text: str) -> bool:
    return bool(_LEVEL_RE.search(text or ""))


def wants_undo(text: str) -> bool:
    return bool(_UNDO_RE.search(text or ""))


def wants(text: str) -> bool:
    return (
        wants_darker(text) or wants_boss(text) or wants_faster(text)
        or wants_weather(text) or wants_tod(text) or wants_colors(text)
        or wants_level(text) or wants_undo(text)
    )


def load_brief(root) -> dict:
    p = Path(root) / "Tools" / "game_brief.json"
    if not p.is_file():
        return {}
    try:
        data = json.loads(p.read_text(encoding="utf-8"))
        return data if isinstance(data, dict) else {}
    except Exception:
        return {}


def save_brief(root, data: dict) -> Path:
    p = Path(root) / "Tools" / "game_brief.json"
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_text(json.dumps(data, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
    return p


def _prev_path(root) -> Path:
    return Path(root) / "Tools" / "game_brief.prev.json"


def snapshot(root) -> None:
    """Remember the current brief so 'undo' can put it back."""
    cur = load_brief(root)
    p = _prev_path(root)
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_text(json.dumps(cur, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")


def undo(root, *, queue_rebuild: bool = True) -> str:
    root = Path(root)
    prev = _prev_path(root)
    if not prev.is_file():
        return f"I don't have a previous change to undo in {root.name}."
    try:
        data = json.loads(prev.read_text(encoding="utf-8"))
        if not isinstance(data, dict):
            data = {}
    except Exception:
        return f"I couldn't read the previous brief for {root.name}."
    # keep the current as the new previous so undo can be toggled
    current = load_brief(root)
    save_brief(root, data)
    prev.write_text(json.dumps(current, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
    msg = f"Undoing the last change in {root.name}."
    if queue_rebuild:
        q = _queue(root)
        if q.startswith("Unity rebuild queued") or "queued" in q.lower():
            msg += f' Rebuilding {root.name} now. Say "play" when it is ready.'
        elif "already running" in q.lower():
            msg += " A build is already running; the undo will be in the next one."
        elif "GAMEBOT_SKIP_UNITY" in q or "skipped" in q.lower():
            msg += " The previous brief is restored; rebuild is skipped in this test run."
        else:
            msg += f" The previous brief is restored ({q})."
    else:
        msg += " The previous brief is restored."
    return msg


def _already_dark(data: dict) -> bool:
    s = " ".join(str(data.get(k) or "") for k in ("style", "setting", "genre", "story")).lower()
    return bool(re.search(r"dark|moody|night|gloom|horror|grim|eerie|creepy|spooky|haunt|noir|dusk|twilight|cursed|sinister|foggy|misty", s))


def apply_fields(root, text: str) -> dict:
    """Mutate brief for whatever this turn asked. Returns a change summary."""
    root = Path(root)
    snapshot(root)
    data = load_brief(root)
    changed = {}
    if wants_darker(text):
        cur = int(data.get("darker") or 0)
        nxt = 2 if (cur >= 1 or _already_dark(data)) else 1
        if cur >= 2:
            nxt = min(cur + 1, 3)
        data["darker"] = nxt
        changed["darker"] = nxt
    if wants_boss(text):
        data["add_boss"] = 1
        changed["add_boss"] = 1
    if wants_faster(text):
        cur = float(data.get("player_speed") or 0) or _DEFAULT_SPEED
        nxt = min(_SPEED_CAP, round(cur * _SPEED_MULT, 2))
        if nxt <= cur:
            nxt = _SPEED_CAP
        data["player_speed"] = nxt
        changed["player_speed"] = nxt
    w = _weather_value(text) if wants_weather(text) else None
    if w:
        data["weather"] = w
        changed["weather"] = w
    tod = _tod_value(text) if wants_tod(text) else None
    if tod:
        data["time_of_day"] = tod
        changed["time_of_day"] = tod
    col = _color_value(text)
    if col:
        data["colors"] = col
        changed["colors"] = col
    if wants_level(text):
        nxt = int(data.get("extra_levels") or 0) + 1
        data["extra_levels"] = nxt
        changed["extra_levels"] = nxt
    save_brief(root, data)
    return changed


def _queue(root) -> str:
    try:
        from auto_studio import queue_rebuild
        return str(queue_rebuild(Path(root)))
    except Exception as e:
        return f"could not queue a rebuild ({e})"


def apply(root, text: str, *, queue_rebuild: bool = True) -> str:
    root = Path(root)
    name = root.name
    if wants_undo(text):
        return undo(root, queue_rebuild=queue_rebuild)
    changed = apply_fields(root, text)
    bits = []
    if "darker" in changed:
        bits.append(f"darker lighting (level {changed['darker']})")
    if "add_boss" in changed:
        bits.append("a boss")
    if "player_speed" in changed:
        bits.append(f"player speed {changed['player_speed']:g}")
    if "weather" in changed:
        bits.append(f"{changed['weather']} weather")
    if "time_of_day" in changed:
        bits.append(f"{changed['time_of_day']} lighting")
    if "colors" in changed:
        bits.append(f"{changed['colors']} colors")
    if "extra_levels" in changed:
        bits.append(f"an extra level (now {changed['extra_levels']} added)")
    what = ", ".join(bits) or "your changes"
    msg = f"Updating {name} with {what}."
    if queue_rebuild:
        q = _queue(root)
        if q.startswith("Unity rebuild queued"):
            msg += f' Rebuilding {name} now. Say "play" when it is ready.'
        elif "already running" in q.lower():
            msg += " A build is already running; these changes will be in the next one."
        elif "GAMEBOT_SKIP_UNITY" in q:
            msg += " Changes are saved; rebuild is skipped in this test run."
        else:
            msg += f" Changes are saved ({q})."
    else:
        msg += ' Say "rebuild" when you want it in the build.'
    return msg
