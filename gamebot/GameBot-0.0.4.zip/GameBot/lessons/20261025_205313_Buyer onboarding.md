# Buyer onboarding

Tags: onboarding config
Saved: 2026-10-25T20:53:13

Paths come from config\gamebot.config.json (auto-detected Unity 6000.x, Blender, %USERPROFILE%\Documents\GameProjects). If no name given, scaffold a working title and proceed.
