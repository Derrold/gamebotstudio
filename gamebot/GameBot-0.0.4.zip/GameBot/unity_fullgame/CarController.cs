﻿using UnityEngine;

/// <summary>Arcade car: Rigidbody drive (throttle/brake/steer/handbrake), chase camera, reset to last checkpoint.</summary>
[RequireComponent(typeof(Rigidbody))]
public class CarController : MonoBehaviour
{
    public float accel = 28f, maxSpeed = 42f, steer = 95f, grip = 6f;
    Rigidbody rb; Transform cam; public Vector3 resetPos; public Quaternion resetRot;
    void Start()
    {
        rb = GetComponent<Rigidbody>(); rb.mass = 1200; rb.linearDamping = 0.2f; rb.angularDamping = 3f;
        rb.centerOfMass = new Vector3(0, -0.4f, 0); rb.interpolation = RigidbodyInterpolation.Interpolate;
        var c = Camera.main; if (c) { cam = c.transform; cam.SetParent(null); }
        resetPos = transform.position; resetRot = transform.rotation;
        Cursor.lockState = CursorLockMode.Locked; Cursor.visible = false;
        GenreState.LapStart = Time.time;
    }
    void FixedUpdate()
    {
        if (GameState.Won || GameState.Lost || PauseMenu.IsPaused || MainMenuUI.InMenu) { rb.linearVelocity *= 0.95f; return; }
        float v = 0, h = 0;
        if (Input.GetKey(GameSettings.KeyForward) || GameBotQA.AutoDrive) v += 1; if (Input.GetKey(GameSettings.KeyBack)) v -= 1;
        if (Input.GetKey(GameSettings.KeyLeft)) h -= 1; if (Input.GetKey(GameSettings.KeyRight)) h += 1;
        bool hand = Input.GetKey(GameSettings.KeyJump);
        Vector3 fwd = transform.forward; fwd.y = 0; fwd.Normalize();
        float fspeed = Vector3.Dot(rb.linearVelocity, fwd);
        if (Mathf.Abs(fspeed) < maxSpeed || Mathf.Sign(v) != Mathf.Sign(fspeed)) rb.AddForce(fwd * v * accel, ForceMode.Acceleration);
        float turn = h * steer * Mathf.Clamp01(Mathf.Abs(fspeed) / 6f) * Mathf.Sign(fspeed == 0 ? 1 : fspeed);
        rb.MoveRotation(rb.rotation * Quaternion.Euler(0, turn * Time.fixedDeltaTime, 0));
        // lateral grip (drift with handbrake)
        Vector3 right = transform.right; float lat = Vector3.Dot(rb.linearVelocity, right);
        rb.AddForce(-right * lat * (hand ? grip * 0.25f : grip), ForceMode.Acceleration);
        if (hand) rb.AddForce(-fwd * fspeed * 0.8f, ForceMode.Acceleration);
        GenreState.SpeedKmh = rb.linearVelocity.magnitude * 3.6f;
        AchievementSystem.NotifySpeed(GenreState.SpeedKmh);
    }
    void Update()
    {
        if (!GameState.Won && !GameState.Lost && !PauseMenu.IsPaused && GenreState.Lap < GenreState.TotalLaps) GenreState.RaceTime += Time.deltaTime;
        if (Input.GetKeyDown(KeyCode.R) || transform.position.y < -10f || Vector3.Dot(transform.up, Vector3.up) < 0.2f && rb.linearVelocity.magnitude < 1f) ResetCar();
    }
    void LateUpdate()
    {
        if (!cam) return;
        Vector3 target = transform.position - transform.forward * 8f + Vector3.up * 3.5f;
        cam.position = Vector3.Lerp(cam.position, target, 6f * Time.deltaTime);
        cam.LookAt(transform.position + transform.forward * 4f + Vector3.up);
    }
    public void ResetCar()
    {
        rb.linearVelocity = Vector3.zero; rb.angularVelocity = Vector3.zero;
        transform.SetPositionAndRotation(resetPos + Vector3.up, resetRot);
    }
}


