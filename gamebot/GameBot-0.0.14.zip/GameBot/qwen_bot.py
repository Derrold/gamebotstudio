﻿"""CLI entry — prefer the UI (desktop Qwen Bot)."""
from agent_core import MODEL, new_session, run_turn, shutdown_tools

def main():
    print(f"Qwen Bot CLI ({MODEL}) — UI is preferred: http://127.0.0.1:7860")
    print("Type /bye to quit\n")
    messages = new_session()
    while True:
        try:
            user = input("You> ").strip()
        except (EOFError, KeyboardInterrupt):
            print()
            break
        if not user:
            continue
        if user.lower() in {"/bye", "/exit", "quit", "exit"}:
            break
        messages.append({"role": "user", "content": user})
        def on_event(ev):
            if ev.get("type") == "tool":
                print(f"\n>> {ev.get('name')}({ev.get('args')})")
        messages, answer = run_turn(messages, on_event=on_event)
        if answer:
            print("\n" + answer + "\n")
    shutdown_tools()

if __name__ == "__main__":
    main()
