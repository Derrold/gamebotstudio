"""'Get the starter packs': curated FREE Unity Asset Store packs (config/starter_packs.json).

Buyers click Add to My Assets on their own Unity account; Game Bot then downloads + imports them
(GameBotAssetFetch). Nothing is redistributed. Owned packs are marked 'owned'."""
from __future__ import annotations

import json
import re
from pathlib import Path

ROOT = Path(__file__).resolve().parent
PATH = ROOT / "config" / "starter_packs.json"
NEED_ROLE = {"ground": "env", "grass": "env", "trees": "env", "buildings": "env", "cover": "env",
             "enemies": "enemies", "weapons": "weapons", "weapon_sfx": "audio", "ambient": "audio", "sfx_misc": "audio"}
_ALIAS = {"fps": "shooter", "shooter_fps": "shooter", "first_person_shooter": "shooter", "tps": "shooter", "br": "battle_royale",
          "openworld": "open_world", "open world": "open_world", "battle royale": "battle_royale", "mmo": "mmorpg", "platform": "platformer"}
_CACHE: dict = {}


def load() -> dict:
    if "d" not in _CACHE:
        try:
            _CACHE["d"] = json.loads(PATH.read_text(encoding="utf-8"))
        except Exception:
            _CACHE["d"] = {"basic": [], "genres": {}}
    return _CACHE["d"]


def genre_id(text: str) -> str:
    g = (text or "").strip().lower()
    gs = load().get("genres") or {}
    if not g:
        return ""
    for cand in (g, g.replace(" ", "_").replace("-", "_"), _ALIAS.get(g, ""), _ALIAS.get(g.replace(" ", "_"), "")):
        if cand in gs:
            return cand
    try:
        import intake as _IN
        al = getattr(_IN, "GENRE_ALIAS", {}) or {}
        for k in sorted(al, key=len, reverse=True):
            if re.search(r"\b" + re.escape(k) + r"\b", g) and al[k] in gs:
                return al[k]
    except Exception:
        pass
    for k in gs:
        if re.search(r"\b" + re.escape(k.replace("_", " ")) + r"\b", g.replace("_", " ")):
            return k
    return ""


def _norm(s: str) -> str:
    return re.sub(r"[^a-z0-9]+", "", (s or "").lower())


def owned_names(rows: list | None = None) -> set:
    if rows is None:
        try:
            import asset_plan as _AP
            rows = _AP.catalog()
        except Exception:
            rows = []
    return {_norm(r.get("name") if isinstance(r, dict) else str(r)) for r in rows or []} - {""}


def is_owned(pack: dict, owned: set) -> bool:
    n = _norm(pack.get("name"))
    head = _norm(re.split(r"[|:(\-–]", pack.get("name") or "")[0])
    return any(n == o or (len(head) >= 6 and head in o) or (len(o) >= 10 and o in n) for o in owned if len(o) >= 4)


def missing_roles(plan: dict | None) -> list[str]:
    roles = []
    try:
        import asset_plan as _AP
        miss = _AP.unresolved(plan or {})
    except Exception:
        miss = (plan or {}).get("missing") or []
    for m in miss:
        r = NEED_ROLE.get(m.get("key"))
        if r and r not in roles:
            roles.append(r)
    return roles


def pick(genre: str = "", roles: list | None = None, owned: set | None = None) -> dict:
    d = load()
    owned = owned_names() if owned is None else owned
    gid = genre_id(genre)
    roles = roles or []

    def mark(ps):
        out = []
        for p in ps:
            q = dict(p)
            q["owned"] = is_owned(p, owned)
            out.append(q)
        # packs filling a missing role first, owned last
        out.sort(key=lambda p: (p["owned"], 0 if p.get("role") in roles else 1))
        return out
    basic = mark(d.get("basic") or [])
    g = (d.get("genres") or {}).get(gid) or {}
    gids = {p["id"] for p in basic}
    gp = mark([p for p in g.get("packs") or [] if p["id"] not in gids])
    return {"genre": gid, "label": g.get("label") or "", "basic": basic, "genre_packs": gp}


def _line(p: dict) -> str:
    return f"- [{p['name']}]({p['url']}) - {p['role']}" + (" (owned)" if p.get("owned") else "")


def offer_text(plan: dict | None = None, genre: str = "", owned: set | None = None) -> str:
    """'Get the starter packs' block: basic list + the chosen genre's list, as clickable links."""
    genre = genre or str((plan or {}).get("genre") or (plan or {}).get("family") or "")
    s = pick(genre, missing_roles(plan), owned)
    if not s["basic"] and not s["genre_packs"]:
        return ""
    lines = ["Get the starter packs (all FREE on the Unity Asset Store - click a link, press Add to My Assets, then say \"rescan\" and I download and import them):",
             "Basic:"] + [_line(p) for p in s["basic"]]
    if s["genre_packs"]:
        lines += [f"{s['label']}:"] + [_line(p) for p in s["genre_packs"]]
    return "\n".join(lines)
