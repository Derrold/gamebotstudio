# VFX, particles, shaders (URP)
Sources: https://docs.unity3d.com/Manual/ParticleSystems.html | https://docs.unity3d.com/Packages/com.unity.shadergraph@17.0/manual/index.html | https://docs.unity3d.com/Packages/com.unity.visualeffectgraph@17.0/manual/index.html | https://docs.unity3d.com/Packages/com.unity.render-pipelines.universal@17.0/manual/index.html

## Choose the tool
- Shuriken Particle System: CPU, works everywhere incl. mobile; default for muzzle flash, smoke, dust, rain/snow, blood puffs.
- VFX Graph: GPU, compute required; big counts (fog banks, swarms). Not for low-end mobile.
- Shader Graph: materials.

## Common hunting-sim effects
- Muzzle flash: 2-4 frame flipbook sprite + short point light (1-2 frames, no shadows) + smoke puff (BpSmoke.cs pattern for black powder). Pool objects, no Instantiate per shot.
- Shell eject / tracer trails: Trail Renderer short lifetime, or ribbon particles.
- Impact: Impact.cs - per-surface table (dirt, bark, water, snow) -> particle + decal + sound.
- Blood (stylized, ratings-safe): Blood.cs - small dark-red droplets, blood trail decals for tracking gameplay, no gore meshes; offer a 'Reduced blood' toggle in Settings (ESRB/PEGI/Steam mature content questionnaire).
- Breath fog in cold mornings, falling leaves, dust at feet.

## Shader Graph basics
- URP Lit/Unlit graph; expose properties; use keywords sparingly (variant explosion); Sub Graphs for shared wind/fade code.
- Foliage: alpha clip (not alpha blend), two-sided, wind via vertex offset; use global shader props (Shader.SetGlobalFloat) for wind like Wind.cs.
- Keep shader variants low: strip unused features in URP asset; check build log 'compiling shader variants'.

## Performance rules
- Particles: cap Max Particles, prefer fewer bigger sprites, disable collision unless needed, no realtime shadows from particles, overdraw check (Scene view Overdraw mode).
- Soft particles cost depth texture; ok on PC, avoid on mobile.

## Verify
- Effect visible at gameplay distance, no per-frame GC alloc (Profiler GC.Alloc), works in all quality presets.
