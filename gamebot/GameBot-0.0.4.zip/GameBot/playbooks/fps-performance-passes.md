# FPS passes (frame-rate performance passes) - NOT the shooter genre
Sources: https://docs.unity.com/en-us/engine/6000.6/script-reference/unityengine/frametimingmanager | https://docs.unity.com/en-us/engine/6000.0/manual/analysis/graphics-performance-profiling/profile-rendering/frame-timing-manager/enable | https://docs.unity3d.com/ScriptReference/QualitySettings.html | https://docs.unity3d.com/ScriptReference/Application-targetFrameRate.html | https://partner.steamgames.com/doc/steamdeck/recommendations | https://docs.unity3d.com/Manual/BuildSettings.html (Development Build)

## 1. What an FPS pass is
- A repeatable measurement: SAME build, SAME scene spot/route, SAME graphics preset + resolution, SAME time of day/weather, warm-up 3 s, then record N seconds (10-30 s). Report avg fps, avg ms, 1% low fps (99th percentile frame time), worst frame ms, CPU ms, GPU ms.
- Always before/after: change ONE thing, re-run, compare. A change that doesn't move numbers gets reverted or noted.

## 2. Unity measurement rules
- Standalone player (Development Build for Profiler attach, or release with Player > Frame Timing Stats enabled). The Editor lies (editor loop, inspector, scene view) - never ship-decide on Editor numbers.
- Turn vsync OFF and uncap for measurement: QualitySettings.vSyncCount=0; Application.targetFrameRate=-1. Restore user values after.
- FrameTimingManager.CaptureFrameTimings() + GetLatestTimings() (4-frame delay; GPU may be 0 on some APIs) or ProfilerRecorder 'CPU Main Thread Frame Time'. Use Time.unscaledDeltaTime for fps samples.
- Hide HUD/debug overlays during capture, freeze player input/camera (fixed look), set Application.runInBackground=true for automated runs, close other heavy apps, note GPU driver + resolution.
- 1% low: sort frame times, take the value at 99th percentile -> fps=1000/ms.

## 4. Pass matrix
- Presets: Low / Normal(Med) / High / Ultra.
- Conditions if cheap: dawn / noon / night; clear / rain / snow.
- Resolutions: 1920x1080 baseline, 2560x1440, 3840x2160 (with upscaler), 1280x800 (Deck).
- Minimum per release: 4 presets x dense forest + field at 1080p and Ultra at 1440p, plus Deck pass.

## 5. Budgets and what to cut
- Targets: 60 fps (16.7 ms) min on recommended spec at High; 90+ for high-refresh Ultra target; Steam Deck 30-40 fps stable (33-25 ms) at Low/Deck preset; 1% lows no worse than ~70% of avg.
- Cut order (usually biggest wins first): shadow distance/cascades/shadow map res -> shadow casters (grass/small props off) -> foliage density + detail distance -> tree full-detail range / impostors -> LOD bias -> draw calls (batching/instancing) -> post FX (SSAO, DoF, bloom) -> render scale / upscaler -> scope render-texture res -> CPU: AI/physics staggering, GC spikes (pool, no allocs in Update).
- GC spikes show as worst-frame spikes: Profiler GC.Alloc column; fix allocs.

## 6. Logging results
- Append to <Project>\Docs\QA\fps_passes.md (create folder if missing) a table row:
  | date | build (V0.0.NN/b) | change | preset | res | location | time/weather | avg fps | avg ms | 1% low | worst ms | cpu ms | gpu ms | GPU/driver | verdict |
- Then call teach_self(title='FPS pass <change>', lesson='before X fps -> after Y fps at <preset/res/spot>; cause; keep/revert; source log path', tags='fps pass performance').

## 7. Steam Deck pass (1280x800)
- Run windowed/fullscreen at 1280x800 (or -screen-width 1280 -screen-height 800 command line) with Low/Deck preset, FSR on, cap 30 or 40 (Deck supports 40 Hz). Check text readable at 7-inch (UI scale), controller-only navigation, no launcher, suspend/resume. Steam Deck Verified needs: default controller config, readable text, no device-incompatible launcher, good default settings.
- Record in the same fps_passes.md table with res 1280x800.
