# Debug & fix playbook: diagnose -> search docs -> patch -> verify -> teach_self
Sources: https://docs.unity3d.com/Manual/LogFiles.html · https://docs.unity3d.com/Manual/upgrade-guides.html · https://docs.unity3d.com/Manual/urp/upgrading-your-shaders.html · https://docs.unity3d.com/Manual/NullReferenceException.html · https://learn.microsoft.com/dotnet/csharp/language-reference/compiler-messages/ · https://dev.epicgames.com/documentation/en-us/unreal-engine/logging-in-unreal-engine

## Where the evidence is (this PC)
- Unity editor log: %LOCALAPPDATA%\Unity\Editor\Editor.log ; batch builds: the -logFile path (Game Bot: ollama-web\unity_builder_run.log).
- Player log: %USERPROFILE%\AppData\LocalLow\<Company>\<Product>\Player.log. READ ONLY.
- Unreal: <Proj>\Saved\Logs\<Proj>.log ; UAT log under Engine\Programs\AutomationTool\Saved\Logs.
- Command: Select-String -Path <log> -Pattern 'error CS|Exception|NullReference|Missing|Shader|failed' | Select -First 40

## Loop
1. Reproduce (batchmode or the logged player run). 2. Grab the FIRST error (later ones cascade). 3. Open the file+line (Get-Content file | Select -Index (line-3)..(line+3)). 4. If not obvious: firefox_search "<exact message> Unity 6" and open the official page. 5. Backup, surgical patch (exact replace of a few lines), never rewrite whole files. 6. Re-run; success = no 'error CS' and exit 0. 7. teach_self symptom/cause/fix/source.

## Known issues -> fixes
- Compile errors (error CS####): see unity-workflow.md list. Many errors at once after a script edit = one broken file: restore its newest .bak_*.
- Missing references ("The referenced script on this Behaviour is missing", "MissingReferenceException"): script renamed/deleted or GUID changed (.meta lost). Restore the .meta from backup or re-add the component; never delete .meta files.
- Pink/magenta materials: shader not supported by the render pipeline (Built-in shader in URP) or shader compile error. Fix: Edit > Rendering > Materials > Convert to URP, or in code set Shader.Find("Universal Render Pipeline/Lit"); make sure the shader is included in builds (Always Included Shaders / referenced by a material in a scene/Resources).
- Import scale wrong (100x or 0.01x): Blender export apply_scale_options='FBX_SCALE_UNITS' + apply transforms; Unity model import Convert Units on, Scale Factor 1. Check renderer.bounds.size in a test.
- Model faces backwards/rotated 90°: axis_forward/axis_up at export; or put mesh under a child with a fixed rotation (don't rotate the root that code moves).
- Batchmode fails: "another Unity instance is running" (project open in editor) | "executeMethod class not found" (not in Editor folder / compile errors) | exit 1 with no error (method threw — search the log for "Exception") | licence errors (open Hub once). Never kill the user's Unity or game.
- NullReferenceException at runtime: find the stack line, check what was null (GetComponent returned null, Find by name failed, object destroyed, Awake/Start order). Fix: assign in builder/inspector, null-check with a log, use [RequireComponent].
- Unreal: missing modules -> regenerate project files & rebuild; LNK2019 -> add module to Build.cs; cook failure -> fix redirectors / broken references.
- Blender script errors: AttributeError/TypeError on bpy ops = API changed between versions -> look up docs.blender.org/api/current/bpy.ops.<module>.html for exact param names.

## Never
- Kill the game or the user's editor; touch saves (registry/LocalLow); install builds unasked; replace a file with stub content.
