"""Start the local Ollama server if it is not already running. Does not change GPU env vars."""
from __future__ import annotations

import os
import shutil
import subprocess
import time
import urllib.request


def ollama_base() -> str:
    host = (os.environ.get("OLLAMA_HOST") or "http://127.0.0.1:11434").rstrip("/")
    if not host.startswith("http"):
        host = "http://" + host
    return host


def ollama_up(timeout: float = 2.0) -> bool:
    try:
        with urllib.request.urlopen(ollama_base() + "/api/tags", timeout=timeout) as r:
            return 200 <= getattr(r, "status", 200) < 300
    except Exception:
        return False


def find_ollama() -> str | None:
    local = os.environ.get("LOCALAPPDATA") or ""
    pf = os.environ.get("ProgramFiles") or r"C:\Program Files"
    pf86 = os.environ.get("ProgramFiles(x86)") or r"C:\Program Files (x86)"
    candidates = [
        os.path.join(local, "Programs", "Ollama", "ollama app.exe"),
        os.path.join(local, "Programs", "Ollama", "ollama.exe"),
        os.path.join(pf, "Ollama", "ollama app.exe"),
        os.path.join(pf, "Ollama", "ollama.exe"),
        os.path.join(pf86, "Ollama", "ollama app.exe"),
        os.path.join(pf86, "Ollama", "ollama.exe"),
    ]
    which = shutil.which("ollama")
    if which:
        candidates.append(which)
    seen = set()
    for path in candidates:
        if not path:
            continue
        key = os.path.normcase(os.path.abspath(path))
        if key in seen:
            continue
        seen.add(key)
        if os.path.isfile(path):
            return path
    return None


def _launch(path: str) -> None:
    name = os.path.basename(path).lower()
    args = [path, "serve"] if name == "ollama.exe" else [path]
    kwargs = {
        "args": args,
        "cwd": os.path.dirname(path) or None,
        "stdin": subprocess.DEVNULL,
        "stdout": subprocess.DEVNULL,
        "stderr": subprocess.DEVNULL,
        "close_fds": True,
    }
    if os.name == "nt":
        flags = getattr(subprocess, "DETACHED_PROCESS", 0) | getattr(subprocess, "CREATE_NEW_PROCESS_GROUP", 0)
        if name == "ollama.exe":
            flags |= getattr(subprocess, "CREATE_NO_WINDOW", 0)
        kwargs["creationflags"] = flags
    else:
        kwargs["start_new_session"] = True
    subprocess.Popen(**kwargs)


def ensure_ollama(timeout: float = 30.0) -> tuple[bool, str]:
    """If Ollama is down, launch it and wait up to timeout seconds. Returns (ok, reason)."""
    if ollama_up():
        return True, ""
    path = find_ollama()
    if not path:
        return False, "Ollama was not found. Install Ollama or add ollama.exe to PATH."
    try:
        _launch(path)
    except Exception as e:
        return False, f"could not launch {path}: {e}"
    deadline = time.time() + max(1.0, float(timeout))
    while time.time() < deadline:
        if ollama_up():
            return True, ""
        time.sleep(0.5)
    return False, f"launched {path} but it did not come up on {ollama_base()} within {int(timeout)}s"
