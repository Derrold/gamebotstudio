using UnityEngine;
/// <summary>Runtime state + text for the dedicated families added for B: action, fighting, strategy, moba, sports, sandbox, stealth, battle_royale, mmorpg.</summary>
public static partial class GenreState
{
    public static int MaxHealth = 100; public static float LastHurt;
    // action
    public static bool BossDown; public static int Combo;
    // fighting
    public static int P1Hp = 100, P2Hp = 100, Round = 1, P1Wins, P2Wins; public static float RoundTime = 60f; public static string RoundMsg = "";
    // strategy / moba
    public static int Quartz, PointsOwned, PointsTotal, Units, TowersDown, EnemyTowers, WaveNo; public static float SkillCd, HealCd, NextWave;
    // sports
    public static int ScoreUs, ScoreThem, GoalsToWin = 3; public static float MatchTime = 180f;
    // sandbox
    public static int Blocks = 40, Placed, BlockType, MaxHeight;
    // stealth
    public static float Detection; public static int Alarms; public static bool Crouched, InCover;
    // battle royale
    public static float StormRadius = 95f; public static int Phase;
    // mmorpg
    public static int Gold, QuestsDone, QuestsTotal = 3, WolvesKilled, Herbs; public static int[] Quest = new int[3]; // 0 none 1 active 2 ready 3 done
    public static string LoseReason = "";
    static string F => Family;
    public static bool IsAction => F == "action"; public static bool IsFighting => F == "fighting"; public static bool IsStrategy => F == "strategy";
    public static bool IsMoba => F == "moba"; public static bool IsSports => F == "sports"; public static bool IsSandbox => F == "sandbox";
    public static bool IsStealth => F == "stealth"; public static bool IsBR => F == "battle_royale"; public static bool IsMmo => F == "mmorpg";
    public static bool IsExtra => IsAction || IsFighting || IsStrategy || IsMoba || IsSports || IsSandbox || IsStealth || IsBR || IsMmo;

    public static void ResetExtra()
    {
        MaxHealth = 100; Health = 100; BossDown = false; Combo = 0;
        P1Hp = P2Hp = 100; Round = 1; P1Wins = P2Wins = 0; RoundTime = 60f; RoundMsg = "";
        Quartz = IsStrategy ? 150 : 0; PointsOwned = 0; Units = 0; TowersDown = 0; WaveNo = 0; SkillCd = HealCd = 0; NextWave = 0;
        ScoreUs = ScoreThem = 0; MatchTime = 180f; Blocks = 40; Placed = 0; BlockType = 0; MaxHeight = 0;
        Detection = 0; Alarms = 0; Crouched = InCover = false; StormRadius = 95f; Phase = 0;
        Gold = 0; QuestsDone = 0; WolvesKilled = 0; Herbs = 0; Quest = new int[3]; LoseReason = "";
        MagSize = IsBR ? 30 : 12; Ammo = MagSize; if (IsBR) { GameState.Lives = 1; Reserve = 90; }
    }
    public static void Lose(string why)
    {
        if (GameState.Won || GameState.Lost) return;
        LoseReason = why ?? ""; GameState.Lost = true; GameState.ClearContinue(); Cursor.lockState = CursorLockMode.None; Cursor.visible = true;
    }
    public static void MmoQuestCheck()
    {
        if (Quest[0] == 1 && WolvesKilled >= 5) { Quest[0] = 2; GameHUD.Flash("Wolf Cull complete - return to Warden Hale"); }
        if (Quest[1] == 1 && Herbs >= 4) { Quest[1] = 2; GameHUD.Flash("Herb Run complete - return to Sister Mae"); }
        if (Quest[2] == 1 && BossDown) { Quest[2] = 2; GameHUD.Flash("The Ancient Treant has fallen - return to Elder Voss"); }
    }
    static string ExtraControls()
    {
        if (IsAction) return "WASD move, mouse look, Left Click / J attack (chain hits for combos), Shift dash, Space jump.";
        if (IsFighting) return "A/D move, W jump, J light punch, K heavy kick, L (hold) block. Best of 3 rounds.";
        if (IsStrategy) return "WASD / screen edge pan, scroll zoom, Left Click / drag select units, Right Click move or attack, 1 = train Soldier (50), 2 = train Guardian (110).";
        if (IsMoba) return "Right Click move/attack, WASD move, Q = Shockwave, E = Heal. Your hero auto-attacks nearby enemies. Push the lane with your minions.";
        if (IsSports) return "WASD move, mouse look, Space / Left Click kick (hold to charge), walk into the ball to dribble.";
        if (IsSandbox) return "Left Click place block, Right Click remove block, 1-4 pick material, E harvest trees/rocks for blocks, Space jump.";
        if (IsStealth) return "WASD move, C / Ctrl crouch (quieter, slower), stay out of guard vision cones, hide in bushes. Grab the intel and reach extraction.";
        if (IsBR) return "Mouse aim, Left Click fire, R reload, walk over crates for loot. Stay inside the safe zone - the storm closes in.";
        if (IsMmo) return "WASD move, 1 Strike, 2 Firebolt, 3 Heal (nearest target in front). Walk up to quest givers (!) to accept and turn in quests.";
        return null;
    }
    static string ExtraStory()
    {
        string n = Name.ToUpper(), c = ExtraControls(); if (c == null) return null;
        if (IsAction) return n + "\n\nThe outpost has been overrun. Cut through three waves of raiders and bring down their warlord.\n" + c + "\n\nGoals:\n- Defeat every raider (" + EnemiesTotal + ")\n- Slay the warlord\n- Do not run out of lives\n\nPress Start when ready.";
        if (IsFighting) return n + "\n\nOne ring. One rival. First to two rounds walks away champion.\n" + c + "\n\nGoals:\n- Win 2 rounds before your rival\n- Each round lasts 60 seconds\n\nPress Start when ready.";
        if (IsStrategy) return n + "\n\nHold the quarry. Capture the three quartz points to fund your army, then raze the enemy keep.\n" + c + "\n\nGoals:\n- Capture all " + PointsTotal + " points\n- Destroy the enemy keep\n- Keep your HQ standing\n\nPress Start when ready.";
        if (IsMoba) return n + "\n\nTwo cores, one lane, endless minion waves. Push with your creeps, topple the towers, crack the enemy core.\n" + c + "\n\nGoals:\n- Destroy both enemy towers\n- Destroy the enemy core\n- Protect your own core\n\nPress Start when ready.";
        if (IsSports) return n + "\n\nThe final. Three minutes on the clock, first to " + GoalsToWin + " goals takes the cup.\n" + c + "\n\nGoals:\n- Score " + GoalsToWin + " goals\n- Do not let the rival out-score you\n\nPress Start when ready.";
        if (IsSandbox) return n + "\n\nAn empty island and a pile of blocks. Build anything - and build high enough to light the Sky Beacon.\n" + c + "\n\nGoals:\n- Place 25 blocks\n- Build a tower to the Sky Beacon and touch it\n- Do not fall into the sea\n\nPress Start when ready.";
        if (IsStealth) return n + "\n\nGet in, get the intel, get out. Guards patrol the compound - three alarms and the job is blown.\n" + c + "\n\nGoals:\n- Steal all intel (" + ItemsTotal + ")\n- Reach the extraction point\n- Fewer than 3 alarms\n\nPress Start when ready.";
        if (IsBR) return n + "\n\nTwelve drop in. One walks out. Loot up, fight, and stay ahead of the storm.\n" + c + "\n\nGoals:\n- Be the last one standing\n- Survive the storm phases\n- One life only\n\nPress Start when ready.";
        if (IsMmo) return n + "\n\nWelcome to Hearthvale, adventurer. Other heroes roam the wilds - the town needs your help too.\n" + c + "\n\nGoals:\n- Complete all 3 town quests\n- Defeat the Ancient Treant\n- Level up along the way\n\nPress Start when ready.";
        return null;
    }
    static string ExtraObjective()
    {
        if (IsAction) return BossDown ? "Objective: finish the remaining raiders (" + Kills + "/" + EnemiesTotal + ")" : "Objective: defeat raiders " + Kills + "/" + EnemiesTotal + " and the warlord";
        if (IsFighting) return "Objective: round " + Round + " - win 2 rounds (you " + P1Wins + " : " + P2Wins + " rival)";
        if (IsStrategy) return "Objective: points " + PointsOwned + "/" + PointsTotal + " - destroy the enemy keep (wave " + WaveNo + ")";
        if (IsMoba) return "Objective: towers down " + TowersDown + "/" + EnemyTowers + " - then destroy the enemy core";
        if (IsSports) return "Objective: first to " + GoalsToWin + " - score " + ScoreUs + " : " + ScoreThem + "  time " + Mathf.CeilToInt(MatchTime) + "s";
        if (IsSandbox) return "Objective: " + (Placed < 25 ? "place 25 blocks (" + Placed + ")" : "build up to the Sky Beacon (height " + MaxHeight + "/10) and touch it");
        if (IsStealth) return Items < ItemsTotal ? "Objective: steal intel " + Items + "/" + ItemsTotal + " - alarms " + Alarms + "/3" : "Objective: reach the green extraction point - alarms " + Alarms + "/3";
        if (IsBR) return "Objective: last one standing - " + Alive + " rivals left, storm phase " + (Phase + 1);
        if (IsMmo) return "Objective: quests " + QuestsDone + "/" + QuestsTotal + QuestLine();
        return null;
    }
    static string QuestLine()
    {
        string s = "";
        if (Quest[0] == 1) s += "  [Wolf Cull " + Mathf.Min(WolvesKilled, 5) + "/5]"; if (Quest[0] == 2) s += "  [Wolf Cull: turn in]";
        if (Quest[1] == 1) s += "  [Herb Run " + Mathf.Min(Herbs, 4) + "/4]"; if (Quest[1] == 2) s += "  [Herb Run: turn in]";
        if (Quest[2] == 1) s += "  [Slay the Treant]"; if (Quest[2] == 2) s += "  [Treant: turn in]";
        return s == "" ? " - talk to a quest giver (!)" : s;
    }
    static string ExtraWin()
    {
        if (IsAction) return "OUTPOST RECLAIMED!\nRaiders down: " + Kills + "  Best combo: " + Combo;
        if (IsFighting) return "CHAMPION!\nRounds " + P1Wins + " : " + P2Wins;
        if (IsStrategy) return "ENEMY KEEP DESTROYED!\nPoints held: " + PointsOwned + "/" + PointsTotal + "  Waves survived: " + WaveNo;
        if (IsMoba) return "VICTORY - ENEMY CORE DESTROYED!\nTowers: " + TowersDown + "  Hero level " + Level;
        if (IsSports) return "FULL TIME - YOU WIN!\nFinal score " + ScoreUs + " : " + ScoreThem;
        if (IsSandbox) return "SKY BEACON LIT!\nBlocks placed: " + Placed + "  Tallest build: " + MaxHeight;
        if (IsStealth) return "CLEAN EXTRACTION!\nIntel: " + Items + "  Alarms: " + Alarms;
        if (IsBR) return "VICTORY ROYALE - #1!\nEliminations: " + Kills;
        if (IsMmo) return "HERO OF HEARTHVALE!\nLevel " + Level + "  Gold " + Gold + "  Quests " + QuestsDone + "/" + QuestsTotal;
        return null;
    }
    static float ExtraProgress()
    {
        if (IsAction) return EnemiesTotal > 0 ? Mathf.Clamp01((float)Kills / EnemiesTotal) * 0.99f : 0f;
        if (IsFighting) return Mathf.Clamp01(P1Wins / 2f) * 0.99f;
        if (IsStrategy) return PointsTotal > 0 ? Mathf.Clamp01(0.6f * PointsOwned / PointsTotal) : 0f;
        if (IsMoba) return EnemyTowers > 0 ? Mathf.Clamp01(0.7f * TowersDown / EnemyTowers) : 0f;
        if (IsSports) return Mathf.Clamp01((float)ScoreUs / GoalsToWin) * 0.99f;
        if (IsSandbox) return Mathf.Clamp01(Placed / 25f * 0.4f + MaxHeight / 10f * 0.59f);
        if (IsStealth) return ItemsTotal > 0 ? Mathf.Clamp01((float)Items / ItemsTotal) * 0.9f : 0f;
        if (IsBR) return Mathf.Clamp01(1f - Alive / 11f) * 0.99f;
        if (IsMmo) return Mathf.Clamp01((float)QuestsDone / QuestsTotal) * 0.99f;
        return -1f;
    }
}
