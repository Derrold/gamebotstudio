# Auto studio pipeline run (WallRepro)

Tags: auto studio pipeline
Saved: 2026-11-11T12:04:24

run_auto_game_pipeline created 33 files under C:\Users\ExtremeHybrid\Documents\GameProjects\WallRepro and UNITY: skipped (GAMEBOT_SKIP_UNITY=1). Run later: C:\Users\ExtremeHybrid\Documents\GameProjects\WallRepro\Tools\auto_unity.ps1. Next: check Builds\auto_unity_status.txt, then work TaskBoard 'Auto next actions' with tools.
