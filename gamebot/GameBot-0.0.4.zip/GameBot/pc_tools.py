"""Local PC tools for Game Bot (no cloud APIs)."""
from __future__ import annotations
import re

import json
import os

import gb_config  # noqa: F401  (config.json -> GAMEBOT_* env defaults)
import subprocess
from datetime import datetime
from pathlib import Path

HOME = Path(os.path.expanduser("~"))
MEM_PATH = Path(__file__).resolve().parent / "memory.json"
NOTES_DIR = Path(__file__).resolve().parent / "notes"
NOTES_DIR.mkdir(exist_ok=True)
SCRIPTS_DIR = Path(__file__).resolve().parent / "scripts"
SCRIPTS_DIR.mkdir(exist_ok=True)
def _find_blender() -> Path:
    """GAMEBOT_BLENDER env, else newest Blender under Program Files, else blender on PATH."""
    env = os.environ.get("GAMEBOT_BLENDER")
    if env and Path(env).exists():
        return Path(env)
    base = Path(os.environ.get("ProgramFiles", r"C:\Program Files")) / "Blender Foundation"
    found = sorted(base.glob("Blender*/blender.exe"), key=lambda p: [int(x) if x.isdigit() else 0 for x in re.findall(r"\d+", p.parent.name)], reverse=True) if base.exists() else []
    if found:
        return found[0]
    import shutil as _sh
    w = _sh.which("blender")
    return Path(w) if w else base / "Blender" / "blender.exe"


BLENDER = _find_blender()


def _load_mem() -> dict:
    if MEM_PATH.exists():
        try:
            return json.loads(MEM_PATH.read_text(encoding="utf-8-sig"))
        except Exception:
            return {"facts": []}
    return {"facts": []}


def _save_mem(data: dict) -> None:
    MEM_PATH.write_text(json.dumps(data, indent=2, ensure_ascii=False), encoding="utf-8")


def remember(fact: str) -> str:
    fact = (fact or "").strip()
    if not fact:
        return "Empty fact."
    data = _load_mem()
    facts = data.setdefault("facts", [])
    if fact not in facts:
        facts.append(fact)
        _save_mem(data)
    return f"Saved: {fact}"


def recall(query: str = "") -> str:
    data = _load_mem()
    facts = data.get("facts") or []
    if not facts:
        return "No saved memory yet."
    q = (query or "").strip().lower()
    if q:
        hits = [f for f in facts if q in f.lower()]
        return "Memory:\n- " + "\n- ".join(hits) if hits else f"No memory matching '{query}'."
    return "Memory:\n- " + "\n- ".join(facts[-40:])


def forget(fact_substring: str) -> str:
    data = _load_mem()
    facts = data.get("facts") or []
    sub = (fact_substring or "").strip().lower()
    keep = [f for f in facts if sub not in f.lower()]
    removed = len(facts) - len(keep)
    data["facts"] = keep
    _save_mem(data)
    return f"Removed {removed} fact(s)."


def note_write(title: str, content: str) -> str:
    safe = "".join(c if c.isalnum() or c in "-_ " else "_" for c in (title or "note")).strip() or "note"
    path = NOTES_DIR / f"{safe}.md"
    path.write_text(content or "", encoding="utf-8")
    return f"Wrote {path}"


def note_read(title: str) -> str:
    safe = "".join(c if c.isalnum() or c in "-_ " else "_" for c in (title or "")).strip()
    path = NOTES_DIR / f"{safe}.md"
    if not path.exists():
        files = sorted(NOTES_DIR.glob("*.md"))
        names = ", ".join(p.stem for p in files[:30]) or "(none)"
        return f"Note not found. Available: {names}"
    return path.read_text(encoding="utf-8")[:12000]


def list_files(path: str = "", pattern: str = "*") -> str:
    base = Path(path) if path else NOTES_DIR
    if not base.exists():
        return f"Path not found: {base}"
    items = sorted(base.glob(pattern))[:80]
    lines = []
    for p in items:
        kind = "DIR" if p.is_dir() else "FILE"
        lines.append(f"{kind}\t{p}")
    return "\n".join(lines) if lines else "Empty."


def read_text_file(path: str, max_chars: int = 8000) -> str:
    p = Path(os.path.expandvars(os.path.expanduser(path or "")))
    if not p.exists():
        return f"Missing: {p}"
    try:
        return p.read_text(encoding="utf-8", errors="replace")[: max(500, int(max_chars or 8000))]
    except Exception as e:
        return f"Error: {e}"


def write_text_file(path: str, content: str) -> str:
    p = Path(os.path.expandvars(os.path.expanduser(path or "")))
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_text(content or "", encoding="utf-8")
    return f"Wrote {p} ({len(content or '')} chars)"


def run_powershell(command: str, timeout_sec: int = 60) -> str:
    cmd = (command or "").strip()
    if not cmd:
        return "Empty command."
    blocked = ("format ", "rm -rf", "remove-item -recurse -force c:\\", "shutdown", "restart-computer",
               "stop-computer", "diskpart", "cipher /w", "rd /s")
    low = cmd.lower()
    if any(b in low for b in blocked):
        return "Blocked dangerous command."
    try:
        r = subprocess.run(
            ["powershell", "-NoProfile", "-ExecutionPolicy", "Bypass", "-Command", cmd],
            capture_output=True, text=True, timeout=max(5, min(int(timeout_sec or 60), 180)),
            encoding="utf-8", errors="replace",
         creationflags=0x08000000)
        out = (r.stdout or "") + (("\n" + r.stderr) if r.stderr else "")
        return (out.strip() or f"(exit {r.returncode})")[:12000]
    except Exception as e:
        return f"Error: {e}"


def open_url(url: str) -> str:
    import webbrowser
    u = (url or "").strip()
    low = u.lower()
    if low.endswith(".exe") or ":\\" in u or low.startswith("c/") or low.startswith("c\\") or low.startswith("file:"):
        return "Refused: that looks like a local path/app. Use launch_app or open_path instead."
    if not u.startswith("http"):
        u = "https://" + u
    webbrowser.open(u)
    return f"Opened {u}"


def launch_app(path: str, args: str = "") -> str:
    raw = (path or "").strip().strip('"')
    if raw.lower().startswith("c/") or raw.lower().startswith("c\\"):
        raw = "C:\\" + raw[2:].replace("/", "\\")
    raw = raw.replace("/", "\\")
    candidates = [raw]
    if "blender" in raw.lower() and not Path(raw).exists():
        candidates.extend([
            str(BLENDER),
            r"C:\Program Files\Blender Foundation\Blender 5.2\blender-launcher.exe",
        ])
    exe = next((c for c in candidates if c and Path(c).exists()), None)
    if not exe:
        return f"App not found. Tried: {candidates}"
    try:
        cmd = [exe] + ([a for a in (args or "").split(" ") if a] if args else [])
        subprocess.Popen(cmd, shell=False)
        return f"Launched: {exe} {args}".strip()
    except Exception as e:
        return f"Launch failed: {e}"


def open_path(path: str) -> str:
    raw = (path or "").strip().strip('"')
    if raw.lower().startswith("c/"):
        raw = "C:\\" + raw[2:].replace("/", "\\")
    pth = Path(os.path.expandvars(os.path.expanduser(raw)))
    if not pth.exists():
        return f"Path not found: {pth}"
    import subprocess
    subprocess.Popen(["explorer.exe", str(pth)], close_fds=True)  # non-blocking
    return f"Opened: {pth}"


def now_local() -> str:
    return datetime.now().strftime("%A, %B %d, %Y %I:%M %p")


def system_info() -> str:
    ps = r"""
$ErrorActionPreference='SilentlyContinue'
$os = Get-CimInstance Win32_OperatingSystem
$cpu = Get-CimInstance Win32_Processor | Select-Object -First 1
$board = Get-CimInstance Win32_BaseBoard | Select-Object -First 1
$cs = Get-CimInstance Win32_ComputerSystem
$ramGB = [math]::Round(($cs.TotalPhysicalMemory/1GB),1)
$mem = Get-CimInstance Win32_PhysicalMemory
$ramModules = @($mem | ForEach-Object { "{0}GB @{1}MHz" -f [math]::Round($_.Capacity/1GB,0), $_.Speed }) -join ', '
$disks = @(Get-CimInstance Win32_DiskDrive | ForEach-Object { "{0} ({1:N0} GB)" -f $_.Model, ($_.Size/1GB) }) -join '; '
$gpuLines = @()
$n = & nvidia-smi --query-gpu=index,name,memory.total --format=csv,noheader 2>$null
if ($n) { $gpuLines = @($n) } else {
  $gpuLines = @(Get-CimInstance Win32_VideoController | ForEach-Object { $_.Name })
}
$net = @(Get-CimInstance Win32_NetworkAdapter | Where-Object { $_.NetEnabled -eq $true -and $_.Name -notmatch 'Virtual|Hyper-V|Bluetooth' } | Select-Object -ExpandProperty Name -Unique | Select-Object -First 6) -join '; '
@(
  "Computer: $env:COMPUTERNAME / User: $env:USERNAME"
  "OS: $($os.Caption) ($($os.Version))"
  "CPU: $($cpu.Name) | Cores: $($cpu.NumberOfCores) | Threads: $($cpu.NumberOfLogicalProcessors)"
  "Board: $($board.Manufacturer) $($board.Product)"
  "RAM: ${ramGB} GB ($ramModules)"
  "Disks: $disks"
  "GPUs (nvidia-smi):"
) + ($gpuLines | ForEach-Object { "  - $_" }) + @(
  "Network: $net"
  "Note: trust nvidia-smi VRAM over Windows AdapterRAM (it caps at 4GB)."
) | Out-String
"""
    return run_powershell(ps, 90)



def _is_placeholder_blender_script(text: str) -> bool:
    """Reject comment-only / stub scripts the model invents."""
    if not text or len(text.strip()) < 80:
        return True
    low = text.lower()
    if any(x in low for x in ("goes here", "placeholder", "add more detailed", "modeling code here", "corrected script", "actual modeling")):
        return True
    # strip comments/strings roughly; require real bpy ops beyond import
    code = re.sub(r"#.*", "", text)
    code = re.sub(r"['\"].*?['\"]", "", code, flags=re.S)
    ops = len(re.findall(r"bpy\.ops\.", code))
    return ops < 2


def run_blender_script(script_path: str = "", script_code: str = "", output_fbx: str = "") -> str:
    """Run Blender in background headless with a Python script. Creates/exports assets for real."""
    if not BLENDER.exists():
        return f"Blender missing: {BLENDER}"

    # PLACEHOLDER_REJECT
    code_src = script_code or ""
    if not code_src and script_path and Path(script_path).exists():
        code_src = Path(script_path).read_text(encoding="utf-8", errors="replace")
    if script_code and _is_placeholder_blender_script(script_code):
        return (
            "REJECTED: script_code is a placeholder/stub (comments only or missing real bpy.ops). "
            "Use the make_asset tool (scripts\\make_prop_generic.py) for props, "
            "or write a FULL script with real mesh ops + export_scene.fbx."
        )
    if script_code and not script_path:
        script_path = str(SCRIPTS_DIR / "blender_job.py")
        Path(script_path).write_text(script_code, encoding="utf-8")
    if not script_path:
        return "Need script_path or script_code."
    sp = Path(script_path)
    if not sp.exists():
        return f"Script missing: {sp}"
    cmd = [str(BLENDER), "--background", "--python", str(sp)]
    try:
        r = subprocess.run(cmd, capture_output=True, text=True, timeout=300, encoding="utf-8", errors="replace", creationflags=0x08000000)
        out = ((r.stdout or "") + "\n" + (r.stderr or "")).strip()
        msg = f"Blender exit {r.returncode}\n{out[-4000:]}"
        if output_fbx:
            msg += f"\nExpected FBX: {output_fbx} exists={Path(output_fbx).exists()}"
        return msg
    except Exception as e:
        return f"Blender run failed: {e}"
