# Auto studio pipeline run (OpenWorldPlusTwo)

Tags: auto studio pipeline
Saved: 2026-11-06T01:21:47

run_auto_game_pipeline created 33 files under C:\Users\ExtremeHybrid\Documents\GameProjects\OpenWorldPlusTwo and UNITY 6000.6.5f1: background job started -> create OpenWorldPlusTwoUnity -> Open World game (gameplay template: adventure; menu, settings, achievements, owned a. Next: check Builds\auto_unity_status.txt, then work TaskBoard 'Auto next actions' with tools.
