# UE5 Packaging Command Line

Tags: unreal ue5 commandline
Saved: 2026-10-25T20:01:42

UE5 packaging uses RunUAT.bat BuildCookRun with specific flags. Success is BUILD SUCCESSFUL and exit code 0.
