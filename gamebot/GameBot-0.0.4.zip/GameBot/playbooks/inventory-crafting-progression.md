# Inventory, crafting, progression, economy
Sources: https://www.gamedeveloper.com/design (design articles) | https://docs.unity3d.com/ScriptReference/PlayerPrefs.html | https://docs.unity3d.com/ScriptReference/JsonUtility.html

## General design
- Inventory: slot or weight-based; items as ScriptableObjects or data tables (id, name, icon, weight, stack, price, tags).
- Crafting: recipe = inputs -> output + time + station; show missing inputs; avoid recipe bloat.
- Progression curve: XP per level roughly geometric (e.g. 100*1.25^n); unlock something meaningful every 15-30 min early.
- Economy: list sources (rewards) and sinks (ammo, licenses, fines, gear); simulate in a spreadsheet before coding; no inflation.
- Save versioning: store saveVersion; migrate old keys.

## Verify
- Fresh profile -> 1 hour playthrough log: cash/XP over time chart; no softlocks; save/load round-trip.
