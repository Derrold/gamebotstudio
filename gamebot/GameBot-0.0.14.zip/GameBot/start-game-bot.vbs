Set sh = CreateObject("WScript.Shell")
sh.CurrentDirectory = "C:\Users\ExtremeHybrid\ollama-web"
sh.Run """C:\Users\ExtremeHybrid\AppData\Local\Programs\Python\Python312\pythonw.exe"" ""C:\Users\ExtremeHybrid\ollama-web\desktop_window.py""", 0, False