# accessibility ux

Tags: accessibility-ux
Saved: 2026-10-25T20:49:36

﻿# Accessibility
Subtitles, colorblind-safe UI, remappable controls, scalable text, reduce-flash option, pause anywhere.
