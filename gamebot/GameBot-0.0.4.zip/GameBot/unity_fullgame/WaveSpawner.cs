using UnityEngine;
/// <summary>Roguelike waves: spawns hostiles at random room spawn points; clearing all waves wins. One life (permadeath).</summary>
public class WaveSpawner : MonoBehaviour
{
    public Transform[] points; float nextWave = 2f;
    void Update()
    {
        if (GameState.Won || GameState.Lost || PauseMenu.IsPaused || MainMenuUI.InMenu) return;
        if (GenreState.Alive > 0 || Time.timeSinceLevelLoad < nextWave) return;
        if (GenreState.Wave >= 1) AchievementSystem.Unlock("wave_1");
        if (GenreState.Wave >= GenreState.WavesTotal) { AchievementSystem.Unlock("run_clear"); GenreState.Win(); return; }
        GenreState.Wave++; int count = 3 + GenreState.Wave * 2; GenreState.EnemiesTotal += count;
        for (int i = 0; i < count; i++)
        {
            var e = GameObject.CreatePrimitive(PrimitiveType.Capsule); e.name = "Hostile_w" + GenreState.Wave + "_" + i;
            e.transform.position = points[Random.Range(0, points.Length)].position + new Vector3(Random.Range(-2f, 2f), 1f, Random.Range(-2f, 2f));
            e.GetComponent<Renderer>().material.color = new Color(0.6f, 0.1f, 0.8f);
            var t = e.AddComponent<EnemyTarget>(); t.hp = 1 + GenreState.Wave; t.speed = 3f + GenreState.Wave * 0.5f; t.sight = 60f;
        }
        GenreState.Alive = count; nextWave = Time.timeSinceLevelLoad + 3f;
        GameHUD.Flash("Wave " + GenreState.Wave + " incoming!");
    }
}
