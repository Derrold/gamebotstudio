# Game-dev fundamentals (for a tool-using Game Bot)
Sources: https://docs.unity3d.com/Manual/ExecutionOrder.html · https://gameprogrammingpatterns.com/game-loop.html · https://gameprogrammingpatterns.com/component.html · https://docs.unity3d.com/Manual/PhysicsOverview.html · https://dev.epicgames.com/documentation/en-us/unreal-engine/gameplay-framework-in-unreal-engine

## Game loop
- Every engine runs: input -> update(dt) -> physics (fixed step) -> render. Unity: Update (per frame), FixedUpdate (physics, default 0.02 s), LateUpdate (cameras after movement). Unreal: Actor Tick / Component Tick with TickGroups.
- Rule: move by speed*Time.deltaTime in Update; apply forces / Rigidbody moves in FixedUpdate. Camera follow in LateUpdate.
- Success check: game speed identical at 30 fps and 144 fps.

## Scenes / levels and entities
- Unity: Scene (.unity) holds GameObjects; behaviour = MonoBehaviour components; reusable objects = Prefabs. Unreal: Level (.umap) holds Actors; behaviour = Components / Blueprints / C++ classes.
- Prefer composition (small components) over deep inheritance (Component pattern).
- edit Builder instead.

## Input
- Unity: Input System package (InputActions asset) or legacy Input Manager; check ProjectSettings activeInputHandler (0 old, 1 new, 2 both). Unreal 5: Enhanced Input (Input Actions + Mapping Contexts).
- Always support rebinding + gamepad from the first prototype;

## Physics
- Collider types: primitive (cheap) > convex mesh > concave mesh (static only). Rigidbody/physics body only on moving objects. Use layers + collision matrix to skip pairs.
- Fast bullets: don't rely on colliders; raycast/sweep each step.

## Cameras
- FPS: camera child of the head pivot, near clip ~0.01–0.05 for weapons; separate weapon render (overlay camera / FOV) if clipping. TPS: spring arm (Unreal SpringArmComponent) / Cinemachine in Unity.

## UI
- Unity: uGUI (Canvas + RectTransform + TextMeshPro) or UI Toolkit (UXML/USS); IMGUI (OnGUI) only for debug. Unreal: UMG Widget Blueprints. See models-and-ui.md.

## Save data
- Small settings: PlayerPrefs (Unity, registry on Windows) / SaveGame object (Unreal). Real progress: versioned JSON in Application.persistentDataPath; write to temp file, then replace (atomic).
- Always include a schemaVersion and migrate old saves; never delete user saves.

## Build / release
- Unity: BuildPipeline.BuildPlayer from an Editor script, or -batchmode -executeMethod. Unreal: RunUAT BuildCookRun.
- Release flow: bump version -> clean build to staging folder -> automated smoke test -> install only when the owner approves -> keep previous build as backup.
