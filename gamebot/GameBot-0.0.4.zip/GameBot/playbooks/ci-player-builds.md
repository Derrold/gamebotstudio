﻿# CI player builds
Optional: Unity batchmode BuildPlayer on push; artifact zip; same as local installers playbook. Prefer local for buyer machines without CI.
