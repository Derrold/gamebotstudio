"""Start the local Ollama server if it is not already running. Never changes saved env vars; on AMD-only PCs the server it starts gets OLLAMA_VULKAN=1."""
from __future__ import annotations

import os
import shutil
import subprocess
import time
import urllib.request


def ollama_base() -> str:
    """Client URL for the local Ollama server.

    OLLAMA_HOST may be a listen address such as 0.0.0.0:11434 (so other PCs can
    reach the server). Connecting to 0.0.0.0 / :: fails on Windows, so those
    wildcards are rewritten to 127.0.0.1. Remote hosts are left unchanged.
    """
    from urllib.parse import urlparse
    host = (os.environ.get("OLLAMA_HOST") or "http://127.0.0.1:11434").strip().rstrip("/")
    if not host.startswith(("http://", "https://")):
        host = "http://" + host
    u = urlparse(host)
    hostname = u.hostname or "127.0.0.1"
    if hostname in ("0.0.0.0", "::", "*"):
        hostname = "127.0.0.1"
    port = u.port or 11434
    return f"{u.scheme}://{hostname}:{port}"


def ollama_up(timeout: float = 2.0) -> bool:
    try:
        with urllib.request.urlopen(ollama_base() + "/api/tags", timeout=timeout) as r:
            return 200 <= getattr(r, "status", 200) < 300
    except Exception:
        return False


def find_ollama() -> str | None:
    local = os.environ.get("LOCALAPPDATA") or ""
    pf = os.environ.get("ProgramFiles") or r"C:\Program Files"
    pf86 = os.environ.get("ProgramFiles(x86)") or r"C:\Program Files (x86)"
    candidates = [
        os.path.join(local, "Programs", "Ollama", "ollama app.exe"),
        os.path.join(local, "Programs", "Ollama", "ollama.exe"),
        os.path.join(pf, "Ollama", "ollama app.exe"),
        os.path.join(pf, "Ollama", "ollama.exe"),
        os.path.join(pf86, "Ollama", "ollama app.exe"),
        os.path.join(pf86, "Ollama", "ollama.exe"),
    ]
    which = shutil.which("ollama")
    if which:
        candidates.append(which)
    seen = set()
    for path in candidates:
        if not path:
            continue
        key = os.path.normcase(os.path.abspath(path))
        if key in seen:
            continue
        seen.add(key)
        if os.path.isfile(path):
            return path
    return None


def _launch(path: str) -> None:
    name = os.path.basename(path).lower()
    args = [path, "serve"] if name == "ollama.exe" else [path]
    kwargs = {
        "args": args,
        "cwd": os.path.dirname(path) or None,
        "stdin": subprocess.DEVNULL,
        "stdout": subprocess.DEVNULL,
        "stderr": subprocess.DEVNULL,
        "close_fds": True,
    }
    if os.name == "nt":
        flags = getattr(subprocess, "DETACHED_PROCESS", 0) | getattr(subprocess, "CREATE_NEW_PROCESS_GROUP", 0)
        if name == "ollama.exe":
            flags |= getattr(subprocess, "CREATE_NO_WINDOW", 0)
        kwargs["creationflags"] = flags
    else:
        kwargs["start_new_session"] = True
    subprocess.Popen(**kwargs)


# ---- 0.0.7: AMD auto-GPU. A working NVIDIA card (nvidia-smi answers) -> CUDA, untouched. Only AMD -> Ollama with Vulkan on.
NO_WINDOW = 0x08000000
_GPU = {"info": None}


def gpu_mode(refresh: bool = False) -> dict:
    """{'mode': 'cuda'|'vulkan'|'cpu', 'vram_gb', 'name'}. GAMEBOT_OLLAMA_BACKEND=cuda|vulkan|cpu overrides."""
    if _GPU["info"] is not None and not refresh:
        return _GPU["info"]
    forced = (os.environ.get("GAMEBOT_OLLAMA_BACKEND") or "").strip().lower()
    info = {"mode": "cpu", "vram_gb": 0.0, "name": ""}
    try:
        import gpu_detect as gd
        nv = [] if forced in ("vulkan", "cpu") else gd.nvidia_gpus()
        if nv:
            info = {"mode": "cuda", "vram_gb": max(float(g.get("vram_gb") or 0) for g in nv), "name": str(nv[0].get("name") or "")}
        elif forced != "cpu":
            amd = [a for a in gd.windows_adapters() if a.get("vendor") == "amd"]
            if amd:
                b = max(amd, key=lambda a: float(a.get("vram_gb") or 0))
                info = {"mode": "vulkan", "vram_gb": float(b.get("vram_gb") or 0), "name": str(b.get("name") or "")}
    except Exception:
        pass
    if forced == "cuda":
        info["mode"] = "cuda"
    _GPU["info"] = info
    return info


def amd_series(name: str) -> int:
    """'AMD Radeon RX 5700 XT' -> 5700; 0 when it is not a Radeon RX nnnn card."""
    import re
    m = re.search(r"\bRX\s*(\d{4})\b", name or "", re.I)
    return int(m.group(1)) if m else 0


def amd_defaults(info: dict | None = None) -> None:
    """Safe AMD defaults. 8 GB-class AMD cards get num_ctx 8192.

    RX 5000 series is below the official requirement and has hit Vulkan device-lost
    at larger contexts, so it is capped at 4096. Never raises a caller's context
    (8 GB edition lock stays in place).
    """
    info = info or gpu_mode()
    if info.get("mode") != "vulkan":
        return
    try:
        cur = int(os.environ.get("GAMEBOT_NUM_CTX") or 8192)
    except ValueError:
        cur = 8192
    ser = amd_series(str(info.get("name") or ""))
    vram = float(info.get("vram_gb") or 0)
    if 5000 <= ser < 6000:
        cap = 4096
    elif 0 < vram <= 10.5:
        cap = 8192
    else:
        return
    os.environ["GAMEBOT_NUM_CTX"] = str(min(cur, cap))


def _vulkan_disabled_in_env() -> bool:
    vals = [os.environ.get("OLLAMA_VULKAN")]
    if os.name == "nt":
        try:
            import winreg
            for hive, key in ((winreg.HKEY_CURRENT_USER, "Environment"),
                              (winreg.HKEY_LOCAL_MACHINE, r"SYSTEM\CurrentControlSet\Control\Session Manager\Environment")):
                try:
                    with winreg.OpenKey(hive, key) as k:
                        vals.append(str(winreg.QueryValueEx(k, "OLLAMA_VULKAN")[0]))
                except OSError:
                    pass
        except Exception:
            pass
    return any(str(v).strip().lower() in ("0", "false", "no", "off") for v in vals if v is not None)


def _state_path() -> str:
    return os.path.join(os.environ.get("LOCALAPPDATA") or ".", "GameBot", "ollama_vulkan.json")


def _pid_alive(pid: int) -> bool:
    try:
        out = subprocess.run(["tasklist", "/FI", f"PID eq {int(pid)}", "/NH"], capture_output=True, text=True,
                             timeout=10, creationflags=NO_WINDOW if os.name == "nt" else 0).stdout
        return "ollama" in out.lower()
    except Exception:
        return False


def ensure_vulkan(timeout: float = 30.0) -> str:
    """AMD-only PC: make sure the Ollama server runs with Vulkan on (only for the server Game Bot starts). '' when not needed."""
    import json
    info = gpu_mode()
    if info.get("mode") != "vulkan":
        return ""
    amd_defaults(info)
    try:
        st = json.loads(open(_state_path(), encoding="utf-8").read())
    except Exception:
        st = {}
    if st.get("pid") and _pid_alive(st["pid"]) and ollama_up():
        return "vulkan (running)"
    if ollama_up() and not _vulkan_disabled_in_env():
        return "vulkan (ollama default)"
    path = find_ollama()
    if not path:
        return ""
    exe = os.path.join(os.path.dirname(path), "ollama.exe")
    if not os.path.isfile(exe):
        return ""
    for im in ("ollama app.exe", "ollama.exe"):  # the tray app's server runs with Vulkan off (CPU only on this PC)
        try:
            subprocess.run(["taskkill", "/F", "/IM", im], capture_output=True, timeout=15, creationflags=NO_WINDOW)
        except Exception:
            pass
    time.sleep(1.5)
    os.makedirs(os.path.dirname(_state_path()), exist_ok=True)
    log = open(os.path.join(os.path.dirname(_state_path()), "ollama_vulkan.log"), "ab")
    env = dict(os.environ, OLLAMA_VULKAN="1")
    flags = getattr(subprocess, "DETACHED_PROCESS", 0) | getattr(subprocess, "CREATE_NEW_PROCESS_GROUP", 0) | NO_WINDOW
    p = subprocess.Popen([exe, "serve"], cwd=os.path.dirname(exe), env=env, stdin=subprocess.DEVNULL, stdout=log, stderr=log,
                         creationflags=flags, close_fds=True)
    with open(_state_path(), "w", encoding="utf-8") as f:
        json.dump({"pid": p.pid, "started": time.time(), "gpu": info.get("name", "")}, f)
    deadline = time.time() + max(1.0, float(timeout))
    while time.time() < deadline and not ollama_up():
        time.sleep(0.5)
    return "vulkan (started)"


def ensure_ollama(timeout: float = 30.0) -> tuple[bool, str]:
    """If Ollama is down, launch it and wait up to timeout seconds. Returns (ok, reason)."""
    if os.name == "nt":
        try:
            ensure_vulkan(timeout)  # 0.0.7: AMD-only PCs
        except Exception:
            pass
    if ollama_up():
        return True, ""
    path = find_ollama()
    if not path:
        return False, "Ollama was not found. Install Ollama or add ollama.exe to PATH."
    try:
        _launch(path)
    except Exception as e:
        return False, f"could not launch {path}: {e}"
    deadline = time.time() + max(1.0, float(timeout))
    while time.time() < deadline:
        if ollama_up():
            return True, ""
        time.sleep(0.5)
    return False, f"launched {path} but it did not come up on {ollama_base()} within {int(timeout)}s"


def list_models(timeout: float = 8.0) -> list[str]:
    """Installed Ollama model names (empty if the server is down or /api/tags times out)."""
    import json
    try:
        with urllib.request.urlopen(ollama_base() + "/api/tags", timeout=timeout) as r:
            data = json.loads(r.read().decode("utf-8", "replace") or "{}")
    except Exception:
        return []
    names = []
    for m in data.get("models") or []:
        n = str(m.get("name") or m.get("model") or "").strip()
        if n:
            names.append(n)
    return names


def model_present(name: str, timeout: float = 8.0, retries: int = 3) -> bool:
    """True if the named model is installed. Retries empty /api/tags results (timeouts)."""
    if os.environ.get("GAMEBOT_MODEL_MISSING") == "1":
        return False
    want = (name or "").strip()
    if not want:
        return False
    attempts = max(1, int(retries))
    for i in range(attempts):
        names = list_models(timeout=timeout)
        if names:
            short = {n.split(":", 1)[0] for n in names}
            return want in names or want in short or f"{want}:latest" in names
        if i + 1 < attempts:
            time.sleep(0.4)
    return False


def ensure_model(name: str, timeout: float = 30.0) -> tuple[bool, str]:
    """Make sure Ollama is up and the named model is installed. Never auto-pulls."""
    if os.environ.get("GAMEBOT_OLLAMA_DOWN") == "1":
        return False, ("I can't reach the model server (Ollama). Open Ollama, or reinstall it, "
                       "then send your message again.")
    ok, reason = ensure_ollama(timeout=timeout)
    if not ok:
        return False, ("I can't reach the model server (Ollama). Open Ollama, or reinstall it, "
                       "then send your message again. " + (reason or "")).strip()
    if not model_present(name):
        return False, (f"Ollama is running, but the Game Bot model \"{name}\" is not installed. "
                       f"In a terminal run: ollama pull {name}  (or pick a model you have). Nothing was built.")
    return True, ""


def edition_num_ctx() -> int:
    """Active edition context window (8192 for 8gb AMD after amd_defaults, not Ollama's 4096)."""
    try:
        info = gpu_mode()
        if info.get("mode") == "vulkan":
            amd_defaults(info)
    except Exception:
        pass
    try:
        from editions import apply_to_agent_options
        return int(apply_to_agent_options({}).get("num_ctx") or os.environ.get("GAMEBOT_NUM_CTX") or 8192)
    except Exception:
        try:
            return int(os.environ.get("GAMEBOT_NUM_CTX") or 8192)
        except Exception:
            return 8192


_KEEP_BUILD = False


def keep_model_loaded(indefinite: bool = False, model: str | None = None) -> bool:
    """Ping Ollama so the model stays loaded. keep_alive -1 during builds, 30m otherwise.
    Always sends the edition num_ctx so a restart does not fall back to 4096."""
    global _KEEP_BUILD
    _KEEP_BUILD = bool(indefinite)
    try:
        import json
        import urllib.request
        import model_settings as MS
        name = model or MS.active_model_name()
        if not name:
            return False
        if not ollama_up():
            ok, _ = ensure_ollama(timeout=30)
            if not ok:
                return False
        ctx = edition_num_ctx()
        body = {
            "model": name,
            "prompt": "",
            "stream": False,
            "keep_alive": -1 if indefinite else "30m",
            "options": {"num_ctx": ctx, "num_predict": 0},
        }
        raw = json.dumps(body).encode("utf-8")
        req = urllib.request.Request(ollama_base() + "/api/generate", data=raw,
                                     headers={"Content-Type": "application/json"}, method="POST")
        with urllib.request.urlopen(req, timeout=20) as resp:
            resp.read()
        return True
    except Exception:
        return False


def refresh_keep_alive_for_builds() -> None:
    """While a Game Bot Unity/Unreal job is running, refresh keep_alive -1; restore 30m when it ends."""
    global _KEEP_BUILD
    running = False
    try:
        import auto_studio as AS
        for root in list(getattr(AS, "_LIVE_BUILDS", set()) or []):
            try:
                if AS.unity_job_running(root):
                    running = True
                    break
            except Exception:
                continue
    except Exception:
        running = False
    if running or _KEEP_BUILD and running:
        keep_model_loaded(indefinite=True)
        return
    if _KEEP_BUILD and not running:
        keep_model_loaded(indefinite=False)

