@echo off
rem Game Bot model setup - the right model for this PC is picked automatically from GPU VRAM.
setlocal
set "ED=%~1"
if "%ED%"=="" for /f %%e in ('py -3 -c "import gpu_auto;print(gpu_auto.install_edition())" 2^>nul') do set "ED=%%e"
if "%ED%"=="" set "ED=8gb"
cd /d "%~dp0.."
set "BASE=qwen2.5:7b"
if /i "%ED%"=="12gb" set "BASE=qwen2.5:14b"
title Game Bot - AI model setup
echo Downloading the recommended Game Bot AI model for this PC (auto-picked from your GPU VRAM)...
echo Approx download: ~4.7 GB (8-11 GB VRAM PCs) or ~9 GB (12 GB+ VRAM PCs).
echo.
:findollama
where ollama >nul 2>nul && goto haveollama
if exist "%LOCALAPPDATA%\Programs\Ollama\ollama.exe" set "PATH=%LOCALAPPDATA%\Programs\Ollama;%PATH%" & goto haveollama
echo Ollama is not installed yet. Finish installing Ollama (https://ollama.com/download), then press any key...
pause >nul
goto findollama
:haveollama
ollama list >nul 2>nul || (start "" /min ollama serve & timeout /t 8 >nul)
ollama pull %BASE% || goto fail
ollama create gamebot-%ED% -f "modelfiles\gamebot-%ED%.Modelfile" || goto fail
echo.
echo Done - the Game Bot AI model is ready. Start Game Bot from the Desktop icon.
pause
exit /b 0
:fail
echo.
echo Model setup failed. Make sure Ollama is running, then run Start menu > Game Bot > Set up AI model again.
pause
exit /b 1


