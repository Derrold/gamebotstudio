# Auto studio pipeline run (GenreProbeRace)

Tags: auto studio pipeline
Saved: 2026-11-05T10:10:18

run_auto_game_pipeline created 32 files under C:\Users\ExtremeHybrid\Documents\GameProjects\GenreProbeRace and UNITY: skipped (GAMEBOT_SKIP_UNITY=1). Run later: C:\Users\ExtremeHybrid\Documents\GameProjects\GenreProbeRace\Tools\auto_unity.ps1. Next: check Builds\auto_unity_status.txt, then work TaskBoard 'Auto next actions' with tools.
