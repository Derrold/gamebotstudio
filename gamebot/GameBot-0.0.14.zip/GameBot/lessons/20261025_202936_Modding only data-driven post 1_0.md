# Modding only data-driven post 1.0

Tags: modding community workshop
Saved: 2026-10-25T20:29:36

Expose JSON/CSV data (weapons like Builder G(), Gfx tuning) from Documents/<Game>/Mods, clamp values, no code exec; Workshop later via ISteamUGC. Source: https://partner.steamgames.com/doc/features/workshop
