# Unity workflow (Unity 6000.6.5f1 / URP on this PC)
Sources: https://docs.unity3d.com/Manual/EditorCommandLineArguments.html · https://docs.unity3d.com/ScriptReference/BuildPipeline.BuildPlayer.html · https://docs.unity3d.com/Manual/Prefabs.html · https://docs.unity3d.com/Manual/class-ScriptableObject.html · https://docs.unity3d.com/Packages/com.unity.addressables@latest · https://docs.unity3d.com/Manual/class-PlayerSettings.html · https://docs.unity3d.com/ScriptReference/

## Paths
- Editor: C:\Program Files\Unity\Hub\Editor\6000.6.5f1\Editor\Unity.exe
- Editor-only scripts MUST live in an Assets/**/Editor/ folder.

## Batch mode (the main automation tool)
& "<Unity.exe>" -batchmode -nographics -quit -projectPath "<proj>" -executeMethod Class.Method -logFile "<log>"
- -executeMethod needs a STATIC method in a class inside an Editor folder; namespaces allowed: Namespace.Class.Method.
- Failure contract: an exception or EditorApplication.Exit(1) -> process exit code 1. Read args via System.Environment.GetCommandLineArgs().
- Only ONE Editor may have a project open. If the Editor already has it open, batchmode fails ("another Unity instance is running") — check Get-Process Unity first; never kill the user's editor.
- -nographics cannot bake GI; drop it if a step needs the GPU. Add -accept-apiupdate when upgrading old scripts.
- Success = exit code 0 AND log has no "error CS" and no "Exception"; grep the log: Select-String log -Pattern 'error CS|Exception|Build succeeded|Build Finished, Result'.

## Scenes, prefabs, ScriptableObjects
- Prefab = reusable GameObject template (variants for skins). ScriptableObject = data asset (stats, weapon defs, loot tables) — no scene object, edit in Inspector, shared by reference.
- Rule: data that designers tune = ScriptableObject; behaviour = MonoBehaviour; whole scene generation = Editor builder script.
- Create via [CreateAssetMenu(menuName="Game/WeaponData")] public class WeaponData : ScriptableObject { ... }, or in Editor code AssetDatabase.CreateAsset(obj, "Assets/.../X.asset").

## Addressables (basics)
- Package com.unity.addressables. Mark assets Addressable, load with Addressables.LoadAssetAsync<T>(key) and release with Addressables.Release. Build content before the player (AddressableAssetSettings.BuildPlayerContent()). Use for big DLC/streaming; Resources/ folder is fine for small projects (both his projects use Resources).

## PlayerSettings / versions
- PlayerSettings.bundleVersion = Application.version; companyName/productName set the LocalLow save folder (changing them MOVES saves — never change on a shipped game).
- Scripting backend Mono (fast iteration) vs IL2CPP (shipping perf); API compatibility .NET Standard 2.1.

## Building a player from code
var r = BuildPipeline.BuildPlayer(opts); if(r.summary.result!=UnityEditor.Build.Reporting.BuildResult.Succeeded) EditorApplication.Exit(1);
- Build Profiles (Unity 6): -activeBuildProfile "Assets/Settings/Build Profiles/X.asset" + -build <path>.
- Scriptable Build Pipeline (com.unity.scriptablebuildpipeline) underlies Addressables/AssetBundles; you rarely call it directly.

## Common compile errors -> fix
- CS0246 type/namespace not found: missing using / package / asmdef reference, or Editor-only API (UnityEditor) used in runtime script -> wrap in #if UNITY_EDITOR or move to Editor folder.
- CS0103 name does not exist: typo or variable out of scope.
- CS1001/CS1002/CS1031 identifier/; /type expected at line 1–2: FILE IS CORRUPT/STUBBED -> restore newest .bak_*, don't patch.
- CS0101 duplicate type: a copied file (e.g. Foo.cs.bak renamed .cs, or two classes named the same).
- CS0117 'X' does not contain a definition: API removed/renamed in Unity 6 — look up docs.unity3d.com/ScriptReference/<Class>.html and use the replacement.
- After ANY compile error: firefox_search "<error code> <message> Unity 6", patch, re-run batchmode, teach_self the fix.
