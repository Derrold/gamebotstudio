# Auto studio pipeline run (OwnScanDemo)

Tags: auto studio pipeline
Saved: 2026-11-05T08:13:28

run_auto_game_pipeline created 32 files under C:\Users\ExtremeHybrid\Documents\GameProjects\OwnScanDemo and UNITY 6000.6.5f1: background job started -> create OwnScanDemoUnity -> Assets/Scenes/Slice01.unity (grey-box, player, goal, HUD) -> Builds\Windows\OwnScanDemo.e. Next: check Builds\auto_unity_status.txt, then work TaskBoard 'Auto next actions' with tools.
