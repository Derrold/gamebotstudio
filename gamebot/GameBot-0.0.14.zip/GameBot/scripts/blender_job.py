import bpy
bpy.ops.wm.read_factory_settings(use_empty=True)
bpy.ops.mesh.primitive_cube_add(size=200, location=(0,0,100))
bpy.ops.wm.save_as_mainfile(filepath=r'C:\Users\ExtremeHybrid\Documents\GameProjects\GBWorldTest\Art\Blender\Imports\castle.blend')