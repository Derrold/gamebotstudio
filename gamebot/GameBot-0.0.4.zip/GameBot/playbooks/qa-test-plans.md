# QA, test plans, regression before upload
Sources: https://docs.unity3d.com/Packages/com.unity.test-framework@1.4/manual/index.html | https://docs.unity3d.com/Manual/CommandLineArguments.html | https://partner.steamgames.com/doc/store/review_process

## Test layers
1. Compile gate: Unity batchmode compile clean (no errors), Builder log check (builder_log_check).
2. Unit/EditMode tests: Unity Test Framework for pure logic (ballistics math, calendar rules, economy).
3. PlayMode/automation: scripted runs with timeout and PASS/FAIL summary.
4. Smoke test (10 min, every build): launch, main menu, new profile, settings change+save, start hunt, shoot range, harvest, save, quit, relaunch - progress kept.
5. Regression list (before Steam upload): all presets launch; FPS pass (fps-performance-passes.md); input remap; controller; alt-tab; 1080p/1440p/4K/ultrawide/1280x800; uninstall/install clean; offline; legal screens; achievements fire; no dev cheats in release.
6. Exploratory: 30 min break-it session per release.

## Bug report format
- Build version, steps, expected vs actual, frequency, log excerpt, screenshot. Track in Docs/QA/bugs.md; severity (blocker/major/minor).

## Release gate
