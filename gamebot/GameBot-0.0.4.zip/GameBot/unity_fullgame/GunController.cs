using UnityEngine;

/// <summary>FPS weapon: hitscan raycast, magazine + reserve ammo, reload, tracer + muzzle flash.</summary>
public class GunController : MonoBehaviour
{
    public float fireRate = 0.12f, range = 120f, reloadTime = 1.2f;
    public int damage = 1;
    float nextShot, reloadUntil;
    Camera cam; LineRenderer tracer; Light flash; float flashOff;
    public static bool Reloading;

    void Start()
    {
        cam = GetComponentInChildren<Camera>();
        tracer = new GameObject("Tracer").AddComponent<LineRenderer>();
        tracer.startWidth = 0.03f; tracer.endWidth = 0.01f; tracer.positionCount = 2; tracer.enabled = false;
        tracer.material = new Material(Shader.Find("Sprites/Default")); tracer.startColor = Color.yellow; tracer.endColor = new Color(1,1,0,0);
        var fl = new GameObject("MuzzleFlash"); fl.transform.SetParent(cam ? cam.transform : transform, false);
        fl.transform.localPosition = new Vector3(0.3f, -0.25f, 0.8f);
        flash = fl.AddComponent<Light>(); flash.type = LightType.Point; flash.range = 6; flash.intensity = 4; flash.color = new Color(1f,0.8f,0.3f); flash.enabled = false;
        // simple viewmodel gun
        if (cam && cam.transform.Find("ViewGun")) return;
        var gun = GameObject.CreatePrimitive(PrimitiveType.Cube); gun.name = "ViewGun";
        Destroy(gun.GetComponent<Collider>());
        gun.transform.SetParent(cam ? cam.transform : transform, false);
        gun.transform.localPosition = new Vector3(0.3f, -0.3f, 0.6f); gun.transform.localScale = new Vector3(0.12f, 0.15f, 0.6f);
        gun.GetComponent<Renderer>().material.color = new Color(0.15f,0.15f,0.18f);
    }

    void Update()
    {
        if (GameState.Won || GameState.Lost || PauseMenu.IsPaused || MainMenuUI.InMenu) return;
        if (Time.time > flashOff) { flash.enabled = false; tracer.enabled = false; }
        if (Reloading && Time.time >= reloadUntil)
        {
            int need = GenreState.MagSize - GenreState.Ammo; int take = Mathf.Min(need, GenreState.Reserve);
            GenreState.Ammo += take; GenreState.Reserve -= take; Reloading = false;
        }
        if (Reloading) return;
        if (Input.GetKeyDown(KeyCode.R) && GenreState.Ammo < GenreState.MagSize && GenreState.Reserve > 0) { Reloading = true; reloadUntil = Time.time + reloadTime; GbAudio.Play("reload"); return; }
        if ((Input.GetMouseButton(0) || GameBotQA.AutoFire) && Time.time >= nextShot)
        {
            nextShot = Time.time + fireRate;
            if (GenreState.Ammo <= 0) { if (GenreState.Reserve > 0) { Reloading = true; reloadUntil = Time.time + reloadTime; GbAudio.Play("reload"); } return; }
            GenreState.Ammo--;
            Fire();
        }
    }

    void Fire()
    {
        GbAudio.Play("fire", 0.8f);
        var origin = cam ? cam.transform : transform;
        Vector3 end = origin.position + origin.forward * range;
        if (Physics.Raycast(origin.position + origin.forward * 0.5f, origin.forward, out var hit, range, ~0, QueryTriggerInteraction.Ignore))
        {
            end = hit.point;
            var e = hit.collider.GetComponentInParent<EnemyTarget>();
            if (e != null) e.Hit(damage);
            else { var g = hit.collider.GetComponentInParent<IGbDamage>(); if (g != null) g.Damage(damage, 0); }
        }
        var mz = cam ? cam.transform.Find("ViewGun/Muzzle") : null;
        if (mz) flash.transform.position = mz.position;
        tracer.SetPosition(0, mz ? mz.position : origin.position + origin.right * 0.3f - origin.up * 0.25f + origin.forward * 0.8f);
        tracer.SetPosition(1, end); tracer.enabled = true; flash.enabled = true; flashOff = Time.time + 0.05f;
    }
}


