"""Game Bot single-PC license (offline, v1).

One purchase = one PC. The installer (or the first run of a zip copy) writes license.json
bound to this PC's Windows MachineGuid. If the folder is copied to another PC the check
fails with "licensed for one PC only". Online activation is an optional stub (no server yet).
"""
from __future__ import annotations

import datetime
import hashlib
import json
import os
from pathlib import Path

ROOT = Path(__file__).resolve().parent
LICENSE_PATH = ROOT / "license.json"
_SALT = "GB1-7f3a9c41-onepc"  # must match GameBot-Setup.iss
ONE_PC_MSG = ("Game Bot is licensed for one PC only.\n\nThis copy is bound to a different computer. "
              "One purchase = one PC. To move Game Bot to a new PC, buy a new license or contact support "
              "for a license transfer (the old PC must be deactivated).")


def machine_guid() -> str:
    try:
        import winreg
        k = winreg.OpenKey(winreg.HKEY_LOCAL_MACHINE, r"SOFTWARE\Microsoft\Cryptography", 0,
                           winreg.KEY_READ | winreg.KEY_WOW64_64KEY)
        return str(winreg.QueryValueEx(k, "MachineGuid")[0]).strip().lower()
    except Exception:
        return ""


def fingerprint() -> str:
    return hashlib.sha1(("GameBot|" + machine_guid()).encode("ascii", "ignore")).hexdigest()


def _sig(fp: str, key: str) -> str:
    return hashlib.sha1((_SALT + fp + key).encode("ascii", "ignore")).hexdigest()


def bind(key: str = "") -> dict:
    fp = fingerprint()
    data = {"product": "Game Bot", "policy": "one-pc", "machine": fp, "key": key, "sig": _sig(fp, key),
            "bound": datetime.date.today().isoformat(), "mode": "offline"}
    LICENSE_PATH.write_text(json.dumps(data, indent=2), encoding="utf-8")
    return data


def activate_online(key: str) -> tuple[bool, str]:
    """Optional future online activation. No server yet - offline bind is the default."""
    return False, "online activation not configured (offline one-PC bind is active)"


def check() -> tuple[bool, str]:
    if not machine_guid():
        return False, "Could not read this PC's machine ID (Windows only)."
    if not LICENSE_PATH.exists():
        bind()  # first run of a fresh copy binds to this PC
        return True, "license bound to this PC"
    try:
        d = json.loads(LICENSE_PATH.read_text(encoding="utf-8-sig"))
    except Exception:
        return False, "license.json is damaged. " + ONE_PC_MSG
    fp = fingerprint()
    if d.get("machine") != fp or d.get("sig") != _sig(fp, str(d.get("key", ""))):
        return False, ONE_PC_MSG
    return True, "license OK (this PC)"


def enforce(gui: bool = False) -> None:
    ok, msg = check()
    if ok:
        return
    if gui:
        try:
            import ctypes
            ctypes.windll.user32.MessageBoxW(0, msg, "Game Bot - license", 0x10)
        except Exception:
            pass
    raise SystemExit(msg)


if __name__ == "__main__":
    print(check())
