# AI, NPCs, navigation
Sources: https://docs.unity3d.com/Packages/com.unity.ai.navigation@2.0/manual/NavMeshSurface.html | https://docs.unity3d.com/Manual/com.unity.ai.navigation.html | https://docs.unity3d.com/ScriptReference/AI.NavMeshAgent.html | https://dev.epicgames.com/documentation/en-us/unreal-engine/behavior-trees-in-unreal-engine

## NavMesh (Unity 6, AI Navigation 2.x)
- Add NavMesh Surface component, choose Agent Type (deer: radius ~0.4, height ~1.6, step 0.4, slope ~40), Use Geometry = Physics Colliders for terrain+trees, Bake. Runtime: surface.BuildNavMesh() for procedural maps (expensive - do at load, async UpdateNavMesh for changes).
- NavMesh Modifier/Modifier Volume: mark water Not Walkable, roads cheaper area cost. NavMesh Obstacle (carve) for blinds/vehicles.
- NavMeshAgent: SetDestination, check pathPending/remainingDistance, NavMesh.SamplePosition before spawning.
- Huge open terrain: tile-based surfaces per region or skip NavMesh for far animals (simulate on a coarse grid, only path near the player).

## Animal AI states
Idle -> Feed -> Walk/Wander -> Alert (head up, stomp, tail flag) -> Flee -> Bed/Rest; Dead.
- Senses: sight cone x World.SightMul (time of day/weather), hearing radius x World.HearMul (noise from movement/shots), wind/scent direction (Wind.cs) - downwind hunter = alert.
- Alert meter accumulates; thresholds drive transitions; cooldown back to Feed.
- Rut (World.Rut / Cal.RutLevel): bucks more mobile, respond to calls/rattling.
- Flee: pick NavMesh point away from threat (SamplePosition), sprint then slow; remember threat location.

## FSM vs Behavior Tree
- FSM (switch/enum + timers): simple, fast, debuggable - fine for animals with <10 states.
- Behavior tree / utility AI: when many NPC types with shared sub-behaviors (human NPCs, wardens). Unity has Behavior package (com.unity.behavior); Unreal has Behavior Trees + Blackboard + EQS.

## Performance
- Update AI on a staggered schedule (not every frame), LOD the AI (far = coarse sim), avoid Physics queries per frame per animal; pool animals; Spawn.cs density budget.

## Debug
- Draw gizmos for sight cones/paths; on-screen state label in dev builds; log state transitions with timestamps; teach_self on bugs (stuck agents = off-mesh spawn, wrong agent type).
