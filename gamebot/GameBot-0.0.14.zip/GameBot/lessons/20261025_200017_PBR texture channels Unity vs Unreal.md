# PBR texture channels Unity vs Unreal

Tags: assets,pbr,textures
Saved: 2026-10-25T20:00:17

BaseColor sRGB; Normal linear (Unity OpenGL Y+, Unreal DirectX Y- -> flip green); URP Lit metallic R + smoothness A; Unreal ORM = AO/Roughness/Metal with sRGB off. Smoothness = 1 - roughness. Name T_<asset>_BC/_N/_ORM. Playbook: assets-pipeline.md. Source: https://docs.unity3d.com/Manual/StandardShaderMaterialParameterMetallic.html
