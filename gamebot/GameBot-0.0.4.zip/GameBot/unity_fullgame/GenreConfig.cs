using UnityEngine;

/// <summary>Baked into each scene by SceneBuilder: intake genre + gameplay family + the creator's intake brief.</summary>
public class GenreConfig : MonoBehaviour
{
    public string mode = "platformer";   // intake genre id (e.g. open_world) - what the creator picked
    public string family = "";           // gameplay template that implements it (e.g. adventure)
    public string title = "";
    public int laps = 3;
    // Intake brief (Tools/game_brief.json)
    public string story = "";
    public string setting = "";
    public string loop = "";
    public string style = "";
    public string[] goals = new string[0];
    public string[] achIds = new string[0];
    public string[] achTitles = new string[0];
    public string[] achDescs = new string[0];
    void Awake()
    {
        string fam = string.IsNullOrEmpty(family) ? mode : family;
        PlayerPrefs.SetString("GB_Mode", mode); PlayerPrefs.SetString("GB_Title", title);
        GenreState.Mode = mode; GenreState.Family = fam; GenreState.Title = title; GenreState.TotalLaps = laps;
        GenreState.BriefStory = story ?? ""; GenreState.BriefSetting = setting ?? ""; GenreState.BriefLoop = loop ?? "";
        GenreState.BriefStyle = style ?? ""; GenreState.BriefGoals = goals ?? new string[0];
        AchievementSystem.RegisterGoals(achIds, achTitles, achDescs);
        GenreState.ResetMode();
        GenreState.EnemiesTotal = FindObjectsByType<EnemyTarget>(FindObjectsSortMode.None).Length;
        GenreState.CheckpointCount = FindObjectsByType<RaceCheckpoint>(FindObjectsSortMode.None).Length;
        GenreState.ItemsTotal = FindObjectsByType<QuestItem>(FindObjectsSortMode.None).Length;
        GenreState.PadsTotal = FindObjectsByType<PressurePad>(FindObjectsSortMode.None).Length;
        if (fam == "roguelike") { GameState.Lives = 1; GenreState.EnemiesTotal = 0; }
        if (fam == "battle_royale") { GameState.Lives = 1; GenreState.Alive = FindObjectsByType<BrBot>(FindObjectsSortMode.None).Length; }
        if (fam == "strategy") GenreState.PointsTotal = FindObjectsByType<CapturePoint>(FindObjectsSortMode.None).Length;
        if (fam == "racing") GenreState.NextCheckpoint = GenreState.CheckpointCount > 1 ? 1 : 0;
    }
}
