"""Hang auto-reports (0.0.2): watchdog writes Builds\\hang_report_*.txt/.json; chat card offers Preview/Send/Cancel
through the existing redacted bug-report flow (to the support address). Nothing is ever sent without a click."""
import sys, shutil
from pathlib import Path

TAG = ".bak_hang_20261113"

def rd(p):
    with open(p, encoding="utf-8-sig", newline="") as fh:
        b = fh.read()
    nl = "\r\n" if "\r\n" in b else "\n"
    return b.replace("\r\n", "\n"), nl, p.read_bytes()[:3] == b"\xef\xbb\xbf"

def wr(p, t, nl, bom):
    if not Path(str(p) + TAG).exists():
        shutil.copy2(p, str(p) + TAG)
    with open(p, "w", encoding="utf-8-sig" if bom else "utf-8", newline="") as fh:
        fh.write(t.replace("\n", nl))

def sub1(t, old, new, name, marker=None):
    if (marker or new) in t:
        return t
    n = t.count(old)
    if n != 1:
        raise SystemExit(f"{name}: expected 1 match, found {n}: {old[:80]!r}")
    return t.replace(old, new)

PS_FUNC = r'''function Write-HangReport([string]$kind, [string]$rel, [int]$stuck) {
  # Hang auto-report: saved in Builds\ so the user can preview/send it from chat. Nothing is sent from here.
  try {
    $ts = Get-Date -Format "yyyyMMdd_HHmmss"
    $bdir = Join-Path $root "Builds"; New-Item -ItemType Directory -Force $bdir | Out-Null
    $folder = if ($rel -match '^Assets/([^/]+)/') { $Matches[1] } else { "" }
    $pack = $folder
    if ($folder) {
      $f2 = ($folder -replace '[^A-Za-z0-9]', '').ToLower()
      foreach ($m in (Select-String -LiteralPath $status -Pattern ' KIT \[[^\]]+\] (.+?): \d+ files' -ErrorAction SilentlyContinue)) {
        $kn = $m.Matches[0].Groups[1].Value; $k2 = ($kn -replace '[^A-Za-z0-9]', '').ToLower()
        if ($k2 -and $f2 -and ($k2.Contains($f2) -or $f2.Contains($k2))) { $pack = $kn; break }
      }
    }
    $gpu = ""; $vram = 0
    $smi = Join-Path $env:SystemRoot "System32\nvidia-smi.exe"
    if (Test-Path $smi) { $l = @(& $smi --query-gpu=name,memory.total --format=csv,noheader,nounits 2>$null) | Select-Object -First 1; if ($l) { $q = $l -split ','; $gpu = $q[0].Trim(); $vram = [int]($q[1].Trim()) } }
    if (-not $gpu) {
      $vc = @(Get-CimInstance Win32_VideoController -ErrorAction SilentlyContinue | Where-Object { $_.Name -notmatch 'Basic|Virtual|Remote|Parsec' })
      $kk = 'HKLM:\SYSTEM\CurrentControlSet\Control\Class\{4d36e968-e325-11ce-bfc1-08002be10318}'
      foreach ($c in (Get-ChildItem $kk -ErrorAction SilentlyContinue)) {
        $pp = Get-ItemProperty $c.PSPath -ErrorAction SilentlyContinue; $qw = $pp.'HardwareInformation.qwMemorySize'
        if ($pp.DriverDesc -and $qw -and @($vc | Where-Object { $_.Name -eq $pp.DriverDesc }).Count) { $mb = [int]([uint64]$qw / 1MB); if ($mb -gt $vram) { $vram = $mb; $gpu = $pp.DriverDesc } }
      }
      if (-not $gpu -and $vc) { $gpu = $vc[0].Name }
    }
    $ram = [math]::Round((Get-CimInstance Win32_ComputerSystem).TotalPhysicalMemory / 1GB)
    $uv = if ($uver) { $uver } else { Split-Path (Split-Path (Split-Path $unity -Parent) -Parent) -Leaf }
    $btail = @(Get-Content -LiteralPath $blog -Tail 40 -ErrorAction SilentlyContinue)
    $wl = Get-ChildItem (Join-Path $proj "Logs") -Filter "AssetImportWorker*.log" -ErrorAction SilentlyContinue | Where-Object { $_.Name -notmatch '-prev' } | Sort-Object LastWriteTime -Descending | Select-Object -First 1
    $wtail = if ($wl) { @(Get-Content -LiteralPath $wl.FullName -Tail 40 -ErrorAction SilentlyContinue) } else { @() }
    $ed = Join-Path $env:LOCALAPPDATA "Unity\Editor\Editor.log"
    $etail = if ((Test-Path $ed) -and ((Get-Item $ed).LastWriteTime -gt (Get-Date).AddHours(-2))) { @(Get-Content -LiteralPath $ed -Tail 40 -ErrorAction SilentlyContinue) } else { @() }
    $game = Split-Path $root -Leaf
    $what = if ($kind -eq "import") { "Unity's importer froze on $rel - Game Bot skipped that file and retried the build." } else { "Unity stopped writing to its build log (no import in progress) - Game Bot retried the build." }
    $fileTxt = if ($rel) { $rel } else { "-" }; $packTxt = if ($pack) { $pack } else { "-" }
    $wname = if ($wl) { $wl.Name } else { "AssetImportWorker log (none)" }
    $txt = @("Game Bot hang report $ts", "Game: $game", "What happened: $what", "File: $fileTxt", "Pack: $packTxt",
      "Stuck for: $stuck seconds", "Unity: $uv", "GPU: $gpu", "VRAM: $([math]::Round($vram / 1024, 1)) GB", "RAM: $ram GB", "When: $(Get-Date -Format s)", "",
      "--- last 40 lines of build.log ---") + $btail + @("", "--- last 40 lines of $wname ---") + $wtail
    if ($etail.Count) { $txt += @("", "--- last 40 lines of Editor.log ---") + $etail }
    $enc = New-Object System.Text.UTF8Encoding($false)
    [IO.File]::WriteAllLines((Join-Path $bdir "hang_report_$ts.txt"), [string[]]$txt, $enc)
    $j = [ordered]@{ id = "hang_report_$ts"; kind = $kind; game = $game; file = $rel; pack = $pack; stuck_seconds = $stuck; unity = $uv; gpu = $gpu;
      vram_gb = [math]::Round($vram / 1024, 1); ram_gb = $ram; when = (Get-Date -Format s); report = "hang_report_$ts.txt" }
    [IO.File]::WriteAllText((Join-Path $bdir "hang_report_$ts.json"), ($j | ConvertTo-Json -Compress), $enc)
    S "hang report saved: Builds\hang_report_$ts.txt"
  } catch { S "hang report failed: $_" }
}

'''

GBS_FUNCS = '''

# ---------------------------------------------------------------- hang auto-reports
# The build watchdog (auto_unity.ps1) writes <game>\\Builds\\hang_report_<ts>.txt/.json when it skips a frozen import or a
# build stalls. The chat shows ONE card per stuck file per game; the report only leaves the PC when the user presses Send,
# through the same redacted bug-report zip/preview/send flow (to the support address).
HANG_SEEN = ROOT / "work" / "hang_prompts.json"


def _games_root() -> Path:
    try:
        import gamedev_core
        return Path(gamedev_core.GAME_PROJECTS)
    except Exception:
        return Path(os.environ.get("GAMEBOT_PROJECTS") or (Path.home() / "Documents" / "GameProjects"))


def _hang_key(game: str, file: str) -> str:
    return f"{game}|{(file or '(stall)').strip().lower()}"


def _hang_seen() -> dict:
    return _read_json(HANG_SEEN)


def pending_hang_reports(limit: int = 3) -> list:
    """New hang reports the user hasn't been asked about yet (at most one per file per game)."""
    seen, out, keys = _hang_seen(), [], set()
    root = _games_root()
    try:
        games = [d for d in root.iterdir() if d.is_dir() and not d.name.startswith(".")]
    except Exception:
        return []
    for d in games:
        b = d / "Builds"
        try:
            files = sorted(b.glob("hang_report_*.json"))
        except Exception:
            continue
        for j in files:
            r = _read_json(j)
            if not r:
                continue
            key = _hang_key(d.name, str(r.get("file") or ""))
            if key in seen or key in keys:
                continue
            keys.add(key)
            out.append({"key": key, "id": j.stem, "game": d.name, "kind": r.get("kind") or "import",
                        "file": r.get("file") or "", "pack": r.get("pack") or "", "stuck_seconds": int(r.get("stuck_seconds") or 0),
                        "unity": r.get("unity") or "", "when": r.get("when") or ""})
    return out[-limit:]


def ack_hang_report(key: str, state: str = "prompted") -> dict:
    key = str(key or "")[:400]
    if "|" not in key:
        return {"ok": False, "message": "bad key"}
    seen = _hang_seen()
    seen[key] = {"state": re.sub(r"[^a-z_]", "", state or "prompted")[:20] or "prompted", "when": datetime.now().isoformat(timespec="seconds")}
    HANG_SEEN.parent.mkdir(parents=True, exist_ok=True)
    HANG_SEEN.write_text(json.dumps(seen, indent=2), encoding="utf-8")
    return {"ok": True}


def _find_hang(key: str) -> tuple:
    game = str(key or "").split("|", 1)[0]
    if not game or re.search(r"[\\\\/:*?\\"<>]|\\.\\.", game):
        return None, None, {}
    g = _games_root() / game
    for j in sorted((g / "Builds").glob("hang_report_*.json"), reverse=True):
        r = _read_json(j)
        if r and _hang_key(game, str(r.get("file") or "")) == key:
            return g, j, r
    return g, None, {}


def create_hang_bug_report(key: str) -> dict:
    """Pack the hang report (no chat) into a normal redacted bug report; returns what /api/bug_report returns. Sends nothing."""
    g, j, r = _find_hang(key)
    if not j:
        return {"ok": False, "error": "hang report not found"}
    what = (f"Unity froze importing {r.get('file')} (pack: {r.get('pack') or '-'})" if r.get("file")
            else "Unity stopped responding during a build (no import in progress)")
    desc = (f"[Automatic hang report] {what} for {r.get('stuck_seconds')} s in game {g.name}. "
            f"Game Bot skipped it and retried. Unity {r.get('unity')}, GPU {r.get('gpu')} ({r.get('vram_gb')} GB VRAM), RAM {r.get('ram_gb')} GB.")
    txt = j.with_suffix(".txt")
    res = save_bug_report(desc, "", [], include_chat=False, game_root=g,
                          extra_files={"hang_report.txt": txt, "hang_report.json": j})
    ack_hang_report(key, "report_created")
    return {"ok": True, "hang": r} | res
'''

APP_ROUTES = '''

@app.get("/api/hang_reports/pending")
def api_hang_pending():
    import gb_support
    return jsonify({"reports": gb_support.pending_hang_reports()})


@app.post("/api/hang_report/ack")
def api_hang_ack():
    import gb_support
    data = request.get_json(force=True, silent=True) or {}
    return jsonify(gb_support.ack_hang_report(str(data.get("key") or ""), str(data.get("state") or "prompted")))


@app.post("/api/hang_report/create")
def api_hang_create():
    import gb_support
    data = request.get_json(force=True, silent=True) or {}
    try:
        r = gb_support.create_hang_bug_report(str(data.get("key") or ""))
        return jsonify(r), (200 if r.get("ok") else 404)
    except Exception as e:
        return jsonify({"ok": False, "error": f"{type(e).__name__}: {e}"}), 500
'''

JS_HANG = r'''
  // ---- Hang auto-report: one card per frozen file per game. Nothing is sent unless the user presses Send.
  const hangShown = new Set();
  const hangPost = (url, body) => fetch(url, {method: 'POST', headers: {'Content-Type': 'application/json'}, body: JSON.stringify(body)}).then(r => r.json());
  function addHangCard(h) {
    if (empty) empty.remove();
    const row = document.createElement('div');
    row.className = 'msg assistant hangcard';
    const title = h.kind === 'stall' ? 'Unity stopped responding during a build, so Game Bot restarted it. Send a report so we can fix it?'
                                     : 'Game Bot skipped a file that froze Unity. Send a report so we can fix it?';
    const what = h.file ? (bugEsc(h.file) + (h.pack ? ' (pack: ' + bugEsc(h.pack) + ')' : '')) : 'no single file';
    row.innerHTML = '<div class="avatar assistant">G</div><div class="bubble"><b>' + bugEsc(title) + '</b>' +
      '<div style="font-size:12px;opacity:.85;margin-top:4px">' + bugEsc(h.game) + ': ' + what + ' - stuck about ' + Math.max(1, Math.round((h.stuck_seconds || 0) / 60)) + ' min' +
      (h.unity ? ', Unity ' + bugEsc(h.unity) : '') + '. The report has the file, pack, Unity version, GPU, VRAM, RAM and the last log lines (no chat), with your user name and folders blanked out.</div>' +
      '<div style="margin-top:6px;display:flex;gap:6px"><button type="button" class="bugbtn" data-a="preview">Preview</button><button type="button" class="bugbtn" data-a="send">Send</button><button type="button" class="bugbtn" data-a="cancel">Cancel</button></div>' +
      '<div class="hangmsg" style="font-size:12px;margin-top:4px;white-space:pre-line"></div></div>';
    const msg = row.querySelector('.hangmsg'), btns = row.querySelectorAll('button');
    const done = t => { msg.textContent = t; btns.forEach(b => b.disabled = true); };
    let made = null;
    async function make() {
      if (made) return made;
      msg.textContent = 'Packing the hang report...';
      const r = await hangPost('/api/hang_report/create', {key: h.key});
      if (!r.ok) { msg.textContent = 'Could not create the report: ' + (r.error || 'unknown error'); return null; }
      made = r; return r;
    }
    row.querySelector('[data-a="preview"]').onclick = async () => {
      const r = await make(); if (!r) return;
      bugReset(); bugModal.classList.add('show'); bugText.style.display = 'none';
      document.getElementById('bugTitle').innerHTML = '<b>Hang report - preview</b>';
      await bugShowPreview(r);
      msg.textContent = 'Preview open - Send or Cancel it there.';
    };
    row.querySelector('[data-a="send"]').onclick = async () => {
      const r = await make(); if (!r) return;
      const s = r.smtp ? await hangPost('/api/bug_report/send', {id: r.id}) : await hangPost('/api/bug_report/email', {id: r.id});
      if (s.ok) done(s.message || 'Sent.'); else msg.textContent = s.message || 'Could not send.';
    };
    row.querySelector('[data-a="cancel"]').onclick = async () => {
      try { if (made) await hangPost('/api/bug_report/discard', {id: made.id}); await hangPost('/api/hang_report/ack', {key: h.key, state: 'cancelled'}); } catch (e) {}
      done('OK - no report was sent. The hang report stays in ' + h.game + '\\Builds if you change your mind.');
    };
    chat.appendChild(row);
    chat.scrollTop = chat.scrollHeight;
  }
  async function pollHangs() {
    try {
      const d = await (await fetch('/api/hang_reports/pending')).json();
      for (const h of (d.reports || [])) {
        if (hangShown.has(h.key)) continue;
        hangShown.add(h.key);
        try { await hangPost('/api/hang_report/ack', {key: h.key, state: 'prompted'}); } catch (e) {}
        addHangCard(h);
      }
    } catch (e) {}
  }
'''

def main(d):
    d = Path(d)
    # ---- auto_studio: hang report function + calls; only an unfinished import is quarantined
    p = d / "auto_studio.py"; t, nl, bom = rd(p)
    t = sub1(t, "# Watchdog: a pack model can hang Unity's import worker forever", PS_FUNC + "# Watchdog: a pack model can hang Unity's import worker forever",
             "ps func", marker="function Write-HangReport")
    t = sub1(t, '''  $bad = (Select-String -Path $blog -Pattern "Importing 'GUID: \\w+ - Path: (.+?)' with importer" -ErrorAction SilentlyContinue | Select-Object -Last 1)\n''',
             '''  $bad = $impKey  # only an import that never finished; a stall after the last import must not quarantine a good file\n''', "bad=impKey")
    t = sub1(t, '''    $rel = $bad.Matches[0].Groups[1].Value; $abs''', '''    $rel = $bad; $abs''', "rel=bad")
    t = sub1(t, '''    S "import hung on $rel - skipped that file, retrying build ($try)"\n''',
             '''    S "import hung on $rel - skipped that file, retrying build ($try)"\n    Write-HangReport "import" $rel ([math]::Max($impStill, $still))\n''', "call import")
    t = sub1(t, '''  } else { S "Unity stalled with no import in progress - retrying build ($try)" }\n''',
             '''  } else { S "Unity stalled with no import in progress - retrying build ($try)"; Write-HangReport "stall" "" $still }\n''', "call stall")
    wr(p, t, nl, bom)

    # ---- gb_support: save_bug_report(game_root, extra_files) + hang helpers
    p = d / "gb_support.py"; t, nl, bom = rd(p)
    t = sub1(t, '''def save_bug_report(description: str, sid: str = "", messages: list | None = None, include_chat: bool = True) -> dict:''',
             '''def save_bug_report(description: str, sid: str = "", messages: list | None = None, include_chat: bool = True,
                    game_root: Path | None = None, extra_files: dict | None = None) -> dict:''', "sig")
    t = sub1(t, '''    game_root, saved = None, {}\n''', '''    saved = {}\n''', "game_root init")
    t = sub1(t, '''        game_root = chat_store.chat_game_root(messages) if messages else None\n''',
             '''        if game_root is None:\n            game_root = chat_store.chat_game_root(messages) if messages else None\n''', "game_root derive")
    t = sub1(t, '''    ld = d / "logs"\n    ld.mkdir(exist_ok=True)\n''',
             '''    for name, p in (extra_files or {}).items():\n        logs[str(name)] = Path(p)\n    ld = d / "logs"\n    ld.mkdir(exist_ok=True)\n''', "extra files")
    if "def pending_hang_reports" not in t:
        t = t.replace("\n\n# ---------------------------------------------------------------- updates", GBS_FUNCS + "\n\n# ---------------------------------------------------------------- updates", 1)
        assert "def pending_hang_reports" in t, "gbs anchor"
    wr(p, t, nl, bom)

    # ---- app routes
    p = d / "app.py"; t, nl, bom = rd(p)
    t = sub1(t, '''@app.get("/api/bug_reports")\ndef api_bug_reports():\n    import gb_support\n    return jsonify({"reports": gb_support.list_bug_reports()})\n''',
             '''@app.get("/api/bug_reports")\ndef api_bug_reports():\n    import gb_support\n    return jsonify({"reports": gb_support.list_bug_reports()})\n''' + APP_ROUTES,
             "routes", marker="/api/hang_reports/pending")
    wr(p, t, nl, bom)

    # ---- UI: reusable preview + hang card + poll
    p = d / "templates" / "index.html"; t, nl, bom = rd(p)
    if "async function bugShowPreview" not in t:
        a = "      bugId = r.id; bugSmtp = !!r.smtp;\n"
        i = t.index(a)
        k = t.index("      bugMsg.textContent = bugSmtp ? ", i)
        e = t.index("\n", k) + 1
        moved = t[i:e]
        t = t[:i] + "      await bugShowPreview(r);\n" + t[e:]
        fn = "  async function bugShowPreview(r) {\n" + moved.replace("\n      ", "\n    ").replace("      bugId", "    bugId", 1) + "  }\n"
        t = sub1(t, "  bugSave.onclick = async () => {\n", fn + "  bugSave.onclick = async () => {\n", "preview fn")
        # the title is changed by the hang preview; restore it on reset
        t = sub1(t, "  function bugReset() { bugMsg.textContent = '';",
                 "  function bugReset() { document.getElementById('bugTitle').innerHTML = '<b>Report a bug</b>'; bugMsg.textContent = '';", "reset title")
    t = sub1(t, "  function vdisp(v){", JS_HANG + "  function vdisp(v){", "hang js", marker="async function pollHangs")
    t = sub1(t, "  pollWorkbar();\n  setInterval(pollWorkbar, 2000);\n", "  pollWorkbar();\n  setInterval(pollWorkbar, 2000);\n  pollHangs();\n  setInterval(pollHangs, 5000);\n",
             "hang poll", marker="setInterval(pollHangs")
    wr(p, t, nl, bom)
    print("patched", d)

if __name__ == "__main__":
    for x in sys.argv[1:]:
        main(x)
