# FPS performance passes

Saved: 2026-10-25T20:20:29

﻿# FPS performance passes

Action playbook for Game Bot. An **FPS pass** = controlled frame-rate measurement on a fixed route/preset to catch regressions before ship.

## Method
1. **Lock variables:** same build (prefer standalone, not Editor), same map spot/route, same camera path, vsync OFF for measure, same resolution.
2. **Warm up** 5–10s (shaders/JIT), then record **30–60s**.
3. Capture **avg FPS**, **1% low** (or 0.1% low), frame time ms, optional GPU/CPU ms.
4. Log to `Docs/QA/fps_passes.md`: date, build/version, preset, scene, resolution, avg, 1% low, notes.
5. Change one thing → re-run pass → compare. teach_self the finding.

## Unity tools
- Window → Analysis → Profiler; Frame Debugger for draw calls.
- `QualitySettings` / URP asset tiers; disable vSync (`QualitySettings.vSyncCount = 0`) while measuring.
- Unity Profile Analyzer / Frame Timing Manager for 1% lows when available.
- Docs: https://docs.unity3d.com/Manual/Profiler.html

## Pass matrix (minimum)
| Preset | Location | Condition |
|--------|----------|-----------|
| Low / High / Ultra | dense content + open + interior | day; add night/weather if cheap |
| Steam Deck stand-in | 1280×800 | gamepad only |

Targets (adjust per game): PC Ultra ≥60 avg with stable 1% lows; Deck playable 30–40.

## What to cut when failing
Shadows distance/cascades, foliage density, MSAA, realtime lights, GPU-heavy post, GC allocations (spike hitch), sync physics rate, occlusion missing.

## Unreal
- `stat fps`, `stat unit`, Unreal Insights; scalability groups; same fixed-route discipline.

## Ship gate
No Steam/Epic upload if Ultra (or target preset) regresses >15% avg or 1% lows tank vs last known-good without a tracked reason.
