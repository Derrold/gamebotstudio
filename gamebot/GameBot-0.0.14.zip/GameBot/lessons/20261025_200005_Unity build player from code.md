# Unity build player from code

Tags: unity,build
Saved: 2026-10-25T20:00:05

In an Editor script: BuildPipeline.BuildPlayer(new BuildPlayerOptions{scenes=..., locationPathName='Builds/Stage_X/Game.exe', target=BuildTarget.StandaloneWindows64}); check report.summary.result==BuildResult.Succeeded else EditorApplication.Exit(1). Stage to a new folder; never install Builds\Windows unasked. Source: https://docs.unity3d.com/ScriptReference/BuildPipeline.BuildPlayer.html
