using UnityEngine;
/// <summary>Sim restock: walking into the stockroom crate refills shelves for $5 per item.</summary>
public class StockCrate : MonoBehaviour
{
    void OnTriggerEnter(Collider o)
    {
        if (!o.CompareTag("Player")) return;
        int add = Mathf.Min(10 - GenreState.Stock, Mathf.Max(0, GenreState.Cash / 5)); if (GenreState.Stock == 0 && add == 0) add = 3;
        GenreState.Stock += add; GenreState.Cash = Mathf.Max(0, GenreState.Cash - add * 5); GameHUD.Flash("Restocked +" + add);
    }
}
