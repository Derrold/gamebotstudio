@echo off
setlocal
set ROOT=%~dp0..
cd /d "%ROOT%"
set CSC=%WINDIR%\Microsoft.NET\Framework64\v4.0.30319\csc.exe
if not exist "%CSC%" (
  echo csc.exe not found at %CSC%
  exit /b 1
)
if not exist "icons\game-bot-site.ico" (
  echo missing icons\game-bot-site.ico
  exit /b 1
)
set OUT=%~1
if "%OUT%"=="" set OUT=GameBot.exe
set VER=%~2
set DISP=%~3
if "%VER%"=="" (
  python "scripts\write_launcher_version.py"
) else (
  python "scripts\write_launcher_version.py" --version "%VER%" --display "%DISP%"
)
if errorlevel 1 exit /b 1
if not exist "launcher\VersionInfo.cs" (
  echo missing launcher\VersionInfo.cs
  exit /b 1
)
"%CSC%" /nologo /target:winexe /platform:x64 /optimize+ /win32icon:"icons\game-bot-site.ico" /reference:System.Windows.Forms.dll /out:"%OUT%" launcher\GameBotLauncher.cs launcher\VersionInfo.cs
if errorlevel 1 exit /b 1
echo built %OUT%
exit /b 0
