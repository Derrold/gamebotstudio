"""Fast, deterministic answers for Game Bot app questions (no model, no game binding)."""
from __future__ import annotations

import re

_UNITY_HUB = "https://public-cdn.cloud.unity3d.com/hub/prod/UnityHubSetup-x64.exe"
_OLLAMA = "https://ollama.com/download"

def _t(text: str) -> str:
    return re.sub(r"\s+", " ", (text or "").strip().lower())



def _is_supported_genres_faq(t: str) -> bool:
    """True only when the user is asking which genres Game Bot can build, not about THIS game."""
    if re.fullmatch(r"(what|which) genres?( can you (build|make|do|create))?( do you (support|build|make))?[.?!]?", t):
        return True
    if not re.search(r"\b(what|which) genres?\b|\bgenres can you\b", t):
        return False
    # "what genre is it / is this game / is NightWard" is about the open game.
    if re.search(r"\b(this|the|my|our)\s+game\b|\bis it\b|\bis this\b|\bcalled\b|\bwhat is this game\b", t):
        return False
    if re.search(r"\bwhat genre is\b|\bwhich genre is\b|\bwhat kind of game\b", t):
        return False
    return bool(re.search(r"\b(can you|do you support|you (build|make|support)|available|supported|list)\b", t))


def asks_about_this_game(text: str) -> bool:
    t = _t(text)
    if not t:
        return False
    if _is_supported_genres_faq(t):
        return False
    return bool(re.search(
        r"\b("
        r"what('?s| is) (this |the |my )?(game )?called|"
        r"what game is this|"
        r"what('?s| is) (its|the|this|my) (name|title|genre)|"
        r"what genre( is it| is this| is the game)?|"
        r"which genre( is it| is this)?|"
        r"what kind of game|"
        r"remind me (the game name|what this (chat|game) is|what (game|genre))|"
        r"what is this (chat|game) about"
        r")\b",
        t,
    ))


def bound_game_reply(text: str, *, title: str = "", genre: str = "", engine: str = "", root=None) -> str | None:
    """Answer name/genre questions about the game already open in this chat. None = not this kind of ask."""
    if not title or not asks_about_this_game(text):
        return None
    genre_txt = (genre or "").replace("_", " ").strip()
    engine_txt = (engine or "").strip()
    bits = [f"This chat is {title}"]
    if genre_txt:
        bits.append(f"a {genre_txt} game")
    if engine_txt:
        bits.append(f"built with {engine_txt}")
    lead = ", ".join(bits[:-1]) + (f", {bits[-1]}" if len(bits) > 1 else "") if len(bits) > 1 else bits[0]
    # nicer: "This chat is NightWard, a horror game, built with Unity."
    if len(bits) == 1:
        sentence = bits[0] + "."
    elif len(bits) == 2:
        sentence = f"{bits[0]}, {bits[1]}."
    else:
        sentence = f"{bits[0]}, {bits[1]}, {bits[2]}."
    if root:
        sentence += f" The project folder is {root}."
    sentence += ' Tell me what to change (for example "make it darker" or "rebuild"), or click New chat for a different game.'
    return sentence



def _app_version() -> tuple[str, str]:
    """(version, display) from the shipped version.json next to this file."""
    try:
        import json
        from pathlib import Path as _P
        d = json.loads((_P(__file__).resolve().parent / "version.json").read_text(encoding="utf-8-sig"))
        if isinstance(d, dict):
            ver = str(d.get("version") or "0.0.0").strip() or "0.0.0"
            disp = str(d.get("display") or "").strip()
            return ver, disp
    except Exception:
        pass
    return "0.0.0", ""


def _is_console_publish_faq(t: str) -> bool:
    """True when the user is asking about Xbox / PlayStation / Switch / console publishing."""
    if not re.search(r"\b(xbox|playstation|play ?station|\bps[45]\b|nintendo|\bswitch\b|consoles?|partner center)\b", t):
        return False
    if re.search(r"\b(called|named|titled)\b", t) and not re.search(
        r"\b(publish|release|ship|port|submit|partner center|dev(eloper)? ?program|store)\b", t
    ):
        return False
    return True


def reply(text: str) -> str | None:
    """Return a direct answer for app/help questions, or None to let other routing run."""
    t = _t(text)
    if not t:
        return None
    # New-game requests must start intake, not a FAQ.
    if re.search(r"\b(make|build|create|start)\b.*\b(game|platformer|shooter|fps)\b", t) and not re.search(
        r"\b(how do i|how to|what happens|install|need)\b", t
    ):
        return None
    if re.search(r"\b(how do i|how to|where do i)\b.*\binstall\b.*\bunity\b|\binstall unity\b", t):
        return (
            "Install Unity Hub, then the Unity 6000.x Editor inside Hub.\n"
            f"1. Download Unity Hub: {_UNITY_HUB}\n"
            "2. Sign in (a free Personal license is enough).\n"
            "3. In Hub, install a Unity 6000.x editor with Windows Build Support.\n"
            "Game Bot looks for that editor automatically. After it's installed, come back here and say "
            "\"make me a game\" and I'll use it. Unreal is optional and not required."
        )
    if re.search(r"\b8\s*gb\b.*\b(edition|mean|means)\b|\bedition\b.*\b8\s*gb\b", t):
        return (
            "The 8 GB edition is the minimum Game Bot edition: it runs the local gamebot-trained model "
            "with context and GPU settings that fit an 8 GB graphics card. That way the same build works "
            "on many PCs, not only high-end ones. If a card has less than 8 GB (or no NVIDIA/AMD GPU Game Bot "
            "can use), I'll say so clearly instead of starting a build that would fail."
        )
    if re.search(
        r"\b(gpu|graphics card|video card|vram)\b|\bsystem requirements?\b|"
        r"\bwhat (gpu|card|hardware|pc) do i need\b|\bminimum (gpu|specs|requirements)\b",
        t,
    ) and not re.search(r"\b8\s*gb\b.*\bedition\b|\bedition\b.*\b8\s*gb\b", t):
        return (
            "NVIDIA RTX 20 series or newer, or AMD RX 6000 series or newer, with at least 8 GB VRAM; 12 GB recommended. "
            "Game Bot picks the AI model for your GPU automatically. "
            "An AMD RX 5000 series card is below that official requirement and may be unstable."
        )
    if re.search(r"\b(report|send|file|submit)\b.*\bbug\b|\bhow do i report\b|\bbug report\b", t):
        return (
            "Use the bug report button in Game Bot (or tell me what went wrong and I'll pack a report). "
            "That saves a zip with this chat, a game summary, logs, and system info. I open a pre-filled "
            "email so you can attach the zip - nothing is sent until you press Send. If your mail app "
            "can't attach the zip automatically, attach GameBot-bug-*.zip from the bug_reports folder yourself."
        )
    if re.search(r"\b(do i )?need unreal\b|\bis unreal (required|needed)\b", t):
        return (
            "No. Unity is enough for most Game Bot games and is the fastest path on an 8-12 GB GPU. "
            "Unreal is optional if you already have it and want Unreal-style visuals or Blueprints. "
            "If Unreal isn't installed, I'll just use Unity (or tell you if you asked for Unreal specifically)."
        )
    if re.search(r"\b(don't|dont|do not|don't have|no)\b.*\bunity\b|\bunity (is )?not installed\b|\bwithout unity\b", t):
        return (
            "You can still chat, plan a game, and get help, but I can't compile a Unity playable build until "
            "Unity Hub and a Unity 6000.x editor (with Windows Build Support) are installed and licensed. "
            f"Hub is here: {_UNITY_HUB}. When that's done, say \"make me a game\" and I'll take it from there. "
            "I won't fail silently - if Unity is missing I'll say so in plain language."
        )
    if _is_supported_genres_faq(t):
        return (
            "I can build games in the top 19 genres, including action, adventure, RPG, shooter, strategy, "
            "simulation, sports, racing, fighting, horror, platformer, puzzle, open world, survival, sandbox, "
            "stealth, battle royale, MOBA, and MMORPG. Say \"make me a game\" and I'll ask for the name, "
            "the main genre, and a few design questions, then build it."
        )
    if re.search(r"\bhow do i (install|get|setup|set up) ollama\b|\bollama (not|isn't|isnt) installed\b", t):
        return (
            "Game Bot's chat AI runs locally through Ollama. Install it from "
            f"{_OLLAMA}, then restart Game Bot. If Ollama is missing or won't start, I'll tell you instead of "
            "hanging with a blank reply."
        )
    if re.search(
        r"\b(other models?|hook (up |in )?models?|bring your own|lm studio|llama\.cpp|"
        r"use (a |my |another |a different )?model|change (the )?model|api key|"
        r"openrouter|anthropic|cloud model)\b",
        t,
    ) and not re.search(r"\b(gpu|graphics card|video card|vram|system requirements?)\b", t):
        return (
            "The default is the Game Bot trained model, which stays on this PC and is the recommended choice. "
            "In Settings you can also pick any Ollama model already installed, point Game Bot at a local "
            "LM Studio or llama.cpp server (an OpenAI-compatible URL), or use a cloud provider "
            "(OpenAI, Anthropic, OpenRouter, or xAI) with an API key you paste in. Keys are stored only "
            "on this PC and encrypted. Cloud models send your chat prompts and game descriptions off this PC."
        )
    # Version / update (not "what version of Unity" unless they also say Game Bot).
    _about_engine_ver = bool(re.search(r"\b(unity|unreal|editor)\b", t) and not re.search(r"\bgame bot\b", t))
    _ask_update = bool(re.search(
        r"\b((how (do i|to|can i)|where do i) update|check for updates?|update game bot|"
        r"get the (new|latest|newest) version)\b",
        t,
    )) and not re.search(r"\b(unity|unreal)\b", t)
    _ask_version = bool(re.search(
        r"\b(what|which|current)\b.{0,40}\bversion\b|"
        r"\bversion\b.{0,30}\b(is this|am i (on|running)|is game bot|are you)\b|"
        r"\bwhat version\b",
        t,
    ))
    if (_ask_update or (_ask_version and not _about_engine_ver)):
        ver, disp = _app_version()
        shown = f"{disp} ({ver})" if disp and disp.lower() != ver.lower() else ver
        bits = [f"This is Game Bot {shown}."]
        if _ask_update or re.search(r"\bupdate\b", t):
            bits.append(
                "Game Bot checks for a newer version when it starts. If one is available, use the update banner "
                "to download and install it (or open Settings and check for updates). The installer backs up your "
                "chats, settings, and license, and it never touches your game projects in Documents\\GameProjects. "
                "You do not need to uninstall first."
            )
        else:
            bits.append(
                "To update, wait for the update banner when a newer version is available, or open Settings and "
                "check for updates. You do not need to uninstall first, and your games stay in place."
            )
        return " ".join(bits)
    if re.search(
        r"\b(run|start|open|launch|use).{0,40}\b(as )?(an? )?(admin|administrator|elevated)\b|"
        r"\b(do i|do we|need (me |to )?|should i|must i)\b.{0,40}\b(admin|administrator|elevated)\b|"
        r"\brun as admin(istrator)?\b|\bneed(s)? admin(istrator)? (rights|privileges|access)?\b|"
        r"\bas administrator\b",
        t,
    ):
        return (
            "No. Run Game Bot normally — do not use Run as administrator and do not start it elevated. "
            "Game Bot launches unelevated on purpose, and Unity is not designed to run with Administrator privileges. "
            "If Windows asks for admin permission, cancel and start Game Bot from the Start Menu shortcut."
        )
    if _is_console_publish_faq(t):
        return (
            "Game Bot builds playable Windows PC games. It does not publish to Xbox, PlayStation, Nintendo Switch, "
            "or other consoles, and it cannot enroll you in those platforms' developer programs (for example "
            "Microsoft Partner Center or Console Partner). Console publishing is a separate process you would do "
            "yourself with that platform's own tools, accounts, and requirements. Game Bot will not set that up "
            "or submit your game there."
        )
    return None


import re as _re

_CHANGE_RE = _re.compile(
    r"\b("
    r"too hard|too easy|too (?:dark|fast|slow|loud|quiet)|"
    r"more trees|more bushes|make it darker|faster player|add a boss|"
    r"crashed|crash(ed|es|ing)?|falls? through|white bushes|bushes are white|"
    r"broken|not working|won'?t start|empty scene|pressed play|"
    r"make more|add more|the player|the floor|the bushes"
    r")\b",
    _re.I,
)


def is_new_game_request(text: str) -> bool:
    """True when the message is asking to start a new game, even if it also lists edits."""
    t = (text or "").strip()
    if not t:
        return False
    if _re.search(r"\b(make|build|create|start)\b.*\bgame\b", t, _re.I):
        return True
    if _re.search(r"\b(i\s+want|i['']d\s+like|id\s+like|i\s+need|please\s+make|lets?\s+make|let['']s\s+make)\b.*\bgame\b", t, _re.I):
        return True
    if _re.search(r"\bnew\s+game\b", t, _re.I):
        return True
    if _re.search(r"\bgame\s+called\b|\b(called|named|titled)\s+[A-Za-z0-9]", t, _re.I):
        return True
    return False


def is_change_without_game(text: str) -> bool:
    t = (text or "").strip()
    if not t:
        return False
    if reply(t):
        return False
    if is_new_game_request(t):
        return False
    return bool(_CHANGE_RE.search(t))


def no_game_change_reply(text: str = "") -> str:
    return (
        "There is no game open in this chat yet, so I can't change a scene or inspect a build. "
        'Say "make me a game" to start one, or tell me the project name if it already exists on this PC.'
    )
