# Game design core loop and meta loop

Tags: design,gdd
Saved: 2026-10-25T20:00:14

Write the core loop (seconds-minutes verb cycle) and meta loop (hours: earn -> unlock -> new content) as one sentence each at the top of Docs/GDD.md. Prove the core loop in grey-box before content. Economy: list sources/sinks, hours-to-next-goal 0.5-2h early. Playbook: game-design.md. Source: https://lostgarden.com/2012/04/30/loops-and-arcs/
