"""Game Bot auto studio: runs the game pipeline with tools, no user steps.

run_auto_game_pipeline(user_text) -> scaffold + filled docs + legal/QA/store/site stubs + Unity project
(background: create project, grey-box Slice01 scene, Windows build). Generic: works for any creator.
Projects live in %USERPROFILE%\\Documents\\GameProjects\\<Name> (override with GAMEBOT_PROJECTS).
"""
from __future__ import annotations

import os
import sys
import json
import shutil

import gb_config  # noqa: F401  (config.json -> GAMEBOT_* env defaults)
import re
import subprocess
from datetime import datetime
from pathlib import Path

from gamedev_core import GAME_PROJECTS, _safe_name, game_name_from, resolve_game_name, make_game_scaffold
from learn_tools import read_playbook, teach_self

ROOT = Path(__file__).resolve().parent
SCRIPTS = ROOT / "scripts"
CURRENT = ROOT / "notes" / "current_game.txt"

# ---------------------------------------------------------------- engine discovery

def find_unity() -> Path | None:
    env = os.environ.get("GAMEBOT_UNITY")
    if env and Path(env).exists():
        return Path(env)
    base = Path(r"C:\Program Files\Unity\Hub\Editor")
    if not base.exists():
        return None
    cands = sorted([p / "Editor" / "Unity.exe" for p in base.iterdir() if (p / "Editor" / "Unity.exe").exists()],
                   key=lambda p: [int(x) for x in re.findall(r"\d+", p.parent.parent.name)], reverse=True)
    pref = [p for p in cands if p.parent.parent.name.startswith("6000")]
    return (pref or cands or [None])[0]


def unity_version(u: Path | None) -> str:
    return u.parent.parent.name if u else "not installed"


# ---------------------------------------------------------------- intent detection

_NEG_Q = re.compile(r"^\s*(how|what|which|why|when|where|explain|tell me|should|can you explain)\b", re.I)


def wants_auto_game(text: str) -> bool:
    t = (text or "").lower().strip()
    if not t:
        return False
    named = re.search(r"\b(called|named|titled)\b", t)
    if _NEG_Q.match(t) and not named:
        return False
    genre = r"game|platformer|fps|shooter|rpg|racing|horror|survival|puzzle|adventure|vertical slice|prototype"
    if re.search(rf"\b(make|build|create|start|scaffold|prototype|design)\b[^.?!]{{0,80}}\b({genre})\b", t):
        return True
    if re.search(r"\bvertical slice\b|\bwhole game\b|\bentire game\b|\bfull game\b|\bstudio setup\b|\bstudio pipeline\b", t):
        return True
    if named and re.search(r"\b(make|build|create|start)\b", t):
        return True
    if re.search(r"\b(auto|automatic(ally)?|do it all|do everything)\b", t) and ("game" in t or named or re.search(rf"\b({genre})\b", t)):
        return True
    return False


SHIP_WORDS = ("steam", "epic", "steampipe", "steamworks", "depot", "capsule", "store page", "storefront",
              "ship it", "ship the", "release prep", "launch prep", "get it on", "publish", "itch")



def engine_choice_from_text(text: str) -> str | None:
    """Return 'Unity' / 'Unreal' if the user clearly picked an engine, else None."""
    t = (text or "").lower().strip()
    if not t:
        return None
    # Asset-import phrases mention Unity but are NOT an engine intake answer
    if re.search(r"\b(my assets|asset store|assets?\s+from\s+unity|import\s+(my|owned|pack)|owned packs?)\b", t):
        return None
    if re.fullmatch(r"assets?(?:\s+from\s+unity)?", t):
        return None
    # explicit pick phrases win
    if re.search(r"\b(use|pick|choose|go with|with)\s+unreal\b|\bunreal\s*(engine|5|ue5)?\b", t) and not re.search(r"\b(unity\s+or\s+unreal|unreal\s+or\s+unity)\b", t):
        if "unity" in t and re.search(r"\b(not|don't|dont)\s+unreal\b", t):
            return "Unity"
        if re.search(r"\bunreal\b|\bue5\b", t) and not re.search(r"\bunity\s+or\s+unreal\b", t):
            # "unity or unreal" question text should not count
            if "unity or unreal" in t or "unreal or unity" in t:
                return None
            return "Unreal"
    if re.search(r"\b(use|pick|choose|go with|with)\s+unity\b|\bunity\s*(6|6000|urp)?\b", t):
        if "unity or unreal" in t or "unreal or unity" in t:
            return None
        if re.search(r"\bunreal\b|\bue5\b", t) and not re.search(r"\b(not|don't|dont)\s+unreal\b", t):
            return None
        return "Unity"
    if re.search(r"\bue5\b|\bunreal\b", t) and "unity" not in t:
        return "Unreal"
    if re.search(r"\bunity\b", t) and not re.search(r"\bunreal\b|\bue5\b", t):
        return "Unity"
    return None


def conversation_engine_choice(messages: list | None, latest: str = "") -> str | None:
    """Scan latest user text then prior user turns for an engine pick."""
    hit = engine_choice_from_text(latest)
    if hit:
        return hit
    for m in reversed(messages or []):
        if m.get("role") != "user":
            continue
        c = str(m.get("content") or "")
        if c.startswith("SYSTEM NOTE"):
            continue
        hit = engine_choice_from_text(c)
        if hit:
            return hit
    return None


def unreal_installed() -> bool:
    return find_unreal() is not None


def intake_ready_for_pipeline(user_text: str, messages: list | None = None) -> tuple[bool, str]:
    """False until full new-game intake is done (title/engine/genre/loop/story/goals/setting/style/template/icon).

    Agrees with intake.tool_gate: unfinished intake blocks; completed assets-phase is OK.
    Never lets a model/forced path scaffold from engine-only.
    """
    try:
        import intake as _INTAKE
        st = getattr(_INTAKE, "_LAST", {}).get("st")
        if st is not None:
            if st.get("phase") == "intake":
                ask = (
                    "Intake is still in progress. Ask the next missing piece "
                    "(engine, title, top-19 genre, core loop, story, goals, setting, art/tone, template, desktop icon) "
                    "and wait - do NOT create a project yet."
                )
                return False, ask
            if st.get("phase") == "assets":
                return True, st.get("engine") or conversation_engine_choice(messages, user_text) or "Unity"
            # idle with a prior completed title still counts if present
            if st.get("title") and st.get("engine"):
                return True, st.get("engine")
    except Exception:
        pass
    eng = conversation_engine_choice(messages, user_text)
    both = "Unity and Unreal are both options on this PC." if unreal_installed() else "Unity is the usual default here; Unreal only if you want it and have it installed."
    ask = (
        "Before I create anything - full intake is required:\n"
        f"1) **Unity or Unreal?** ({both})\n"
        "2) **What is the game called?**\n"
        "3) Genre from the top-19 list\n"
        "4) Core loop, story, goals, setting, art/tone\n"
        "5) Template (Unity URP/Built-in or Unreal Third Person/First Person/Blank)\n"
        "6) Desktop icon after the build? (yes/no)\n\n"
        "Answer through intake (one step at a time). Do not call run_auto_game_pipeline until intake finishes."
    )
    # Engine alone is NOT enough to start the pipeline anymore
    return False, ask


def wants_ship_prep(text: str) -> bool:
    t = (text or "").lower()
    if not any(w in t for w in SHIP_WORDS):
        return False
    if re.match(r"^\s*(why|what is|what's)\b", t):
        return False
    return True


ASSET_WORDS = ("asset", "prop", "3d model", "model of", "mesh", "fbx", "blender", "texture", "low poly", "low-poly")


def wants_asset(text: str) -> bool:
    t = (text or "").lower()
    # Owned Unity pack import - never treat as Blender make_asset
    if re.search(r"\b(my assets|asset store|assets?\s+from\s+unity|owned packs?|import)\b", t):
        return False
    if not any(w in t for w in ASSET_WORDS):
        return False
    # Coaching / progressive asset intake questions - never force Blender
    if re.search(r"\b(what assets|which assets|assets next|start with|characters or weapons|player or tileset|progressive)\b", t):
        return False
    return bool(re.search(r"\b(make|create|build|generate|need|get|model|add|give)\b", t)) and not _NEG_Q.match(t)


# ---------------------------------------------------------------- project resolution

def _set_current(root: Path) -> None:
    try:
        CURRENT.parent.mkdir(exist_ok=True)
        CURRENT.write_text(str(root), encoding="utf-8")
    except Exception:
        pass
    try:
        GAME_PROJECTS.mkdir(parents=True, exist_ok=True)
        (GAME_PROJECTS / ".current").write_text(root.name, encoding="utf-8")
    except Exception:
        pass


def resolve_project(text: str = "") -> Path | None:
    """Named project in text -> that folder; else last auto project; else most recently modified."""
    GAME_PROJECTS.mkdir(parents=True, exist_ok=True)
    m = re.search(r"(?:called|named|titled|for|of)\s+[\"']?([A-Za-z0-9 _-]{2,40})", text or "", re.I)
    if m:
        p = GAME_PROJECTS / _safe_name(re.split(r"\s+[-\u2013\u2014]\s+|\s*[,;:.]\s+", m.group(1).strip())[0])
        if p.exists():
            return p
    low = (text or "").lower().replace(" ", "")
    for p in GAME_PROJECTS.iterdir():
        if p.is_dir() and p.name.lower() in low:
            return p
    if CURRENT.exists():
        p = Path(CURRENT.read_text(encoding="utf-8").strip())
        if p.exists():
            return p
    dirs = [p for p in GAME_PROJECTS.iterdir() if p.is_dir()]
    return max(dirs, key=lambda p: p.stat().st_mtime) if dirs else None


def _w(path: Path, content: str, made: list, root: Path, overwrite: bool = False) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    if path.exists() and not overwrite:
        return
    path.write_text(content, encoding="utf-8")
    made.append(str(path.relative_to(root)))


def _slug(nm: str) -> str:
    return re.sub(r"[^a-z0-9]+", "-", re.sub(r"([a-z])([A-Z])", r"\1-\2", nm).lower()).strip("-") or "game"


def _genre(text: str) -> str:
    t = (text or "").lower()
    for pat, gid in ((r"battle[- ]?royale", "battle_royale"), (r"\bmmo(rpg)?\b|massively multiplayer", "mmorpg"),
                     (r"\bmoba\b|lane[- ]push", "moba"), (r"\bstealth\b|\bsneak", "stealth"), (r"\bsandbox\b|\bvoxel\b", "sandbox"),
                     (r"\bfighting\b|\bfighter\b|\bbrawler\b|beat[- ]?'?em[- ]?up", "fighting"), (r"\bstrategy\b|\brts\b|tower defen[cs]e", "strategy"),
                     (r"\bsports?\b|\bsoccer\b|\bfootball\b|\bbasketball\b|\bhockey\b", "sports"), (r"open[- ]world", "open_world")):
        if re.search(pat, t):
            return gid
    if re.search(r"first[- ]person|\bfps\b|shooter|\bshoot", t):
        return "fps"
    if re.search(r"\bracing\b|\bracer\b|\brace\b|\bdriving\b|\bkart\b", t):
        return "racing"
    if re.search(r"rogue-?like|rogue-?lite|roguelite|permadeath", t):
        return "roguelike"
    if re.search(r"\bhorror\b|\bscary\b", t):
        return "horror"
    if re.search(r"\brpg\b|role[- ]playing", t):
        return "rpg"
    if re.search(r"\bpuzzle\b|sokoban", t):
        return "puzzle"
    if re.search(r"\bsurvival\b|\bcrafting\b", t):
        return "survival"
    if re.search(r"\bsim\b|simulat|tycoon|shop ?keep|management", t):
        return "sim"
    for g in ("platformer", "shooter", "fps", "rpg", "racing", "puzzle", "survival", "horror", "strategy",
              "sim", "simulator", "roguelike", "metroidvania", "sports", "farming", "stealth", "adventure"):
        if g in t:
            return g
    return "action-adventure"


# Top-19 intake genre id -> gameplay family (which SceneBuilder builder implements it). Mirrors SceneBuilder.FamilyFor.
GENRE_LABELS = {
    "action": "Action", "adventure": "Adventure", "rpg": "RPG", "shooter": "Shooter / FPS", "fps": "Shooter / FPS",
    "strategy": "Strategy", "simulation": "Simulation", "sim": "Simulation", "sports": "Sports", "racing": "Racing",
    "fighting": "Fighting", "horror": "Horror", "platformer": "Platformer", "puzzle": "Puzzle",
    "open_world": "Open World", "survival": "Survival", "sandbox": "Sandbox", "stealth": "Stealth",
    "battle_royale": "Battle Royale", "moba": "MOBA", "mmorpg": "MMORPG", "roguelike": "Roguelike",
    "action-adventure": "Action-adventure",
}


EXACT_FAMILY = {
    "action": "action", "adventure": "adventure", "rpg": "rpg", "shooter": "fps", "fps": "fps", "strategy": "strategy",
    "simulation": "sim", "sim": "sim", "sports": "sports", "racing": "racing", "fighting": "fighting", "horror": "horror",
    "platformer": "platformer", "puzzle": "puzzle", "open_world": "adventure", "survival": "survival", "sandbox": "sandbox",
    "stealth": "stealth", "battle_royale": "battle_royale", "moba": "moba", "mmorpg": "mmorpg", "roguelike": "roguelike",
    "action-adventure": "adventure", "metroidvania": "platformer", "farming": "sim",
}
# Free-text fallback: FIRST matching row wins (specific genres before the generic ones they contain).
FAMILY_PRIORITY = (
    ("battle_royale", ("battle_royale", "battle royale", "battle-royale")), ("mmorpg", ("mmorpg", "mmo")), ("moba", ("moba",)),
    ("stealth", ("stealth", "sneak", "infiltrat")), ("sandbox", ("sandbox", "voxel", "block build")),
    ("fighting", ("fighting", "fighter", "brawler", "beat 'em", "martial")), ("strategy", ("strategy", "rts", "tactics", "tower defense")),
    ("sports", ("sports", "soccer", "football", "basketball", "hockey")), ("roguelike", ("roguelike", "roguelite", "rogue-like", "rogue")),
    ("racing", ("racing", "race", "driving", "kart")), ("horror", ("horror", "scary")), ("fps", ("shooter", "fps", "first person shooter")),
    ("rpg", ("rpg", "role playing", "role-playing")), ("puzzle", ("puzzle", "sokoban")), ("survival", ("survival", "crafting")),
    ("sim", ("simulation", "tycoon", "shop", "management", "sim")), ("adventure", ("open_world", "open world", "adventure")),
    ("platformer", ("platformer", "platform")), ("action", ("action", "hack and slash", "hack-and-slash")),
)


def builder_family(genre: str) -> str:
    """Intake genre id -> SceneBuilder family. Exact id first, then priority keywords (no substring collisions:
    mmorpg is not rpg, battle_royale is not fps, stealth is not horror, sandbox is not survival)."""
    g = (genre or "").strip().lower().replace(" ", "_")
    if g in EXACT_FAMILY:
        return EXACT_FAMILY[g]
    t = g.replace("_", " ")
    for fam, keys in FAMILY_PRIORITY:
        if any(k.replace("_", " ") in t for k in keys):
            return fam
    return "platformer"


FAMILY_LOOP_LINE = {
    "fps": "Playable FPS loop (aim, shoot, reload, clear hostiles)",
    "racing": "Playable racing loop (laps, checkpoints, timer)",
    "horror": "Playable horror loop (flashlight, fuses, stalker, exit)",
    "rpg": "Playable RPG loop (quest giver, relics, XP/levels)",
    "puzzle": "Playable puzzle loop (push blocks onto pads)",
    "survival": "Playable survival loop (gather wood/food, build fire, hunger)",
    "adventure": "Playable explore loop (objective marker, key, gate, landmark)",
    "sim": "Playable shop-sim loop (serve, restock, cash goal)",
    "roguelike": "Playable wave-combat loop (permadeath, waves)",
    "platformer": "Playable 3D platformer loop (coins, hazards, goal flag)",
    "action": "Playable action loop (melee combos, dash, enemy camps, boss)",
    "fighting": "Playable 1v1 fighting loop (light/heavy/block, best of 3 rounds)",
    "strategy": "Playable RTS loop (gather income, train units, capture points, destroy the enemy HQ)",
    "moba": "Playable MOBA loop (hero abilities, minion waves, towers, enemy core)",
    "sports": "Playable football match (kick, dribble, keeper AI, first to 3 goals)",
    "sandbox": "Playable sandbox build loop (harvest, place/remove blocks, light the sky beacon)",
    "stealth": "Playable stealth loop (guard vision cones, crouch/cover, steal intel, extract)",
    "battle_royale": "Playable battle-royale loop (loot, shrinking storm, last one standing)",
    "mmorpg": "Playable MMO-style loop (quest hub, mobs, XP/levels, abilities, world boss)",
}


def split_goals(goals: str) -> list[str]:
    parts = re.split(r"\s*(?:[,;\n]|\band then\b|\bthen\b)\s*|\s+and\s+(?=[a-z]+\s)", (goals or "").strip(), flags=re.I)
    out = []
    for p in parts:
        p = (p or "").strip(" .-")
        if len(p) >= 3 and p.lower() not in ("and", "then"):
            out.append(p[:1].upper() + p[1:])
    return out[:6]


def _ach_title(goal: str) -> str:
    words = re.sub(r"[^A-Za-z0-9 ']+", " ", goal).split()
    keep = [w for w in words if w.lower() not in ("the", "a", "an", "to", "of", "his", "her", "their", "my")] or words
    return " ".join(w[:1].upper() + w[1:] for w in keep[:4]) or "Goal"


def _sentence(s: str) -> str:
    """'jon is searching' -> 'Jon is searching.' (capitalised, ends with . ! or ?)"""
    s = re.sub(r"\s+", " ", (s or "").strip())
    if not s:
        return ""
    s = s[:1].upper() + s[1:]
    return s if s[-1] in ".!?" else s + "."


def asset_name_from(desc: str, max_len: int = 48) -> str:
    """'a rusted radio tower with a red warning light' -> 'RustedRadioTowerRedWarningLight'.
    Drops filler words, keeps whole words, filesystem-safe, <= max_len chars."""
    stop = {"a", "an", "the", "with", "and", "of", "for", "some", "my", "me", "on", "in", "to", "that", "this",
            "model", "asset", "prop", "mesh", "make", "create", "build", "generate", "please"}
    words = [w for w in re.findall(r"[A-Za-z0-9]+", desc or "") if w.lower() not in stop]
    out = ""
    for w in words:
        piece = w[:1].upper() + w[1:]
        if len(out) + len(piece) > max_len:
            break
        out += piece
    return out or "Prop"


def _display_title(t: str) -> str:
    t = re.sub(r"\s+", " ", (t or "").strip())
    if t and t == t.lower():
        t = " ".join(w[:1].upper() + w[1:] for w in t.split())
    return t


def make_brief(nm: str, display_title: str = "", genre: str = "", loop: str = "", story: str = "",
               goals: str = "", setting: str = "", style: str = "") -> dict:
    """Single source of truth for what the creator asked for. Written to Tools/game_brief.json and read by
    SceneBuilder (intro, objectives, win text, achievements) and by the docs below."""
    gl = split_goals(goals)
    ids = [f"goal_{nm.lower()}_{i}" for i in range(len(gl))]
    return {
        "title": nm,
        "display_title": _display_title(display_title or nm),
        "genre": genre or "",
        "genre_label": GENRE_LABELS.get(genre or "", (genre or "").replace("_", " ").title()),
        "family": builder_family(genre),
        "loop": (loop or "").strip(),
        "story": (story or "").strip(),
        "setting": (setting or "").strip(),
        "style": (style or "").strip(),
        "goals": gl,
        "ach_ids": ids,
        "ach_titles": [_ach_title(g) for g in gl],
        "ach_descs": gl,
    }


def _brief_from_text(user_text: str) -> dict:
    """Legacy: pull 'core loop: ... | story: ...' bits out of a pipe-joined request."""
    out = {}
    for key, label in (("loop", "core loop"), ("story", "story"), ("goals", "goals"), ("setting", "setting"), ("style", "art/tone")):
        m = re.search(re.escape(label) + r":\s*([^|]+)", user_text or "", re.I)
        if m:
            out[key] = m.group(1).strip()
    return out


def load_brief(root: Path) -> dict | None:
    p = root / "Tools" / "game_brief.json"
    try:
        if p.is_file():
            return json.loads(p.read_text(encoding="utf-8"))
    except Exception:
        pass
    return None


def _status_file(root: Path) -> Path:
    """Builds/auto_unity_status.txt, or Builds/auto_unreal_status.txt for an Unreal project (whichever is newer)."""
    u, r = root / "Builds" / "auto_unity_status.txt", root / "Builds" / "auto_unreal_status.txt"
    if r.is_file() and (not u.is_file() or r.stat().st_mtime > u.stat().st_mtime):
        return r
    return u


def _save_job_pid(root: Path, proc) -> None:
    """Remember the background build's powershell PID so a killed/crashed job is detected (not left RUNNING)."""
    try:
        (root / "Builds").mkdir(parents=True, exist_ok=True)
        (root / "Builds" / "auto_job.pid").write_text(str(proc.pid), encoding="utf-8")
    except Exception:
        pass


def _pid_alive(pid: int) -> bool:
    try:
        r = subprocess.run(["tasklist", "/FI", f"PID eq {pid}", "/NH"], capture_output=True, text=True, timeout=10, creationflags=0x08000000)
        return str(pid) in (r.stdout or "")
    except Exception:
        return True


def _job_pid_state(root: Path, st: Path):
    """True/False if a pid file for the current job exists (alive/dead), None if unknown."""
    pf = root / "Builds" / "auto_job.pid"
    try:
        if pf.is_file() and pf.stat().st_mtime >= st.stat().st_mtime - 60 * 60 * 6:
            return _pid_alive(int(pf.read_text().strip() or 0))
    except Exception:
        pass
    return None


def _mark_stopped(root: Path, st: Path, lines: list) -> str:
    """Rewrite a dead job's RUNNING/QUEUED status as a finished failure so chat/demo stop saying 'in progress'."""
    head = "DONE FAIL STOPPED - the build process ended without finishing (killed or crashed)"
    # the job may have finished (logged "HH:MM:SS DONE ...") but failed to rewrite the head line (file busy) - trust the log
    import re as _re
    done = next((l for l in reversed(lines) if _re.match(r"^\d\d:\d\d:\d\d DONE (OK|FAIL)", l)), "")
    if done:
        head = done[9:]
    try:
        st.write_text("\n".join([head, "--- log ---"] + [l for l in lines[1:] if l != "--- log ---"]) + "\n", encoding="utf-8")
    except Exception:
        pass
    return head


def unity_job_running(root: Path) -> bool:
    """True while this project's background Unity/Unreal job (auto_unity.ps1 / auto_unreal.ps1) is queued or running."""
    st = _status_file(root)
    try:
        if not st.is_file():
            return False
        head = st.read_text(encoding="utf-8", errors="ignore").lstrip()
        if not head.startswith(("QUEUED", "RUNNING")):
            return False
        alive = _job_pid_state(root, st)
        if alive is not None:
            return alive  # the build's own powershell process is the truth (covers Blender/kit steps between Unity runs)
        import time as _t
        age = _t.time() - st.stat().st_mtime
        if age > 45 * 60:
            return False  # stale status from a killed job
        if head.startswith("QUEUED") and age < 180:
            return True
        if st.name == "auto_unreal_status.txt":
            r = subprocess.run(["tasklist", "/NH"], capture_output=True, text=True, timeout=10, creationflags=0x08000000)
            return any(x in (r.stdout or "") for x in ("UnrealEditor", "dotnet.exe", "UnrealBuildTool", "AutomationTool"))
        r = subprocess.run(["tasklist", "/FI", "IMAGENAME eq Unity.exe", "/NH"], capture_output=True, text=True, timeout=10, creationflags=0x08000000)
        return "Unity.exe" in (r.stdout or "")
    except Exception:
        return False


def build_status(root: Path | None = None) -> str:
    """Real status of the current project's Unity job for chat / progress (never invents NOT_STARTED)."""
    try:
        root = root or resolve_project("")
    except Exception:
        root = None
    if not root:
        return ""
    st = _status_file(root)
    eng = "Unreal" if st.name == "auto_unreal_status.txt" else "Unity"
    if not st.is_file():
        return f"{root.name}: no Unity build started yet."
    lines = [l.strip() for l in st.read_text(encoding="utf-8", errors="ignore").splitlines() if l.strip()]
    head = lines[0] if lines else ""
    last = next((l for l in reversed(lines) if l != head and not l.startswith("---")), "")
    import time as _t
    if head.startswith(("QUEUED", "RUNNING")):
        if unity_job_running(root):
            return f"{eng} build RUNNING for {root.name} ({int(_t.time() - st.stat().st_mtime)}s since last step): {last or head}"
        if _job_pid_state(root, st) is False or (_t.time() - st.stat().st_mtime) > 600:
            h2 = _mark_stopped(root, st, lines)
            return f"{root.name}: {h2}" if h2.startswith("DONE OK") or not h2.startswith("DONE FAIL STOPPED") else f"{root.name}: {h2} - last step: {last}"
        return f"{root.name}: status says {head} but no {eng} process is running (job may have stopped) - last step: {last}"
    return f"{root.name}: {head}"


def last_build_summary(root: Path | None = None) -> str:
    """'' when no build ever ran; else 'Last build - OpenWorldPlusTwo: DONE OK <exe> (finished 1:28 AM)'."""
    try:
        root = root or resolve_project("")
        if not root:
            return ""
        st = _status_file(root)
        if not st.is_file():
            return ""
        lines = [l.strip() for l in st.read_text(encoding="utf-8", errors="ignore").splitlines() if l.strip()]
        head = lines[0] if lines else ""
        if not head:
            return ""
        when = datetime.fromtimestamp(st.stat().st_mtime).strftime("%I:%M %p").lstrip("0")
        if head.startswith(("QUEUED", "RUNNING")):
            return f"Last build - {root.name}: stopped while {head} (last update {when})"
        extra = [l for l in lines[1:] if not l.startswith("---")]
        note = f"; {extra[-1]}" if extra and "DONE" not in extra[-1] else ""
        return f"Last build - {root.name}: {head} (finished {when}{note})"
    except Exception:
        return ""


def refresh_unity_tools(root: Path) -> None:
    """Bring an existing game's build scripts up to this Game Bot version (after an update or a fix):
    copy the current Unity C# templates and swap in the current build/watchdog section of auto_unity.ps1."""
    try:
        src = Path(__file__).resolve().parent / "unity_fullgame"
        dst = root / "Tools" / "Unity"
        if src.is_dir() and dst.is_dir():
            for f in src.glob("*.cs"):
                shutil.copy2(f, dst / f.name)
        ps1 = root / "Tools" / "auto_unity.ps1"
        if ps1.is_file():
            t = ps1.read_text(encoding="utf-8-sig")
            a, b = 'S "build scene + Windows player"\n', 'S "build exit'
            i, j = t.find(a), t.find(b)
            ti, tj = AUTO_UNITY_PS1.find(a), AUTO_UNITY_PS1.find(b)
            if i >= 0 and j > i and ti >= 0 and tj > ti:
                new = t[:i] + AUTO_UNITY_PS1[ti:tj] + t[j:]
                if new != t:
                    ps1.write_text(new, encoding="utf-8")
    except Exception:
        pass


def queue_unity_rebuild(root: Path) -> str:
    """Re-run Tools/auto_unity.ps1 (skips createProject, rebuilds scenes + player) unless a job is already running."""
    ps1 = root / "Tools" / "auto_unity.ps1"
    if not ps1.is_file():
        return "no Tools\\auto_unity.ps1 yet (build starts with the pipeline)"
    if unity_job_running(root):
        return "a Unity build is already running - the next build picks this up"
    refresh_unity_tools(root)
    if os.environ.get("GAMEBOT_SKIP_UNITY") == "1":
        return "rebuild skipped (GAMEBOT_SKIP_UNITY=1)"
    (root / "Builds" / "auto_unity_status.txt").write_text("QUEUED\n", encoding="utf-8")
    flags = 0x00000200 | 0x08000000
    _jp = subprocess.Popen(["powershell", "-NoProfile", "-ExecutionPolicy", "Bypass", "-WindowStyle", "Hidden", "-File", str(ps1)],
                     creationflags=flags, close_fds=True, stdin=subprocess.DEVNULL,
                     stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    _save_job_pid(root, _jp)
    return "Unity rebuild queued (Builds\\auto_unity_status.txt)"


def unity_project_dir(root: Path) -> Path | None:
    for c in [root / f"{root.name}Unity", root / "Unity", root]:
        if (c / "Assets").is_dir() and (c / "ProjectSettings").is_dir():
            return c
    try:
        for c in root.iterdir():
            if c.is_dir() and (c / "Assets").is_dir() and (c / "ProjectSettings").is_dir():
                return c
    except Exception:
        pass
    return None


def _index_sections() -> list[str]:
    try:
        idx = read_playbook("complete-game-builder-index")
        return [l[3:].strip() for l in idx.splitlines() if l.startswith("## ") and l[3:4].isdigit()]
    except Exception:
        return []


# ---------------------------------------------------------------- Unity templates

SCENE_BUILDER_CS = r'''using System.IO;
using UnityEditor;
using UnityEditor.SceneManagement;
using UnityEngine;

// Generated by Game Bot auto studio. Re-run any time: -executeMethod SceneBuilder.Build (scene is rebuilt from code).
public static class SceneBuilder
{
    const string ScenePath = "Assets/Scenes/Slice01.unity";

    public static void Build()
    {
        Directory.CreateDirectory("Assets/Scenes");
        string game = System.Environment.GetEnvironmentVariable("GAMEBOT_GAME_NAME");
        if (!string.IsNullOrEmpty(game)) PlayerSettings.productName = game;
        var scene = EditorSceneManager.NewScene(NewSceneSetup.DefaultGameObjects, NewSceneMode.Single);

        var ground = GameObject.CreatePrimitive(PrimitiveType.Plane);
        ground.name = "Ground";
        ground.transform.localScale = new Vector3(10f, 1f, 10f);

        for (int i = 0; i < 12; i++)
        {
            var b = GameObject.CreatePrimitive(PrimitiveType.Cube);
            b.name = "Block_" + i;
            float a = i * 30f * Mathf.Deg2Rad;
            float h = 2f + (i % 3) * 2f;
            b.transform.position = new Vector3(Mathf.Cos(a) * 20f, h * 0.5f, Mathf.Sin(a) * 20f);
            b.transform.localScale = new Vector3(2f, h, 2f);
        }

        var goal = GameObject.CreatePrimitive(PrimitiveType.Cylinder);
        goal.name = "Goal";
        goal.transform.position = new Vector3(0f, 1f, 30f);
        goal.transform.localScale = new Vector3(2f, 1f, 2f);
        goal.GetComponent<Collider>().isTrigger = true;
        goal.AddComponent<SliceGoal>();

        var player = GameObject.CreatePrimitive(PrimitiveType.Capsule);
        player.name = "Player";
        player.tag = "Player";
        player.transform.position = new Vector3(0f, 1.1f, 0f);
        Object.DestroyImmediate(player.GetComponent<CapsuleCollider>());
        player.AddComponent<CharacterController>();
        player.AddComponent<SimplePlayer>();
        var camGo = GameObject.Find("Main Camera");
        if (camGo != null)
        {
            camGo.transform.SetParent(player.transform, false);
            camGo.transform.localPosition = new Vector3(0f, 0.6f, 0f);
            camGo.transform.localRotation = Quaternion.identity;
        }
        new GameObject("HUD").AddComponent<SliceHud>();

        EditorSceneManager.SaveScene(scene, ScenePath);
        EditorBuildSettings.scenes = new[] { new EditorBuildSettingsScene(ScenePath, true) };
        AssetDatabase.SaveAssets();
        Debug.Log("SCENEBUILDER_OK " + ScenePath);
    }

    public static void BuildWindows()
    {
        Build();
        string outDir = System.Environment.GetEnvironmentVariable("GAMEBOT_BUILD_DIR");
        if (string.IsNullOrEmpty(outDir)) outDir = Path.GetFullPath("../Builds/Windows");
        Directory.CreateDirectory(outDir);
        var opts = new BuildPlayerOptions
        {
            scenes = new[] { ScenePath },
            locationPathName = Path.Combine(outDir, PlayerSettings.productName + ".exe"),
            target = BuildTarget.StandaloneWindows64,
            options = BuildOptions.None
        };
        var report = BuildPipeline.BuildPlayer(opts);
        Debug.Log("BUILD_RESULT " + report.summary.result + " " + opts.locationPathName);
        if (report.summary.result != UnityEditor.Build.Reporting.BuildResult.Succeeded) EditorApplication.Exit(1);
    }
}
'''

SIMPLE_PLAYER_CS = r'''using UnityEngine;

[RequireComponent(typeof(CharacterController))]
public class SimplePlayer : MonoBehaviour
{
    public float speed = 6f, look = 2f, gravity = -20f, jump = 6f;
    float vy, pitch;
    CharacterController cc;
    Transform cam;

    void Start()
    {
        cc = GetComponent<CharacterController>();
        var c = GetComponentInChildren<Camera>();
        if (c != null) cam = c.transform;
        Cursor.lockState = CursorLockMode.Locked;
    }

    void Update()
    {
        float h = 0f, v = 0f;
        bool jumpPressed = false;
#if ENABLE_LEGACY_INPUT_MANAGER
        h = Input.GetAxis("Horizontal");
        v = Input.GetAxis("Vertical");
        transform.Rotate(0f, Input.GetAxis("Mouse X") * look, 0f);
        pitch = Mathf.Clamp(pitch - Input.GetAxis("Mouse Y") * look, -80f, 80f);
        if (cam != null) cam.localEulerAngles = new Vector3(pitch, 0f, 0f);
        jumpPressed = Input.GetButtonDown("Jump");
        if (Input.GetKeyDown(KeyCode.Escape)) Cursor.lockState = CursorLockMode.None;
#endif
        if (cc.isGrounded) vy = jumpPressed ? jump : -1f; else vy += gravity * Time.deltaTime;
        Vector3 move = (transform.right * h + transform.forward * v) * speed;
        move.y = vy;
        cc.Move(move * Time.deltaTime);
    }
}
'''

SLICE_GOAL_CS = r'''using UnityEngine;

public class SliceGoal : MonoBehaviour
{
    public static bool Reached;
    void OnTriggerEnter(Collider other)
    {
        if (other.CompareTag("Player")) Reached = true;
    }
}
'''

SLICE_HUD_CS = r'''using UnityEngine;

public class SliceHud : MonoBehaviour
{
    void OnGUI()
    {
        var s = new GUIStyle(GUI.skin.label) { fontSize = 22 };
        string msg = SliceGoal.Reached ? "SLICE COMPLETE - Esc to unlock cursor" : "Objective: reach the goal pillar (WASD + mouse, Space = jump)";
        GUI.Label(new Rect(20, 20, 900, 40), msg, s);
    }
}
'''

AUTO_UNITY_PS1 = r'''# Generated by Game Bot auto studio. Runs Unity in batchmode: create project -> grey-box scene -> Windows build.
$ErrorActionPreference = "Continue"
$unity  = "__UNITY__"
$root   = "__ROOT__"
$proj   = "__PROJ__"
$status = Join-Path $root "Builds\auto_unity_status.txt"
$env:GAMEBOT_GAME_NAME = "__NAME__"
$tpl    = "__TEMPLATE__"
$icon   = "__ICON__"
$env:GAMEBOT_BUILD_DIR = Join-Path $root "Builds\Windows"
$env:GAMEBOT_GENRE = "__GENRE__"
$env:GAMEBOT_BRIEF = Join-Path $root "Tools\game_brief.json"
function S($m) { Add-Content -Path $status -Value ("{0:HH:mm:ss} {1}" -f (Get-Date), $m) }
# Wait for Unity.exe only (not its process tree): Start-Process -Wait also waits on the orphan Roslyn VBCSCompiler server Unity leaves running, which hung builds ~5+ min.
function WaitUnity($p) { $null = $p.Handle; $p.WaitForExit(); $ud = Split-Path $unity -Parent
  Get-CimInstance Win32_Process -Filter "name='dotnet.exe'" -ErrorAction SilentlyContinue | Where-Object { $_.CommandLine -match "VBCSCompiler" -and $_.CommandLine -like "*$ud*" } | ForEach-Object { Stop-Process -Id $_.ProcessId -Force -ErrorAction SilentlyContinue; S "killed orphan VBCSCompiler $($_.ProcessId)" }
  return $p }
New-Item -ItemType Directory -Force (Join-Path $root "Builds") | Out-Null
Set-Content -Path $status -Value "RUNNING"
# Pre-build checks for fresh PCs: stop early with a plain-English fix instead of a bare "see build.log"
function PreFail($m) { S "PRECHECK FAIL $m"; $pl = @(Get-Content -Path $status | Where-Object { $_ -ne "RUNNING" }); Set-Content -Path $status -Value (@("DONE FAIL SETUP: $m", "--- log ---") + $pl); exit 1 }
if (-not $unity -or -not (Test-Path -LiteralPath $unity)) { PreFail "Unity Editor not found ($unity). Open Unity Hub > Installs > Install Editor, pick a Unity 6 (6000.x) version, then build again." }
$ued = Split-Path $unity -Parent
$uver = Split-Path (Split-Path $ued -Parent) -Leaf
S "precheck Unity $uver at $ued"
if ($uver -match '^\d{4}\.' -and $uver -notmatch '^6000\.') { S "warning: Unity $uver found; Game Bot is made for Unity 6 (6000.x). If the build fails, install a 6000.x editor in Unity Hub." }
if (-not (Test-Path -LiteralPath (Join-Path $ued "Data\PlaybackEngines\windowsstandalonesupport"))) { PreFail "Windows Build Support is not installed for Unity $uver. Open Unity Hub > Installs > click the gear next to $uver > Add modules > tick 'Windows Build Support (Mono)' > Install, then build again." }
$lic = (Test-Path -LiteralPath "$env:ProgramData\Unity\Unity_lic.ulf") -or (Test-Path -LiteralPath "$env:LOCALAPPDATA\Unity\licenses\UnityEntitlementLicense.xml")
if (-not $lic) { S "warning: no Unity license found on this PC. If the build fails: open Unity Hub, sign in, then Preferences > Licenses > Add > Get a free Personal license." }
$tdir = Join-Path $ued "Data\Resources\PackageManager\ProjectTemplates"
if (-not (Get-ChildItem -LiteralPath $tdir -Filter "*urp*" -ErrorAction SilentlyContinue)) { S "note: this Unity install has no URP template, so new games use the Built-in renderer (fine; reinstall the editor from Unity Hub to get URP)." }
$free = (Get-PSDrive -Name ($root.Substring(0,1)) -ErrorAction SilentlyContinue).Free
if ($free -and $free -lt 5GB) { PreFail ("Only {0:N1} GB free on drive {1}:. A Unity build needs about 5 GB. Free some space, then build again." -f ($free/1GB), $root.Substring(0,1)) }
if (-not (Test-Path (Join-Path $proj "ProjectSettings"))) {
  S "createProject"
  $cargs = @("-batchmode","-nographics","-quit","-createProject","`"$proj`"","-logFile","`"$root\Builds\create.log`"")
  if ($tpl -and (Test-Path $tpl)) { $cargs += @("-cloneFromTemplate","`"$tpl`""); S "template $(Split-Path $tpl -Leaf)" } else { S "template 3D (Built-in)" }
  $p = WaitUnity (Start-Process -FilePath $unity -ArgumentList $cargs -PassThru -WindowStyle Hidden)
  S "createProject exit $($p.ExitCode)"
}
New-Item -ItemType Directory -Force (Join-Path $proj "Assets\Editor"), (Join-Path $proj "Assets\Scripts"), (Join-Path $proj "Assets\Art\Imports") | Out-Null
# Editor-only scripts (SceneBuilder*.cs, SceneInspector.cs) MUST live under Assets\Editor or the player build fails.
Get-ChildItem (Join-Path $proj "Assets\Scripts") -ErrorAction SilentlyContinue | Where-Object { $_.Name -like "SceneBuilder*" -or $_.Name -like "SceneInspector*" } | Remove-Item -Force -ErrorAction SilentlyContinue
Get-ChildItem (Join-Path $root "Tools\Unity") -Filter *.cs | ForEach-Object {
  if ($_.Name -like "SceneBuilder*.cs" -or $_.Name -eq "SceneInspector.cs") { Copy-Item $_.FullName (Join-Path $proj "Assets\Editor\$($_.Name)") -Force }
  else { Copy-Item $_.FullName (Join-Path $proj "Assets\Scripts\$($_.Name)") -Force }
}
# Things the creator chose to have modelled in Blender (no owned pack) -> headless Blender -> Art\Blender\Exports
S "blender models for missing assets"
try { $blo = & "__PY__" "__PLANPY__" "blender" "$root" 2>&1; foreach ($k in $blo) { S "$k" } } catch { S "blender step failed: $_" }
# Generated Blender models + fetched CC0 models -> Unity Assets (scattered into the level by SceneBuilder)
$bl = Join-Path $root "Art\Blender\Exports"
if (Test-Path $bl) { $bd = Join-Path $proj "Assets\Art\Imports\Blender"; New-Item -ItemType Directory -Force $bd | Out-Null
  Get-ChildItem $bl -Filter *.fbx | ForEach-Object { Copy-Item $_.FullName (Join-Path $bd $_.Name) -Force; S "blender asset -> Assets\Art\Imports\Blender\$($_.Name)" } }
$cc = Join-Path $root "Art\CC0"
if (Test-Path $cc) { $cd = Join-Path $proj "Assets\Art\Imports\CC0"; New-Item -ItemType Directory -Force $cd | Out-Null
  Copy-Item (Join-Path $cc "*") $cd -Recurse -Force; S "cc0 assets -> Assets\Art\Imports\CC0" }
# Owned Asset Store genre kit (character + environment + props) so no family builds primitives-only
S "genre kit __FAMILY__ (owned packs)"
try { $kit = & "__PY__" "__KITPY__" "$proj" "$root" "__FAMILY__" 2>&1; foreach ($k in $kit) { S "$k" } } catch { S "genre kit failed: $_" }
$psAsset = Join-Path $proj "ProjectSettings\ProjectSettings.asset"
if (Test-Path $psAsset) {
  (Get-Content $psAsset -Raw) -replace "activeInputHandler: \d","activeInputHandler: 2" | Set-Content $psAsset -NoNewline
  S "activeInputHandler=2 (Both)"
}
S "build scene + Windows player"
# Watchdog: a pack model can hang Unity's import worker forever (no log output). If the log stalls, skip that file and retry.
$blog = Join-Path $root "Builds\build.log"; $quar = Join-Path $root "Builds\SkippedImports"
for ($try = 1; $try -le 4; $try++) {
  $p = Start-Process -FilePath $unity -ArgumentList @("-batchmode","-nographics","-quit","-projectPath","`"$proj`"","-executeMethod","SceneBuilder.BuildWindows","-logFile","`"$blog`"") -PassThru -WindowStyle Hidden
  $null = $p.Handle; $last = -1; $still = 0; $hung = $false
  while (-not $p.HasExited) {
    Start-Sleep 15
    $len = if (Test-Path $blog) { (Get-Item $blog).Length } else { 0 }
    if ($len -eq $last) { $still += 15 } else { $still = 0; $last = $len }
    if ($still -ge 360) { $hung = $true; break }
  }
  if (-not $hung) { $p = WaitUnity $p; break }
  $bad = (Select-String -Path $blog -Pattern "Importing 'GUID: \w+ - Path: (.+?)' with importer" -ErrorAction SilentlyContinue | Select-Object -Last 1)
  Get-CimInstance Win32_Process -Filter "name='Unity.exe'" -ErrorAction SilentlyContinue | Where-Object { $_.ProcessId -eq $p.Id -or $_.CommandLine -match "-parentPid`"? `"?$($p.Id)\b" } | ForEach-Object { Stop-Process -Id $_.ProcessId -Force -ErrorAction SilentlyContinue }
  Start-Sleep 3
  if ($bad) {
    $rel = $bad.Matches[0].Groups[1].Value; $abs = Join-Path $proj ($rel -replace '/', '\')
    New-Item -ItemType Directory -Force $quar | Out-Null
    foreach ($f in @($abs, "$abs.meta")) { if (Test-Path $f) { Move-Item $f (Join-Path $quar ((Split-Path $f -Leaf))) -Force } }
    Add-Content -Path (Join-Path $root "Tools\skip_imports.txt") -Value $rel
    S "import hung on $rel - skipped that file, retrying build ($try)"
  } else { S "Unity stalled with no import in progress - retrying build ($try)" }
}
S "build exit $($p.ExitCode)"
$errs = (Select-String -Path "$root\Builds\build.log" -Pattern "error CS\d{4}" -ErrorAction SilentlyContinue | Measure-Object).Count
S "error CS lines: $errs"
$pref = Join-Path $root "Builds\Windows\__NAME__.exe"
if (Test-Path $pref) { $exe = Get-Item $pref } else { $exe = Get-ChildItem (Join-Path $root "Builds\Windows") -Filter *.exe -ErrorAction SilentlyContinue | Where-Object { $_.Name -notmatch "^UnityCrashHandler" } | Select-Object -First 1 }
$qa = Select-String -Path "$root\Builds\build.log" -Pattern "QA_FAIL (.+)$" -ErrorAction SilentlyContinue | Select-Object -Last 1
if ($qa) { $final = "DONE FAIL QA: " + $qa.Matches[0].Groups[1].Value }
elseif ($p.ExitCode -eq 0 -and $exe) { $final = "DONE OK $($exe.FullName)" } else {
  # Tell the user the real reason (first matching line of the Unity logs) plus a plain-English fix
  $why = ""; $hint = ""
  $ulogs = @((Join-Path $root "Builds\build.log"), (Join-Path $root "Builds\create.log")) | Where-Object { Test-Path -LiteralPath $_ }
  $rules = @(
    @('No valid Unity Editor license|License is not active|has not been activated|Licensing::|entitlement.*(fail|denied|missing)|com\.unity\.editor\.headless', "Unity isn't activated on this PC. Open Unity Hub, sign in, then Preferences > Licenses > Add > Get a free Personal license, and build again."),
    @('Build target .*(not supported|not installed)|Switching to .*StandaloneWindows.* is disabled|[Mm]odule .* not (loaded|installed)|Windows Build Support', "Windows Build Support is missing. Open Unity Hub > Installs > gear > Add modules > 'Windows Build Support (Mono)'."),
    @('Multiple Unity instances cannot open the same project|another Unity instance is running', "Another Unity window has this project open. Close Unity and build again."),
    @('error CS\d{4}', "A game script didn't compile."),
    @('executeMethod.*(not found|could not be found)', "Game Bot's build script didn't load (usually caused by a script compile error)."),
    @('No space left on device|not enough (disk )?space', "The disk is full. Free some space and build again."),
    @('BuildFailedException|Error building Player|Build Failed|Aborting batchmode due to failure', "")
  )
  foreach ($rule in $rules) {
    $m = $null
    foreach ($lf in $ulogs) { $m = Select-String -LiteralPath $lf -Pattern $rule[0] -Context 0,1 -ErrorAction SilentlyContinue | Select-Object -First 1; if ($m) { break } }
    if ($m) {
      $why = $m.Line.Trim()
      if ($why -match 'Aborting batchmode due to failure:?\s*$' -and $m.Context.PostContext) { $why = ($m.Context.PostContext[0]).Trim() }
      $hint = $rule[1]; break
    }
  }
  if (-not $why) { $why = "Unity exited with code $($p.ExitCode) and no error line was found" }
  if ($why.Length -gt 220) { $why = $why.Substring(0, 220) + "..." }
  $parts = @(); if ($hint) { $parts += $hint }; $parts += ("Unity said: " + $why)
  $final = "DONE FAIL: " + ($parts -join " ") + " (full log: Builds\build.log)"
}
S $final
if ($final -like "DONE OK*" -and $icon -eq "1") {
  try {
    $inst = Join-Path $root "Builds\Installer"; New-Item -ItemType Directory -Force $inst | Out-Null
    $zip = Join-Path $inst "__NAME___Windows.zip"
    # Ship only player files: skip Unity debug/backup folders (*_BackUpThisFolder_ButDontShipItWithYourGame, *_BurstDebugInformation_DoNotShip, *.pdb)
$ship = Get-ChildItem (Join-Path $root "Builds\Windows") | Where-Object { $_.Name -notmatch "DontShip|DoNotShip|_BackUpThisFolder" -and $_.Extension -ne ".pdb" }
Compress-Archive -Path $ship.FullName -DestinationPath $zip -Force
    S "installer zip $zip"
    $lnk = Join-Path ([Environment]::GetFolderPath("Desktop")) "__NAME__.lnk"
    $ws = New-Object -ComObject WScript.Shell; $sc = $ws.CreateShortcut($lnk)
    $sc.TargetPath = $exe.FullName; $sc.WorkingDirectory = $exe.DirectoryName; $sc.IconLocation = $exe.FullName; $sc.Save()
    S "desktop icon $lnk"
  } catch { S "installer/icon failed: $_" }
}
$log = @(Get-Content -Path $status | Where-Object { $_ -ne "RUNNING" })
for ($i = 0; $i -lt 20; $i++) { try { Set-Content -Path $status -Value (@($final, "--- log ---") + $log) -ErrorAction Stop; break } catch { Start-Sleep -Milliseconds 250 } }
'''


def _unity_template(unity, template) -> str:
    """'urp' -> path of the editor's URP project template .tgz (Built-in = Unity's default createProject)."""
    if not unity or (template or "").lower() != "urp":
        return ""
    d = Path(unity).parent / "Data" / "Resources" / "PackageManager" / "ProjectTemplates"
    hits = sorted(d.glob("com.unity.template.urp-blank-*.tgz")) or sorted(d.glob("com.unity.template.*urp*.tgz"))
    return str(hits[-1]) if hits else ""


def _python_exe() -> str:
    """Console python.exe for the genre-kit step (pythonw.exe has no stdout)."""
    exe = Path(sys.executable)
    if exe.name.lower() == "pythonw.exe" and (exe.parent / "python.exe").is_file():
        exe = exe.parent / "python.exe"
    return str(exe)


def start_unity_pipeline(root: Path, nm: str, template: str | None = None, desktop_icon: bool = False, genre: str = "") -> str:
    unity = find_unity()
    (root / "Tools").mkdir(parents=True, exist_ok=True)
    (root / "Tools" / "genre.txt").write_text(genre or "platformer", encoding="utf-8")
    tools = root / "Tools" / "Unity"
    tools.mkdir(parents=True, exist_ok=True)
    full = Path(__file__).resolve().parent / "unity_fullgame"
    if full.is_dir() and (full / "SceneBuilder.cs").is_file():
        for src in full.glob("*.cs"):
            (tools / src.name).write_text(src.read_text(encoding="utf-8"), encoding="utf-8")
    else:
        for fn, src in (("SceneBuilder.cs", SCENE_BUILDER_CS), ("SimplePlayer.cs", SIMPLE_PLAYER_CS),
                        ("SliceGoal.cs", SLICE_GOAL_CS), ("SliceHud.cs", SLICE_HUD_CS)):
            (tools / fn).write_text(src, encoding="utf-8")
    if not unity:
        return "UNITY: not installed -> Unity templates written to Tools\\Unity (human gate: install Unity Hub + a 6000.x editor)."
    proj = root / f"{nm}Unity"
    ps1 = root / "Tools" / "auto_unity.ps1"
    ps1.write_text(AUTO_UNITY_PS1.replace("__UNITY__", str(unity)).replace("__ROOT__", str(root))
                   .replace("__PROJ__", str(proj)).replace("__NAME__", nm)
                   .replace("__TEMPLATE__", _unity_template(unity, template)).replace("__ICON__", "1" if desktop_icon else "0").replace("__GENRE__", genre or "platformer")
                   .replace("__FAMILY__", builder_family(genre)).replace("__PY__", _python_exe())
                   .replace("__KITPY__", str(Path(__file__).resolve().parent / "gb_kits.py"))
                   .replace("__PLANPY__", str(Path(__file__).resolve().parent / "asset_plan.py")), encoding="utf-8")
    if os.environ.get("GAMEBOT_SKIP_UNITY") == "1":
        return f"UNITY: skipped (GAMEBOT_SKIP_UNITY=1). Run later: {ps1}"
    if unity_job_running(root):
        return f"UNITY: a build for {nm} is already running - not starting a second one. {build_status(root)}"
    (root / "Builds").mkdir(parents=True, exist_ok=True)
    (root / "Builds" / "auto_unity_status.txt").write_text("QUEUED\n", encoding="utf-8")
    flags = 0x00000200 | 0x08000000  # NEW_PROCESS_GROUP | NO_WINDOW (survives the chat turn)
    _jp = subprocess.Popen(["powershell", "-NoProfile", "-ExecutionPolicy", "Bypass", "-WindowStyle", "Hidden", "-File", str(ps1)],
                     creationflags=flags, close_fds=True, stdin=subprocess.DEVNULL,
                     stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    _save_job_pid(root, _jp)
    return (f"UNITY {unity_version(unity)}: background job started -> create {proj.name} -> {GENRE_LABELS.get(genre or '', genre or 'platformer')} game "
            f"(gameplay template: {builder_family(genre)}; menu, settings, achievements, owned genre kit) "
            f"-> Builds\\Windows\\{nm}.exe. Status: Builds\\auto_unity_status.txt")


# ---------------------------------------------------------------- docs

CAPSULES = [
    ("header_capsule", 920, 430), ("small_capsule", 462, 174), ("main_capsule", 1232, 706),
    ("vertical_capsule", 748, 896), ("page_background", 1438, 810), ("library_capsule", 600, 900),
    ("library_header", 920, 430), ("library_hero", 3840, 1240), ("library_logo", 1280, 720),
    ("event_cover", 800, 450), ("event_header", 1920, 622), ("community_icon", 184, 184),
    ("screenshot_min_x5", 1920, 1080),
]


def capsule_table() -> str:
    return "\n".join(f"| {n} | {w}x{h} | Store\\Capsules\\{n}\\ |" for n, w, h in CAPSULES)


def write_ship_prep(root: Path, nm: str) -> list[str]:
    made: list[str] = []
    today = datetime.now().strftime("%Y-%m-%d")
    for n, w, h in CAPSULES:
        d = root / "Store" / "Capsules" / n
        d.mkdir(parents=True, exist_ok=True)
        _w(d / "README.txt", f"{n}: {w}x{h} PNG/JPG. Game logo/title readable at small size (except library_hero: no text).\n", made, root)
    _w(root / "Docs" / "Store" / "steam_checklist.md", f"""# {nm} - Steam release checklist (auto-generated {today})
Bot prepares everything below locally. Items marked HUMAN are human gates - the bot never fakes them.

## Account & app (HUMAN)
- [ ] HUMAN: Steamworks partner signup, Steam Direct fee, tax + bank interview
- [ ] HUMAN: create the app -> real AppID + DepotID (replace PLACEHOLDER_APPID / PLACEHOLDER_DEPOTID in Store\\Steam\\*.vdf)
- [ ] HUMAN: content survey / age rating questionnaire

## Store page (bot prepares)
- [ ] Short description (<= 300 chars) + long description -> Docs\\Store\\store_copy.md
- [ ] Capsules (sizes below) in Store\\Capsules\\*
- [ ] 5+ screenshots 1920x1080 real gameplay
- [ ] Trailer MP4 (gameplay in first 5 s)
- [ ] Tags (top 5 accurate), genre, languages, system requirements from QA\\fps_passes.md
- [ ] Coming Soon page live early (wishlists) - HUMAN clicks publish

## Build
- [ ] Windows x64 build in Builds\\Windows (auto via Tools\\auto_unity.ps1)
- [ ] Steamworks SDK init / achievements / cloud (steamworks-sdk-integration playbook) with real AppID only
- [ ] SteamPipe upload: steamcmd +login <user> +run_app_build Store\\Steam\\app_build_PLACEHOLDER_APPID.vdf +quit
- [ ] Set build live on a beta branch, test on clean PC + Steam Deck
- [ ] HUMAN: submit store page + build for review
- [ ] HUMAN: final Release click

## Capsule sizes
| asset | size | folder |
|---|---|---|
{capsule_table()}
""", made, root)
    steam = root / "Store" / "Steam"
    _w(steam / "app_build_PLACEHOLDER_APPID.vdf", f""""AppBuild"
{{
    "AppID" "PLACEHOLDER_APPID"
    "Desc" "{nm} auto build"
    "ContentRoot" "..\\..\\Builds\\Windows\\"
    "BuildOutput" "..\\..\\Builds\\steam_output\\"
    "SetLive" ""
    "Depots"
    {{
        "PLACEHOLDER_DEPOTID" "depot_build_PLACEHOLDER_DEPOTID.vdf"
    }}
}}
""", made, root)
    _w(steam / "depot_build_PLACEHOLDER_DEPOTID.vdf", """"DepotBuild"
{
    "DepotID" "PLACEHOLDER_DEPOTID"
    "FileMapping"
    {
        "LocalPath" "*"
        "DepotPath" "."
        "Recursive" "1"
    }
    "FileExclusion" "*.pdb"
    "FileExclusion" "*_BurstDebugInformation_DoNotShip*"
    "FileExclusion" "*_BackUpThisFolder_ButDontShipItWithYourGame*"
}
""", made, root)
    _w(steam / "README.md", "Replace PLACEHOLDER_APPID / PLACEHOLDER_DEPOTID with the real IDs from the Steamworks dashboard (human gate). Never invent IDs.\n", made, root)
    _w(root / "Store" / "Epic" / "buildpatch_upload_PLACEHOLDER.txt",
       "BuildPatchTool.exe -OrganizationId=PLACEHOLDER_ORG -ProductId=PLACEHOLDER_PRODUCT -ArtifactId=PLACEHOLDER_ARTIFACT "
       "-ClientId=PLACEHOLDER_CLIENT -ClientSecretEnvVar=EPIC_BPT_SECRET -mode=UploadBinary "
       f"-BuildRoot=\"{root}\\Builds\\Windows\" -CloudDir=\"{root}\\Builds\\epic_cloud\" -BuildVersion=0.1.0-win "
       f"-AppLaunch=\"{nm}.exe\" -AppArgs=\"\"\n# IDs come from the Epic Dev Portal (human gate). Never invent them.\n", made, root)
    _w(root / "Docs" / "Store" / "store_copy.md", f"# {nm} - store copy\n\n## Short description (<=300 chars)\nTODO-auto: fill from Pitch.md\n\n## About this game\n\n## Key features\n- \n- \n- \n\n## Tags\n\n## System requirements\nFrom QA\\fps_passes.md\n", made, root)
    return made


def run_ship_prep(user_text: str = "") -> str:
    root = resolve_project(user_text)
    if not root:
        return "SHIP_PREP: no game project yet. Start one first (run_auto_game_pipeline)."
    made = write_ship_prep(root, root.name)
    _append_tasks(root, ["Ship prep files created (Store\\*, Docs\\Store\\steam_checklist.md) - fill store_copy.md + make capsules"])
    return (f"SHIP_PREP {root}\ncreated: {made or 'nothing new (already existed)'}\n"
            "IDs are PLACEHOLDER_* until the creator supplies real Steamworks/Epic IDs (human gate).")


def _append_tasks(root: Path, items: list[str]) -> None:
    tb = root / "Docs" / "TaskBoard.md"
    try:
        old = tb.read_text(encoding="utf-8") if tb.exists() else f"# {root.name} - task board\n"
        add = "\n".join(f"- [ ] {i}" for i in items if i not in old)
        if add:
            stamp = datetime.now().strftime("%Y-%m-%d %H:%M")
            tb.write_text(old.rstrip() + f"\n\n## Auto next actions ({stamp})\n" + add + "\n", encoding="utf-8")
    except Exception:
        pass



def find_unreal() -> Path | None:
    """Return UnrealEditor.exe if UE 5.x is installed."""
    cfg = Path(__file__).resolve().parent / "config" / "gamebot.config.json"
    try:
        data = json.loads(cfg.read_text(encoding="utf-8-sig"))
        for k in ("unreal_editor", "unreal_engine_root"):
            v = str(data.get(k) or "").strip()
            if not v:
                continue
            p = Path(os.path.expandvars(v))
            if p.is_file() and p.name.lower().startswith("unrealeditor"):
                return p
            cand = p / "Engine" / "Binaries" / "Win64" / "UnrealEditor.exe"
            if cand.is_file():
                return cand
    except Exception:
        pass
    for base in (Path(r"C:\Program Files\Epic Games"), Path(os.path.expandvars(r"%ProgramFiles%\Epic Games"))):
        if not base.is_dir():
            continue
        for ue in sorted(base.glob("UE_*"), reverse=True):
            ed = ue / "Engine" / "Binaries" / "Win64" / "UnrealEditor.exe"
            if ed.is_file():
                return ed
    return None


# Unreal (Blueprint-only; works with the precompiled engine): genre -> (template, shared + variant content packs, startup map, extra plugins)
_UE_FP = ["High/Characters", "High/LevelPrototyping", "High/Input"]
_UE_TD = ["High/LevelPrototyping", "High/Characters", "Standard/Cursor", "High/Input"]
_UE_VEH = ["Standard/Vehicles", "High/Input"]
_VEH_PLUGINS = [{"Name": "ChaosVehiclesPlugin", "Enabled": True},
                {"Name": "GameInputWindows", "Enabled": True, "SupportedTargetPlatforms": ["Win64"], "TargetDenyList": ["Server"]}]
UNREAL_VARIANTS = {
    "shooter":    ("TP_FirstPersonBP", _UE_FP + ["Standard/Weapons", "Standard/Variant_Shooter"], "/Game/Variant_Shooter/Lvl_ArenaShooter", [], "Arena Shooter"),
    "horror":     ("TP_FirstPersonBP", _UE_FP + ["Standard/Variant_Horror"], "/Game/Variant_Horror/Lvl_Horror", [], "Survival Horror"),
    "combat":     ("TP_ThirdPersonBP", _UE_FP + ["Standard/Variant_Combat"], "/Game/Variant_Combat/Lvl_Combat", [], "Combat"),
    "platforming": ("TP_ThirdPersonBP", _UE_FP + ["Standard/Variant_Platforming"], "/Game/Variant_Platforming/Lvl_Platforming", [], "Platforming"),
    "sidescroller": ("TP_ThirdPersonBP", _UE_FP + ["Standard/Variant_SideScroller"], "/Game/Variant_SideScroller/Lvl_SideScrolling", [], "Side Scroller"),
    "strategy":   ("TP_TopDownBP", _UE_TD + ["Standard/Variant_Strategy"], "/Game/Variant_Strategy/LVL_Strategy", [], "Strategy"),
    "twinstick":  ("TP_TopDownBP", _UE_TD + ["Standard/Variant_TwinStick"], "/Game/Variant_TwinStick/LVL_TwinStick", [], "Twin Stick"),
    "timetrial":  ("TP_VehicleAdvBP", _UE_VEH + ["Standard/Variant_Timetrial"], "/Game/Variant_Timetrial/Maps/Lvl_Timetrial", _VEH_PLUGINS, "Time Trial"),
    "offroad":    ("TP_VehicleAdvBP", _UE_VEH + ["Standard/Variant_Offroad"], "/Game/Variant_Offroad/Maps/Lvl_Offroad", _VEH_PLUGINS, "Offroad open world"),
}
UNREAL_GENRE_VARIANT = {
    "shooter": "shooter", "fps": "shooter", "battle_royale": "shooter", "horror": "horror", "stealth": "horror",
    "action": "combat", "fighting": "combat", "rpg": "combat", "mmorpg": "combat", "adventure": "combat", "action-adventure": "combat",
    "platformer": "platforming", "puzzle": "platforming", "metroidvania": "sidescroller",
    "strategy": "strategy", "moba": "strategy", "simulation": "strategy", "sim": "strategy",
    "roguelike": "twinstick", "survival": "twinstick", "racing": "timetrial", "sports": "timetrial",
    "open_world": "offroad", "sandbox": "offroad",
}


def unreal_variant_for(genre: str) -> str:
    g = (genre or "").strip().lower().replace(" ", "_")
    if g in UNREAL_GENRE_VARIANT:
        return UNREAL_GENRE_VARIANT[g]
    fam = builder_family(g)
    return UNREAL_GENRE_VARIANT.get(fam, {"fps": "shooter", "sim": "strategy"}.get(fam, "platforming"))


AUTO_UNREAL_PS1_TMPL = Path(__file__).resolve().parent / "auto_unreal.ps1.tmpl"


def start_unreal_pipeline(root: Path, nm: str, genre: str = "", desktop_icon: bool = False, title: str = "") -> str:
    """Blueprint-only Unreal game: template + genre variant packs -> <nm>.uproject (genre description)
    -> background RunUAT BuildCookRun Win64 -> Builds\\Windows\\<nm>.exe + installer zip + desktop shortcut + DONE line."""
    ed = find_unreal()
    if not ed:
        return "UNREAL: UnrealEditor.exe not found. Install UE 5.x or set unreal_editor in config/gamebot.config.json."
    ue_root = ed.parents[3]  # .../UE_5.8
    key = unreal_variant_for(genre)
    tmpl_name, packs, umap, plugins, vlabel = UNREAL_VARIANTS[key]
    if not (ue_root / "Templates" / tmpl_name).is_dir():
        return f"UNREAL: template {tmpl_name} missing under {ue_root / 'Templates'}"
    root.mkdir(parents=True, exist_ok=True)
    (root / "Tools").mkdir(parents=True, exist_ok=True)
    (root / "Tools" / "genre.txt").write_text(genre or "platformer", encoding="utf-8")
    label = GENRE_LABELS.get((genre or "").lower(), (genre or "Action").replace("_", " ").title())
    title = title or _display_title(nm)
    desc = f"{title} - {label} game ({vlabel} gameplay)"
    m = re.search(r"UE_(\d+\.\d+)", str(ue_root))
    plug = [{"Name": "ModelingToolsEditorMode", "Enabled": True, "TargetAllowList": ["Editor"]},
            {"Name": "PythonScriptPlugin", "Enabled": True, "TargetAllowList": ["Editor"]},
            {"Name": "EditorScriptingUtilities", "Enabled": True, "TargetAllowList": ["Editor"]}] + list(plugins)
    uproj = root / f"{nm}.uproject"
    uproj.write_text(json.dumps({"FileVersion": 3, "EngineAssociation": m.group(1) if m else "", "Category": "Games",
                                 "Description": desc, "Plugins": plug}, indent="\t"), encoding="utf-8")
    if not AUTO_UNREAL_PS1_TMPL.is_file():
        return f"UNREAL: created {uproj} ({desc}) but {AUTO_UNREAL_PS1_TMPL.name} is missing - cannot package."
    clean = lambda v: str(v).replace('"', "'").replace("`", "'").replace("$", "")
    ps1 = root / "Tools" / "auto_unreal.ps1"
    ps1.write_text(AUTO_UNREAL_PS1_TMPL.read_text(encoding="utf-8").replace("__UEROOT__", str(ue_root)).replace("__ROOT__", str(root))
                   .replace("__NAME__", nm).replace("__TEMPLATE__", tmpl_name).replace("__PACKS__", ";".join(packs))
                   .replace("__MAP__", f"{umap}.{umap.rsplit('/', 1)[-1]}").replace("__GAMEMODE__", "")
                   .replace("__ICON__", "1" if desktop_icon else "0").replace("__TITLE__", clean(title)).replace("__DESC__", clean(desc)),
                   encoding="utf-8")
    if os.environ.get("GAMEBOT_SKIP_UNREAL") == "1":
        return f"UNREAL: skipped (GAMEBOT_SKIP_UNREAL=1). Run later: {ps1}"
    if unity_job_running(root):
        return f"UNREAL: a build for {nm} is already running. {build_status(root)}"
    status = root / "Builds" / "auto_unreal_status.txt"
    status.parent.mkdir(parents=True, exist_ok=True)
    status.write_text("QUEUED\n", encoding="utf-8")
    flags = 0x00000200 | 0x08000000
    _jp = subprocess.Popen(["powershell", "-NoProfile", "-ExecutionPolicy", "Bypass", "-WindowStyle", "Hidden", "-File", str(ps1)],
                     creationflags=flags, close_fds=True, stdin=subprocess.DEVNULL, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    _save_job_pid(root, _jp)
    return (f"UNREAL {m.group(1) if m else ''}: background job started -> {uproj.name} ({desc}) from {tmpl_name} + {vlabel} variant "
            f"-> RunUAT BuildCookRun Win64 Shipping -> Builds\\Windows\\{nm}.exe (+ installer zip{', desktop icon' if desktop_icon else ''}). "
            f"Status: Builds\\auto_unreal_status.txt")


# ---------------------------------------------------------------- inspect_scene

UE_INSPECT_PY = r'''import json, os, unreal
out = os.environ.get("GAMEBOT_INSPECT_OUT")
mp = os.environ.get("GAMEBOT_INSPECT_SCENE") or ""
if mp:
    unreal.EditorLoadingAndSavingUtils.load_map(mp)
acts = unreal.get_editor_subsystem(unreal.EditorActorSubsystem).get_all_level_actors()
objs, warn, packs = [], [], {}
prim = vis = 0
for a in acts:
    par = a.get_attach_parent_actor()
    o = {"name": a.get_actor_label(), "class": a.get_class().get_name(), "parent": par.get_actor_label() if par else "",
         "pos": [round(v, 1) for v in (a.get_actor_location().x, a.get_actor_location().y, a.get_actor_location().z)], "meshes": []}
    for c in a.get_components_by_class(unreal.StaticMeshComponent):
        sm = c.static_mesh
        if not sm:
            continue
        p = sm.get_path_name()
        vis += 1
        if p.startswith("/Engine/BasicShapes") or "/LevelPrototyping/Meshes/" in p:
            prim += 1
        else:
            k = p.split("/")[2] if p.count("/") > 2 else p
            packs[k] = packs.get(k, 0) + 1
        o["meshes"].append(p)
    if par and ("Character" in par.get_class().get_name() or "Pawn" in par.get_class().get_name()) and o["meshes"]:
        warn.append("FOLLOWS_PLAYER " + o["name"])
    objs.append(o)
if vis and prim == vis:
    warn.append("PRIMITIVES_ONLY")
json.dump({"ok": True, "engine": "Unreal", "scene": mp or "(startup map)", "objects_count": len(objs),
           "renderers": {"visible": vis, "primitive": prim, "pack": vis - prim}, "packs": packs, "warnings": warn, "objects": objs},
          open(out, "w"), indent=1)
'''


def _inspect_summary(d: dict, path: Path) -> str:
    r = d.get("renderers", {})
    lines = [f"INSPECT_SCENE {d.get('engine', 'Unity')} scene={d.get('scene')} objects={d.get('objects_count')}",
             f"renderers: visible={r.get('visible')} primitive={r.get('primitive')} pack={r.get('pack')}",
             "packs: " + (", ".join(f"{k}({v})" for k, v in sorted((d.get("packs") or {}).items(), key=lambda kv: -kv[1])[:10]) or "NONE")]
    if d.get("player"):
        lines.append(f"player: {d['player']}")
        for c in d.get("player_children", [])[:15]:
            lines.append(f"  player child: {c}")
    if d.get("camera"):
        lines.append(f"camera: {d['camera']}")
        for c in d.get("camera_children", [])[:10]:
            lines.append(f"  camera child: {c}")
    for w in d.get("warnings", [])[:20]:
        lines.append(f"WARN {w}")
    if not d.get("warnings"):
        lines.append("WARN none")
    lines.append(f"json={path}")
    return "\n".join(lines)


def inspect_scene(project: str = "", scene: str = "") -> str:
    """Dump the built scene: hierarchy (parent/child), components, colliders, scripts, positions, player/camera children,
    primitive-vs-pack renderers + warnings (FOLLOWS_PLAYER / FOLLOWS_CAMERA / PRIMITIVES_ONLY / MISSING_SCRIPTS).
    Unity: batchmode -executeMethod SceneInspector.Dump. Unreal: UnrealEditor-Cmd -run=pythonscript. JSON -> Builds\\scene_inspect.json."""
    root = resolve_project(project or "")
    if not root:
        return "INSPECT_SCENE: no project found (pass project=<game title>)."
    out = root / "Builds" / "scene_inspect.json"
    out.parent.mkdir(parents=True, exist_ok=True)
    if unity_job_running(root):
        return f"INSPECT_SCENE: a build is running for {root.name} - wait for DONE, then inspect. {build_status(root)}"
    env = dict(os.environ, GAMEBOT_INSPECT_OUT=str(out))
    proj = unity_project_dir(root)
    if out.exists():
        out.unlink()
    if proj:
        unity = find_unity()
        if not unity:
            return "INSPECT_SCENE: Unity editor not found."
        src = Path(__file__).resolve().parent / "unity_fullgame" / "SceneInspector.cs"
        ed = proj / "Assets" / "Editor"
        ed.mkdir(parents=True, exist_ok=True)
        if src.is_file() and (not (ed / "SceneInspector.cs").is_file() or (ed / "SceneInspector.cs").read_bytes() != src.read_bytes()):
            shutil.copy2(src, ed / "SceneInspector.cs")
        env["GAMEBOT_INSPECT_SCENE"] = scene or "Assets/Scenes/Game.unity"
        log = root / "Builds" / "inspect.log"
        try:
            subprocess.run([str(unity), "-batchmode", "-nographics", "-quit", "-projectPath", str(proj), "-executeMethod",
                            "SceneInspector.Dump", "-logFile", str(log)], env=env, timeout=900,
                           stdin=subprocess.DEVNULL, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, creationflags=0x08000000)
        except subprocess.TimeoutExpired:
            return f"INSPECT_SCENE: Unity timed out (see {log})."
    else:
        up = next(iter(sorted(root.glob("*.uproject"))), None)
        ued = find_unreal()
        if not up or not ued:
            return f"INSPECT_SCENE: {root.name} has no Unity project or .uproject to inspect."
        py = root / "Tools" / "Unreal" / "gb_inspect.py"
        py.parent.mkdir(parents=True, exist_ok=True)
        py.write_text(UE_INSPECT_PY, encoding="utf-8")
        env["GAMEBOT_INSPECT_SCENE"] = scene
        cmd = ued.parent / "UnrealEditor-Cmd.exe"
        try:
            subprocess.run([str(cmd), str(up), "-run=pythonscript", f"-script={py}", "-unattended", "-nosplash", "-nullrhi"],
                           env=env, timeout=1200, stdin=subprocess.DEVNULL, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, creationflags=0x08000000)
        except subprocess.TimeoutExpired:
            return "INSPECT_SCENE: UnrealEditor-Cmd timed out."
    if not out.is_file():
        return f"INSPECT_SCENE: no JSON written for {root.name} (scene missing or editor error; see Builds\\inspect.log)."
    try:
        d = json.loads(out.read_text(encoding="utf-8-sig"))
    except Exception as e:
        return f"INSPECT_SCENE: bad JSON {out}: {e}"
    return _inspect_summary(d, out)


def run_auto_game_pipeline(user_text: str, name: str | None = None, engine: str | None = None,
                           template: str | None = None, desktop_icon: bool = False,
                           genre: str | None = None, brief: dict | None = None,
                           asset_choices: dict | None = None) -> str:
    """genre/brief come from intake (the creator's answers). They always beat words guessed from user_text,
    and a re-run on an existing project keeps that project's saved Tools/game_brief.json."""
    raw_name = resolve_game_name(user_text, name)
    nm = _safe_name(raw_name)
    engine = engine or ("Unreal" if re.search(r"\b(unreal|ue5)\b", (user_text or "").lower()) else "Unity")
    root = GAME_PROJECTS / nm
    saved = load_brief(root) or {}
    bits = dict(_brief_from_text(user_text))
    if brief:
        bits.update({k: v for k, v in brief.items() if v})
    if not genre:
        genre = saved.get("genre") or bits.get("genre") or _genre(user_text)
    for k in ("loop", "story", "goals", "setting", "style"):
        if not bits.get(k) and saved.get(k):
            bits[k] = "; ".join(saved[k]) if isinstance(saved[k], list) else saved[k]
    the_brief = make_brief(nm, bits.get("display_title") or saved.get("display_title") or raw_name, genre,
                           bits.get("loop", ""), bits.get("story", ""), bits.get("goals", ""),
                           bits.get("setting", ""), bits.get("style", ""))
    genre_label = the_brief["genre_label"]
    sc = make_game_scaffold(nm, (the_brief["story"] or user_text or "")[:300], engine)
    _set_current(root)
    made: list[str] = []
    (root / "Tools").mkdir(parents=True, exist_ok=True)
    (root / "Tools" / "game_brief.json").write_text(json.dumps(the_brief, indent=2), encoding="utf-8")
    made.append("Tools\\game_brief.json")
    today = datetime.now().strftime("%Y-%m-%d")
    pitch = (user_text or "").strip()
    unity = find_unity()
    eng = (f"Unity {unity_version(unity)} (default)" if engine == "Unity"
           else "Unreal Engine 5 (install needs the creator's OK; Unity fallback templates written)")
    phases = _index_sections() or ["0. Studio operating rules", "1. Concept & pre-production", "2. Vertical slice",
                                   "3. Production", "4. Polish, performance, QA", "5. Ship", "6. Live / post-launch"]
    for d in ("Art/Concept", "Art/Blender/Exports", "Art/UI", "Audio/Music", "Audio/SFX", "Docs/Legal", "Docs/QA",
              "Docs/Store", "Docs/Site", "Store/Capsules", "Tools/Unity", "Builds"):
        (root / d).mkdir(parents=True, exist_ok=True)

    scaffold_gdd = (root / "Docs" / "GDD.md")
    gdd_is_template = scaffold_gdd.exists() and "## Core loop (one sentence)\n\n## Meta loop" in scaffold_gdd.read_text(encoding="utf-8", errors="replace")
    pitch_p = root / "Docs" / "Pitch.md"
    if "TODO: fill from the request" in pitch_p.read_text(encoding="utf-8", errors="replace") or "## Pillars (3)\n1. \n" in pitch_p.read_text(encoding="utf-8", errors="replace"):
        _gl = the_brief["goals"]
        _hook = " ".join(x for x in [_sentence(the_brief["story"]), ("Setting: " + _sentence(the_brief["setting"])) if the_brief["setting"] else ""] if x)
        pitch_p.write_text(f"""# {nm} - pitch
Date: {today}  |  Engine: {eng}  |  Genre: {genre_label}

## Title
{the_brief['display_title']}

## Two-line pitch
{the_brief['display_title']} is {'an' if genre_label[:1].lower() in 'aeiou' else 'a'} {genre_label} game: {(the_brief['loop'] or 'core loop defined in pre-production').rstrip('.!? ')}.
{_hook or 'Story to be refined in pre-production.'}

## Core loop
{the_brief['loop'] or '(not set)'}

## Story / premise
{the_brief['story'] or '(not set)'}

## Goals
{chr(10).join('- ' + g for g in _gl) or '(not set)'}

## Setting
{the_brief['setting'] or '(not set)'}

## Art / tone
{the_brief['style'] or '(not set)'}

## Always included
Main + pause menus, full Settings (video/audio/controls), HUD, achievements, playable Windows build.

## Pillars (3)
1. Readable, responsive core verb (feel first)
2. One strong hook that sets it apart
3. Scope a solo/small team can finish

## Scope
Vertical slice first (Slice01), then production in milestones. Quality bar rises each milestone.
""", encoding="utf-8")
        made.append("Docs\\Pitch.md (filled)")
    if gdd_is_template:
        _core_loop = the_brief["loop"] or "Move/jump/look -> collect -> avoid hazards -> reach the goal. Lives + score + achievements."
        _story_bit = the_brief["story"]
        _goals_bit = "\n".join("- " + g for g in the_brief["goals"])
        _setting_bit = the_brief["setting"]
        _style_bit = the_brief["style"]
        _achs = "\n".join(f"- {t}: {d}" for t, d in zip(the_brief["ach_titles"], the_brief["ach_descs"])) or "(per gameplay template)"
        sections = "\n".join(f"### {p}\n- Status: [ ] not started\n" for p in phases)
        scaffold_gdd.write_text(f"""# {nm} - Game Design Document
Engine: {eng}  |  Genre: {genre_label} ({genre})  |  Gameplay template: {the_brief['family']}  |  Generated: {today}

## Pitch
See Pitch.md. Title: {the_brief['display_title']}

## Story / premise
{_story_bit or '(see Pitch request)'}

## Goals
{_goals_bit or '(see Pitch request)'}

## Setting
{_setting_bit or '(see Pitch request)'}

## Art / tone
{_style_bit or '(see Pitch request)'}

## Pillars
See Pitch.md.

## Core loop
{_core_loop}

## Meta loop
Unlocks/progression between sessions (define in production).

## Player verbs
Move, look, jump, interact (expand per genre: {genre_label}).

## Content list (counts)
| type | slice | 1.0 target |
|---|---|---|
| levels/maps | 1 | TBD |
| enemies/NPCs | 0-1 | TBD |
| items | 0 | TBD |

## Progression & economy
TBD in production (inventory-crafting-progression playbook).

## UX flow
Main menu (Start/Continue/Settings/Achievements/Story/Quit) -> Settings (video/audio/controls) -> Game HUD/story -> Pause -> Win/Lose -> menu

## Achievements (from the goals above)
{_achs}

## Tech & budgets
60 fps target on recommended spec, 1% lows >= 70% of avg (see QA\\fps_passes.md).

## Art direction
Concept prompts in Art\\Concept\\concept_brief.md.

## Audio
Music + SFX folders under Audio\\. CC0 or original only; log in ATTRIBUTION.md.

## Pipeline phases (from complete-game-builder-index)
{sections}
## Risks
Scope creep, asset licensing, performance.

## IP guardrails
Original or CC0/licensed assets only; no trademarks. Log every third-party asset in ATTRIBUTION.md.
""", encoding="utf-8")
        made.append("Docs\\GDD.md (filled)")

    tb = root / "Docs" / "TaskBoard.md"
    tasks = "\n".join(f"\n## {p}\n- [ ] Read playbooks for this phase and execute with tools" for p in phases)
    tb.write_text(f"""# {nm} - task board (auto studio)

## Done by auto pipeline ({today})
- [x] Project scaffold + folders
- [x] Pitch.md, GDD.md, ScenePlan.md
- [x] Legal EULA/Privacy stubs, Credits, ATTRIBUTION.md
- [x] QA\\fps_passes.md template, Store\\steam_checklist.md, capsule folders, VDF templates (PLACEHOLDER IDs)
- [x] Website stub Docs\\Site\\index.html, concept brief
- [x] Unity full-game templates (Tools\\Unity) + background job (create project, MainMenu+Game, Windows build)
- [x] Main menu (Start/Continue/Settings/Achievements/Story/Quit) + pause menu
- [x] Full Settings: Video/Audio/Controls via PlayerPrefs (Apply persists)
- [x] In-game HUD + story intro + win/lose
- [x] Achievements from the creator's goals ({len(the_brief['goals'])}) with unlock toast
- [x] {FAMILY_LOOP_LINE.get(the_brief['family'], 'Playable loop')} - intro/objectives/win text use the intake story + goals (Tools\\game_brief.json)

## Auto next actions
- [ ] Verify Builds\\auto_unity_status.txt says DONE OK; on fail read Builds\\build.log, research_error, patch, re-run Tools\\auto_unity.ps1
- [ ] Import owned Asset Store packs via chat (my assets then pack number) into Assets\\Art\\Imports + ATTRIBUTION.md, then rebuild
- [ ] First FPS pass (QA\\fps_passes.md)
- [ ] Concept art from Art\\Concept\\concept_brief.md
{tasks}
""", encoding="utf-8")
    made.append("Docs\\TaskBoard.md")

    _w(root / "Docs" / "Legal" / "EULA.md", f"""# {nm} - End User License Agreement (STUB - have a lawyer review before release)
Copyright (c) {datetime.now().year} [STUDIO NAME]. All rights reserved.

1. License: personal, non-exclusive, non-transferable license to install and play.
2. Restrictions: no resale, reverse engineering, or redistribution except as allowed by law.
3. Third-party content: see ATTRIBUTION.md / Third-party notices screen in-game.
4. No warranty: provided "as is" to the extent permitted by law.
5. Termination: the license ends if these terms are broken.
6. Governing law: [JURISDICTION].
""", made, root)
    _w(root / "Docs" / "Legal" / "Privacy.md", f"""# {nm} - Privacy notice (STUB - review before release)
- Data collected: none by default. Saves and settings stay on the player's device.
- Telemetry/analytics: off unless the player opts in (analytics-telemetry playbook).
- Platform data (Steam/Epic) is handled by the platform under its own policy.
- Contact: [STUDIO EMAIL]
""", made, root)
    _w(root / "Docs" / "Legal" / "ThirdPartyNotices.md", f"# {nm} - third-party notices\nGenerated from ATTRIBUTION.md before each release.\n", made, root)
    _w(root / "Docs" / "QA" / "fps_passes.md", f"""# {nm} - FPS passes
Fixed route, same build, same spot. Record avg fps + 1% lows per preset. Targets: 60 fps recommended spec, Steam Deck 30-40 stable.

| date | build | preset | resolution | spot/route | avg fps | 1% low | cpu ms | gpu ms | change | keep/revert |
|---|---|---|---|---|---|---|---|---|---|---|
| | | Low | 1920x1080 | Slice01 start->goal | | | | | baseline | |
| | | Medium | 1920x1080 | | | | | | | |
| | | High | 1920x1080 | | | | | | | |
| | | Ultra | 2560x1440 | | | | | | | |
| | | Deck | 1280x800 | | | | | | | |
""", made, root)
    _w(root / "Docs" / "QA" / "test_plan.md", f"# {nm} - test plan\n- Smoke: launch -> menu -> play -> reach goal -> quit (every build)\n- Regression list grows with Bugs.md\n", made, root)
    _w(root / "ATTRIBUTION.md", f"""# {nm} - asset attribution & licences
Every third-party asset goes here BEFORE it is used. CC0 still logged.

| asset | file(s) | source URL | author | licence | date | notes |
|---|---|---|---|---|---|---|
| Grey-box primitives | Unity built-in | - | Unity | engine | {today} | slice placeholder |
""", made, root)
    _w(root / "Art" / "Concept" / "concept_brief.md", f"""# {nm} - concept brief
Genre: {genre_label}. Story: {the_brief['story']} Setting: {the_brief['setting']} Art/tone: {the_brief['style']}

## Shots to produce
1. Key art (hero moment) 16:9 -> also crops for capsules
2. Environment mood x3 (day / night / interior)
3. Character/hero object turnaround
4. UI mood board (menus, HUD)

## Palette / mood
TBD from pitch - keep consistent with store capsules.

Outputs go in Art\\Concept\\ and are logged in ATTRIBUTION.md if any reference is third-party.
""", made, root)
    site_slug = _slug(nm)
    _w(root / "Docs" / "Site" / "index.html", f"""<!doctype html>
<html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>{nm}</title><meta name="description" content="{nm} - a {genre_label} game.">
<meta property="og:title" content="{nm}"><meta property="og:image" content="og.png">
<style>body{{margin:0;font-family:system-ui,sans-serif;background:#0d0f14;color:#eee}}
header{{min-height:60vh;display:flex;flex-direction:column;justify-content:center;align-items:center;background:#1b1f2a;text-align:center;padding:24px}}
h1{{font-size:clamp(2rem,6vw,4rem);margin:0}} section{{max-width:900px;margin:40px auto;padding:0 20px}}
.btn{{display:inline-block;margin-top:20px;padding:12px 22px;border-radius:8px;background:#e8642c;color:#fff;text-decoration:none}}
footer{{text-align:center;color:#888;padding:30px;font-size:.9rem}}</style></head>
<body><header><h1>{the_brief['display_title']}</h1><p>A {genre_label} game.</p>
<a class="btn" href="#" title="Replace with the real store URL once the page exists">Wishlist (store page coming soon)</a></header>
<section><h2>About</h2><p>{(the_brief['story'] or pitch).replace('<','&lt;')}</p></section>
<section><h2>Features</h2><ul><li>Feature 1</li><li>Feature 2</li><li>Feature 3</li></ul></section>
<section><h2>Media</h2><p>Screenshots and trailer go here.</p></section>
<section><h2>Press kit</h2><p>Fact sheet, logo, capsules: coming soon.</p></section>
<footer>&copy; {datetime.now().year} [STUDIO NAME] &middot; <a href="privacy.html" style="color:#aaa">Privacy</a></footer></body></html>
""", made, root)
    _w(root / "Docs" / "Site" / "privacy.html", f"<!doctype html><meta charset=utf-8><title>{nm} privacy</title><h1>Privacy</h1><p>See Docs/Legal/Privacy.md - publish the reviewed text here.</p>\n", made, root)
    _w(root / "Docs" / "Site" / "README.md", f"Static site for {nm} (slug: {site_slug}). Deploy to any static host (GitHub Pages / Netlify / itch) - deploying is a human gate.\n", made, root)
    made += write_ship_prep(root, nm)
    plan_note = ""
    try:
        from asset_plan import build_plan, save_plan, load_plan, summary_lines
        prev = load_plan(root) or {}
        ch = dict(prev.get("choices") or {}); ch.update(asset_choices or {})
        plan = build_plan(the_brief.get("family") or builder_family(genre), the_brief, template or "", ch)
        save_plan(root, plan)
        made.append("Tools\\asset_plan.json")
        plan_note = "ASSET_PLAN\n" + summary_lines(plan)
    except Exception as e:
        plan_note = f"ASSET_PLAN failed: {e}"
    if engine == "Unity":
        unity_msg = start_unity_pipeline(root, nm, template, desktop_icon, genre)
    elif os.environ.get("GAMEBOT_UNREAL_FALLBACK_UNITY") == "1":
        unity_msg = start_unity_pipeline(root, nm, genre=genre)
    else:
        unity_msg = start_unreal_pipeline(root, nm, genre, desktop_icon, the_brief.get("display_title", ""))
    try:
        teach_self(f"Auto studio pipeline run ({nm})",
                   f"run_auto_game_pipeline created {len(made)} files under {root} and {unity_msg[:160]}. "
                   "Next: check Builds\\auto_unity_status.txt, then work TaskBoard 'Auto next actions' with tools.",
                   "auto studio pipeline")
    except Exception:
        pass
    return (f"AUTO_PIPELINE {nm}\nROOT {root}\n{sc.splitlines()[1] if len(sc.splitlines()) > 1 else ''}\n"
            f"files: {', '.join(made)}\n{unity_msg}\n{plan_note}\n"
            "Human gates (not done by bot): store accounts/tax/bank, real AppIDs, age ratings, Release click, public posting.")


# ---------------------------------------------------------------- assets

def copy_into_unity(root: Path, files: list[Path], sub: str) -> list[str]:
    """Copy generated/downloaded asset files into <Project>Unity/Assets/Art/Imports/<sub> so Unity imports them
    (SceneBuilder.ScatterOwnedProps places Assets/Art/Imports models in the level on the next build)."""
    up = unity_project_dir(root)
    if not up:
        return []
    dest = up / "Assets" / "Art" / "Imports" / sub
    dest.mkdir(parents=True, exist_ok=True)
    out = []
    for f in files:
        try:
            if f.is_file():
                shutil.copy2(f, dest / f.name)
                out.append(str(dest / f.name))
        except Exception:
            pass
    return out


def run_asset_auto(user_text: str, project: str | None = None) -> str:
    from pc_tools import run_blender_script
    root = None
    if project:
        cand = GAME_PROJECTS / _safe_name(project)
        root = cand if cand.is_dir() else None
    root = root or resolve_project(user_text)
    if not root:
        root = GAME_PROJECTS / "AssetLab"
        root.mkdir(parents=True, exist_ok=True)
    m = re.search(r"(?:model|asset|prop|mesh)\s+(?:of\s+)?(?:a\s+|an\s+|the\s+)?([A-Za-z][A-Za-z0-9 _-]{1,80})", user_text or "", re.I)
    m2 = re.search(r"(?:make|create|build|generate)\s+(?:me\s+)?(?:a\s+|an\s+|the\s+)?([A-Za-z][A-Za-z0-9 _-]{1,80}?)\s+(?:model|asset|prop|mesh)\b", user_text or "", re.I)
    name = asset_name_from((m2 or m).group(1) if (m2 or m) else "Prop")
    out_dir = root / "Art" / "Blender" / "Exports"
    out_dir.mkdir(parents=True, exist_ok=True)
    os.environ["PROP_NAME"] = name
    os.environ["PROP_OUT"] = str(out_dir)
    os.environ["PROP_HINT"] = (user_text or "")[:200]
    fbx = out_dir / f"{name}.fbx"
    res = run_blender_script(script_path=str(SCRIPTS / "make_prop_generic.py"), output_fbx=str(fbx))
    if fbx.exists():
        att = root / "ATTRIBUTION.md"
        if att.exists():
            with att.open("a", encoding="utf-8") as f:
                f.write(f"| {name} | Art/Blender/Exports/{name}.fbx | original (Game Bot Blender script) | studio | original | {datetime.now():%Y-%m-%d} | blockout |\n")
    unity_line = ""
    if fbx.exists():
        copied = copy_into_unity(root, [fbx], "Blender")
        if copied:
            unity_line = f"\nUNITY_COPY {copied[0]}\n{queue_unity_rebuild(root)}"
        else:
            unity_line = "\nUNITY_COPY pending: Unity project not created yet - Tools\\auto_unity.ps1 copies Art\\Blender\\Exports\\*.fbx into Assets\\Art\\Imports\\Blender on the next build."
            _append_tasks(root, [f"Import {name}.fbx into Unity Assets/Art/Imports/Blender"])
    intake = ""
    if any(w in (user_text or "").lower() for w in ("cc0", "poly haven", "polyhaven", "kenney", "download", "free asset", "texture", "hdri")):
        try:
            intake = "\n--- asset-intake playbook ---\n" + read_playbook("asset-intake")[:1500]
        except Exception:
            pass
    return f"ASSET {name} -> {fbx} exists={fbx.exists()}{unity_line}\n{str(res)[-1200:]}{intake}"
