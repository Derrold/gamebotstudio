using UnityEngine;
/// <summary>Fighting family: 2.5D duel on the X axis. Player (J light, K heavy, L block, A/D, W jump) vs AI. Best of 3 rounds, 60 s each.</summary>
public class Fighter : MonoBehaviour
{
    public bool isAI; public Fighter other; public Transform visual;
    public static Fighter P1, P2; static float roundEndAt = -1; static Vector3 p1Start, p2Start;
    float vy, nextAtk, stunUntil, aiNext, aiBlockUntil, atkAnim; bool blocking; int pendingDmg; float hitAt; float baseY;
    public int Hp { get => isAI ? GenreState.P2Hp : GenreState.P1Hp; set { if (isAI) GenreState.P2Hp = value; else GenreState.P1Hp = value; } }
    void Start() { if (isAI) { P2 = this; p2Start = transform.position; } else { P1 = this; p1Start = transform.position; roundEndAt = -1; } baseY = transform.position.y; }
    void Update()
    {
        if (GameState.Won || GameState.Lost || PauseMenu.IsPaused || MainMenuUI.InMenu || other == null) return;
        if (!isAI) RoundTick();
        if (roundEndAt > 0) return;
        float dir = Mathf.Sign(other.transform.position.x - transform.position.x); if (dir == 0) dir = 1;
        transform.rotation = Quaternion.LookRotation(new Vector3(dir, 0, 0));
        float mv = 0; bool jump = false, light = false, heavy = false; blocking = false;
        if (Time.time >= stunUntil)
        {
            if (!isAI)
            {
                if (Input.GetKey(GameSettings.KeyLeft) || Input.GetKey(KeyCode.LeftArrow)) mv -= 1; if (Input.GetKey(GameSettings.KeyRight) || Input.GetKey(KeyCode.RightArrow)) mv += 1;
                jump = Input.GetKeyDown(GameSettings.KeyForward) || Input.GetKeyDown(KeyCode.UpArrow); light = Input.GetKeyDown(KeyCode.J) || Input.GetMouseButtonDown(0) || GameBotQA.AutoFire; heavy = Input.GetKeyDown(KeyCode.K) || Input.GetMouseButtonDown(1); blocking = Input.GetKey(KeyCode.L);
            }
            else
            {
                float d = Mathf.Abs(other.transform.position.x - transform.position.x);
                if (d > 1.8f) mv = dir; else if (d < 0.9f) mv = -dir * 0.5f;
                if (other.atkAnim > 0.5f && Random.value < 0.02f) aiBlockUntil = Time.time + 0.5f; blocking = Time.time < aiBlockUntil;
                if (!blocking && d < 2.1f && Time.time > aiNext) { aiNext = Time.time + Random.Range(0.55f, 1.2f); if (Random.value < 0.65f) light = true; else heavy = true; }
                if (Random.value < 0.002f) jump = true;
            }
        }
        float x = transform.position.x + mv * (blocking ? 1.5f : 4.2f) * Time.deltaTime; x = Mathf.Clamp(x, -9f, 9f);
        if (Mathf.Abs(x - other.transform.position.x) < 0.8f) x = transform.position.x;
        bool grounded = transform.position.y <= baseY + 0.001f; if (grounded && jump) vy = 7.5f; vy -= 22f * Time.deltaTime;
        float y = Mathf.Max(baseY, transform.position.y + vy * Time.deltaTime); if (y <= baseY) vy = 0;
        transform.position = new Vector3(x, y, transform.position.z);
        if (Time.time >= nextAtk && (light || heavy)) { nextAtk = Time.time + (heavy ? 0.85f : 0.38f); pendingDmg = heavy ? 14 : 7; hitAt = Time.time + (heavy ? 0.22f : 0.1f); atkAnim = 1f; }
        if (pendingDmg > 0 && Time.time >= hitAt)
        {
            float d = Mathf.Abs(other.transform.position.x - transform.position.x);
            if (d <= (pendingDmg > 10 ? 2.2f : 1.7f)) other.TakeHit(pendingDmg, dir);
            pendingDmg = 0;
        }
        atkAnim = Mathf.MoveTowards(atkAnim, 0, Time.deltaTime * 3f);
        if (visual) { visual.localPosition = new Vector3(0, 0, atkAnim * 0.35f); visual.localScale = Vector3.one * (blocking ? 0.92f : 1f); }
    }
    public void TakeHit(int dmg, float dir)
    {
        if (roundEndAt > 0) return;
        int d = blocking ? Mathf.Max(1, dmg / 5) : dmg; Hp = Mathf.Max(0, Hp - d);
        if (!blocking) { stunUntil = Time.time + 0.25f; transform.position += new Vector3(dir * 0.5f, 0, 0); }
        if (!isAI && d >= 14 && !blocking) AchievementSystem.Unlock("took_heavy");
        if (isAI && !blocking && dmg >= 14) AchievementSystem.Unlock("heavy_hit");
    }
    static void RoundTick()
    {
        if (roundEndAt > 0) { if (Time.time >= roundEndAt) NextRound(); return; }
        GenreState.RoundTime -= Time.deltaTime;
        if (GenreState.P1Hp <= 0 || GenreState.P2Hp <= 0 || GenreState.RoundTime <= 0)
        {
            bool p1 = GenreState.P1Hp > GenreState.P2Hp; bool draw = GenreState.P1Hp == GenreState.P2Hp;
            if (!draw) { if (p1) GenreState.P1Wins++; else GenreState.P2Wins++; }
            GenreState.RoundMsg = draw ? "DRAW ROUND" : p1 ? "YOU WIN ROUND " + GenreState.Round : "RIVAL WINS ROUND " + GenreState.Round; GameHUD.Flash(GenreState.RoundMsg);
            if (p1 && GenreState.P1Hp == 100) AchievementSystem.Unlock("perfect_round");
            if (GenreState.P1Wins >= 2) { AchievementSystem.Unlock("champion"); GenreState.Win(); return; }
            if (GenreState.P2Wins >= 2) { GenreState.Lose("Your rival won 2 rounds"); return; }
            roundEndAt = Time.time + 2.5f;
        }
    }
    static void NextRound()
    {
        roundEndAt = -1; GenreState.Round++; GenreState.P1Hp = GenreState.P2Hp = 100; GenreState.RoundTime = 60f;
        if (P1) P1.transform.position = p1Start; if (P2) P2.transform.position = p2Start; GameHUD.Flash("ROUND " + GenreState.Round + " - FIGHT!");
    }
}
