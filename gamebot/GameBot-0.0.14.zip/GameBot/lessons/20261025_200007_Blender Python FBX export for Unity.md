# Blender Python FBX export for Unity

Tags: blender,fbx,assets,unity
Saved: 2026-10-25T20:00:07

blender.exe -b -P script.py. Apply transforms first, then bpy.ops.export_scene.fbx(filepath=out, use_selection=True, apply_scale_options='FBX_SCALE_UNITS', axis_forward='-Z', axis_up='Y', add_leaf_bones=False, mesh_smooth_type='FACE'). Verify file exists >10KB and imported bounds are real size. bake_space_transform is experimental (breaks armatures). Source: https://docs.blender.org/api/current/bpy.ops.export_scene.html
