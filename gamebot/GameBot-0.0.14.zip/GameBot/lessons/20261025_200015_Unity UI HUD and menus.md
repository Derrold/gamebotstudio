# Unity UI HUD and menus

Tags: unity,ui,hud
Saved: 2026-10-25T20:00:15

Canvas Screen Space Overlay + CanvasScaler Scale With Screen Size 1920x1080 + EventSystem; TextMeshPro text; separate static vs dynamic canvases; set firstSelectedGameObject for gamepad. UI Toolkit (UXML/USS/UIDocument) for menus/inventory. Reuse project styles. Sources: https://docs.unity3d.com/Packages/com.unity.ugui@latest https://docs.unity3d.com/Manual/UIElements.html
