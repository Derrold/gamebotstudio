# Monetization & store page strategy
Sources: https://partner.steamgames.com/doc/store/pricing | https://partner.steamgames.com/doc/store/earlyaccess | https://partner.steamgames.com/doc/store/application/dlc | https://partner.steamgames.com/doc/marketing/visibility | https://partner.steamgames.com/doc/store/coming_soon

## Models
- Premium (one price): default for sim/hunting. Research comparable titles' prices (firefox_search 'hunting simulator steam price') and reviews before choosing; regional pricing via Steam's suggested matrix.
- Early Access: only if game is fun now and roadmap is credible; EA page needs honest 'why EA / how long / current state'. Price usually <= full release.
- DLC: maps/regions, weapon packs, species - after base game is solid; no pay-to-win.
- Free demo: separate demo app (Steam Next Fest), or playtest app.
- Avoid: loot boxes, aggressive MTX in premium games.

## Store page
- Capsules (sizes in turnkey-assets-stores-gaps.md), 5+ screenshots (1920x1080, real gameplay), trailer first 5 seconds = gameplay, short description hooks, tags accurate (top 5 matter), system requirements from FPS passes.
- Coming Soon page ASAP to collect wishlists; update with devlogs/events. Wishlist strategy: real progress posts, festivals (Next Fest), streamer keys - NO spam, no fake reviews, no review-for-key deals (against Steam rules).
- Launch discount: modest (10-20%) optional.

## Revenue math
- Steam takes 30% (lower tiers above $10M/$50M); refunds ~; taxes. Model: wishlists x conversion (rough 10-20% first week) - estimate only.
- Human-only: Steam Direct fee, tax/bank interview, price approval, Release button.
