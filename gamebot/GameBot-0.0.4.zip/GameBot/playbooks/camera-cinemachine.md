# Camera systems (1st/3rd person, ADS, Cinemachine)
Sources: https://docs.unity3d.com/Packages/com.unity.cinemachine@3.1/manual/CinemachineCamera.html | https://docs.unity3d.com/Packages/com.unity.cinemachine@3.1/manual/CinemachineThirdPersonFollow.html | https://docs.unity3d.com/Packages/com.unity.cinemachine@3.1/manual/CinemachineHardLockToTarget.html

## Cinemachine 3 (Unity 6)
- CinemachineBrain on the Main Camera; CinemachineCamera objects with Priority; blends between them.
- First person: Tracking Target = head/eye pivot, Position Control = Hard Lock to Target, Rotation Control = Pan Tilt (driven by Input Axis Controller or your own script).
- Third person over-shoulder: Third Person Follow (Shoulder Offset ~0.7,0.3,-0.5; Camera Distance 2; built-in collision) + aim target; for 1st person set distance 0 and arm 0.
- Cutscenes/kill-cam/trophy shots: Spline Dolly + Timeline.

## ADS / scopes
- ADS: lerp weapon to sight offset, lower FOV (e.g. 70 -> 50), mouse sensitivity scale per zoom (Settings), optional depth-of-field on weapon only.
- Scopes: render-texture scope (costly: second camera render - lower res/LOD bias in scope) vs FOV-zoom with overlay (cheap). Variable zoom: FOV = 2*atan(tan(baseFOV/2)/mag).
- Recoil: camera kick + recovery curve; breathing sway; hold-breath steadies.

## Comfort
- FOV slider (60-100), head-bob toggle, motion blur off by default, camera shake intensity slider (see accessibility.md).
