"""Real CC0 fetch for the 'free' asset answer: Poly Haven models (CC0, public API) -> project + Unity Assets.

Returns a dict {"ok": bool, "msg": str, ...}. Never pretends: on no match / no network it says so."""
from __future__ import annotations

import json
import re
import urllib.request
from datetime import datetime
from pathlib import Path

API = "https://api.polyhaven.com"
UA = {"User-Agent": "GameBot/1.0 (asset intake)"}

# asset-question key -> search words (Poly Haven is props/nature/buildings; no characters/UI/audio)
KEY_WORDS = {
    "world": ["rock", "tree", "nature", "ground", "boulder", "stump", "log"],
    "environment": ["rock", "tree", "barrel", "crate", "fence", "wall", "ruin"],
    "landmarks": ["building", "tower", "shed", "ruin", "statue", "fence", "wall", "sign"],
    "props": ["barrel", "crate", "lamp", "bench", "box", "sign"],
    "resources": ["log", "wood", "rock", "crate", "barrel", "stump"],
    "pickups": ["box", "crate", "bottle", "can", "jar"],
    "collectible": ["bottle", "jar", "coin", "box"],
    "vehicles": ["car", "vehicle", "bike", "cart", "wheel"],
    "vehicle": ["car", "vehicle", "bike", "cart"],
    "track": ["barrier", "cone", "sign", "fence"],
    "furniture": ["chair", "table", "shelf", "cabinet", "sofa"],
    "building": ["shelf", "table", "cabinet", "counter"],
    "tileset": ["rock", "crate", "stone"],
    "arena": ["rock", "crate", "barrel", "pillar"],
    "map": ["rock", "tree", "building"],
    "zones": ["rock", "tree", "building", "statue"],
    "board": ["table", "box", "stone"],
    "blocks": ["box", "crate", "stone", "brick"],
    "field": ["bench", "barrier", "goal"],
    "stage": ["pillar", "rock", "barrel"],
    "lane": ["rock", "tree", "pillar", "statue"],
    "buildings": ["building", "shed", "tower", "wall"],
    "items": ["sword", "bottle", "jar", "chest", "box"],
    "gear": ["sword", "chest", "box", "lamp"],
    "weapons": ["sword", "axe", "hammer", "tool"],
    "tools": ["hammer", "axe", "shovel", "tool", "saw"],
    "gadgets": ["lamp", "radio", "box", "tool"],
}
NO_MODELS = {"hero", "player", "characters", "fighters", "heroes", "avatar", "agent", "athletes", "npcs", "enemies",
             "creature", "threats", "guards", "mobs", "minions", "units", "ui", "audio", "vfx", "sky", "hazard", "ball"}


def _get(url: str, timeout: int = 25):
    req = urllib.request.Request(url, headers=UA)
    with urllib.request.urlopen(req, timeout=timeout) as r:
        return r.read()


def _score(meta: dict, words: list[str]) -> int:
    blob = " ".join([meta.get("name", "")] + list(meta.get("tags") or []) + list(meta.get("categories") or [])).lower()
    return sum(3 if re.search(r"\b" + re.escape(w) + r"\b", blob) else 0 for w in words)


def fetch_cc0_model(key: str, label: str, project_root: Path, extra_words: list[str] | None = None,
                    max_mb: float = 60.0) -> dict:
    if key in NO_MODELS:
        return {"ok": False, "msg": (f"Poly Haven (the CC0 source I can download automatically) has no models for {label}. "
                                     "Nothing was downloaded. Options: describe it and I'll model it in Blender, say \"my assets\" "
                                     "for an owned pack, or grab a CC0 kit by hand from Quaternius/Kenney and I'll import it.")}
    words = list(KEY_WORDS.get(key, [])) + [w for w in (extra_words or []) if len(w) > 3]
    if not words:
        words = re.findall(r"[a-z]{4,}", (label or "").lower())
    try:
        assets = json.loads(_get(f"{API}/assets?t=models"))
    except Exception as e:
        return {"ok": False, "msg": f"Couldn't reach Poly Haven to fetch a CC0 {label} ({type(e).__name__}). Nothing was downloaded."}
    ranked = sorted(((_score(m, words), aid) for aid, m in assets.items()), reverse=True)
    ranked = [r for r in ranked if r[0] > 0]
    if not ranked:
        return {"ok": False, "msg": f"No CC0 Poly Haven model matched {label} ({', '.join(words[:5])}). Nothing was downloaded."}
    for _, aid in ranked[:6]:
        try:
            files = json.loads(_get(f"{API}/files/{aid}"))
            fbx = ((files.get("fbx") or {}).get("1k") or {}).get("fbx")
            if not fbx:
                continue
            inc = {k: v for k, v in (fbx.get("include") or {}).items() if k.lower().endswith((".jpg", ".png"))}
            total = (fbx.get("size", 0) + sum(v.get("size", 0) for v in inc.values())) / 1e6
            if total > max_mb:
                continue
            out = project_root / "Art" / "CC0" / aid
            out.mkdir(parents=True, exist_ok=True)
            fpath = out / Path(fbx["url"]).name
            fpath.write_bytes(_get(fbx["url"], 120))
            written = [fpath]
            for rel, v in inc.items():
                tp = out / rel
                tp.parent.mkdir(parents=True, exist_ok=True)
                tp.write_bytes(_get(v["url"], 120))
                written.append(tp)
            meta = assets.get(aid) or {}
            url = f"https://polyhaven.com/a/{aid}"
            att = project_root / "ATTRIBUTION.md"
            if att.exists():
                authors = ", ".join((meta.get("authors") or {}).keys()) or "Poly Haven"
                with att.open("a", encoding="utf-8") as f:
                    f.write(f"| {meta.get('name', aid)} | Art/CC0/{aid}/{fpath.name} | {url} | {authors} | CC0 | {datetime.now():%Y-%m-%d} | {label} |\n")
            return {"ok": True, "id": aid, "name": meta.get("name", aid), "url": url, "files": written, "mb": round(total, 1),
                    "msg": f"CC0 FETCHED {meta.get('name', aid)} ({round(total, 1)} MB) from {url} -> {out}"}
        except Exception:
            continue
    return {"ok": False, "msg": f"Found CC0 matches for {label} but none downloaded cleanly (size/network). Nothing was added."}
