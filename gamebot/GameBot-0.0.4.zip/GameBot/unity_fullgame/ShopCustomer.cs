using UnityEngine;
/// <summary>Sim customer: walks to counter, waits, buys if the player is serving and stock is available, then leaves.</summary>
public class ShopCustomer : MonoBehaviour
{
    public Vector3 counter, exit; float patience = 14f; bool served; bool left;
    void Update()
    {
        if (PauseMenu.IsPaused || MainMenuUI.InMenu || GameState.Won) return;
        Vector3 dest = served || patience <= 0 ? exit : counter;
        transform.position = Vector3.MoveTowards(transform.position, dest, 2.5f * Time.deltaTime);
        if (!served && (transform.position - counter).sqrMagnitude < 0.05f)
        {
            patience -= Time.deltaTime;
            if (ShopCounter.Serving && GenreState.Stock > 0)
            {
                served = true; GenreState.Stock--; GenreState.Cash += 25; GenreState.Sales++; AchievementSystem.Unlock("first_sale");
                if (GenreState.Cash >= GenreState.CashGoal) { AchievementSystem.Unlock("cash_goal"); GenreState.Win(); }
            }
        }
        if ((transform.position - exit).sqrMagnitude < 0.1f && !left) { left = true; Destroy(gameObject); }
    }
}
