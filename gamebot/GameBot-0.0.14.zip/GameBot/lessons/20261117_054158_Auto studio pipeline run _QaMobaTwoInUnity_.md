# Auto studio pipeline run (QaMobaTwoInUnity)

Tags: auto studio pipeline
Saved: 2026-11-17T05:41:58

run_auto_game_pipeline created 34 files under C:\Users\Derrold PC\Documents\GameProjects\QaMobaTwoInUnity and UNITY 6000.6.5f1: background job started -> create QaMobaTwoInUnityUnity -> MOBA game (gameplay template: moba; menu, settings, achievements, owned genre kit) -. Next: check Builds\auto_unity_status.txt, then work TaskBoard 'Auto next actions' with tools.
