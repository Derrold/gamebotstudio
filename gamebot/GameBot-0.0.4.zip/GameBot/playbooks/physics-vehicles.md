# Physics, ballistics, ragdolls, vehicles
Sources: https://docs.unity3d.com/Manual/PhysicsOverview.html | https://docs.unity3d.com/Manual/wizard-RagdollBuilder.html | https://docs.unity3d.com/Manual/class-WheelCollider.html | https://docs.unity3d.com/Manual/rigidbody-interpolation.html

## Rigidbody rules
- Move physics objects in FixedUpdate with Rigidbody.MovePosition/AddForce, not transform; Interpolate on for player-visible bodies.
- Collision Detection Continuous for fast small objects (arrows); bullets: raycast/sphere-cast stepping (Ballistics.cs/Bullet.cs) not rigidbodies.
- Layer collision matrix: disable pairs that never interact (grass vs everything).
- Fixed Timestep default 0.02; lowering costs CPU.

## Ballistics (hunting)
- Per-step: gravity drop, drag (G1/G7 BC), wind drift, velocity -> energy at impact; penetration through organs (Organ.cs) decides wound type; data in WeaponDef/cart.
- Validate vs published ballistic tables (manufacturer data) - store sources in lessons.

## Ragdolls / death
- Ragdoll Wizard for humanoids; for deer, author colliders+CharacterJoints manually or use DeathPose.cs (posed death animation) - cheaper and more stable. Switch animator off -> enable ragdoll on death; freeze after settle for perf.

## Vehicles (if a game needs them)
- WheelCollider x4 + Rigidbody (mass ~1200-1500 kg, low center of mass), motorTorque/brakeTorque/steerAngle; or arcade raycast suspension for simpler feel.

## Verify
- No jitter (interpolation), no tunneling, Profiler Physics.Simulate under budget (~1-2 ms PC).
