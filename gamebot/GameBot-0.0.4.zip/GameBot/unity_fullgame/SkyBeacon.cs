using UnityEngine;
/// <summary>Sandbox win trigger high above the island; requires 25 placed blocks.</summary>
public class SkyBeacon : MonoBehaviour
{
    void Update() { transform.Rotate(0, 40 * Time.deltaTime, 0); }
    void OnTriggerEnter(Collider o) { if (!o.CompareTag("Player")) return; if (GenreState.Placed < 25) { GameHUD.Flash("The beacon needs a real build - place 25 blocks first"); return; } AchievementSystem.Unlock("beacon"); GenreState.Win(); }
}
