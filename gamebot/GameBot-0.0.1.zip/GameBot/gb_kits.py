"""Game Bot genre kits: import the creator's OWNED packs into a Unity project before every build.
If <Game>/Tools/asset_plan.json exists (asset_plan.py), import exactly the planned packs per need and write
Tools/asset_map.json (need -> Unity folders) so SceneBuilder places ground/trees/buildings/cover/enemies/guns/sounds
from the right pack. Also writes generated fallback sound clips so a game is never silent.
Usage: python gb_kits.py <UnityProjectDir> <GameRoot> <family>"""
from __future__ import annotations
import gzip, io, json, math, random, re, shutil, struct, sys, tarfile, wave
from datetime import datetime
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))

COMMON = ["Stylized Player Character"]
KITS = {
    "action": ["Nature Starter Kit 2", "Yughues Free Bushes", "Free pack of medieval weapons", "Polygon City Pack", "Harbor Props"],
    "fighting": ["Free Street Props", "Polygon City Pack"],
    "strategy": ["Free House 01", "Nature Starter Kit 2", "URP Tree Models", "Free Street Props"],
    "moba": ["Nature Starter Kit 2", "URP Tree Models", "Yughues Free Bushes", "Free pack of medieval weapons"],
    "sports": ["Free Street Props", "Polygon City Pack", "URP Tree Models"],
    "sandbox": ["Carpentry Tools", "Nature Starter Kit 2", "Polygon City Pack", "Yughues Free Bushes"],
    "stealth": ["House Interior Free", "Low Poly Furniture", "Modular Storage Shelves", "Free House 01", "Yughues Free Bushes", "Free Street Props"],
    "battle_royale": ["Low Poly Weapons VOL1", "Nature Starter Kit 2", "URP Tree Models", "Free House 01", "Free Street Props", "American Sedans", "Harbor Props"],
    "mmorpg": ["Animals FREE", "Free House 01", "Nature Starter Kit 2", "URP Tree Models", "Free pack of medieval weapons", "Polygon City Pack", "Yughues Free Bushes"],
    "platformer": ["Nature Starter Kit 2", "Yughues Free Bushes", "Polygon City Pack"],
    "fps": ["Low Poly Weapons VOL1", "Harbor Props", "Free Street Props"],
    "racing": ["American Sedans", "Free Street Props", "URP Tree Models"],
    "horror": ["House Interior Free", "Low Poly Furniture"],
    "rpg": ["Animals FREE", "Free House 01", "Nature Starter Kit 2", "Free pack of medieval weapons"],
    "puzzle": ["Polygon City Pack", "Harbor Props"],
    "survival": ["Nature Starter Kit 2", "URP Tree Models", "Yughues Free Bushes", "Animals FREE", "Carpentry Tools"],
    "adventure": ["Nature Starter Kit 2", "Animals FREE", "Polygon City Pack"],
    "sim": ["Modular Storage Shelves", "Low Poly Furniture", "Polygon City Pack"],
    "roguelike": ["Low Poly Weapons VOL1", "Harbor Props"],
}
# Families whose SceneBuilder uses the asset plan only (no legacy kit list on top)
PLAN_ONLY = {"fps", "battle_royale"}
SKIP_EXT = {".cs", ".js", ".dll", ".asmdef", ".asmref", ".unity", ".rsp", ".pdb", ".boo", ".mdb", ".unitypackage"}
SKIP_DIR = ("/editor/", "/demo scene", "/scenes/")
AUDIO_EXT = {".wav", ".ogg", ".mp3", ".aif", ".aiff"}
AUDIO_NEEDS = {"weapon_sfx", "ambient", "sfx_misc"}
AUDIO_KEYS = {
    "weapon_sfx": r"gunshot|shot|fire|reload|mag ?in|magin|magout|mag_?out|charge|chamber|equip|tail",
    "ambient": r"wind|forest|bird|ambien|night|cicada|rain|field|nature",
    "sfx_misc": r"hit|impact|punch|body|growl|monster|creature|scream|grunt|roar|whoosh|thud|bullet|flesh|death|die",
}


def _norm(s: str) -> str:
    return re.sub(r"[^a-z0-9]+", "", s.lower())


def kit_for(family: str) -> list[str]:
    return COMMON + KITS.get(family, KITS["platformer"])


def find_packs(names: list[str]) -> list[dict]:
    from owned_assets import list_owned_assets
    packs = list_owned_assets("Unity", limit=0)["packs"]
    out = []
    for want in names:
        w = _norm(want)
        hit = next((p for p in packs if _norm(p["name"]).startswith(w)), None) or next((p for p in packs if w in _norm(p["name"])), None)
        if hit and hit not in out:
            out.append(hit)
    return out


def extract_filtered(pkg: Path, assets: Path, keep=None, cap: int = 0) -> tuple[int, list[str], list[str]]:
    """Extract a .unitypackage into the project (no scripts/scenes). keep(rel_lower) -> bool filters files.
    Returns (files written, prefabs, top folders)."""
    raw = pkg.read_bytes()
    try:
        raw = gzip.decompress(raw)
    except Exception:
        pass
    tf = tarfile.open(fileobj=io.BytesIO(raw), mode="r:")
    mem: dict = {}
    for m in tf.getmembers():
        parts = m.name.strip("/").lstrip("./").split("/")
        if len(parts) == 2:
            mem.setdefault(parts[0], {})[parts[1]] = m
    n, prefabs, folders = 0, [], []
    skip = set()
    try:  # files that hung Unity's importer before (written by the build watchdog) are never re-imported
        sf = assets.parent.parent / "Tools" / "skip_imports.txt"
        if sf.is_file():
            skip = {l.strip().lower().replace("\\", "/") for l in sf.read_text(encoding="utf-8", errors="replace").splitlines() if l.strip()}
    except Exception:
        skip = set()
    for guid, k in mem.items():
        if "pathname" not in k or "asset" not in k:
            continue
        rel = tf.extractfile(k["pathname"]).read().decode("utf-8", "replace").splitlines()[0].strip().replace("\\", "/")
        if not rel.lower().startswith("assets/") or ".." in rel.split("/"):
            continue
        low = "/" + rel.lower()
        if rel.lower() in skip:
            continue
        if Path(rel).suffix.lower() in SKIP_EXT or any(d in low for d in SKIP_DIR):
            continue
        if keep is not None and not keep(low):
            continue
        if cap and n >= cap:
            break
        top = "/".join(rel.split("/")[:2])
        if top not in folders and "/" in top:
            folders.append(top)
        dst = assets.parent / rel
        if low.endswith(".prefab"):
            prefabs.append(rel)
        if dst.exists():
            continue
        dst.parent.mkdir(parents=True, exist_ok=True)
        dst.write_bytes(tf.extractfile(k["asset"]).read())
        if "asset.meta" in k:
            Path(str(dst) + ".meta").write_bytes(tf.extractfile(k["asset.meta"]).read())
        n += 1
    return n, prefabs, folders


def copy_folder(src: Path, assets: Path) -> tuple[int, list[str]]:
    """Copy a pack folder from one of the creator's Unity projects (read only) into this project."""
    dst = assets / src.name
    n = 0
    for f in src.rglob("*"):
        if f.is_dir() or f.suffix.lower() in SKIP_EXT or (f.suffix == ".meta" and Path(f.stem).suffix.lower() in SKIP_EXT):
            continue
        t = dst / f.relative_to(src)
        if t.exists():
            continue
        t.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(f, t)
        n += 1
    return n, [f"Assets/{src.name}"]


# ------------------------------------------------------------- generated fallback audio

def _write_wav(path: Path, samples: list[float], rate: int = 22050) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with wave.open(str(path), "wb") as w:
        w.setnchannels(1); w.setsampwidth(2); w.setframerate(rate)
        w.writeframes(b"".join(struct.pack("<h", int(max(-1, min(1, s)) * 30000)) for s in samples))


def make_fallback_audio(assets: Path) -> list[str]:
    out = assets / "GameBot" / "Audio" / "Generated"
    rnd = random.Random(5)
    r = 22050
    made = []
    def env(i, n, a=0.002, d=0.25):
        t = i / r
        return min(1.0, t / a) * math.exp(-t / d)
    clips = {}
    n = int(r * 0.45); clips["gb_fire"] = [(rnd.uniform(-1, 1) * 0.9 + math.sin(2 * math.pi * 70 * i / r) * 0.6) * env(i, n, 0.001, 0.07) for i in range(n)]
    n = int(r * 0.6); clips["gb_reload"] = [(rnd.uniform(-1, 1) * (1 if (i < r * 0.03 or r * 0.35 < i < r * 0.38) else 0)) * 0.7 for i in range(n)]
    n = int(r * 0.25); clips["gb_hit"] = [(math.sin(2 * math.pi * 140 * i / r) * 0.8 + rnd.uniform(-1, 1) * 0.3) * env(i, n, 0.001, 0.05) for i in range(n)]
    n = int(r * 0.9); clips["gb_enemy"] = [math.sin(2 * math.pi * (85 + 25 * math.sin(2 * math.pi * 6 * i / r)) * i / r) * 0.55 * (1 if i < n * 0.8 else (n - i) / (n * 0.2)) * min(1, i / (r * 0.05)) for i in range(n)]
    n = int(r * 6.0); acc = 0.0; amb = []
    for i in range(n):
        acc = acc * 0.995 + rnd.uniform(-1, 1) * 0.02
        amb.append(acc * (0.6 + 0.4 * math.sin(2 * math.pi * 0.17 * i / r)) * 2.2)
    fade = int(r * 0.3)
    for i in range(fade):
        k = i / fade; amb[i] *= k; amb[-1 - i] *= k
    clips["gb_ambient"] = amb
    for nm, s in clips.items():
        p = out / f"{nm}.wav"
        if not p.exists():
            _write_wav(p, s)
        made.append(f"Assets/GameBot/Audio/Generated/{nm}.wav")
    return made


# ------------------------------------------------------------- import

def _audio_keep(need: str, size_mb: float):
    rx = re.compile(AUDIO_KEYS.get(need, r"."))
    def keep(low: str) -> bool:
        if Path(low).suffix not in AUDIO_EXT:
            return False
        return (size_mb or 0) < 15 or bool(rx.search(Path(low).name))
    return keep


def import_plan(proj: Path, root: Path, plan: dict) -> dict:
    assets = proj / "Assets"
    rep = {"family": plan.get("family"), "packs": [], "missing": [], "map": {}}
    done: dict = {}
    groups = list((plan.get("needs") or {}).items()) + [("extra:" + k, v) for k, v in (plan.get("extras") or {}).items()]
    for need, packs in groups:
        folders = rep["map"].setdefault(need, [])
        for p in packs:
            key = p["path"]
            try:
                if key in done and need not in AUDIO_NEEDS:
                    folders += [f for f in done[key] if f not in folders]
                    continue
                if p.get("kind") == "folder":
                    n, fl = copy_folder(Path(p["path"]), assets); pf = []
                else:
                    keep = _audio_keep(need, p.get("size_mb") or 0) if need in AUDIO_NEEDS else None
                    n, pf, fl = extract_filtered(Path(p["path"]), assets, keep=keep, cap=40 if need in AUDIO_NEEDS else 0)
                done[key] = fl
                folders += [f for f in fl if f not in folders]
                rep["packs"].append({"need": need, "name": p["name"], "files": n, "prefabs": len(pf), "folders": fl})
            except Exception as e:
                rep["packs"].append({"need": need, "name": p["name"], "error": str(e)[:200]})
    rep["map"]["generated_audio"] = ["Assets/GameBot/Audio/Generated"]
    rep["blender"] = list((plan.get("blender") or {}).values())
    ch = plan.get("choices") or {}
    rep["placeholders"] = [m["label"] for m in plan.get("missing") or [] if ch.get(m["key"]) == "placeholder"]
    return rep


def import_kit(proj: Path, root: Path, family: str) -> dict:
    assets = proj / "Assets"
    plan = None
    pp = root / "Tools" / "asset_plan.json"
    if pp.is_file():
        try:
            plan = json.loads(pp.read_text(encoding="utf-8"))
        except Exception:
            plan = None
    if plan is None:
        try:
            from asset_plan import build_plan, save_plan
            brief = {}
            bp = root / "Tools" / "game_brief.json"
            if bp.is_file():
                brief = json.loads(bp.read_text(encoding="utf-8"))
            plan = build_plan(family, brief)
            save_plan(root, plan)
        except Exception as e:
            print(f"KIT plan failed: {e}")
    rep = {"family": family, "packs": [], "missing": [], "map": {}}
    if plan:
        rep = import_plan(proj, root, plan)
    hits = []
    if family not in PLAN_ONLY:
        names = kit_for(family)
        hits = find_packs(names)
        have = {p.get("name") for p in rep["packs"]}
        rep["missing"] = [w for w in names if not any(_norm(p["name"]).startswith(_norm(w)) or _norm(w) in _norm(p["name"]) for p in hits)]
        for p in hits:
            if p["name"] in have:
                continue
            try:
                n, pf, fl = extract_filtered(Path(p["path"]), assets)
                rep["packs"].append({"need": "kit", "name": p["name"], "files": n, "prefabs": len(pf), "sample": pf[:6], "folders": fl})
            except Exception as e:
                rep["packs"].append({"need": "kit", "name": p["name"], "error": str(e)[:200]})
    rep["generated_audio"] = make_fallback_audio(assets)
    (root / "Tools").mkdir(parents=True, exist_ok=True)
    (root / "Tools" / "kit_packs.json").write_text(json.dumps(rep, indent=1), encoding="utf-8")
    # SceneBuilder reads this (JsonUtility-friendly arrays)
    amap = {"entries": [{"need": k, "folders": v} for k, v in rep.get("map", {}).items()],
            "blender": [{"key": b.get("label", ""), "path": b.get("unity", ""), "size": b.get("size", "prop")} for b in rep.get("blender", [])],
            "placeholders": rep.get("placeholders", [])}
    (root / "Tools" / "asset_map.json").write_text(json.dumps(amap, indent=1), encoding="utf-8")
    att = root / "ATTRIBUTION.md"
    if not att.is_file():
        att.write_text(f"# {root.name} - asset attribution & licences\n\n| asset | file(s) | source URL | author | licence | date | notes |\n|---|---|---|---|---|---|---|\n", encoding="utf-8")
    txt = att.read_text(encoding="utf-8", errors="replace")
    today = datetime.now().strftime("%Y-%m-%d")
    allp = [(p["name"], p.get("publisher", ""), p["path"], need) for need, ps in (plan or {}).get("needs", {}).items() for p in ps]
    allp += [(p["name"], p.get("publisher", ""), p["path"], "extra " + k) for k, ps in (plan or {}).get("extras", {}).items() for p in ps]
    allp += [(p["name"], p.get("publisher", ""), p["path"], "genre kit " + family) for p in hits]
    with att.open("a", encoding="utf-8") as f:
        for nm, pub, path, note in allp:
            if nm not in txt:
                txt += nm
                f.write(f"| {nm} | {path} | Unity Asset Store (owned, local cache) | {pub or '?'} | owned (Asset Store EULA) | {today} | {note} |\n")
    return rep


if __name__ == "__main__":
    r = import_kit(Path(sys.argv[1]), Path(sys.argv[2]), sys.argv[3] if len(sys.argv) > 3 else "platformer")
    for p in r["packs"]:
        print(f"KIT [{p.get('need')}] {p['name']}: {p.get('files', 0)} files, {p.get('prefabs', 0)} prefabs {p.get('error', '')}")
    if r.get("missing"):
        print("KIT missing: " + ", ".join(r["missing"]))
    if r.get("placeholders"):
        print("KIT placeholders: " + ", ".join(r["placeholders"]))
    print("KIT generated audio: " + str(len(r.get("generated_audio", []))))
