﻿using UnityEngine;

/// <summary>Persisted settings: video, audio, controls. Real PlayerPrefs — not stubs.</summary>
public static class GameSettings
{
    const string P = "TF_";
    public static int Width { get => PlayerPrefs.GetInt(P+"W", Screen.currentResolution.width); set => PlayerPrefs.SetInt(P+"W", value); }
    public static int Height { get => PlayerPrefs.GetInt(P+"H", Screen.currentResolution.height); set => PlayerPrefs.SetInt(P+"H", value); }
    public static bool Fullscreen { get => PlayerPrefs.GetInt(P+"FS", 1) == 1; set => PlayerPrefs.SetInt(P+"FS", value ? 1 : 0); }
    public static int Quality { get => PlayerPrefs.GetInt(P+"Q", QualitySettings.GetQualityLevel()); set => PlayerPrefs.SetInt(P+"Q", value); }
    public static bool VSync { get => PlayerPrefs.GetInt(P+"VS", 1) == 1; set => PlayerPrefs.SetInt(P+"VS", value ? 1 : 0); }
    public static float MasterVol { get => PlayerPrefs.GetFloat(P+"MV", 1f); set => PlayerPrefs.SetFloat(P+"MV", value); }
    public static float MusicVol { get => PlayerPrefs.GetFloat(P+"Music", 0.7f); set => PlayerPrefs.SetFloat(P+"Music", value); }
    public static float SfxVol { get => PlayerPrefs.GetFloat(P+"SFX", 1f); set => PlayerPrefs.SetFloat(P+"SFX", value); }
    public static float LookSens { get => PlayerPrefs.GetFloat(P+"Sens", 2f); set => PlayerPrefs.SetFloat(P+"Sens", value); }
    public static KeyCode KeyForward { get => (KeyCode)PlayerPrefs.GetInt(P+"KF", (int)KeyCode.W); set => PlayerPrefs.SetInt(P+"KF", (int)value); }
    public static KeyCode KeyBack { get => (KeyCode)PlayerPrefs.GetInt(P+"KB", (int)KeyCode.S); set => PlayerPrefs.SetInt(P+"KB", (int)value); }
    public static KeyCode KeyLeft { get => (KeyCode)PlayerPrefs.GetInt(P+"KL", (int)KeyCode.A); set => PlayerPrefs.SetInt(P+"KL", (int)value); }
    public static KeyCode KeyRight { get => (KeyCode)PlayerPrefs.GetInt(P+"KR", (int)KeyCode.D); set => PlayerPrefs.SetInt(P+"KR", (int)value); }
    public static KeyCode KeyJump { get => (KeyCode)PlayerPrefs.GetInt(P+"KJ", (int)KeyCode.Space); set => PlayerPrefs.SetInt(P+"KJ", (int)value); }
    public static KeyCode KeyPause { get => (KeyCode)PlayerPrefs.GetInt(P+"KP", (int)KeyCode.Escape); set => PlayerPrefs.SetInt(P+"KP", (int)value); }

    public static void ApplyVideo()
    {
        Screen.SetResolution(Width, Height, Fullscreen ? FullScreenMode.FullScreenWindow : FullScreenMode.Windowed);
        QualitySettings.SetQualityLevel(Mathf.Clamp(Quality, 0, QualitySettings.names.Length - 1), true);
        QualitySettings.vSyncCount = VSync ? 1 : 0;
    }
    public static void ApplyAudio()
    {
        AudioListener.volume = Mathf.Clamp01(MasterVol);
    }
    public static void ApplyAll() { ApplyVideo(); ApplyAudio(); PlayerPrefs.Save(); }
    public static void LoadAndApply() { ApplyAll(); }
}
