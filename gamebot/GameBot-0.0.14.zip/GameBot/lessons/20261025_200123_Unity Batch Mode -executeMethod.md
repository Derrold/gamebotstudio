# Unity Batch Mode -executeMethod

Tags: unity batchmode executeMethod
Saved: 2026-10-25T20:01:23

Unity's batch mode allows for automated builds and scripting through the use of -executeMethod flag. This flag runs a static method in an Editor script, useful for CI/CD pipelines. Official docs: https://docs.unity3d.com/Manual/CommandLineArguments.html
