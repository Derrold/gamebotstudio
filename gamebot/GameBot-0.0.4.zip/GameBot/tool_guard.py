"""Sandbox for the model's tools (review fix 2).

The local model may only read/write inside the app's own data folders and the game projects, may not run
destructive PowerShell, and every tool call is logged to work/tool_calls.log. Internal Game Bot code calls
pc_tools directly and is not affected; only model-initiated tool calls go through guard()."""
from __future__ import annotations

import json
import os
import re
import time
from pathlib import Path

ROOT = Path(__file__).resolve().parent
LOG = ROOT / "work" / "tool_calls.log"
HOME = Path.home()


def _p(x) -> Path | None:
    try:
        return Path(os.path.expandvars(os.path.expanduser(str(x)))).resolve()
    except Exception:
        return None


def _projects_root() -> Path:
    v = os.environ.get("GAMEBOT_PROJECTS", "").strip()
    return _p(v) if v else (HOME / "Documents" / "GameProjects")


def write_roots() -> list[Path]:
    r = [_projects_root(), ROOT / "work", ROOT / "notes", ROOT / "scripts", ROOT / "lessons",
         Path(os.environ.get("LOCALAPPDATA", str(HOME))) / "GameBot"]
    return [x for x in (_p(y) for y in r) if x]


def read_roots() -> list[Path]:
    extra = [ROOT, HOME / "Documents" / "UnityProjects", Path(os.environ.get("APPDATA", str(HOME))) / "Unity",
             Path(os.environ.get("LOCALAPPDATA", str(HOME))) / "Unity"]
    return write_roots() + [x for x in (_p(y) for y in extra) if x]


_SECRET_NAMES = re.compile(r"(?i)(license\.json|gamebot\.config\.json|\.key$|\.pem$|id_rsa|\.ssh|credentials|cookies|login data|\.env$|GameBotSigningKey)")


def _inside(p: Path, roots: list[Path]) -> bool:
    for r in roots:
        try:
            p.relative_to(r)
            return True
        except ValueError:
            continue
    return False


def check_path(path: str, write: bool) -> str | None:
    """None if allowed, else a refusal message."""
    p = _p(path)
    if not p or not str(path or "").strip():
        return "REFUSED: no path given."
    if _SECRET_NAMES.search(str(p)):
        return f"REFUSED: {p.name} is private (license, settings or keys) - the model may not open it."
    roots = write_roots() if write else read_roots()
    if not _inside(p, roots):
        where = "write" if write else "read"
        return (f"REFUSED (sandbox): Game Bot can only {where} files inside the game projects folder "
                f"({_projects_root()}) or its own data folders, not {p}.")
    if write and p.suffix.lower() in (".exe", ".dll", ".bat", ".cmd", ".ps1", ".vbs", ".reg", ".lnk", ".scr", ".msi"):
        return f"REFUSED: the model may not write program files ({p.suffix})."
    return None


_PS_BLOCK = re.compile(r"""(?ix)
    \b(format(-volume)?|clear-disk|initialize-disk|remove-partition|diskpart|bcdedit|vssadmin|wbadmin|cipher\s+/w|
       shutdown|restart-computer|stop-computer|reg(\.exe)?\s+(delete|add|import)|remove-itempropert(y|ies)|set-itemproperty\s+-path\s+hk|
       new-itemproperty|takeown|icacls|set-acl|set-executionpolicy|invoke-expression|iex|
       invoke-webrequest|iwr|invoke-restmethod|irm|start-bitstransfer|downloadstring|downloadfile|net\s+user|
       add-mppreference|set-mppreference|schtasks|new-service|sc(\.exe)?\s+(create|delete|config)|
       remove-appxpackage|uninstall-package|wmic|mklink|encodedcommand|-enc\b|frombase64string|
       rm\s+-rf|rd\s+/s|rmdir\s+/s|del\s+/[sfq]|stop-process\s+.*-name\s+(explorer|winlogon|csrss|lsass|svchost))\b
""")
_DELETE = re.compile(r"(?i)\b(remove-item|rm|del|erase|rd|rmdir|ri|clear-content|move-item|mv|set-content|add-content|out-file|new-item|rename-item)\b|(?<!\d)>>?(?!\s*(\$null|&))")
_PATHS = re.compile(r"""(?i)(?:"([^"]+)"|'([^']+)'|((?:[a-z]:|\\\\|%[a-z]+%|\$env:[a-z]+|~)[^\s;|'"]*))""")


def check_powershell(cmd: str) -> str | None:
    c = cmd or ""
    if _PS_BLOCK.search(c):
        return "REFUSED (sandbox): that command can change system settings, download code, or wipe data, so Game Bot won't run it."
    if _DELETE.search(c):
        paths = [next(g for g in m.groups() if g) for m in _PATHS.finditer(c)]
        if not paths:
            return "REFUSED (sandbox): delete/move/write commands need a full path inside the game projects folder."
        for raw in paths:
            raw = re.sub(r"(?i)\$env:([a-z_]+)", lambda m: os.environ.get(m.group(1), ""), raw)
            p = _p(raw)
            if not p or not _inside(p, write_roots()) or any(p == r for r in write_roots()) or len(p.parts) <= 3:
                return f"REFUSED (sandbox): Game Bot may only delete, move or write files inside a game project, not {raw}."
        if re.search(r"(?i)\*\s*$|\\\*|/\*", c) and re.search(r"(?i)-recurse", c):
            return "REFUSED (sandbox): recursive wildcard deletes are not allowed."
    return None


def log_call(name: str, args: dict, verdict: str) -> None:
    try:
        LOG.parent.mkdir(parents=True, exist_ok=True)
        a = {k: (str(v)[:300] + ("..." if len(str(v)) > 300 else "")) for k, v in (args or {}).items()}
        with LOG.open("a", encoding="utf-8") as f:
            f.write(json.dumps({"t": time.strftime("%Y-%m-%d %H:%M:%S"), "tool": name, "args": a, "verdict": verdict}, ensure_ascii=False) + "\n")
        if LOG.stat().st_size > 5 * 1024 * 1024:
            LOG.replace(LOG.with_suffix(".log.1"))
    except Exception:
        pass


_PATH_TOOLS = {"read_text_file": ("path", False), "list_files": ("path", False), "write_text_file": ("path", True),
               "open_path": ("path", False)}


def guard(name: str, args: dict) -> str | None:
    """Return a refusal string if this model tool call is not allowed; None to run it. Always logs."""
    args = args or {}
    why = None
    if name in _PATH_TOOLS:
        key, write = _PATH_TOOLS[name]
        if name == "list_files" and not str(args.get(key) or "").strip():
            why = None
        else:
            why = check_path(str(args.get(key) or ""), write)
    elif name == "run_powershell":
        why = check_powershell(str(args.get("command") or ""))
    elif name == "run_blender_script":
        sp = str(args.get("script_path") or "")
        if sp:
            why = check_path(sp, False)
        out = str(args.get("output_fbx") or "")
        if not why and out:
            why = check_path(out, True)
        code = str(args.get("script_code") or "")
        if not why and re.search(r"(?i)\b(subprocess|os\.system|os\.remove|os\.unlink|shutil\.rmtree|os\.rmdir|urllib|requests|socket|winreg|ctypes|__import__|eval\(|exec\()", code):
            why = "REFUSED (sandbox): Blender scripts may only build and export models (no file deletes, network or shell)."
    elif name == "launch_app":
        exe = str(args.get("path") or "").lower()
        if not re.search(r"(blender|unity|unityhub|unrealeditor|epicgameslauncher|steam)[^\\/]*\.exe$", exe) and not _inside(_p(exe) or Path("/"), [_projects_root()]):
            why = "REFUSED (sandbox): Game Bot only launches Blender, Unity, Unreal, Steam or a game it built."
    log_call(name, args, why or "ok")
    return why
