# AAA production checklist (gates — do not advance until the gate passes)
Sources: https://docs.unity3d.com/Manual/BuildSettings.html · https://docs.unity3d.com/Manual/Profiler.html · https://dev.epicgames.com/documentation/unreal-engine/packaging-and-cooking-games-in-unreal-engine · https://partner.steamgames.com/doc/store/review_process

## Gate 1 — Prototype playable
- [ ] Grey-box scene; core loop playable start->finish in < 5 min. [ ] Input (KB/M + gamepad). [ ] Batch build exits 0, no 'error CS'. [ ] 3 written notes on what is fun / not fun.
## Gate 2 — Content pipeline proven
- [ ] One asset of each type through the full path (Blender -> FBX -> engine -> material -> in scene) by script. [ ] Correct scale/axes/LODs/colliders. [ ] Scene rebuilt from a builder script with no manual steps. [ ] Licences logged.
## Gate 3 — Meta-systems
- [ ] Save/load with schemaVersion. [ ] Progression (XP/ranks/unlocks) + economy table balanced in a spreadsheet. [ ] Settings (graphics/audio/controls rebinding). [ ] Main menu -> play -> results -> hub flow.
## Gate 4 — Vertical slice
- [ ] One area at target quality (art, lighting, audio, VFX, UI). [ ] Performance budget met on target PC (Profiler capture saved). [ ] Smoke test automated.
## Gate 5 — Content volume plan
- [ ] Content list with counts (maps, items, enemies/animals, quests) and per-asset time estimate. [ ] Asset factory scripts for each family. [ ] Task board with milestones.
## Gate 6 — Ship checklist
- [ ] Version bumped everywhere. [ ] Dev/cheat unlocks removed. [ ] Clean build from scratch. [ ] Smoke + regression tests pass. [ ] Crash/log review. [ ] Installer upgrade keeps saves. [ ] Credits/licences complete, no trademarks. [ ] Store page assets (capsules, screenshots, trailer) — owner publishes. [ ] Owner approval before install/release.
