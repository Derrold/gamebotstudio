# Auto studio pipeline run (QaHuntFive)

Tags: auto studio pipeline
Saved: 2026-11-17T07:10:45

run_auto_game_pipeline created 34 files under C:\Users\Derrold PC\Documents\GameProjects\QaHuntFive and UNITY 6000.6.5f1: background job started -> create QaHuntFiveUnity -> Simulation game (gameplay template: sim; menu, settings, achievements, owned genre kit) ->. Next: check Builds\auto_unity_status.txt, then work TaskBoard 'Auto next actions' with tools.
