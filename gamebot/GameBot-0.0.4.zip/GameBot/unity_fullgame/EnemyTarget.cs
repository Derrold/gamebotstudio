using UnityEngine;

/// <summary>FPS enemy drone: patrols, chases when it sees the player, deals contact damage, dies to hits.</summary>
public class EnemyTarget : MonoBehaviour
{
    public int hp = 3; public float speed = 3.2f, sight = 25f, dps = 15f; public bool isBoss;
    Transform player; Vector3 home; Renderer rend; Color baseCol; float hitFlash; float dmgAcc;
    void Start()
    {
        var p = GameObject.FindGameObjectWithTag("Player"); if (p) player = p.transform;
        home = transform.position; rend = GetComponentInChildren<Renderer>(); if (rend) baseCol = rend.material.color;
    }
    public void Hit(int d)
    {
        hp -= d; hitFlash = Time.time + 0.1f; GbAudio.PlayAt("hit", transform.position + Vector3.up, 1f);
        if (hp <= 0)
        {
            GenreState.Kills++; GbAudio.PlayAt("enemy", transform.position + Vector3.up, 1f);
            AchievementSystem.NotifyKill(GenreState.Kills, GenreState.EnemiesTotal);
            if (isBoss) { GenreState.BossDown = true; AchievementSystem.Unlock("boss_down"); GameHUD.Flash("The warlord falls!"); }
            if ((GenreState.IsFps || GenreState.IsAction) && GenreState.Kills >= GenreState.EnemiesTotal) { if (GenreState.IsAction) AchievementSystem.Unlock("action_clear"); GenreState.Win(); }
            if (GenreState.IsRogue) GenreState.Alive--;
            Destroy(gameObject);
        }
    }
    void Update()
    {
        if (rend) rend.material.color = Time.time < hitFlash ? Color.white : baseCol;
        if (player == null || GameState.Won || GameState.Lost || PauseMenu.IsPaused) return;
        Vector3 to = player.position - transform.position; to.y = 0;
        if (to.magnitude < sight)
        {
            transform.rotation = Quaternion.LookRotation(to);
            if (to.magnitude > 1.4f) transform.position += to.normalized * speed * Time.deltaTime;
            else
            {
                dmgAcc += dps * Time.deltaTime;
                if (dmgAcc >= 1f) { int d = (int)dmgAcc; dmgAcc -= d; GbCombat.HurtPlayer(d); }
            }
        }
        else transform.position = Vector3.MoveTowards(transform.position, home + new Vector3(Mathf.Sin(Time.time) * 3f, 0, 0), speed * 0.5f * Time.deltaTime);
    }
}


