"""'Add more enemies' / 'more enemies': bump the current game's enemy count.

Games that already have an enemy system (FPS WorldEnemies, genre builders,
spawners, EnemyTarget, etc.) get a proposed count increase; 'yes' writes
Tools/game_brief.json enemy_count and queues a rebuild. Packs are offered
only when the game truly has no enemy models/system.
"""
from __future__ import annotations

import json
import re
from pathlib import Path

_PENDING: dict[str, dict] = {}  # key -> {root, count, prev}

_MORE_RE = re.compile(
    r"\b((add|spawn|place|put|include)\s+(a\s+few\s+|some\s+|more\s+|extra\s+)?(more\s+)?enem(y|ies|ys)\b|"
    r"(more|extra|additional)\s+enem(y|ies|ys)\b|"
    r"enem(y|ies|ys)\s+(count|numbers?|spawns?)\s+(up|higher|increase)|\bincrease\s+(the\s+)?enem)",
    re.I,
)
_FEWER_RE = re.compile(
    r"\b((remove|delete|take\s+out|get\s+rid\s+of|clear\s+out|kill\s+off)\s+"
    r"(all\s+|the\s+|every\s+|those\s+)?(enem(y|ies|ys)|bad\s+guys|monsters)\b|"
    r"(no|zero|without)\s+(more\s+)?(enem(y|ies|ys)|bad\s+guys)\b|"
    r"(fewer|less|not\s+so\s+many|not\s+as\s+many)\s+(enem(y|ies|ys)|bad\s+guys|monsters)\b|"
    r"(take\s+the\s+)?(enem(y|ies|ys)|bad\s+guys)\s+(out|away|gone|off|removed))\b",
    re.I,
)
_ALL_GONE_RE = re.compile(
    r"\b(no|zero|without|all|every|get\s+rid|remove|delete|take\s+out|gone)\b",
    re.I,
)
_ODD_CC0_RE = re.compile(r"\s*[\(,\-–—]*\s*free,?\s*no\s+CC0\s*[\)]?", re.I)

_DEFAULTS = {
    "fps": 10, "shooter": 10,
    "action": 4,
    "horror": 2,
    "battle_royale": 11, "br": 11,
    "stealth": 6,
    "rpg": 6,
    "roguelike": 5, "rogue": 5,
    "survival": 6,
    "open_world": 8,
    "adventure": 6,
    "platformer": 3,
}

_ENEMY_GENRES = frozenset(_DEFAULTS) | {"first person shooter", "tps"}

_ENEMY_FILE_RX = re.compile(
    r"WorldEnemies\s*\(|AddComponent<\s*EnemyTarget|class\s+EnemyTarget|class\s+WaveSpawner|"
    r"class\s+Stalker|class\s+BrBot|class\s+GuardPatrol|class\s+MmoMob|"
    r"name\s*=\s*\"(Enemy_|Raider_|Stalker_|Guard_|Hostile_)",
    re.I,
)


def _key(root=None, sid: str = "") -> str:
    if sid:
        return "sid:" + str(sid)
    return str(root).lower() if root else "_nogame"


def wants_more_enemies(text: str) -> bool:
    t = (text or "").strip()
    if not t or t.startswith("SYSTEM NOTE"):
        return False
    return bool(_MORE_RE.search(t))


def wants_fewer_enemies(text: str) -> bool:
    t = (text or "").strip()
    if not t or t.startswith("SYSTEM NOTE"):
        return False
    if wants_more_enemies(t):
        return False
    return bool(_FEWER_RE.search(t))


def scrub_odd_cc0(text: str) -> str:
    """Drop the odd 'free, no CC0' wording if a model or template slips it in."""
    if not text:
        return text
    out = _ODD_CC0_RE.sub("", text)
    out = re.sub(r" {2,}", " ", out)
    return out.strip() if text.strip() == text else out


def _brief_path(root) -> Path | None:
    if not root:
        return None
    p = Path(root) / "Tools" / "game_brief.json"
    return p if p.is_file() else Path(root) / "Tools" / "game_brief.json"


def load_brief(root) -> dict:
    p = _brief_path(root)
    if not p or not p.is_file():
        return {}
    try:
        return json.loads(p.read_text(encoding="utf-8"))
    except Exception:
        return {}


def _genre(root) -> str:
    b = load_brief(root)
    for k in ("family", "genre"):
        v = str(b.get(k) or "").strip().lower().replace("-", "_").replace(" ", "_")
        if v:
            return v
    if root:
        g = Path(root) / "Tools" / "genre.txt"
        try:
            return g.read_text(encoding="utf-8").strip().lower()
        except Exception:
            pass
    return ""


def _unity_dir(root) -> Path | None:
    if not root:
        return None
    p = Path(root) / "Tools" / "Unity"
    return p if p.is_dir() else None


def has_enemy_system(root) -> bool:
    """True if this game already places or can place enemies (builder, spawner, or genre)."""
    if not root:
        return False
    root = Path(root)
    b = load_brief(root)
    if int(b.get("enemy_count") or 0) > 0:
        return True
    g = _genre(root)
    if g in _ENEMY_GENRES:
        # shooter/FPS/action/etc. builders always place enemies (WorldEnemies, raiders, stalkers, ...)
        return True
    ud = _unity_dir(root)
    if ud:
        for f in list(ud.glob("*.cs"))[:80]:
            try:
                txt = f.read_text(encoding="utf-8", errors="replace")
            except Exception:
                continue
            if _ENEMY_FILE_RX.search(txt):
                return True
    log = root / "Builds" / "auto_unity_status.txt"
    try:
        if "WORLD_ENEMIES" in log.read_text(encoding="utf-8", errors="replace"):
            return True
    except Exception:
        pass
    # owned pack mapped to enemies counts as a model/system
    try:
        plan = json.loads((root / "Tools" / "asset_plan.json").read_text(encoding="utf-8"))
        for item in (plan.get("owned") or plan.get("packs") or plan.get("slots") or []):
            if isinstance(item, dict) and "enem" in json.dumps(item).lower():
                return True
    except Exception:
        pass
    return False


def _parse_builder_count(root) -> int:
    ud = _unity_dir(root)
    if not ud:
        return 0
    rx = re.compile(r"WorldEnemies\s*\(\s*(?:EnemyCount\s*\(\s*)?(\d+)")
    for nm in ("SceneBuilderWorld.cs", "SceneBuilder.cs", "SceneBuilderGenres.cs"):
        p = ud / nm
        if not p.is_file():
            continue
        try:
            txt = p.read_text(encoding="utf-8", errors="replace")
        except Exception:
            continue
        m = rx.search(txt)
        if m:
            return int(m.group(1))
    return 0


def current_count(root) -> int:
    b = load_brief(root)
    if "enemy_count" in b and b.get("enemy_count") is not None and str(b.get("enemy_count")).strip() != "":
        try:
            return max(0, int(b.get("enemy_count")))
        except (TypeError, ValueError):
            pass
    # Prefer this genre's default over a count parsed from another genre's builder
    # (e.g. WorldEnemies(EnemyCount(10)) in the FPS helper would steal a platformer's 3).
    g = _genre(root)
    if g in _DEFAULTS:
        return _DEFAULTS[g]
    n = _parse_builder_count(root)
    if n > 0:
        return n
    return 0


def next_count(cur: int) -> int:
    cur = max(int(cur or 0), 0)
    if cur <= 0:
        cur = 10
    return max(cur + 2, int(round(cur * 1.5)))


def set_enemy_count(root, n: int) -> Path:
    root = Path(root)
    try:
        import game_tweaks as _GT
        _GT.snapshot(root)
    except Exception:
        pass
    p = root / "Tools" / "game_brief.json"
    p.parent.mkdir(parents=True, exist_ok=True)
    data = load_brief(root)
    data["enemy_count"] = int(n)
    p.write_text(json.dumps(data, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
    return p


def _target_fewer(root, text: str) -> int:
    cur = current_count(root)
    t = (text or "").lower()
    if re.search(r"\b(no|zero|without|all|every|get\s+rid|remove|delete|take\s+out|gone|none)\b", t):
        if re.search(r"\b(fewer|less|not\s+so\s+many|not\s+as\s+many)\b", t):
            return max(0, cur // 2 if cur > 2 else max(0, cur - 1))
        return 0
    if re.search(r"\b(fewer|less|not\s+so\s+many|not\s+as\s+many)\b", t):
        return max(0, cur // 2 if cur > 2 else max(0, cur - 1))
    return 0


def apply_fewer(root, text: str = "", *, queue_rebuild: bool = True) -> str:
    if not root:
        return _no_game_reply().replace("add more enemies", "remove enemies")
    root = Path(root)
    name = root.name
    prev = current_count(root)
    nxt = _target_fewer(root, text)
    set_enemy_count(root, nxt)
    if nxt <= 0:
        msg = f"Removing the enemies from {name}."
    else:
        msg = f"Reducing enemies in {name} from {prev} to {nxt}."
    if queue_rebuild:
        try:
            from auto_studio import queue_rebuild
            q = queue_rebuild(root)
            if str(q).startswith("Unity rebuild queued"):
                msg += f' Rebuilding {name} now. Say "play" when it is ready.'
            elif "already running" in str(q).lower():
                msg += " A build is already running; this count will be in the next one."
            elif "GAMEBOT_SKIP_UNITY" in str(q):
                msg += " Count is saved; rebuild is skipped in this test run."
            else:
                msg += f" Count is saved ({q})."
        except Exception as e:
            msg += f" Count is saved; could not queue a rebuild ({e})."
    else:
        msg += " Say \"rebuild\" when you want it in the build."
    return msg


def take_pending(root, text: str, sid: str = "") -> dict | None:
    try:
        import reasoning as R
        yes = R.is_yes(text)
    except Exception:
        yes = bool(re.match(r"^\s*(yes|yeah|yep|yup|sure|ok(ay)?|do it|go ahead)\b", text or "", re.I))
    k = _key(root, sid)
    if k in _PENDING and yes:
        return _PENDING.pop(k)
    if k in _PENDING and not yes:
        _PENDING.pop(k, None)
    return None


def apply_pending(pend: dict, *, queue_rebuild: bool = True) -> str:
    root = Path(pend["root"])
    n = int(pend["count"])
    prev = int(pend.get("prev") or 0)
    set_enemy_count(root, n)
    name = root.name
    msg = f"Increasing enemies in {name} from {prev} to {n}."
    if queue_rebuild:
        try:
            from auto_studio import queue_rebuild
            q = queue_rebuild(root)
            if str(q).startswith("Unity rebuild queued"):
                msg += f' Rebuilding {name} now. Say "play" when it is ready.'
            elif "already running" in str(q).lower():
                msg += " A build is already running; this count will be in the next one."
            elif "GAMEBOT_SKIP_UNITY" in str(q):
                msg += " Count is saved; rebuild is skipped in this test run."
            else:
                msg += f" Count is saved ({q})."
        except Exception as e:
            msg += f" Count is saved; could not queue a rebuild ({e})."
    else:
        msg += " Say \"rebuild\" when you want it in the build."
    return msg


def _no_system_reply(root) -> str:
    name = Path(root).name if root else "your game"
    return (
        f"{name} does not have an enemy system yet, so there is no enemy count to increase. "
        "I can add a basic enemy spawner and place some enemies, or use an enemies pack you already own. "
        "Which would you like?"
    )


def _no_game_reply() -> str:
    return (
        "I need a game open to add more enemies. Open the game's chat (or tell me the game name) and say "
        '"add more enemies" again.'
    )


def propose_reply(root, text: str = "", sid: str = "") -> str:
    """Return the chat reply. Stores pending when a count bump is proposed."""
    if not root:
        return _no_game_reply()
    root = Path(root)
    name = root.name
    if not has_enemy_system(root):
        return _no_system_reply(root)
    prev = current_count(root) or _DEFAULTS.get(_genre(root), 10) or 10
    nxt = next_count(prev)
    _PENDING[_key(root, sid)] = {"root": str(root), "count": nxt, "prev": prev}
    return (
        f"{name} already has enemies in the game ({prev} in the current builder). "
        f"I will increase that to {nxt} and rebuild so you see more of them in play. "
        'Want me to go ahead? Say "yes" and I\'ll do it, or tell me a different number.'
    )