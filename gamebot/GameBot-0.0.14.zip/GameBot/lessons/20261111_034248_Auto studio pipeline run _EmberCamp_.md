# Auto studio pipeline run (EmberCamp)

Tags: auto studio pipeline
Saved: 2026-11-11T03:42:48

run_auto_game_pipeline created 33 files under C:\Users\ExtremeHybrid\Documents\GameProjects\EmberCamp and UNITY 6000.6.5f1: background job started -> create EmberCampUnity -> Survival game (gameplay template: survival; menu, settings, achievements, owned assets) -> . Next: check Builds\auto_unity_status.txt, then work TaskBoard 'Auto next actions' with tools.
