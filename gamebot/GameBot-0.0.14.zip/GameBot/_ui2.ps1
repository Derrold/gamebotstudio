param([string]$Action="shot",[string]$Text="",[string]$Out="C:\Users\ExtremeHybrid\ollama-web\_ui_shot.png")
Add-Type -AssemblyName UIAutomationClient,UIAutomationTypes,System.Drawing
Add-Type @"
using System; using System.Runtime.InteropServices;
public class W2 { [DllImport("user32.dll")] public static extern bool PrintWindow(IntPtr h, IntPtr hdc, uint f);
 [DllImport("user32.dll")] public static extern bool GetWindowRect(IntPtr h,out RECT r);
 [StructLayout(LayoutKind.Sequential)] public struct RECT { public int L,T,R,B; } }
"@
$p = Get-Process | ? { $_.MainWindowTitle -eq 'Game Bot' } | Select -First 1
if (-not $p) { "NO WINDOW"; exit 1 }
$h = $p.MainWindowHandle
$AE=[System.Windows.Automation.AutomationElement]
$root = $AE::FromHandle($h)
if ($Action -eq "send") {
  $edits = $root.FindAll([System.Windows.Automation.TreeScope]::Descendants, (New-Object System.Windows.Automation.PropertyCondition($AE::ControlTypeProperty,[System.Windows.Automation.ControlType]::Edit)))
  "edits: $($edits.Count)"
  $box = $null; foreach($e in $edits){ if ($e.Current.Name -match 'Describe' -or $e.Current.HelpText -match 'Describe') { $box=$e } }
  if (-not $box -and $edits.Count -gt 0) { $box = $edits[$edits.Count-1] }
  $box.GetCurrentPattern([System.Windows.Automation.ValuePattern]::Pattern).SetValue($Text)
  Start-Sleep -Milliseconds 300
  $btns = $root.FindAll([System.Windows.Automation.TreeScope]::Descendants, (New-Object System.Windows.Automation.PropertyCondition($AE::ControlTypeProperty,[System.Windows.Automation.ControlType]::Button)))
  $send=$null; foreach($b in $btns){ if ($b.Current.Name -eq 'Send') { $send=$b } }
  if (-not $send) { "NO SEND BUTTON"; exit 2 }
  $send.GetCurrentPattern([System.Windows.Automation.InvokePattern]::Pattern).Invoke(); "sent via UIA"
  Start-Sleep -Milliseconds 800
}
$r = New-Object W2+RECT; [W2]::GetWindowRect($h,[ref]$r) | Out-Null
$bmp = New-Object Drawing.Bitmap ($r.R-$r.L),($r.B-$r.T); $g=[Drawing.Graphics]::FromImage($bmp); $hdc=$g.GetHdc(); [W2]::PrintWindow($h,$hdc,2) | Out-Null; $g.ReleaseHdc($hdc); $bmp.Save($Out); "shot $Out"
