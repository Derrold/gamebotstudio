using UnityEngine;
/// <summary>One-shot jump scare: flashes a red light and shows a toast when the player walks in.</summary>
public class ScareTrigger : MonoBehaviour
{
    public string text = "Something moved behind you..."; bool done; Light l; float off;
    void OnTriggerEnter(Collider o)
    {
        if (done || !o.CompareTag("Player")) return; done = true;
        l = new GameObject("ScareLight").AddComponent<Light>(); l.transform.position = transform.position + Vector3.up * 2; l.color = Color.red; l.intensity = 8; l.range = 15; off = Time.time + 0.6f;
        GameHUD.Flash(text);
    }
    void Update() { if (l && Time.time > off) Destroy(l.gameObject); }
}
