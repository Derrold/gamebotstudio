# Prefab vs ScriptableObject for weapon data in Unity

Tags: unity game-dev
Saved: 2026-10-25T20:07:32

For Unity games, use ScriptableObject for shared tunable data like weapon stats (damage, mag capacity). Use prefab for the visual/behavioral implementation. Rule: Data that designers tune = ScriptableObject; behavior = MonoBehaviour.
