using System.Collections.Generic;
using UnityEngine;

/// <summary>Achievements with unlock toast + PlayerPrefs persistence.</summary>
public static class AchievementSystem
{
    public class Ach { public string Id, Title, Desc; public bool Unlocked; public Ach(string id, string t, string d){ Id=id; Title=t; Desc=d; } }
    static readonly List<Ach> All = new List<Ach>{
        new Ach("first_coin", "First Spark", "Collect your first coin"),
        new Ach("coins_5", "Fox Cache", "Collect 5 coins"),
        new Ach("coins_10", "Trail Treasure", "Collect 10 coins"),
        new Ach("reach_flag", "Summit Flag", "Reach the end flag"),
        new Ach("no_death", "Clean Trail", "Reach the flag with 0 deaths"),
        new Ach("first_kill", "First Contact", "Take down your first hostile"),
        new Ach("kills_5", "Clearing House", "Take down 5 hostiles"),
        new Ach("all_kills", "Sector Clear", "Eliminate every hostile in the zone"),
        new Ach("first_lap", "Green Flag", "Complete your first lap"),
        new Ach("fast_lap", "Ridge Runner", "Complete a lap in under 45 seconds"),
        new Ach("speed_100", "Ton Up", "Hit 100 km/h"),
        new Ach("fuse_first", "Spark in the Dark", "Find your first fuse"),
        new Ach("escape", "Lights Out", "Escape the halls"),
        new Ach("relic_first", "Relic Hunter", "Recover a relic"),
        new Ach("level_up", "Stronger", "Reach level 2"),
        new Ach("quest_done", "Hero of the Vale", "Complete the elder's quest"),
        new Ach("pad_first", "Click", "Push a block onto a pad"),
        new Ach("solved", "Vault Breaker", "Solve the vault"),
        new Ach("fire_built", "Firestarter", "Build a campfire"),
        new Ach("survived", "Dawn", "Survive the night"),
        new Ach("found_key", "Keyholder", "Find the gate key"),
        new Ach("explorer", "Explorer", "Find a hidden treasure"),
        new Ach("shrine", "Pilgrim", "Reach the shrine"),
        new Ach("first_sale", "Open for Business", "Make your first sale"),
        new Ach("cash_goal", "Good Day", "Hit the cash goal"),
        new Ach("wave_1", "Still Breathing", "Clear wave 1"),
        new Ach("run_clear", "Against the Odds", "Clear a full run"),
        new Ach("combo_5", "Blade Dancer", "Land a 5-hit combo"), new Ach("boss_down", "Warlord Slayer", "Defeat the warlord"), new Ach("action_clear", "Outpost Reclaimed", "Defeat every raider"),
        new Ach("heavy_hit", "Haymaker", "Land a clean heavy kick"), new Ach("perfect_round", "Flawless", "Win a round without taking damage"), new Ach("champion", "Champion", "Win the match"),
        new Ach("first_unit", "Muster", "Train your first unit"), new Ach("point_first", "Foothold", "Capture a quartz point"), new Ach("all_points", "Quarry Lord", "Hold every point"), new Ach("hold_3", "Holding the Line", "Survive 3 raids"), new Ach("keep_down", "Siege Breaker", "Destroy the enemy keep"),
        new Ach("tower_down", "Tower Diver", "Destroy an enemy tower"), new Ach("shockwave_3", "Crowd Control", "Hit 3 enemies with one Shockwave"), new Ach("core_down", "Core Breaker", "Destroy the enemy core"),
        new Ach("first_goal", "On the Board", "Score your first goal"), new Ach("clean_sheet", "Clean Sheet", "Win without conceding"),
        new Ach("harvest", "Lumberjack", "Harvest a tree or rock"), new Ach("builder_25", "Architect", "Place 25 blocks"), new Ach("tower_5", "Sky High", "Build 5 blocks tall"), new Ach("beacon", "Beacon Lit", "Light the Sky Beacon"),
        new Ach("intel_first", "Light Fingers", "Steal a piece of intel"), new Ach("ghost", "Ghost", "Grab all intel without an alarm"), new Ach("extracted", "Extraction", "Reach the extraction point"),
        new Ach("looter", "Looter", "Open a loot crate"), new Ach("victory_royale", "Last One Standing", "Win the battle royale"),
        new Ach("quest_accept", "Adventurer", "Accept a quest"), new Ach("treant", "Treant Felled", "Defeat the Ancient Treant"), new Ach("hero_hearthvale", "Hero of Hearthvale", "Complete every town quest"),
    };
    static string _toast; static float _toastT;
    const string P = "TFA_";

    public static IReadOnlyList<Ach> List => All;
    public static string Toast => string.IsNullOrEmpty(_toast) || Time.unscaledTime > _toastT ? null : _toast;

    public static void Load()
    {
        foreach (var a in All) a.Unlocked = PlayerPrefs.GetInt(P + a.Id, 0) == 1;
    }
    public static void Unlock(string id)
    {
        var a = All.Find(x => x.Id == id);
        if (a == null || a.Unlocked) return;
        a.Unlocked = true;
        PlayerPrefs.SetInt(P + id, 1); PlayerPrefs.Save();
        _toast = "Achievement: " + a.Title; _toastT = Time.unscaledTime + 3.5f;
    }
    static readonly List<string> GoalIds = new List<string>();
    /// <summary>Register per-game goal achievements (ids/titles/descs come from the intake goals).</summary>
    public static void RegisterGoals(string[] ids, string[] titles, string[] descs)
    {
        GoalIds.Clear();
        if (ids == null) return;
        for (int i = 0; i < ids.Length; i++)
        {
            if (string.IsNullOrEmpty(ids[i])) continue;
            string t = titles != null && i < titles.Length ? titles[i] : ids[i];
            string d = descs != null && i < descs.Length ? descs[i] : t;
            var a = All.Find(x => x.Id == ids[i]);
            if (a == null) { a = new Ach(ids[i], t, d); All.Add(a); } else { a.Title = t; a.Desc = d; }
            a.Unlocked = PlayerPrefs.GetInt(P + a.Id, 0) == 1;
            GoalIds.Add(ids[i]);
        }
    }
    public static void UnlockGoal(int index) { if (index >= 0 && index < GoalIds.Count) Unlock(GoalIds[index]); }
    public static void NotifyCoin(int total)
    {
        if (total >= 1) Unlock("first_coin");
        if (total >= 5) Unlock("coins_5");
        if (total >= 10) Unlock("coins_10");
    }
    public static void NotifyGoal()
    {
        Unlock("reach_flag");
        if (GameState.Deaths == 0) Unlock("no_death");
    }
    public static void NotifyDeath() { }
    public static void NotifyKill(int kills, int total)
    {
        if (kills >= 1) Unlock("first_kill");
        if (kills >= 5) Unlock("kills_5");
        if (total > 0 && kills >= total) Unlock("all_kills");
    }
    public static void NotifyLap(int lap, float lapTime)
    {
        if (lap >= 1) Unlock("first_lap");
        if (lapTime < 45f) Unlock("fast_lap");
    }
    public static void NotifySpeed(float kmh) { if (kmh >= 100f) Unlock("speed_100"); }
    /// <summary>Achievements relevant to the current genre (menus list these).</summary>
    public static System.Collections.Generic.IEnumerable<Ach> ForMode()
    {
        if (GoalIds.Count > 0)
        {
            // This game's own achievements, generated from the creator's intake goals
            foreach (var gid in GoalIds) { var g = All.Find(q => q.Id == gid); if (g != null) yield return g; }
            yield break;
        }
        string m = GenreState.Family;
        string[] xids = m == "action" ? new[]{"first_kill","combo_5","boss_down","action_clear"} : m == "fighting" ? new[]{"heavy_hit","perfect_round","champion"} : m == "strategy" ? new[]{"first_unit","point_first","all_points","hold_3","keep_down"}
            : m == "moba" ? new[]{"tower_down","shockwave_3","level_up","core_down"} : m == "sports" ? new[]{"first_goal","clean_sheet"} : m == "sandbox" ? new[]{"harvest","builder_25","tower_5","beacon"}
            : m == "stealth" ? new[]{"intel_first","ghost","extracted"} : m == "battle_royale" ? new[]{"first_kill","looter","victory_royale"} : m == "mmorpg" ? new[]{"quest_accept","level_up","treant","hero_hearthvale"} : null;
        if (xids != null) { foreach (var id in xids) { var x = All.Find(q => q.Id == id); if (x != null) yield return x; } yield break; }
        string[] ids = m == "horror" ? new[]{"fuse_first","escape","no_death"} : m == "rpg" ? new[]{"relic_first","level_up","quest_done"}
            : m == "puzzle" ? new[]{"pad_first","solved"} : m == "survival" ? new[]{"fire_built","survived"}
            : m == "adventure" ? new[]{"found_key","explorer","shrine"} : m == "sim" ? new[]{"first_sale","cash_goal"}
            : m == "roguelike" ? new[]{"first_kill","wave_1","run_clear"} : GenreState.IsFps ? new[]{"first_kill","kills_5","all_kills","reach_flag","no_death"}
            : GenreState.IsRacing ? new[]{"first_lap","fast_lap","speed_100","reach_flag","no_death"}
            : new[]{"first_coin","coins_5","coins_10","reach_flag","no_death"};
        foreach (var id in ids) { var x = All.Find(q => q.Id == id); if (x != null) yield return x; }
    }
}

