﻿param(
  [Parameter(Mandatory=$true)][string]$Name,
  [Parameter(Mandatory=$true)][string]$TargetPath,
  [string]$WorkingDirectory = "",
  [string]$IconPath = "",
  [string]$Description = ""
)
$desk = [Environment]::GetFolderPath('Desktop')
if (-not $WorkingDirectory) { $WorkingDirectory = Split-Path -Parent $TargetPath }
$W = New-Object -ComObject WScript.Shell
$lnk = Join-Path $desk ($Name + ".lnk")
$s = $W.CreateShortcut($lnk)
$s.TargetPath = $TargetPath
$s.WorkingDirectory = $WorkingDirectory
if ($IconPath) { $s.IconLocation = "$IconPath,0" }
if ($Description) { $s.Description = $Description }
$s.Save()
Write-Output "SHORTCUT $lnk Icon=$($s.IconLocation)"
