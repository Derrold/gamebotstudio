# Steam store capsules and wishlist campaign

1. Export capsule sizes from turnkey-assets-stores-gaps.md into Art\Store\Steam\<app>\.
2. Coming Soon page early for wishlists; refresh screenshots as slice improves.
3. Research competitor tags via firefox_search.
4. Optional demo depot; keep demo build green.
5. Launch posts only if the creator asks; Game Bot prepares copy+art locally.
