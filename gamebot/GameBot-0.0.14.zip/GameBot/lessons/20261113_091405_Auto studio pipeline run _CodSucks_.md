# Auto studio pipeline run (CodSucks)

Tags: auto studio pipeline
Saved: 2026-11-13T09:14:05

run_auto_game_pipeline created 33 files under C:\Users\ExtremeHybrid\Documents\GameProjects\CodSucks and UNITY 6000.6.5f1: background job started -> create CodSucksUnity -> Shooter / FPS game (gameplay template: fps; menu, settings, achievements, owned genre kit) -. Next: check Builds\auto_unity_status.txt, then work TaskBoard 'Auto next actions' with tools.
