using UnityEngine;
/// <summary>Sandbox family: grid block placing/removing with owned-pack materials, harvest nodes for more blocks, Sky Beacon goal.</summary>
public class SandboxBuilder : MonoBehaviour
{
    public Material[] mats; public string[] matNames; Camera cam; GameObject ghost; float nextAct;
    void Start()
    {
        cam = GetComponentInChildren<Camera>();
        ghost = GameObject.CreatePrimitive(PrimitiveType.Cube); ghost.name = "BuildGhost"; Destroy(ghost.GetComponent<Collider>()); ghost.GetComponent<Renderer>().material.color = new Color(1, 1, 1, 0.35f);
    }
    void Update()
    {
        if (GameState.Won || GameState.Lost || PauseMenu.IsPaused || MainMenuUI.InMenu || !cam) return;
        for (int i = 0; i < 4; i++) if (Input.GetKeyDown(KeyCode.Alpha1 + i) && mats != null && i < mats.Length) { GenreState.BlockType = i; GameHUD.Flash("Material: " + (matNames != null && i < matNames.Length ? matNames[i] : "#" + (i + 1))); }
        ghost.SetActive(false);
        if (!Physics.Raycast(cam.transform.position, cam.transform.forward, out var hit, 8f, ~0, QueryTriggerInteraction.Ignore)) return;
        Vector3 cell = Snap(hit.point + hit.normal * 0.5f); ghost.SetActive(true); ghost.transform.position = cell;
        if (Time.time < nextAct) return;
        if (Input.GetMouseButtonDown(0) || (GameBotQA.AutoFire && GenreState.Placed < 3))
        {
            nextAct = Time.time + 0.12f;
            if (GenreState.Blocks <= 0) { GameHUD.Flash("Out of blocks - press E on trees/rocks to harvest"); return; }
            if (Vector3.Distance(cell, transform.position + Vector3.up) < 1.1f) return;
            var b = GameObject.CreatePrimitive(PrimitiveType.Cube); b.name = "PlacedBlock"; b.transform.position = cell; if (mats != null && mats.Length > 0) b.GetComponent<Renderer>().sharedMaterial = mats[Mathf.Clamp(GenreState.BlockType, 0, mats.Length - 1)];
            GenreState.Blocks--; GenreState.Placed++; int h = Mathf.RoundToInt(cell.y - 0.5f) + 1; if (h > GenreState.MaxHeight) GenreState.MaxHeight = h;
            if (GenreState.Placed >= 25) AchievementSystem.Unlock("builder_25"); if (GenreState.MaxHeight >= 5) AchievementSystem.Unlock("tower_5");
        }
        else if (Input.GetMouseButtonDown(1) && hit.collider.name == "PlacedBlock") { nextAct = Time.time + 0.12f; Destroy(hit.collider.gameObject); GenreState.Blocks++; }
        else if (Input.GetKeyDown(KeyCode.E))
        {
            var node = hit.collider.GetComponentInParent<SandboxNode>(); if (node) { nextAct = Time.time + 0.3f; node.Harvest(); }
        }
    }
    static Vector3 Snap(Vector3 p) => new Vector3(Mathf.Floor(p.x) + 0.5f, Mathf.Floor(p.y) + 0.5f, Mathf.Floor(p.z) + 0.5f);
}
