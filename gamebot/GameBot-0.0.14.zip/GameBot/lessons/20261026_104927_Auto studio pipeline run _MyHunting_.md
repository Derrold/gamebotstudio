# Auto studio pipeline run (MyHunting)

Tags: auto studio pipeline
Saved: 2026-10-26T10:49:27

run_auto_game_pipeline created 1 files under C:\Users\ExtremeHybrid\Documents\GameProjects\MyHunting and UNREAL: created C:\Users\ExtremeHybrid\Documents\GameProjects\MyHunting\MyHunting.uproject from TP_FirstPersonBP; launched UnrealEditor.exe. Next: check Builds\auto_unity_status.txt, then work TaskBoard 'Auto next actions' with tools.
