// Game Bot branded launcher (WinExe). Sets the same AppUserModelID the
// installer writes on the shortcut, then starts desktop_window.py via pythonw
// (never a visible console). The window process also sets this AUMID and the
// shared multi-size icon so the taskbar groups under the Game Bot shortcut.
using System;
using System.Diagnostics;
using System.IO;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading;
using System.Windows.Forms;
using System.Security.Principal;

internal static class Program
{
    public const string Aumid = "AlphaMaxStudios.GameBot";
    const string MutexName = "Local\\AlphaMaxStudios.GameBot";
    const string WindowTitle = "Game Bot";

    [DllImport("shell32.dll", CharSet = CharSet.Unicode)]
    static extern int SetCurrentProcessExplicitAppUserModelID(string appID);

    [DllImport("user32.dll", CharSet = CharSet.Unicode)]
    static extern IntPtr FindWindow(string lpClassName, string lpWindowName);

    [DllImport("user32.dll")]
    static extern bool SetForegroundWindow(IntPtr hWnd);

    [DllImport("user32.dll")]
    static extern bool ShowWindow(IntPtr hWnd, int nCmdShow);

    [DllImport("user32.dll")]
    static extern bool IsIconic(IntPtr hWnd);

    const int SW_RESTORE = 9;

    [STAThread]
    static int Main(string[] args)
    {
        SetCurrentProcessExplicitAppUserModelID(Aumid);
        if (RelaunchUnelevatedIfNeeded())
            return 0;

        bool created;
        using (var mutex = new Mutex(true, MutexName, out created))
        {
            if (!created)
            {
                FocusExisting();
                return 0;
            }

            string root = Path.GetDirectoryName(
                System.Reflection.Assembly.GetExecutingAssembly().Location);
            if (string.IsNullOrEmpty(root) || !Directory.Exists(root))
            {
                Fail("Game Bot could not find its install folder.");
                return 1;
            }
            try { Directory.SetCurrentDirectory(root); }
            catch { }

            string script = Path.Combine(root, "desktop_window.py");
            if (!File.Exists(script))
            {
                Fail("desktop_window.py is missing from:\n" + root);
                return 1;
            }

            string pythonw = FindPythonw();
            if (string.IsNullOrEmpty(pythonw))
            {
                Fail("Game Bot needs Python 3.11+ (python.org) on PATH. See PREREQUISITES.txt.");
                return 1;
            }

            var psi = new ProcessStartInfo
            {
                FileName = pythonw,
                Arguments = Quote(script),
                WorkingDirectory = root,
                UseShellExecute = false,
                CreateNoWindow = true,
            };
            psi.EnvironmentVariables["OLLAMA_MODEL"] = "gamebot-trained";
            psi.EnvironmentVariables["QWEN_HEADLESS"] = "1";

            try
            {
                using (var proc = Process.Start(psi))
                {
                    if (proc == null)
                    {
                        Fail("Game Bot failed to start.");
                        return 1;
                    }
                    proc.WaitForExit();
                    return proc.ExitCode;
                }
            }
            catch (Exception ex)
            {
                Fail("Game Bot failed to start:\n" + ex.Message);
                return 1;
            }
        }
    }

    static void FocusExisting()
    {
        IntPtr hwnd = FindWindow(null, WindowTitle);
        if (hwnd == IntPtr.Zero)
            return;
        if (IsIconic(hwnd))
            ShowWindow(hwnd, SW_RESTORE);
        SetForegroundWindow(hwnd);
    }

    static void Fail(string msg)
    {
        try { MessageBox.Show(msg, WindowTitle, MessageBoxButtons.OK, MessageBoxIcon.Error); }
        catch { }
    }

    static string Quote(string path)
    {
        if (string.IsNullOrEmpty(path))
            return "\"\"";
        return "\"" + path.Replace("\"", "\\\"") + "\"";
    }

    static string FindPythonw()
    {
        string env = Environment.GetEnvironmentVariable("GAMEBOT_PYTHONW");
        if (!string.IsNullOrEmpty(env) && File.Exists(env))
            return env;

        string fromPy = RunHidden("py", "-3 -c \"import sys,os; p=sys.executable; w=os.path.join(os.path.dirname(p),'pythonw.exe'); print(w if os.path.exists(w) else p)\"");
        if (!string.IsNullOrEmpty(fromPy) && File.Exists(fromPy))
            return fromPy;

        string fromPython = RunHidden("python", "-c \"import sys,os; p=sys.executable; w=os.path.join(os.path.dirname(p),'pythonw.exe'); print(w if os.path.exists(w) else p)\"");
        if (!string.IsNullOrEmpty(fromPython) && File.Exists(fromPython))
            return fromPython;

        string path = Environment.GetEnvironmentVariable("PATH") ?? "";
        foreach (string dir in path.Split(Path.PathSeparator))
        {
            if (string.IsNullOrWhiteSpace(dir))
                continue;
            string cand = Path.Combine(dir.Trim().Trim('"'), "pythonw.exe");
            if (File.Exists(cand))
                return cand;
        }

        string[] roots = new string[]
        {
            Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "Programs", "Python"),
            Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ProgramFiles), "Python"),
            Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ProgramFilesX86), "Python"),
        };
        foreach (string r in roots)
        {
            if (!Directory.Exists(r))
                continue;
            string[] dirs;
            try { dirs = Directory.GetDirectories(r, "Python3*"); }
            catch { continue; }
            Array.Sort(dirs);
            for (int i = dirs.Length - 1; i >= 0; i--)
            {
                string cand = Path.Combine(dirs[i], "pythonw.exe");
                if (File.Exists(cand))
                    return cand;
            }
        }
        return null;
    }

    static string RunHidden(string file, string args)
    {
        try
        {
            var psi = new ProcessStartInfo
            {
                FileName = file,
                Arguments = args,
                UseShellExecute = false,
                RedirectStandardOutput = true,
                RedirectStandardError = true,
                CreateNoWindow = true,
            };
            using (var p = Process.Start(psi))
            {
                if (p == null)
                    return null;
                string output = (p.StandardOutput.ReadToEnd() ?? "").Trim();
                p.WaitForExit(15000);
                if (!p.HasExited)
                {
                    try { p.Kill(); } catch { }
                    return null;
                }
                if (p.ExitCode != 0)
                    return null;
                foreach (string line in output.Split(new[] { '\r', '\n' }, StringSplitOptions.RemoveEmptyEntries))
                    return line.Trim();
            }
        }
        catch { }
        return null;
    }
    [DllImport("advapi32.dll", SetLastError = true)]
    static extern bool OpenProcessToken(IntPtr ProcessHandle, uint desiredAccess, out IntPtr TokenHandle);
    [DllImport("advapi32.dll", SetLastError = true)]
    static extern bool GetTokenInformation(IntPtr TokenHandle, int tokenInfoClass, IntPtr info, int infoLength, out int returnLength);
    [DllImport("advapi32.dll", SetLastError = true)]
    static extern bool DuplicateTokenEx(IntPtr hExistingToken, uint dwDesiredAccess, IntPtr lpTokenAttributes, int ImpersonationLevel, int TokenType, out IntPtr phNewToken);
    [DllImport("advapi32.dll", SetLastError = true, CharSet = CharSet.Unicode)]
    static extern bool CreateProcessWithTokenW(IntPtr hToken, uint dwLogonFlags, string lpApplicationName, string lpCommandLine, uint dwCreationFlags, IntPtr lpEnvironment, string lpCurrentDirectory, ref STARTUPINFO lpStartupInfo, out PROCESS_INFORMATION lpProcessInformation);
    [DllImport("kernel32.dll")] static extern IntPtr OpenProcess(uint acc, bool inherit, int pid);
    [DllImport("kernel32.dll")] static extern bool CloseHandle(IntPtr h);
    [DllImport("kernel32.dll")] static extern bool ProcessIdToSessionId(int dwProcessId, out int pSessionId);

    [StructLayout(LayoutKind.Sequential, CharSet = CharSet.Unicode)]
    struct STARTUPINFO {
        public int cb; public string lpReserved; public string lpDesktop; public string lpTitle;
        public int dwX, dwY, dwXSize, dwYSize, dwXCountChars, dwYCountChars, dwFillAttribute, dwFlags;
        public short wShowWindow, cbReserved2; public IntPtr lpReserved2, hStdInput, hStdOutput, hStdError;
    }
    [StructLayout(LayoutKind.Sequential)]
    struct PROCESS_INFORMATION {
        public IntPtr hProcess, hThread; public int dwProcessId, dwThreadId;
    }

    static bool IsElevated()
    {
        try
        {
            IntPtr tok;
            if (!OpenProcessToken(System.Diagnostics.Process.GetCurrentProcess().Handle, 0x0008, out tok))
                return false;
            int sz = 4, ret;
            IntPtr buf = Marshal.AllocHGlobal(sz);
            bool ok = GetTokenInformation(tok, 20, buf, sz, out ret);
            int val = ok ? Marshal.ReadInt32(buf) : 0;
            Marshal.FreeHGlobal(buf);
            CloseHandle(tok);
            return val != 0;
        }
        catch { return false; }
    }

    static bool RelaunchUnelevatedIfNeeded()
    {
        if (!IsElevated())
            return false;
        // Drop to the medium-integrity Explorer token. Never request admin (no UAC).
        try
        {
            int mySession;
            ProcessIdToSessionId(System.Diagnostics.Process.GetCurrentProcess().Id, out mySession);
            IntPtr token = IntPtr.Zero;
            foreach (var p in System.Diagnostics.Process.GetProcessesByName("explorer"))
            {
                try
                {
                    int sid;
                    ProcessIdToSessionId(p.Id, out sid);
                    if (sid != mySession) continue;
                    IntPtr hp = OpenProcess(0x1400, false, p.Id);
                    if (hp == IntPtr.Zero) continue;
                    IntPtr tok;
                    if (!OpenProcessToken(hp, 0x0002 | 0x0008, out tok)) { CloseHandle(hp); continue; }
                    IntPtr elevBuf = Marshal.AllocHGlobal(4);
                    int ret;
                    GetTokenInformation(tok, 20, elevBuf, 4, out ret);
                    int elevated = Marshal.ReadInt32(elevBuf);
                    Marshal.FreeHGlobal(elevBuf);
                    if (elevated != 0) { CloseHandle(tok); CloseHandle(hp); continue; }
                    IntPtr dup;
                    if (DuplicateTokenEx(tok, 0x000F, IntPtr.Zero, 2, 1, out dup) && dup != IntPtr.Zero)
                        token = dup;
                    CloseHandle(tok);
                    CloseHandle(hp);
                    if (token != IntPtr.Zero) break;
                }
                catch { }
            }
            if (token == IntPtr.Zero)
                return false;
            string exe = System.Reflection.Assembly.GetExecutingAssembly().Location;
            var si = new STARTUPINFO();
            si.cb = Marshal.SizeOf(typeof(STARTUPINFO));
            si.dwFlags = 0x00000001;
            si.wShowWindow = 0;
            PROCESS_INFORMATION pi;
            string cmd = "\"" + exe + "\"";
            bool ok = CreateProcessWithTokenW(token, 0, exe, cmd, 0x00000008 | 0x00000200, IntPtr.Zero,
                Path.GetDirectoryName(exe), ref si, out pi);
            CloseHandle(token);
            if (ok)
            {
                if (pi.hThread != IntPtr.Zero) CloseHandle(pi.hThread);
                if (pi.hProcess != IntPtr.Zero) CloseHandle(pi.hProcess);
            }
            return ok;
        }
        catch { return false; }
    }


}
