# Auto studio pipeline run (BlockShift)

Tags: auto studio pipeline
Saved: 2026-11-05T09:10:20

run_auto_game_pipeline created 32 files under C:\Users\ExtremeHybrid\Documents\GameProjects\BlockShift and UNITY 6000.6.5f1: background job started -> create BlockShiftUnity -> Assets/Scenes/Slice01.unity (grey-box, player, goal, HUD) -> Builds\Windows\BlockShift.exe. Next: check Builds\auto_unity_status.txt, then work TaskBoard 'Auto next actions' with tools.
