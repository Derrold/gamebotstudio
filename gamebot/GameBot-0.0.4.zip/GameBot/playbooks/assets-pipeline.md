# Asset pipeline: Blender -> FBX/glTF -> Unity/Unreal
Sources: https://docs.blender.org/api/current/bpy.ops.export_scene.html · https://docs.unity3d.com/Manual/FBXImporter-Model.html · https://docs.unity3d.com/Manual/LevelOfDetail.html · https://dev.epicgames.com/documentation/en-us/unreal-engine/fbx-content-pipeline · https://docs.blender.org/manual/en/latest/addons/import_export/scene_gltf2.html

## Run Blender headless (this PC)
- Blender: the Blender path from config.json (auto-detected)
- Tool: run_blender_script(script_path=..., output_fbx=...) or run_powershell: & "<blender.exe>" -b -P script.py -- args
- Success = the output file exists and size > 10 KB; then read the Blender stdout for "FBX export" / errors. Never claim success without exists=True.

## Modelling rules
- Real-world scale: 1 Blender unit = 1 m. Apply transforms (Ctrl+A / bpy.ops.object.transform_apply(location=False, rotation=True, scale=True)) before export.
- Origin/pivot: guns at the grip or receiver centre; props at the base centre; doors at the hinge.
- Forward axis: Unity is +Z forward, Y up -> FBX export axis_forward='-Z', axis_up='Y', apply_scale_options='FBX_SCALE_UNITS' (or 'FBX_SCALE_ALL' if Unity shows 100x/0.01 scale). Unreal: X forward, Z up, cm units — use the Unreal FBX import 'Convert Scene' option.
- Triangles budget (rough): hero first-person weapon 10–40k tris, NPC/animal 15–60k, props 0.5–5k, with LODs.
- Naming: SM_ (static mesh), SK_ (skeletal), M_/MI_ (material/instance), T_<name>_BC/_N/_ORM, A_ (anim), UCX_<mesh> (Unreal custom convex collision), <mesh>_LOD0/_LOD1 (Unity auto-groups LODs on import).

## Export (bpy)
bpy.ops.export_scene.fbx(filepath=out, use_selection=True, apply_scale_options='FBX_SCALE_UNITS', axis_forward='-Z', axis_up='Y', mesh_smooth_type='FACE', add_leaf_bones=False, bake_anim=True, use_tspace=True)
- glTF/GLB: bpy.ops.export_scene.gltf(filepath=out.glb, export_format='GLB', export_apply=True) — good for web/interchange; Unity needs a glTF package (glTFast), Unreal has glTF importer plugin.

## Textures / PBR
- Metal/rough workflow: BaseColor (sRGB), Normal (linear, OpenGL Y+ for Unity, DirectX Y- for Unreal — flip green channel), packed masks: Unity URP Lit uses Metallic(R)+Smoothness(A); HDRP mask map = R metal, G AO, B detail, A smoothness; Unreal ORM = R AO, G roughness, B metal.
- Smoothness = 1 - roughness. Power-of-two sizes (512–4096). Texel density consistent across props.

## Collision
- Unity: simple BoxCollider/CapsuleCollider or MeshCollider(convex) on a low-poly proxy. Unreal: UCX_ prefixed convex hulls exported with the mesh, or auto-generate in the Static Mesh editor.

## Animation
- One armature, deform bones only, no leaf bones. Export each action as a separate clip (bake_anim_use_all_actions=True) or NLA strips. Unity: Rig tab -> Humanoid for people, Generic for animals/weapons; split clips in Animation tab; loop walk/run.

## Import settings to verify (Unity)
- Model tab: Scale Factor 1, Convert Units on, Read/Write off unless runtime mesh edits, Generate Colliders off (add your own).
- Materials tab: extract materials; convert to URP Lit (pink = wrong shader, see debug-fix-playbook.md).
- Check imported bounds: a rifle ~1 m long, a deer ~1.0 m at shoulder.

## Licensing
- Only original or CC0 / Unity Asset Store EULA / Fab (Unreal) assets. Log every third-party asset (URL, license, date) in CREDITS.md / ThirdPartyLicenses.md. No trademarked gun brands/logos.
