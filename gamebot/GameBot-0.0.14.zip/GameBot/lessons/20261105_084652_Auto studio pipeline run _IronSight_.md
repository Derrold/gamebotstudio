# Auto studio pipeline run (IronSight)

Tags: auto studio pipeline
Saved: 2026-11-05T08:46:52

run_auto_game_pipeline created 32 files under C:\Users\ExtremeHybrid\Documents\GameProjects\IronSight and UNITY 6000.6.5f1: background job started -> create IronSightUnity -> Assets/Scenes/Slice01.unity (grey-box, player, goal, HUD) -> Builds\Windows\IronSight.exe. . Next: check Builds\auto_unity_status.txt, then work TaskBoard 'Auto next actions' with tools.
