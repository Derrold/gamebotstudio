# Auto studio pipeline run (CascadeHop)

Tags: auto studio pipeline
Saved: 2026-11-17T04:01:38

run_auto_game_pipeline created 34 files under C:\Users\Derrold PC\Documents\GameProjects\CascadeHop and UNREAL 5.8: background job started -> CascadeHop.uproject (CascadeHop - Platformer game (Platforming gameplay)) from TP_ThirdPersonBP + Platforming variant -> R. Next: check Builds\auto_unity_status.txt, then work TaskBoard 'Auto next actions' with tools.
