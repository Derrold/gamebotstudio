# Unity AI Navigation NavMeshSurface Bake for Deer Flee AI

Tags: Unity AI Navigation NavMeshSurface Deer Flee
Saved: 2026-10-25T20:27:01

To bake a NavMeshSurface in Unity runtime for deer flee AI, follow the official documentation on dev.epicgames.com and docs.unity3d.com. Ensure to set appropriate agent parameters such as radius, height, step height, and slope limit specific to deer movement mechanics.
