# Ship: game build, installer, desktop icons

Action playbook for Game Bot. Run tools — do not dump tutorials to the user.

## 1) Make the game build

- Editor: `C:\Program Files\Unity\Hub\Editor\6000.6.5f1\Editor\Unity.exe`
- Content bake (weapons/scenes):  
- Player build: Editor script calling `BuildPipeline.BuildPlayer` → output under `Builds\Stage_<ver>` or project convention. Prefer existing Hunting-game stage scripts when present.
- **Safety:** never kill a running game; never touch player saves;
- Docs: https://docs.unity3d.com/Manual/EditorCommandLineArguments.html · https://docs.unity3d.com/ScriptReference/BuildPipeline.BuildPlayer.html

## 2) Installer

- Bump version everywhere, compile `.iss` → setup exe.
- Generic PC games: Inno Setup or NSIS, or zip + desktop shortcut for test builds.
- After install, verify desktop/start-menu shortcut targets the new build folder.

## 3) Put an icon on the desktop (.lnk)

PowerShell (WScript.Shell):

```powershell
$W = New-Object -ComObject WScript.Shell
$s = $W.CreateShortcut("$env:USERPROFILE\Desktop\My Game.lnk")
$s.TargetPath = "C:\Path\To\Game.exe"
$s.WorkingDirectory = "C:\Path\To"
$s.IconLocation = "C:\Path\To\icon.ico,0"
$s.Description = "My Game"
$s.Save()
```

Script: `ollama-web\scripts\make_desktop_shortcut.ps1`

## 4) Design an icon and apply it

1. Create art (Blender still / GenerateImage / paint) → save PNG (512×512 or 256×256, transparent OK).
2. Convert PNG → multi-size ICO: `python ollama-web\scripts\png_to_ico.py in.png out.ico`
3. Set shortcut `IconLocation` to that `.ico,0` (same as Game Bot devil icon at `ollama-web\icons\game-bot-devil.ico`).
4. Refresh desktop (F5) if Windows caches the old glyph.

## 5) Unreal (when installed)

- Package via Project Launcher or `RunUAT BuildCookRun`; ship packaged folder or installer wrapping `Binaries\Win64\*.exe`. Desktop `.lnk` same as above.

## Success checks

- [ ] Build folder contains runnable `.exe`
- [ ] Installer (if used) installs and uninstalls cleanly
- [ ] Desktop `.lnk` opens the game
- [ ] Custom `.ico` shows on the shortcut
