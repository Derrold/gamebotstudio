# Content pipeline automation
Sources: https://docs.blender.org/manual/en/latest/advanced/command_line/arguments.html | https://docs.unity3d.com/Manual/CommandLineArguments.html | https://docs.unity3d.com/ScriptReference/BuildPipeline.BuildPlayer.html | https://docs.unity3d.com/ScriptReference/AssetPostprocessor.html | https://docs.unity3d.com/Packages/com.unity.addressables@2.0/manual/index.html

## Blender batch
- blender -b file.blend --python export_fbx.py -- --out X.fbx  (Game Bot tool run_blender_script). Script: apply transforms, select collection, bpy.ops.export_scene.fbx(...). Loop over a folder for batch; verify output exists + size > 0.

## Unity batchmode
- Grep log for 'error CS', 'Build succeeded/failed'.
- AssetPostprocessor (Editor script) to enforce import settings: textures max size/compression by folder, models scale/animation type, audio load type.

## Addressables / AssetBundles (overview)
- Use when: DLC, big streaming worlds, patch size reduction, mod content. Mark assets Addressable, groups by region/DLC, build content in batch (AddressableAssetSettings.BuildPlayerContent). Otherwise keep Resources-free direct references.

## CI-ish locally
- Game Bot runs it step-by-step and reports.
