"""Game Bot: open a game's Unity project in the Unity Editor and fetch owned Asset Store packs inside it.

- open_project(): create the project if needed (hidden batchmode), then open it in the real Unity Editor (-projectPath,
  never batchmode) so the creator's Unity sign-in is used.
- start_fetch(): drop Assets/Editor/GameBotAssetFetch.cs + GameBotFetch/request.json in the project. The editor script
  reads My Assets with the signed-in account, downloads each owned pack Game Bot needs into the Asset Store cache
  (%APPDATA%\\Unity\\Asset Store-5.x) and imports it with AssetDatabase.ImportPackage(path, false).
  Status: <game>\\Builds\\asset_fetch_status.json (shown in the build bar).
- Only owned/free packs that are already in the creator's My Assets are downloaded. Nothing is ever bought.
"""
from __future__ import annotations

import json
import os
import re
import subprocess
import threading
import time
from datetime import datetime
from pathlib import Path

HERE = Path(__file__).resolve().parent
CS_NAME = "GameBotAssetFetch.cs"
NO_WINDOW = 0x08000000
WORK = HERE / "work"

OPEN_STEPS = ("Unity is opening your project. In Unity: Window > Package Manager > My Assets, "
              "then click Download and Import on each pack. Say rescan when done.")
PLACEHOLDER_OFFER = "Or say \"continue\" to continue with placeholders now and swap in packs later."

# ------------------------------------------------------------------ intent: open a game in Unity

_OPEN_RX = re.compile(
    r"\b(open|put|make|load|edit|launch|show|start|bring|move|send)\b[^.?!]{0,50}?\b(in|into|inside|with|on)\s+(the\s+)?unity(\s+editor)?\b"
    r"|\bopen\s+(the\s+|my\s+|this\s+|that\s+)?(unity\s+)?project\b"
    r"|\b(open|launch|start|run)\s+(the\s+)?unity(\s+editor)?\b"
    r"|\bedit\b[^.?!]{0,40}\bunity\b"
    r"|\b(make|create)\s+(a\s+|the\s+)?project\s+(in|for)\s+unity\b",
    re.I)
_NEW_WORD = re.compile(r"\bnew\s+(game|project)\b|\b(called|named|titled)\b", re.I)


def wants_open_unity(text: str) -> bool:
    t = (text or "").strip()
    if not t or len(t) > 160 or _NEW_WORD.search(t):
        return False
    if re.match(r"^\s*(how|why|what)\b", t, re.I) and not re.search(r"\bopen\b", t, re.I):
        return False
    return bool(_OPEN_RX.search(t))


def _projects() -> Path:
    try:
        import auto_studio
        return Path(auto_studio.GAME_PROJECTS)
    except Exception:
        return Path(os.environ.get("GAMEBOT_PROJECTS") or (Path.home() / "Documents" / "GameProjects"))


def _norm(s: str) -> str:
    return re.sub(r"[^a-z0-9]+", "", (s or "").lower())


def find_game(text: str = "", title: str | None = None) -> Path | None:
    """An existing game folder named in the text (or the given title). Apostrophes/spaces/case don't matter."""
    gp = _projects()
    if not gp.is_dir():
        return None
    games = [p for p in gp.iterdir() if p.is_dir() and not p.name.startswith((".", "_"))]
    if title:
        n = _norm(title)
        for p in games:
            if n and _norm(p.name) == n:
                return p
        return None
    low = _norm(text)
    words = {_norm(w) for w in re.findall(r"[A-Za-z0-9'_-]+", text or "")}
    best = None
    for p in games:
        n = _norm(p.name)
        if len(n) < 2:
            continue
        if n in words or (len(n) >= 4 and n in low):
            if best is None or len(n) > len(_norm(best.name)):
                best = p
    return best


def current_game() -> Path | None:
    try:
        import auto_studio
        cur = auto_studio.CURRENT
        if cur.exists():
            p = Path(cur.read_text(encoding="utf-8").strip())
            if p.is_dir():
                return p
    except Exception:
        pass
    gp = _projects()
    try:
        mark = gp / ".current"
        if mark.is_file():
            p = gp / mark.read_text(encoding="utf-8").strip()
            if p.is_dir():
                return p
    except Exception:
        pass
    return None


def project_dir(root: Path) -> Path:
    try:
        from auto_studio import unity_project_dir
        p = unity_project_dir(root)
        if p:
            return p
    except Exception:
        pass
    return root / f"{root.name}Unity"


def editor_open(proj: Path) -> bool:
    """Unity holds Temp\\UnityLockfile open while the project is open."""
    lf = proj / "Temp" / "UnityLockfile"
    if not lf.exists():
        return False
    try:
        with open(lf, "a"):
            return False
    except OSError:
        return True


# ------------------------------------------------------------------ launching (patched in tests)

LAUNCHED: list = []


def _launch(args: list, hidden: bool) -> object:
    LAUNCHED.append({"args": list(args), "hidden": hidden})
    if os.environ.get("GAMEBOT_SKIP_UNITY") == "1":
        return None
    if "-batchmode" in args:
        try:
            import gpu_guard
            gpu_guard.before_unity()
        except Exception:
            pass
    flags = 0x00000200 | (NO_WINDOW if hidden else 0)
    si = None
    if hidden and os.name == "nt":
        si = subprocess.STARTUPINFO()
        si.dwFlags |= subprocess.STARTF_USESHOWWINDOW
        si.wShowWindow = 0
    return subprocess.Popen(args, creationflags=flags if os.name == "nt" else 0, startupinfo=si, close_fds=True,
                            stdin=subprocess.DEVNULL, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)


def _unity():
    try:
        from auto_studio import find_unity
        return find_unity()
    except Exception:
        return None


def _template(unity, template) -> str:
    try:
        from auto_studio import _unity_template
        return _unity_template(unity, template) or ""
    except Exception:
        return ""


def install_script(proj: Path) -> Path:
    src = HERE / "unity_tools" / CS_NAME
    dst = proj / "Assets" / "Editor" / CS_NAME
    dst.parent.mkdir(parents=True, exist_ok=True)
    if src.is_file():
        data = src.read_bytes()
        if not dst.is_file() or dst.read_bytes() != data:
            dst.write_bytes(data)
    pend = proj.parent / "Builds" / "pending_fetch" / "request.json"
    if pend.is_file():
        (proj / "GameBotFetch").mkdir(parents=True, exist_ok=True)
        os.replace(pend, proj / "GameBotFetch" / "request.json")
    return dst


def _write_active(root: Path) -> None:
    try:
        WORK.mkdir(parents=True, exist_ok=True)
        (WORK / "asset_fetch_active.json").write_text(json.dumps({"root": str(root), "when": time.time()}), encoding="utf-8")
    except Exception:
        pass


def _create_then_open(root: Path, proj: Path, template: str | None, then_open: bool) -> None:
    unity = _unity()
    st = status_path(root)
    try:
        if not (proj / "ProjectSettings").is_dir():
            _note(root, "creating the Unity project (first time takes a few minutes)")
            args = [str(unity), "-batchmode", "-nographics", "-quit", "-createProject", str(proj),
                    "-logFile", str(root / "Builds" / "create.log")]
            tpl = _template(unity, template)
            if tpl and Path(tpl).exists():
                args += ["-cloneFromTemplate", tpl]
            p = _launch(args, hidden=True)
            if p is not None:
                p.wait(timeout=1800)
        if (proj / "Assets").is_dir() or os.environ.get("GAMEBOT_SKIP_UNITY") == "1":
            install_script(proj)
            register_hub(proj)
        if then_open:
            _note(root, "opening Unity")
            _launch([str(unity), "-projectPath", str(proj)], hidden=False)
    except Exception as e:
        _note(root, f"couldn't open Unity: {type(e).__name__}: {e}", state="failed")


def open_project(root: Path, template: str | None = None, wait_create: bool = False) -> str:
    """Open <game>\\<Name>Unity in the Unity Editor (GUI). Creates the project first if it doesn't exist."""
    root = Path(root)
    (root / "Builds").mkdir(parents=True, exist_ok=True)
    unity = _unity()
    if not unity:
        return ("Unity isn't installed on this PC. Open Unity Hub > Installs > Install Editor and pick a Unity 6 (6000.x) "
                "version, then say \"open in unity\" again.")
    proj = project_dir(root)
    try:
        from auto_studio import unity_job_running
        if unity_job_running(root):
            return (f"A Unity build for {root.name} is running right now, and Unity can't open the same project twice. "
                    "I'll open it when the build finishes - say \"open in unity\" again then.")
    except Exception:
        pass
    if editor_open(proj):
        install_script(proj)
        register_hub(proj)
        return f"{root.name} is already open in Unity ({proj})."
    _write_active(root)
    exists = (proj / "ProjectSettings").is_dir()
    if exists:
        install_script(proj)
        register_hub(proj)
        _launch([str(unity), "-projectPath", str(proj)], hidden=False)
        return f"Opening {root.name} in Unity: {proj}"
    if wait_create:
        _create_then_open(root, proj, template, True)
    else:
        threading.Thread(target=_create_then_open, args=(root, proj, template, True), daemon=True).start()
    return f"Creating the Unity project for {root.name} (hidden), then opening it in Unity: {proj}"


def open_reply(text: str, st: dict | None = None) -> str:
    """'open cod2 in unity' / 'make project in unity' / 'open project' / 'edit in unity'."""
    root = find_game(text)
    if root is None and st and st.get("title"):
        root = find_game(title=st.get("title")) or find_game(title=re.sub(r"[^A-Za-z0-9]", "", st.get("title") or ""))
    if root is None:
        root = current_game()
    if root is None:
        gp = _projects()
        names = sorted(p.name for p in gp.iterdir() if p.is_dir() and not p.name.startswith((".", "_"))) if gp.is_dir() else []
        if names:
            return "Which game should I open in Unity? You have: " + ", ".join(names[:12]) + ". Say \"open <name> in unity\"."
        return "You don't have a game yet. Say \"make a new game\" to start one."
    return open_project(root)


# ------------------------------------------------------------------ fetching owned packs inside the editor

def status_path(root: Path) -> Path:
    return Path(root) / "Builds" / "asset_fetch_status.json"


def read_status(root: Path | None) -> dict:
    if not root:
        return {}
    try:
        return json.loads(status_path(root).read_text(encoding="utf-8-sig"))
    except Exception:
        return {}


def _note(root: Path, step: str, state: str = "starting") -> None:
    try:
        d = read_status(root)
        d.update({"step": step, "state": state, "updated": datetime.now().isoformat(timespec="seconds")})
        d.setdefault("items", [])
        status_path(root).parent.mkdir(parents=True, exist_ok=True)
        status_path(root).write_text(json.dumps(d, indent=1), encoding="utf-8")
    except Exception:
        pass


def wants_from_plan(plan: dict) -> list[dict]:
    from asset_plan import NEEDS, EXTRA, unresolved
    out = []
    for m in unresolved(plan):
        spec = NEEDS.get(m["key"]) or EXTRA.get(m["key"])
        out.append({"key": m["key"], "label": m["label"], "pattern": spec[2] if spec else re.escape(m["label"])})
    return out


def write_request(root: Path, wants: list[dict], names: list[str] | None = None, mode: str = "watch",
                  quit_when_done: bool = False, watch_minutes: int = 45, import_into_project: bool = False) -> dict:
    """import_into_project=False: download into the Asset Store cache only; the build imports the packs itself
    (gb_kits, no scripts/scenes). Unity 6.6+ would otherwise stop at its "Missing signature" window for the creator."""
    proj = project_dir(root)
    # Never create files inside a project folder Unity hasn't made yet (-createProject wants it empty/new).
    d = proj / "GameBotFetch" if (proj / "ProjectSettings").is_dir() else Path(root) / "Builds" / "pending_fetch"
    d.mkdir(parents=True, exist_ok=True)
    req = {"id": int(time.time()), "mode": mode, "wants": wants, "names": list(names or []),
           "status": str(status_path(root)), "since": datetime.now().astimezone().isoformat(timespec="seconds"),
           "watch_minutes": watch_minutes, "import_into_project": import_into_project, "quit_when_done": quit_when_done,
           "open_my_assets_on_fail": True}
    (d / "request.json").write_text(json.dumps(req, indent=1), encoding="utf-8")
    return req


def start_fetch(root: Path, plan: dict | None = None, wants: list[dict] | None = None, template: str | None = None,
                names: list[str] | None = None) -> str:
    """Open the game's project in the signed-in Unity Editor and download+import the owned packs it needs."""
    root = Path(root)
    (root / "Builds").mkdir(parents=True, exist_ok=True)
    wants = wants if wants is not None else (wants_from_plan(plan) if plan else [])
    try:
        status_path(root).unlink()
    except Exception:
        pass
    _note(root, "starting Unity to fetch packs from My Assets")
    write_request(root, wants, names)
    return open_project(root, template)


def finish(root: Path, wait_s: int = 0) -> bool:
    """Ask a Game Bot-opened editor to close (so the batchmode build can use the project). True when closed."""
    proj = project_dir(root)
    if not editor_open(proj):
        return True
    st = read_status(root)
    if not st or not (proj / "GameBotFetch" / "request.json").is_file():
        return False  # the creator opened Unity themselves: never close their editor
    write_request(root, [], mode="finish")
    end = time.time() + wait_s
    while time.time() < end:
        if not editor_open(proj):
            return True
        time.sleep(2)
    return not editor_open(proj)


# ------------------------------------------------------------------ rescan helpers

def project_packages(root: Path) -> list[str]:
    """Pack names already inside the game's Unity project: Packages\\manifest.json deps, embedded Packages\\*,
    and top-level Assets\\<Pack> folders (Game Bot's own folders excluded)."""
    proj = project_dir(root)
    out: list[str] = []
    try:
        man = json.loads((proj / "Packages" / "manifest.json").read_text(encoding="utf-8"))
        for k in (man.get("dependencies") or {}):
            if not k.startswith("com.unity."):
                out.append(k)
    except Exception:
        pass
    try:
        for p in (proj / "Packages").iterdir():
            if p.is_dir():
                try:
                    out.append(json.loads((p / "package.json").read_text(encoding="utf-8")).get("displayName") or p.name)
                except Exception:
                    out.append(p.name)
    except Exception:
        pass
    skip = {"editor", "scripts", "art", "scenes", "settings", "resources", "plugins", "gamebotfetch", "streamingassets",
            "textmesh pro", "textmeshpro", "tutorialinfo", "samples", "gizmos", "materials", "prefabs"}
    try:
        for p in (proj / "Assets").iterdir():
            if p.is_dir() and p.name.lower() not in skip:
                out.append(p.name)
    except Exception:
        pass
    return out


def not_downloaded(root: Path | None, plan: dict) -> list[dict]:
    """Owned (My Assets) packs that match a missing need but aren't in the download cache yet."""
    st = read_status(root)
    if not st:
        return []
    wants = wants_from_plan(plan)
    rows = []
    seen = set()
    items = {i.get("id"): i for i in st.get("items") or []}
    for o in (st.get("owned") or []) + list(items.values()):
        oid = o.get("id")
        if oid in seen:
            continue
        it = items.get(oid, o)
        state = it.get("state") or ""
        if state in ("in_cache", "downloaded", "imported"):
            continue
        name = o.get("name") or ""
        hit = next((w for w in wants if w.get("pattern") and re.search(w["pattern"], name, re.I)), None)
        if hit is None and it.get("key") not in ("recent", "named"):
            continue
        seen.add(oid)
        rows.append({"name": name, "need": hit["label"] if hit else "", "state": state, "pct": it.get("pct") or 0,
                     "msg": it.get("msg") or ""})
    return rows


def not_downloaded_lines(rows: list[dict]) -> list[str]:
    out = []
    for r in rows:
        extra = ""
        if r["state"] in ("downloading", "queued"):
            extra = f" (downloading now, {int(100 * float(r['pct'] or 0))}%)"
        elif r["state"] == "importing":
            extra = " (importing now)"
        elif r["state"] == "failed":
            extra = f" ({r['msg'] or 'download failed'})"
        out.append(f"{r['name']} is in My Assets but not downloaded yet{extra}.")
    return out


# ------------------------------------------------------------------ build bar

def bar_state() -> dict | None:
    try:
        a = json.loads((WORK / "asset_fetch_active.json").read_text(encoding="utf-8"))
        root = Path(a["root"])
    except Exception:
        return None
    st = read_status(root)
    if not st:
        return None
    try:
        age = time.time() - datetime.fromisoformat(str(st.get("updated"))).timestamp()
    except Exception:
        age = 9999
    state = st.get("state") or ""
    items = st.get("items") or []
    busy = [i for i in items if i.get("state") in ("queued", "downloading", "importing")]
    if age > 600 or state in ("done", "done_with_errors", "failed") and not busy:
        return None
    if not busy and state not in ("starting",):
        return None
    total = max(1, len(items))
    done = sum(1 for i in items if i.get("state") in ("imported", "downloaded"))
    cur = busy[0] if busy else None
    frac = (done + (float(cur.get("pct") or 0) if cur else 0)) / total if items else 0
    if cur:
        verb = "Importing" if cur.get("state") == "importing" else "Downloading"
        detail = f"{verb} packs {done + 1}/{len(items)}: {cur.get('name')} {int(100 * float(cur.get('pct') or 0))}%"
    else:
        detail = st.get("step") or "Fetching packs from My Assets"
    return {"active": True, "state": "run", "step": "Downloading packs", "pct": int(5 + 60 * frac),
            "elapsed_s": 0, "detail": detail[:240], "project": root.name}


# ------------------------------------------------------------------ Unity Hub project list

_HUB_DONE: set = set()


def hub_projects_file() -> Path:
    app = os.environ.get("APPDATA") or str(Path.home() / "AppData" / "Roaming")
    return Path(app) / "UnityHub" / "projects-v1.json"


def _project_version(proj: Path) -> tuple[str, str]:
    try:
        t = (proj / "ProjectSettings" / "ProjectVersion.txt").read_text(encoding="utf-8", errors="ignore")
        v = re.search(r"m_EditorVersion:\s*(\S+)", t)
        c = re.search(r"m_EditorVersionWithRevision:\s*\S+\s*\(([0-9a-f]+)\)", t)
        return (v.group(1) if v else ""), (c.group(1) if c else "")
    except Exception:
        return "", ""


def register_hub(proj: Path, force: bool = False) -> str:
    """Add the project to Unity Hub's Projects list (projects-v1.json). Keeps every existing entry; one backup."""
    proj = Path(proj)
    key = str(proj)
    if not force and key.lower() in _HUB_DONE:
        return "already registered"
    if not (proj / "ProjectSettings").is_dir():
        return "no Unity project yet"
    f = hub_projects_file()
    try:
        data = json.loads(f.read_text(encoding="utf-8-sig")) if f.is_file() else {}
    except Exception as e:
        return f"Hub projects file unreadable ({type(e).__name__}) - left alone"
    if not isinstance(data, dict):
        return "Hub projects file has an unknown format - left alone"
    data.setdefault("schema_version", "v1")
    rows = data.setdefault("data", {})
    if not isinstance(rows, dict):
        return "Hub projects file has an unknown format - left alone"
    if any(str(k).lower() == key.lower() for k in rows):
        _HUB_DONE.add(key.lower())
        return "already in Unity Hub"
    ver, cs = _project_version(proj)
    rows[key] = {"title": proj.name, "lastModified": int(time.time() * 1000), "isCustomEditor": False, "path": key,
                 "containingFolderPath": str(proj.parent), "version": ver, "architecture": "x64", "changeset": cs,
                 "isFavorite": False, "cloudEnabled": False}
    try:
        f.parent.mkdir(parents=True, exist_ok=True)
        bak = f.with_name(f.name + ".gamebot.bak")
        if f.is_file() and not bak.exists():
            bak.write_bytes(f.read_bytes())
        tmp = f.with_name(f.name + ".gamebot.tmp")
        tmp.write_text(json.dumps(data, separators=(",", ":")), encoding="utf-8")
        os.replace(tmp, f)
    except Exception as e:
        return f"couldn't write the Hub projects file: {e}"
    _HUB_DONE.add(key.lower())
    return "added to Unity Hub"
