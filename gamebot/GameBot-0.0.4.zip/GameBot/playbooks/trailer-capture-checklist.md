# Trailer + screenshot capture
- Capture: Unity Recorder package (MovieRecorderSettings, 1920x1080 60 fps, MP4 H.264) driven by a scripted camera path (Timeline/Cinemachine dolly) so captures are repeatable in batch/PlayMode. OBS for live gameplay.
- Hide debug UI, dev overlays, FPS counters; use final-ish HUD or none.
- Steam rules: first 5 seconds show gameplay; 30-90 s; logo at end; no fake footage; age-appropriate.
- Screenshots: >=5 at 1920x1080, real gameplay, no text overlays. ScreenCapture.CaptureScreenshot with superSize for 4K source.
- Shot list in Docs\Store\trailer_shotlist.md: hook (0-5 s), core loop (5-30 s), variety (30-60 s), features + call to action (wishlist) + date.
- Music: CC0/owned only, logged in ATTRIBUTION.md. Export captions/subtitle file if VO.
- Upload to Steam/YouTube = human gate (public posting).
