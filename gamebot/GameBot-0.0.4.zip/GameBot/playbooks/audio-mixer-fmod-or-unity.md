﻿# Audio
Unity AudioMixer groups (Master/Music/SFX/Voice); ducking; pool SFX; FMOD/Wwise optional later. Mute when unfocused. Export Steam trailer audio separately.
