﻿"""Extract a Unity .unitypackage (gzip tar) into a Unity Assets folder."""
from __future__ import annotations
import io, re, tarfile, gzip
from pathlib import Path

def _safe_rel(rel: str) -> str:
    rel = rel.replace("\\", "/").split("\n")[0].split("\r")[0].strip().strip("\x00")
    # drop any trailing non-printable
    rel = "".join(ch for ch in rel if ch.isprintable())
    while "//" in rel:
        rel = rel.replace("//", "/")
    return rel.strip("/")

def extract_unitypackage(pkg: Path, dest_assets: Path, folder_name: str | None = None) -> dict:
    pkg = Path(pkg)
    dest_assets = Path(dest_assets)
    dest_assets.mkdir(parents=True, exist_ok=True)
    name = folder_name or re.sub(r"[^A-Za-z0-9_-]+", "_", pkg.stem)[:60]
    out_root = dest_assets / "Art" / "Imports" / name
    out_root.mkdir(parents=True, exist_ok=True)
    raw = pkg.read_bytes()
    try:
        tar_bytes = gzip.decompress(raw)
    except Exception:
        tar_bytes = raw
    tf = tarfile.open(fileobj=io.BytesIO(tar_bytes), mode="r:")
    members = {}
    for m in tf.getmembers():
        parts = m.name.strip("/").split("/")
        if len(parts) < 2:
            continue
        guid, kind = parts[0], "/".join(parts[1:])  # asset / asset.meta / pathname
        # normalize kind: first segment only for lookup
        kind0 = parts[1]
        members.setdefault(guid, {})[kind0] = m
        if len(parts) > 2:
            members[guid][kind] = m
    written = 0
    skipped = 0
    for guid, kinds in members.items():
        path_m = kinds.get("pathname")
        asset_m = kinds.get("asset")
        if not path_m or not asset_m:
            skipped += 1
            continue
        rel = _safe_rel(tf.extractfile(path_m).read().decode("utf-8", errors="replace"))
        if not rel:
            skipped += 1
            continue
        if not rel.lower().startswith("assets/"):
            rel = "Assets/Art/Imports/" + name + "/" + rel
        rel_under = rel[7:] if rel.lower().startswith("assets/") else rel
        # prevent path escape
        if ".." in rel_under.split("/"):
            skipped += 1
            continue
        low = rel_under.lower().replace("\\", "/")
        if "standard assets/effects" in low or "/imageeffects/" in low:
            skipped += 1
            continue
        target = dest_assets / rel_under
        try:
            target.parent.mkdir(parents=True, exist_ok=True)
            data = tf.extractfile(asset_m).read()
            target.write_bytes(data)
            meta_m = kinds.get("asset.meta")
            if meta_m is not None:
                Path(str(target) + ".meta").write_bytes(tf.extractfile(meta_m).read())
            written += 1
        except OSError:
            skipped += 1
            continue
    return {"ok": True, "files": written, "skipped": skipped, "folder": str(out_root)}

if __name__ == "__main__":
    import sys
    print(extract_unitypackage(Path(sys.argv[1]), Path(sys.argv[2])))
