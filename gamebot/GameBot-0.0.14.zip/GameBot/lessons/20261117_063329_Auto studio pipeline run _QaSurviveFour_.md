# Auto studio pipeline run (QaSurviveFour)

Tags: auto studio pipeline
Saved: 2026-11-17T06:33:29

run_auto_game_pipeline created 34 files under C:\Users\Derrold PC\Documents\GameProjects\QaSurviveFour and UNITY 6000.6.5f1: background job started -> create QaSurviveFourUnity -> Survival game (gameplay template: survival; menu, settings, achievements, owned genre k. Next: check Builds\auto_unity_status.txt, then work TaskBoard 'Auto next actions' with tools.
