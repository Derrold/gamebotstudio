# Auto studio pipeline run (AshHook)

Tags: auto studio pipeline
Saved: 2026-11-11T02:25:39

run_auto_game_pipeline created 33 files under C:\Users\ExtremeHybrid\Documents\GameProjects\AshHook and UNITY 6000.6.5f1: background job started -> create AshHookUnity -> Action game (gameplay template: platformer; menu, settings, achievements, owned assets) -> Bu. Next: check Builds\auto_unity_status.txt, then work TaskBoard 'Auto next actions' with tools.
