# Auto studio pipeline run (RiverKite)

Tags: auto studio pipeline
Saved: 2026-11-11T02:33:37

run_auto_game_pipeline created 33 files under C:\Users\ExtremeHybrid\Documents\GameProjects\RiverKite and UNITY 6000.6.5f1: background job started -> create RiverKiteUnity -> Adventure game (gameplay template: adventure; menu, settings, achievements, owned assets) -. Next: check Builds\auto_unity_status.txt, then work TaskBoard 'Auto next actions' with tools.
