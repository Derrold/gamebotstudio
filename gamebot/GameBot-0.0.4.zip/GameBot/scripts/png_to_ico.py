﻿"""Convert PNG to multi-size .ico for Windows shortcuts."""
from __future__ import annotations
import sys
from pathlib import Path

def main():
    if len(sys.argv) < 3:
        print("Usage: png_to_ico.py in.png out.ico")
        return 2
    src, dst = Path(sys.argv[1]), Path(sys.argv[2])
    try:
        from PIL import Image
    except ImportError:
        import subprocess
        subprocess.check_call([sys.executable, "-m", "pip", "install", "pillow", "-q"])
        from PIL import Image
    im = Image.open(src).convert("RGBA")
    sizes = [(16,16),(32,32),(48,48),(64,64),(128,128),(256,256)]
    icons = []
    for s in sizes:
        icons.append(im.resize(s, Image.Resampling.LANCZOS))
    icons[0].save(dst, format="ICO", sizes=[(i.width,i.height) for i in icons], append_images=icons[1:])
    print("ICO", dst, "bytes", dst.stat().st_size)
    return 0

if __name__ == "__main__":
    raise SystemExit(main())
