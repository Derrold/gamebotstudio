using UnityEngine;
/// <summary>Strategy capture point: units of one team inside the radius flip it; owned points pay income.</summary>
public class CapturePoint : MonoBehaviour
{
    public float radius = 6f; public int owner = -1; float prog; Renderer flag;
    void Start() { var f = transform.Find("Flag"); if (f) flag = f.GetComponent<Renderer>(); }
    void Update()
    {
        if (GameState.Won || GameState.Lost || PauseMenu.IsPaused || MainMenuUI.InMenu) return;
        int a = 0, b = 0; foreach (var u in GbCombat.All) { if (u == null || u.Dead || u.Tr == null || (u is RtsUnit r && r.Structure)) continue; if (Vector3.Distance(u.Tr.position, transform.position) < radius) { if (u.Team == 0) a++; else if (u.Team == 1) b++; } }
        float d = (a > 0 && b == 0) ? 1 : (b > 0 && a == 0) ? -1 : 0; prog = Mathf.Clamp(prog + d * Time.deltaTime / 4f, -1, 1);
        int was = owner; if (prog >= 1) owner = 0; else if (prog <= -1) owner = 1; else if (Mathf.Abs(prog) < 0.05f) owner = -1;
        if (was != owner) { if (owner == 0) { AchievementSystem.Unlock("point_first"); GameHUD.Flash(name + " captured!"); } if (owner == 1) GameHUD.Flash(name + " lost to the enemy!"); }
        if (flag) flag.material.color = owner == 0 ? new Color(0.2f, 0.6f, 1f) : owner == 1 ? new Color(1f, 0.25f, 0.2f) : Color.Lerp(Color.white, prog > 0 ? Color.cyan : Color.red, Mathf.Abs(prog));
    }
    public static int Owned(int team) { int n = 0; foreach (var c in FindObjectsByType<CapturePoint>(FindObjectsSortMode.None)) if (c.owner == team) n++; return n; }
}
