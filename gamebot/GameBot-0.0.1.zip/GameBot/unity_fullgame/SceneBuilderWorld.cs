using System.Collections.Generic;
using System.IO;
using System.Text.RegularExpressions;
using UnityEditor;
using UnityEditor.Animations;
using UnityEngine;

// Game Bot "real world" builder: textured terrain + grass, owned trees, buildings, cover, rigged animated enemies,
// forward-facing first-person gun and sound, all from the packs mapped in ../Tools/asset_map.json (gb_kits.py).
public static partial class SceneBuilder
{
    [System.Serializable] public class MapEntry { public string need = ""; public string[] folders = new string[0]; }
    [System.Serializable] public class BlenderEntry { public string key = "", path = "", size = "prop"; }
    [System.Serializable] public class AssetMap { public MapEntry[] entries = new MapEntry[0]; public BlenderEntry[] blender = new BlenderEntry[0]; public string[] placeholders = new string[0]; }
    static AssetMap _amap; static bool _amapLoaded;
    static AssetMap AMap()
    {
        if (_amapLoaded) return _amap; _amapLoaded = true;
        try { if (File.Exists("../Tools/asset_map.json")) _amap = JsonUtility.FromJson<AssetMap>(File.ReadAllText("../Tools/asset_map.json")); }
        catch (System.Exception e) { Debug.LogWarning("ASSET_MAP_FAIL " + e.Message); }
        if (_amap == null) _amap = new AssetMap();
        Debug.Log("ASSET_MAP entries=" + _amap.entries.Length + " blender=" + _amap.blender.Length);
        return _amap;
    }
    static string[] FoldersFor(params string[] needs)
    {
        var l = new List<string>();
        foreach (var e in AMap().entries) foreach (var n in needs)
            if (e.need == n) foreach (var f in e.folders) if (AssetDatabase.IsValidFolder(f) && !l.Contains(f)) l.Add(f);
        return l.ToArray();
    }
    static List<string> PathsIn(string filter, params string[] needs)
    {
        var res = new List<string>(); var f = FoldersFor(needs); if (f.Length == 0) return res;
        foreach (var g in AssetDatabase.FindAssets(filter, f)) { var p = AssetDatabase.GUIDToAssetPath(g); if (!res.Contains(p)) res.Add(p); }
        res.Sort(System.StringComparer.OrdinalIgnoreCase); return res;
    }
    static readonly Regex BadPf = new Regex("demo|example|camera|canvas|projector|setup|scene|controller|light|lod_?\\d|billboard|impostor|collider|particle|fx_|vfx|_ui|icon|spawn", RegexOptions.IgnoreCase);
    static List<GameObject> PrefabsIn(Regex want, Regex none, params string[] needs)
    {
        var res = new List<GameObject>();
        var paths = PathsIn("t:Prefab", needs); if (paths.Count == 0) paths = PathsIn("t:Model", needs); else paths.AddRange(PathsIn("t:Model", needs).FindAll(p => !paths.Exists(q => Path.GetFileNameWithoutExtension(q) == Path.GetFileNameWithoutExtension(p))));
        foreach (var p in paths)
        {
            var file = Path.GetFileNameWithoutExtension(p).ToLower(); var low = p.ToLower();
            if (BadPf.IsMatch(file) || low.Contains("/editor/") || low.Contains("/scenes/") || low.Contains("/standard assets/") || low.Contains("tessellation") || Regex.IsMatch(low, "/animations?/|/animationclips?/|/demo/")) continue;
            if (want != null && !want.IsMatch(low)) continue; if (none != null && none.IsMatch(file)) continue;
            var pf = AssetDatabase.LoadAssetAtPath<GameObject>(p); if (pf == null || pf.GetComponentsInChildren<Renderer>(true).Length == 0) continue;
            if (pf.GetComponentsInChildren<Terrain>(true).Length > 0) continue;
            res.Add(pf);
        }
        return res;
    }
    // Tree Creator prefabs (e.g. Nature Starter Kit) ship with an empty MeshFilter + editor-only shaders: give them their baked mesh and plain shaders.
    static Texture SavedTex(Material m, string prop)
    {
        if (m.HasProperty(prop) && m.GetTexture(prop)) return m.GetTexture(prop);
        var so = new SerializedObject(m); var envs = so.FindProperty("m_SavedProperties.m_TexEnvs");
        if (envs != null) for (int i = 0; i < envs.arraySize; i++) { var e = envs.GetArrayElementAtIndex(i); if (e.FindPropertyRelative("first").stringValue == prop) return e.FindPropertyRelative("second.m_Texture").objectReferenceValue as Texture; }
        return null;
    }
    static void FixTreeCreator(GameObject go, string path)
    {
        if (go == null) return; bool tc = false;
        foreach (var t in go.GetComponentsInChildren<Tree>(true)) { tc = true; Object.DestroyImmediate(t); }
        Mesh baked = null;
        foreach (var mf in go.GetComponentsInChildren<MeshFilter>(true))
            if (mf.sharedMesh == null && !string.IsNullOrEmpty(path))
            {
                if (baked == null) foreach (var o in AssetDatabase.LoadAllAssetsAtPath(path)) if (o is Mesh m && m.vertexCount > 0) { baked = m; break; }
                if (baked != null) { mf.sharedMesh = baked; tc = true; }
            }
        Material bark = null, leafM = null;
        if (tc && !string.IsNullOrEmpty(path)) foreach (var o in AssetDatabase.LoadAllAssetsAtPath(path)) if (o is Material mo) { if (Regex.IsMatch(mo.name.ToLower(), "leaf|leaves")) leafM = mo; else bark = bark ?? mo; }
        foreach (var r in go.GetComponentsInChildren<Renderer>(true))
        {
            var mats = r.sharedMaterials; bool ch = false;
            if (tc && (bark || leafM))
            {
                var mf0 = r.GetComponent<MeshFilter>(); int sub = mf0 && mf0.sharedMesh ? mf0.sharedMesh.subMeshCount : mats.Length;
                bool empty = mats.Length < sub; foreach (var mm in mats) if (mm == null) empty = true;
                if (empty) { mats = new Material[Mathf.Max(sub, 1)]; for (int k = 0; k < mats.Length; k++) mats[k] = k == 0 ? (bark ?? leafM) : (leafM ?? bark); ch = true; }
            }
            for (int i = 0; i < mats.Length; i++)
            {
                var m = mats[i]; if (m == null || m.shader == null) continue; var sn = m.shader.name;
                if (!(sn.Contains("Tree Creator") || sn.Contains("Tree Soft Occlusion") || (tc && (sn.Contains("InternalError") || !m.shader.isSupported || sn.StartsWith("Hidden/"))))) continue;
                bool leaf = Regex.IsMatch((m.name + sn).ToLower(), "leaf|leaves|frond|needle");
                var mt = SavedTex(m, "_MainTex");
                var urpLit = UnityEngine.Rendering.GraphicsSettings.currentRenderPipeline != null ? Shader.Find("Universal Render Pipeline/Lit") : null;
                Material nm;
                if (urpLit)
                {   // URP project: legacy shaders render magenta/purple here, so go straight to URP Lit (alpha-clipped, two-sided leaves)
                    nm = new Material(urpLit) { name = m.name + "_gb" }; if (mt) nm.SetTexture("_BaseMap", mt); nm.SetColor("_BaseColor", Color.white); nm.SetFloat("_Smoothness", 0.05f);
                    if (leaf) { nm.SetFloat("_AlphaClip", 1f); nm.SetFloat("_Cutoff", 0.3f); nm.EnableKeyword("_ALPHATEST_ON"); nm.SetFloat("_Cull", 0f); nm.renderQueue = 2450; }
                }
                else
                {
                    nm = new Material(Shader.Find(leaf ? "Legacy Shaders/Transparent/Cutout/Diffuse" : "Legacy Shaders/Diffuse")) { name = m.name + "_gb" };
                    if (mt) nm.mainTexture = mt; if (leaf) nm.SetFloat("_Cutoff", 0.3f); nm.color = Color.white;
                }
                mats[i] = nm; ch = true;
            }
            if (ch) r.sharedMaterials = mats;
        }
    }
    static Vector3 NativeSize(GameObject pf)
    {
        var tmp = (GameObject)Object.Instantiate(pf); FixTreeCreator(tmp, AssetDatabase.GetAssetPath(pf)); tmp.transform.position = Vector3.zero; tmp.transform.rotation = Quaternion.identity;
        var b = Bounds(tmp); Object.DestroyImmediate(tmp); return b.size;
    }
    static GameObject BlenderModel(string key)
    {
        foreach (var b in AMap().blender) if (b.key == key && !string.IsNullOrEmpty(b.path)) { var g = AssetDatabase.LoadAssetAtPath<GameObject>(b.path); if (g) { Debug.Log("BLENDER_MODEL_USED " + key + " " + b.path); return g; } }
        return null;
    }
    static Terrain _terr;
    static float GroundY(Vector3 p) => _terr ? _terr.SampleHeight(p) + _terr.transform.position.y : 0f;
    static Vector3 OnGround(float x, float z) { var p = new Vector3(x, 0, z); p.y = GroundY(p); return p; }
    static readonly List<Bounds> _blocked = new List<Bounds>();
    static bool Free(Vector3 p, float r) { foreach (var b in _blocked) { var bb = b; bb.Expand(r * 2f); if (bb.Contains(new Vector3(p.x, bb.center.y, p.z))) return false; } return true; }
    static void Block(GameObject go) { _blocked.Add(Bounds(go)); }

    // ------------------------------------------------------------------ terrain
    static Texture2D PickTex(List<string> paths, string want)
    {
        var rx = new Regex(want, RegexOptions.IgnoreCase); var bad = new Regex("(_n|_s|_h|_r|_m|_ao|_mask|normal|spec|rough|height|metal|gloss|occlusion|_disp|bump|emiss)(\\.|$)|normal|_nrm", RegexOptions.IgnoreCase);
        string best = null; int bs = -1;
        foreach (var p in paths)
        {
            var f = Path.GetFileNameWithoutExtension(p).ToLower(); if (!rx.IsMatch(f) || bad.IsMatch(f + ".")) continue;
            int s = 1; if (Regex.IsMatch(f, "(_d|_albedo|albedo|diffuse|_col|color|basecolor)$")) s += 3; if (f.Contains("leaf") || f.Contains("leaves")) s -= 2; if (f.Contains("detail")) s += 5;
            if (s > bs) { bs = s; best = p; }
        }
        return best == null ? null : AssetDatabase.LoadAssetAtPath<Texture2D>(best);
    }
    static Terrain WorldTerrain(float S, float arena)
    {
        Directory.CreateDirectory("Assets/GameBot/Terrain");
        var tex = PathsIn("t:Texture2D", "ground");
        var all = new List<string>(tex);
        var green = tex.FindAll(t => !Regex.IsMatch(Path.GetFileName(t).ToLower(), "frozen|snow|ice|dry|dead|burn|autumn|desert|lava|mars"));
        var grassT = PickTex(green, "grass|moss|meadow|lawn") ?? PickTex(tex, "grass|moss|meadow") ?? PickTex(all, "ground|soil|dirt");
        var dirtT = PickTex(tex, "soil|dirt|gravel|mud|dry|path|sand");
        var rockT = PickTex(tex, "rock|stone|cliff");
        var layers = new List<TerrainLayer>();
        int li = 0;
        foreach (var t in new[] { grassT, dirtT, rockT })
        {
            if (t == null) continue;
            var tl = new TerrainLayer { diffuseTexture = t, tileSize = new Vector2(7, 7) };
            var lp = "Assets/GameBot/Terrain/Layer_" + (li++) + ".terrainlayer"; AssetDatabase.DeleteAsset(lp); AssetDatabase.CreateAsset(tl, lp); layers.Add(tl);
            Debug.Log("TERRAIN_LAYER " + AssetDatabase.GetAssetPath(t));
        }
        if (layers.Count == 0)
        {
            var any = PickTex(new List<string>(System.Array.ConvertAll(AssetDatabase.FindAssets("t:Texture2D grass"), AssetDatabase.GUIDToAssetPath)), "grass");
            if (any) { var tl = new TerrainLayer { diffuseTexture = any, tileSize = new Vector2(7, 7) }; AssetDatabase.DeleteAsset("Assets/GameBot/Terrain/Layer_0.terrainlayer"); AssetDatabase.CreateAsset(tl, "Assets/GameBot/Terrain/Layer_0.terrainlayer"); layers.Add(tl); Debug.Log("TERRAIN_LAYER (any) " + AssetDatabase.GetAssetPath(any)); }
            else Debug.LogWarning("TERRAIN_NO_GROUND_TEXTURE (no ground pack)");
        }
        const int R = 257; float H = 40f;
        var td = new TerrainData(); td.heightmapResolution = R; td.size = new Vector3(S, H, S);
        var h = new float[R, R]; float ox = 13.7f, oz = 71.3f;
        for (int z = 0; z < R; z++) for (int x = 0; x < R; x++)
        {
            float wx = (x / (float)(R - 1) - 0.5f) * S, wz = (z / (float)(R - 1) - 0.5f) * S; float d = Mathf.Sqrt(wx * wx + wz * wz);
            float small = Mathf.PerlinNoise(ox + wx * 0.045f, oz + wz * 0.045f) * 1.1f / H;
            float hill = Mathf.SmoothStep(0f, 1f, Mathf.InverseLerp(arena, S * 0.5f, d)) * (0.25f + 0.45f * Mathf.PerlinNoise(ox + wx * 0.02f, oz + wz * 0.02f));
            h[z, x] = 0.01f + small + hill;
        }
        td.SetHeights(0, 0, h);
        if (layers.Count > 0)
        {
            td.terrainLayers = layers.ToArray(); int A = 256; td.alphamapResolution = A; var a = new float[A, A, layers.Count];
            for (int z = 0; z < A; z++) for (int x = 0; x < A; x++)
            {
                float nx = x / (float)(A - 1), nz = z / (float)(A - 1); float steep = td.GetSteepness(nx, nz);
                float n = Mathf.PerlinNoise(nx * 18f + 3f, nz * 18f + 9f);
                float wr = layers.Count > 2 ? Mathf.InverseLerp(18f, 32f, steep) : 0f;
                float wd = layers.Count > 1 ? Mathf.InverseLerp(0.58f, 0.75f, n) * (1 - wr) : 0f;
                float wg = Mathf.Max(0f, 1f - wr - wd);
                a[z, x, 0] = wg; if (layers.Count > 1) a[z, x, 1] = wd; if (layers.Count > 2) a[z, x, 2] = wr;
            }
            td.SetAlphamaps(0, 0, a);
        }
        // grass details from the owned grass pack
        var gtex = PathsIn("t:Texture2D", "grass");
        var gd = PickTex(gtex.FindAll(p => Regex.IsMatch(Path.GetFileName(p).ToLower(), "grass|detail|fern|weed")), "grass|detail|weed");
        int D = 256; td.SetDetailResolution(D, 16);
        if (gd != null)
        {
            var dp = new DetailPrototype { prototypeTexture = gd, renderMode = DetailRenderMode.GrassBillboard, usePrototypeMesh = false, useInstancing = false,
                minWidth = 0.6f, maxWidth = 1.1f, minHeight = 0.45f, maxHeight = 0.95f, healthyColor = new Color(0.75f, 0.85f, 0.6f), dryColor = new Color(0.7f, 0.65f, 0.45f), noiseSpread = 0.3f };
            td.detailPrototypes = new[] { dp }; var dm = new int[D, D];
            for (int z = 0; z < D; z++) for (int x = 0; x < D; x++) { float n = Mathf.PerlinNoise(x * 0.09f + 5f, z * 0.09f + 1f); dm[z, x] = n > 0.38f ? (n > 0.6f ? 7 : 4) : 0; }
            td.SetDetailLayer(0, 0, 0, dm); Debug.Log("TERRAIN_GRASS " + AssetDatabase.GetAssetPath(gd));
        }
        else Debug.LogWarning("TERRAIN_NO_GRASS_TEXTURE");
        AssetDatabase.DeleteAsset("Assets/GameBot/Terrain/World.asset"); AssetDatabase.CreateAsset(td, "Assets/GameBot/Terrain/World.asset");
        var go = Terrain.CreateTerrainGameObject(td); go.name = "Terrain"; go.transform.position = new Vector3(-S / 2f, 0, -S / 2f);
        var terr = go.GetComponent<Terrain>(); terr.detailObjectDistance = 90f; terr.detailObjectDensity = 1f; terr.treeDistance = 400f; terr.heightmapPixelError = 4f;
        var urp = Shader.Find("Universal Render Pipeline/Terrain/Lit");
        if (urp) { var m = new Material(urp); AssetDatabase.DeleteAsset("Assets/GameBot/Terrain/TerrainURP.mat"); AssetDatabase.CreateAsset(m, "Assets/GameBot/Terrain/TerrainURP.mat"); terr.materialTemplate = m; }
        _terr = terr; Terrain.SetConnectivityDirty();
        var old = GameObject.Find("Ground"); if (old) Object.DestroyImmediate(old);
        Debug.Log("TERRAIN_OK size=" + S + " layers=" + layers.Count + " grass=" + (gd != null));
        return terr;
    }

    // ------------------------------------------------------------------ buildings / cover / trees / extras
    static readonly Regex NotBuilding = new Regex("door|window|wall|floor|roof|stair|frame|lamp|light|fence|interior|furniture|chair|table|bed|sofa|shelf|plant|tree|rock|car|prop|glass|pipe|sign|beam|column|pillar|tile|plank|rail|bath|pool|kitchen|toilet|wardrobe|sink|tub|shower|desk|cabinet|carpet|rug|curtain|bench|stove|fridge|closet|mirror|towel", RegexOptions.IgnoreCase);
    static int WorldBuildings(Transform root, float arena)
    {
        var pool = PrefabsIn(null, NotBuilding, "buildings", "extra:house");
        pool.RemoveAll(p => Regex.IsMatch(AssetDatabase.GetAssetPath(p).ToLower(), "interior|furniture|/props?/|bathroom|bedroom|kitchen|livingroom|dining|chandelier|bookshel|bookself|/lamps?/|/bed/|sofa|couch|chair|table|wardrobe"));
        pool.RemoveAll(p => { var s = NativeSize(p); float mx = Mathf.Max(s.x, s.y, s.z), mn = Mathf.Min(s.x, s.z); return mx < 0.01f || mn < mx * 0.25f; });
        pool.Sort((a, b) => { var sa = NativeSize(a); var sb = NativeSize(b); return (sb.x * sb.y * sb.z).CompareTo(sa.x * sa.y * sa.z); });
        if (pool.Count > 6) pool = pool.GetRange(0, 6);
        var bl = BlenderModel("house") ?? BlenderModel("buildings"); if (bl) pool.Insert(0, bl);
        int n = 0; var rnd = new System.Random(11);
        Vector3[] spots = { new Vector3(-20, 0, 8), new Vector3(20, 0, 8), new Vector3(-20, 0, 28), new Vector3(20, 0, 28), new Vector3(-38, 0, -12), new Vector3(38, 0, -10), new Vector3(0, 0, 44), new Vector3(-36, 0, 40), new Vector3(36, 0, 42) };
        if (pool.Count == 0) { Debug.LogWarning("WORLD_NO_BUILDINGS (no building pack mapped)"); return 0; }
        for (int i = 0; i < spots.Length; i++)
        {
            var pf = pool[i % pool.Count]; var p = OnGround(spots[i].x, spots[i].z);
            var go = Spawn(pf, root, true); go.name = "Building_" + i;
            float yaw = spots[i].x < 0 ? 90 : -90; if (Mathf.Abs(spots[i].x) < 5) yaw = 180;
            FitTo(go, p + Vector3.up * 4.5f, new Vector3(12f, 9f, 11f), true, yaw);
            foreach (var mf in go.GetComponentsInChildren<MeshFilter>(true)) if (mf.sharedMesh && !mf.GetComponent<Collider>()) mf.gameObject.AddComponent<MeshCollider>().sharedMesh = mf.sharedMesh;
            Block(go); n++; _dressCount++; _dressUsed.Add(AssetDatabase.GetAssetPath(pf));
        }
        Debug.Log("WORLD_BUILDINGS " + n + " from " + string.Join(" | ", pool.ConvertAll(AssetDatabase.GetAssetPath)));
        return n;
    }
    static int WorldTrees(Transform root, float S, float arena)
    {
        var pool = PrefabsIn(null, new Regex("leaf|leaves|branch|stump|log|grass|flower|rock|bark|trunk_only|bush|shrub|plant|fern|sphere|cube|billboard"), "trees");
        pool.RemoveAll(p => { var s = NativeSize(p); return s.y < Mathf.Max(s.x, s.z) * 0.7f; });
        var bl = BlenderModel("trees") ?? BlenderModel("tree"); if (bl) pool.Add(bl);
        if (pool.Count == 0) { Debug.LogWarning("WORLD_NO_TREES (no tree pack mapped)"); return 0; }
        var rnd = new System.Random(17); int n = 0, tries = 0;
        while (n < 170 && tries++ < 2000)
        {
            float a = (float)rnd.NextDouble() * Mathf.PI * 2f; bool inside = n < 16;
            float d = inside ? Mathf.Lerp(14f, arena - 4f, (float)rnd.NextDouble()) : Mathf.Lerp(arena - 6f, S * 0.47f, (float)rnd.NextDouble());
            var p = OnGround(Mathf.Cos(a) * d, Mathf.Sin(a) * d);
            if (p.z < -30 && Mathf.Abs(p.x) < 16) continue; if (!Free(p, 2.5f)) continue;
            var pf = pool[rnd.Next(pool.Count)]; var go = Spawn(pf, root, true); go.name = "Tree_" + n; if (n == 0) foreach (var rr in go.GetComponentsInChildren<Renderer>()) foreach (var mm in rr.sharedMaterials) if (mm) Debug.Log("TREE_MAT " + mm.name + " shader=" + mm.shader.name + " tex=" + (mm.mainTexture ? mm.mainTexture.name : "none"));
            float ht = Mathf.Lerp(7f, 13f, (float)rnd.NextDouble()); FitTo(go, p + Vector3.up * ht / 2f, new Vector3(ht, ht, ht), true, rnd.Next(360));
            go.transform.position += Vector3.down * 0.15f;
            if (!go.GetComponentInChildren<Collider>()) { var c = go.AddComponent<CapsuleCollider>(); var ls = go.transform.lossyScale.y; c.radius = 0.35f / Mathf.Max(ls, 1e-3f); c.height = 4f / Mathf.Max(ls, 1e-3f); c.center = new Vector3(0, c.height / 2f, 0); }
            n++; _dressCount++; _dressUsed.Add(AssetDatabase.GetAssetPath(pf));
        }
        // bushes / plants from the grass pack
        var bush = PrefabsIn(null, new Regex("tree|rock|demo"), "grass"); int nb = 0;
        if (bush.Count > 0) for (int i = 0; i < 90; i++)
        {
            float a = (float)rnd.NextDouble() * Mathf.PI * 2f, d = Mathf.Lerp(8f, S * 0.45f, (float)rnd.NextDouble()); var p = OnGround(Mathf.Cos(a) * d, Mathf.Sin(a) * d);
            if (!Free(p, 1f)) continue; var go = Spawn(bush[rnd.Next(bush.Count)], root, false); float ht = Mathf.Lerp(0.7f, 1.6f, (float)rnd.NextDouble()); FitTo(go, p + Vector3.up * ht / 2f, new Vector3(ht * 2, ht, ht * 2), true, rnd.Next(360)); nb++;
        }
        Debug.Log("WORLD_TREES " + n + " bushes=" + nb + " from " + string.Join(" | ", pool.ConvertAll(AssetDatabase.GetAssetPath)));
        return n;
    }
    static List<GameObject> _coverPool;
    static List<GameObject> CoverPool()
    {
        if (_coverPool != null) return _coverPool;
        _coverPool = PrefabsIn(null, new Regex("shelf_?part|screw|bolt|nail|hook|tiny|decal|sign_|poster|paper|bottle|can_|cup|pen|book"), "cover");
        _coverPool.RemoveAll(p => { var s = NativeSize(p); return Mathf.Max(s.x, s.y, s.z) < 0.001f; });
        return _coverPool;
    }
    static int WorldCover(Transform root, float arena)
    {
        var pool = CoverPool(); if (pool.Count == 0) { Debug.LogWarning("WORLD_NO_COVER (no props pack mapped)"); return 0; }
        var rnd = new System.Random(23); int n = 0, tries = 0;
        while (n < 34 && tries++ < 600)
        {
            float x = rnd.Next(-(int)arena + 6, (int)arena - 6), z = rnd.Next(-34, (int)arena - 6); if (Mathf.Abs(x) < 4 && z < -30) continue;
            var p = OnGround(x, z); if (!Free(p, 1.2f)) continue;
            var pf = pool[rnd.Next(pool.Count)]; var go = Spawn(pf, root, true); go.name = "Cover_" + n;
            float ht = Mathf.Lerp(1.0f, 1.6f, (float)rnd.NextDouble()); FitTo(go, p + Vector3.up * ht / 2f, new Vector3(ht * 2.2f, ht, ht * 2.2f), true, rnd.Next(360));
            if (!go.GetComponentInChildren<Collider>()) { var bb = Bounds(go); var bc = go.AddComponent<BoxCollider>(); bc.center = go.transform.InverseTransformPoint(bb.center); var ls = go.transform.lossyScale; bc.size = new Vector3(bb.size.x / Mathf.Max(ls.x, 1e-3f), bb.size.y / Mathf.Max(ls.y, 1e-3f), bb.size.z / Mathf.Max(ls.z, 1e-3f)); }
            Block(go); n++; _dressCount++; _dressUsed.Add(AssetDatabase.GetAssetPath(pf));
        }
        Debug.Log("WORLD_COVER " + n);
        return n;
    }
    static readonly Dictionary<string, float> SizeOf = new Dictionary<string, float> { { "building", 9f }, { "car", 4.5f }, { "big", 16f }, { "creature", 3f }, { "humanoid", 1.8f }, { "prop", 1.2f } };
    static int WorldExtras(Transform root, float arena)
    {
        int n = 0; var rnd = new System.Random(29);
        foreach (var e in AMap().entries)
        {
            if (!e.need.StartsWith("extra:") || e.need == "extra:house" || e.need == "extra:soldier" || e.need == "extra:zombie" || e.need == "extra:robot") continue;
            var pool = PrefabsIn(null, null, e.need); if (pool.Count == 0) continue;
            for (int i = 0; i < 3; i++) { var p = OnGround(rnd.Next(-(int)arena, (int)arena), rnd.Next(-20, (int)arena)); if (!Free(p, 3f)) continue; var go = Spawn(pool[i % pool.Count], root, true); go.name = "Extra_" + e.need.Substring(6) + "_" + i; FitTo(go, p + Vector3.up * 2f, new Vector3(5f, 4f, 5f), true, rnd.Next(360)); Block(go); n++; }
        }
        foreach (var b in AMap().blender)
        {
            if (b.key == "house" || b.key == "trees" || b.key == "tree" || b.key == "buildings") continue;
            var pf = AssetDatabase.LoadAssetAtPath<GameObject>(b.path); if (!pf) { Debug.LogWarning("BLENDER_MODEL_MISSING " + b.path); continue; }
            float sz = SizeOf.ContainsKey(b.size) ? SizeOf[b.size] : 1.5f;
            int want = sz >= 8f ? 1 : 3, placed = 0;
            for (int i = 0; i < 60 && placed < want; i++) { Vector3 p; if (sz >= 8f) { float a = Mathf.Lerp(0.15f, 0.85f, (float)rnd.NextDouble()) * Mathf.PI, d = arena - sz * 0.6f; p = OnGround(Mathf.Cos(a) * d, Mathf.Sin(a) * d); } else p = OnGround(rnd.Next(-(int)arena + 8, (int)arena - 8), rnd.Next(-10, (int)arena - 8)); if (!Free(p, sz * (i < 30 ? 0.5f : 0.2f))) continue; placed++; var go = Spawn(pf, root, true); go.name = "Blender_" + b.key + "_" + i; FitTo(go, p + Vector3.up * sz / 2f, new Vector3(sz * 1.4f, sz, sz * 1.4f), true, rnd.Next(360)); foreach (var mf in go.GetComponentsInChildren<MeshFilter>()) if (!mf.GetComponent<Collider>()) mf.gameObject.AddComponent<MeshCollider>().sharedMesh = mf.sharedMesh; Block(go); n++; }
            Debug.Log((placed > 0 ? "BLENDER_MODEL_USED " : "BLENDER_MODEL_NOT_PLACED ") + b.key + " x" + placed + " " + b.path);
        }
        Debug.Log("WORLD_EXTRAS " + n);
        return n;
    }
    static void WorldBounds(float half)
    {
        var b = new GameObject("WorldBounds").transform;
        for (int i = 0; i < 4; i++)
        {
            var w = new GameObject("Bound_" + i); w.transform.SetParent(b, false); var c = w.AddComponent<BoxCollider>();
            bool x = i < 2; float s = i % 2 == 0 ? 1 : -1; w.transform.position = x ? new Vector3(s * half, 10, 0) : new Vector3(0, 10, s * half); c.size = x ? new Vector3(1, 40, half * 2) : new Vector3(half * 2, 40, 1);
        }
    }

    // ------------------------------------------------------------------ enemies (rigged + animated)
    static readonly Dictionary<string, RuntimeAnimatorController> _ctrl = new Dictionary<string, RuntimeAnimatorController>();
    static List<AnimationClip> ClipsNear(string assetPath)
    {
        var res = new List<AnimationClip>();
        // pack root = first two folders (Assets/<Pack>)
        var parts = assetPath.Split('/'); var pack = parts.Length > 2 ? parts[0] + "/" + parts[1] : "Assets";
        foreach (var g in AssetDatabase.FindAssets("t:AnimationClip", new[] { pack }))
        {
            var p = AssetDatabase.GUIDToAssetPath(g);
            foreach (var o in AssetDatabase.LoadAllAssetsAtPath(p)) { var c = o as AnimationClip; if (c && !c.name.StartsWith("__preview__") && !res.Contains(c)) res.Add(c); }
        }
        return res;
    }
    static void MakeLoop(AnimationClip c)
    {
        var p = AssetDatabase.GetAssetPath(c);
        if (p.ToLower().EndsWith(".anim")) { var s = AnimationUtility.GetAnimationClipSettings(c); if (!s.loopTime) { s.loopTime = true; AnimationUtility.SetAnimationClipSettings(c, s); EditorUtility.SetDirty(c); } return; }
        var mi = AssetImporter.GetAtPath(p) as ModelImporter; if (mi == null) return;
        var arr = mi.clipAnimations.Length > 0 ? mi.clipAnimations : mi.defaultClipAnimations; bool ch = false;
        foreach (var ca in arr) if (!ca.loopTime) { ca.loopTime = true; ch = true; }
        if (ch) { mi.clipAnimations = arr; mi.SaveAndReimport(); }
    }
    static RuntimeAnimatorController EnemyController(GameObject pf, string family)
    {
        var path = AssetDatabase.GetAssetPath(pf); if (_ctrl.TryGetValue(path, out var hit)) return hit;
        var clips = ClipsNear(path); string fam = Path.GetFileNameWithoutExtension(path).Split('_')[0].ToLower();
        AnimationClip walk = null, idle = null;
        foreach (var c in clips) { var n = c.name.ToLower(); bool mine = n.Contains(fam) || clips.Count < 8; if (!mine) continue; if (walk == null && Regex.IsMatch(n, "walk")) walk = c; if (idle == null && Regex.IsMatch(n, "idle")) idle = c; }
        if (walk == null) foreach (var c in clips) { var n = c.name.ToLower(); if ((n.Contains(fam) || clips.Count < 8) && Regex.IsMatch(n, "run|move|locomotion")) { walk = c; break; } }
        if (walk == null && idle == null) { _ctrl[path] = null; return null; }
        string wp = walk ? AssetDatabase.GetAssetPath(walk) : null, ip = idle ? AssetDatabase.GetAssetPath(idle) : null;
        string wn = walk ? walk.name : null, inn = idle ? idle.name : null;
        if (walk) MakeLoop(walk); if (idle && ip != wp) MakeLoop(idle); else if (idle && wp == ip && !walk) MakeLoop(idle);
        walk = null; idle = null;
        if (wp != null) foreach (var o in AssetDatabase.LoadAllAssetsAtPath(wp)) if (o is AnimationClip ac && ac.name == wn) walk = ac;
        if (ip != null) foreach (var o in AssetDatabase.LoadAllAssetsAtPath(ip)) if (o is AnimationClip ac && ac.name == inn) idle = ac;
        Directory.CreateDirectory("Assets/GameBot/Anim");
        var cp = "Assets/GameBot/Anim/Enemy_" + Regex.Replace(Path.GetFileNameWithoutExtension(path), "[^A-Za-z0-9]", "") + ".controller"; AssetDatabase.DeleteAsset(cp);
        var ctl = AnimatorController.CreateAnimatorControllerAtPath(cp); ctl.AddParameter("Moving", AnimatorControllerParameterType.Bool);
        var sm = ctl.layers[0].stateMachine;
        var sw = walk ? sm.AddState("Walk") : null; if (sw) sw.motion = walk;
        var si = idle ? sm.AddState("Idle") : null; if (si) si.motion = idle;
        if (sw && si)
        {
            sm.defaultState = si;
            var t1 = si.AddTransition(sw); t1.AddCondition(AnimatorConditionMode.If, 0, "Moving"); t1.hasExitTime = false; t1.duration = 0.15f;
            var t2 = sw.AddTransition(si); t2.AddCondition(AnimatorConditionMode.IfNot, 0, "Moving"); t2.hasExitTime = false; t2.duration = 0.15f;
        }
        else sm.defaultState = sw ? sw : si;
        Debug.Log("ENEMY_ANIM " + path + " walk=" + (walk ? walk.name : "-") + " idle=" + (idle ? idle.name : "-"));
        _ctrl[path] = ctl; return ctl;
    }
    static List<GameObject> EnemyPool()
    {
        var all = PrefabsIn(null, new Regex("hand|arms|fps_character|weapon|gun|ragdoll"), "enemies", "extra:soldier", "extra:zombie", "extra:robot");
        all.RemoveAll(p => p.GetComponentInChildren<SkinnedMeshRenderer>(true) == null);
        var human = all.FindAll(p => Regex.IsMatch(AssetDatabase.GetAssetPath(p).ToLower(), "player|character|soldier|zombie|human|man|woman|robot|monster|enemy"));
        var bl = BlenderModel("zombie") ?? BlenderModel("soldier") ?? BlenderModel("robot");
        var animalRx = new Regex("animal|horse|deer|wolf|bear|fox|cow|chicken|dog|cat_|rabbit|boar|creature");
        human.RemoveAll(p => animalRx.IsMatch(AssetDatabase.GetAssetPath(p).ToLower()));
        all.RemoveAll(p => animalRx.IsMatch(AssetDatabase.GetAssetPath(p).ToLower()));
        var res = human.Count > 0 ? human : all; if (res.Count == 0 && bl) res.Add(bl);
        if (res.Count == 0) { var cp = CharPool(); cp.RemoveAll(p => p.GetComponentInChildren<SkinnedMeshRenderer>(true) == null); res = cp; }
        return res;
    }
    // Dress a gameplay host with an owned (preferably rigged) character and give it a walk/idle Animator.
    static GameObject DressAnimated(GameObject host, GameObject pf, ref int skinned, ref int anim)
    {
        var v = Dressed(host, pf, 1.8f, null); if (v == null) return null;
        if (v.GetComponentInChildren<SkinnedMeshRenderer>(true)) skinned++;
        var ctl = EnemyController(pf, "");
        var an = v.GetComponentInChildren<Animator>(true);
        if (an == null && ctl != null) { an = v.AddComponent<Animator>(); foreach (var o in AssetDatabase.LoadAllAssetsAtPath(AssetDatabase.GetAssetPath(pf))) if (o is Avatar av) an.avatar = av; }
        if (an != null) { if (ctl != null) an.runtimeAnimatorController = ctl; an.applyRootMotion = false; an.cullingMode = AnimatorCullingMode.AlwaysAnimate; if (an.runtimeAnimatorController) anim++; }
        return v;
    }
    static int WorldEnemies(int count, float arena, int hp = 3)
    {
        var pool = EnemyPool(); var root = new GameObject("Enemies").transform; var rnd = new System.Random(5); int n = 0, skinned = 0, anim = 0;
        var growl = FindClip(new[] { "growl|monster|creature|zombie|roar|beast|demon", "grunt|scream|vocal|voice|breath|^hey" }, "gb_enemy");
        for (int i = 0; i < count; i++)
        {
            Vector3 p = Vector3.zero; for (int t = 0; t < 30; t++) { p = OnGround(rnd.Next(-(int)arena + 8, (int)arena - 8), rnd.Next(-5, (int)arena - 6)); if (Free(p, 1.2f)) break; }
            var host = Host("Enemy_" + i, p, 0.45f, 1.8f); host.transform.SetParent(root, true); host.transform.rotation = Quaternion.Euler(0, rnd.Next(360), 0);
            host.AddComponent<EnemyTarget>().hp = hp;
            if (pool.Count > 0)
            {
                var dv = DressAnimated(host, pool[i % pool.Count], ref skinned, ref anim);
                if (i == 0 && dv) foreach (var rr in dv.GetComponentsInChildren<Renderer>(true)) foreach (var mm in rr.sharedMaterials) if (mm) Debug.Log("ENEMY_MAT " + mm.name + " shader=" + mm.shader.name + " tex=" + (mm.mainTexture ? mm.mainTexture.name : (mm.HasProperty("_BaseMap") && mm.GetTexture("_BaseMap") ? mm.GetTexture("_BaseMap").name : "none")));
            }
            else { var cap = GameObject.CreatePrimitive(PrimitiveType.Capsule); Object.DestroyImmediate(cap.GetComponent<Collider>()); cap.transform.SetParent(host.transform, false); cap.transform.localPosition = Vector3.up * 0.9f; Debug.LogWarning("ENEMY_PLACEHOLDER (no character pack)"); }
            var src = host.AddComponent<AudioSource>(); src.playOnAwake = false; src.spatialBlend = 1f; src.minDistance = 3f; src.maxDistance = 40f; src.clip = growl; src.volume = 0.8f;
            host.AddComponent<GbEnemyAnim>();
            n++;
        }
        Debug.Log("WORLD_ENEMIES " + n + " skinned=" + skinned + " animated=" + anim + " pool=" + string.Join(" | ", pool.ConvertAll(AssetDatabase.GetAssetPath)));
        return n;
    }

    // ------------------------------------------------------------------ sound
    static AudioClip FindClip(string[] rx, string fallback)
    {
        var paths = PathsIn("t:AudioClip", "weapon_sfx", "ambient", "sfx_misc");
        foreach (var r in rx)
        {
            var re = new Regex(r, RegexOptions.IgnoreCase);
            foreach (var p in paths) { var f = Path.GetFileNameWithoutExtension(p); if (re.IsMatch(f)) { var c = AssetDatabase.LoadAssetAtPath<AudioClip>(p); if (c) return c; } }
        }
        // fix5: any owned clip already in the project (other imported packs) before the generated fallback
        var all = new List<string>(); foreach (var g in AssetDatabase.FindAssets("t:AudioClip", new[] { "Assets" })) { var p = AssetDatabase.GUIDToAssetPath(g); if (!p.Contains("/GameBot/Audio/Generated/")) all.Add(p); }
        foreach (var r in rx)
        {
            var re = new Regex(r, RegexOptions.IgnoreCase);
            foreach (var p in all) { var f = Path.GetFileNameWithoutExtension(p); if (re.IsMatch(f)) { var c = AssetDatabase.LoadAssetAtPath<AudioClip>(p); if (c) { Debug.Log("AUDIO_OWNED_ANYPACK " + fallback + " " + p); return c; } } }
        }
        var fb = AssetDatabase.LoadAssetAtPath<AudioClip>("Assets/GameBot/Audio/Generated/" + fallback + ".wav");
        return fb;
    }
    static GbAudio WorldAudio(bool gun)
    {
        var go = new GameObject("GameAudio"); var a = go.AddComponent<GbAudio>();
        a.fire = gun ? FindClip(new[] { "ar_gunshot", "rifle.*shot|shot.*rifle", "gunshot", "^(?!.*tail).*shot", "fire" }, "gb_fire") : null;
        a.reload = gun ? FindClip(new[] { "ar_reload.*magin|reload.*mag_?in", "reload" }, "gb_reload") : null;
        a.hit = FindClip(new[] { "bullet.*(hit|impact)|impact.*flesh|flesh", "hit|impact|punch|body" }, "gb_hit");
        a.enemy = FindClip(new[] { "growl|monster|creature|zombie|roar|beast|demon", "grunt|scream|vocal|voice|breath|^hey" }, "gb_enemy");
        a.ambient = FindClip(new[] { "wind_forest|forest_birds", "wind|forest|birds", "ambien" }, "gb_ambient");
        var one = go.AddComponent<AudioSource>(); one.playOnAwake = false; one.spatialBlend = 0f;
        var amb = go.AddComponent<AudioSource>(); amb.playOnAwake = true; amb.loop = true; amb.clip = a.ambient; amb.volume = 0.35f; amb.spatialBlend = 0f;
        var cam = Camera.main ? Camera.main.gameObject : GameObject.Find("Main Camera"); if (cam && !cam.GetComponent<AudioListener>()) cam.AddComponent<AudioListener>();
        if (!Object.FindAnyObjectByType<AudioListener>()) go.AddComponent<AudioListener>();
        System.Func<AudioClip, string> nm = c => c ? AssetDatabase.GetAssetPath(c) : "-";
        Debug.Log("WORLD_AUDIO fire=" + nm(a.fire) + " reload=" + nm(a.reload) + " hit=" + nm(a.hit) + " enemy=" + nm(a.enemy) + " ambient=" + nm(a.ambient) + " listener=" + (Object.FindAnyObjectByType<AudioListener>() != null));
        return a;
    }

    // ------------------------------------------------------------------ first-person gun: detect forward axis
    static readonly Regex GunPrefer = new Regex("m4|ak|ar[-_ ]?1|ar15|rifle|scar|m16|carbine|smg|uzi|mp5|mp7|famas|aug|g36|m249|lmg|kalash|assault", RegexOptions.IgnoreCase);
    static readonly Regex GunBad = new Regex("icon|/ui/|attachment|optic|scope|sight|magazine|mag_|bullet|shell|casing|grenade|rgd|rpg|launcher|flash|anpeq|laser|suppressor|silencer|m2_50|stock|grip|barrel_|knife|bow|arrow|holster|ammo|muzzle", RegexOptions.IgnoreCase);
    static List<string> GunCandidates()
    {
        var res = new List<string>();
        var mapped = PathsIn("t:Prefab", "weapons"); mapped.AddRange(PathsIn("t:Model", "weapons"));
        var global = new List<string>(); foreach (var g in AssetDatabase.FindAssets("t:Prefab")) global.Add(AssetDatabase.GUIDToAssetPath(g)); foreach (var g in AssetDatabase.FindAssets("t:Model")) global.Add(AssetDatabase.GUIDToAssetPath(g));
        foreach (var src in new[] { mapped, global })
        {
            var good = new List<string>(); var ok = new List<string>();
            foreach (var p in src) { var low = p.ToLower(); var file = Path.GetFileName(low); if (!low.StartsWith("assets/") || GunBad.IsMatch(file) || low.Contains("/ui/") || low.Contains("icon")) continue; if (src == global && !IsWeapon(low)) continue; if (GunPrefer.IsMatch(file)) good.Add(p); else ok.Add(p); }
            res.AddRange(good); res.AddRange(ok); if (res.Count > 0) break;
        }
        return res;
    }
    /// <summary>Muzzle direction (F) and up (U) of a gun in its own space, from mesh shape: the barrel end is the thin end, the grip/magazine hang below.</summary>
    static bool GunAxes(GameObject vis, out Vector3 F, out Vector3 U, out Vector3 muzzleLocal)
    {
        F = Vector3.forward; U = Vector3.up; muzzleLocal = Vector3.zero;
        var pts = new List<Vector3>(); var w2l = vis.transform.worldToLocalMatrix;
        foreach (var mf in vis.GetComponentsInChildren<MeshFilter>(true)) { var m = mf.sharedMesh; if (!m) continue; var v = m.vertices; int step = Mathf.Max(1, v.Length / 6000); var l2w = mf.transform.localToWorldMatrix; for (int i = 0; i < v.Length; i += step) pts.Add(w2l.MultiplyPoint3x4(l2w.MultiplyPoint3x4(v[i]))); }
        foreach (var sm in vis.GetComponentsInChildren<SkinnedMeshRenderer>(true)) { var m = sm.sharedMesh; if (!m) continue; var v = m.vertices; int step = Mathf.Max(1, v.Length / 6000); var l2w = sm.transform.localToWorldMatrix; for (int i = 0; i < v.Length; i += step) pts.Add(w2l.MultiplyPoint3x4(l2w.MultiplyPoint3x4(v[i]))); }
        if (pts.Count < 8) return false;
        Vector3 mn = pts[0], mx = pts[0]; foreach (var p in pts) { mn = Vector3.Min(mn, p); mx = Vector3.Max(mx, p); }
        var size = mx - mn; int L = size.x >= size.y && size.x >= size.z ? 0 : (size.y >= size.z ? 1 : 2);
        int A = (L + 1) % 3, B = (L + 2) % 3; int V = size[A] >= size[B] ? A : B; // vertical = taller of the two short axes
        float len = size[L], lo = mn[L] + len * 0.18f, hi = mx[L] - len * 0.18f;
        float aMin = float.MaxValue, aMax = float.MinValue, bMin = float.MaxValue, bMax = float.MinValue; Vector3 aSum = Vector3.zero, bSum = Vector3.zero; int aN = 0, bN = 0; Vector3 all = Vector3.zero;
        foreach (var p in pts) { all += p; if (p[L] <= lo) { aMin = Mathf.Min(aMin, p[V]); aMax = Mathf.Max(aMax, p[V]); aSum += p; aN++; } else if (p[L] >= hi) { bMin = Mathf.Min(bMin, p[V]); bMax = Mathf.Max(bMax, p[V]); bSum += p; bN++; } }
        all /= pts.Count; float spreadA = aN > 0 ? aMax - aMin : 99f, spreadB = bN > 0 ? bMax - bMin : 99f;
        bool muzzleHigh = spreadB < spreadA; // the thinner end is the barrel
        string how = "shape";
        foreach (var t in vis.GetComponentsInChildren<Transform>(true))
        {
            var n = t.name.ToLower(); if (!(n.Contains("muzzle") || n.Contains("barrel_end") || n.Contains("firepoint") || n.Contains("shootpoint") || n == "tip")) continue;
            var lp = w2l.MultiplyPoint3x4(t.position); muzzleHigh = lp[L] > (mn[L] + mx[L]) * 0.5f; how = "named:" + t.name; break;
        }
        var axL = Vector3.zero; axL[L] = 1f; F = muzzleHigh ? axL : -axL;
        var endC = muzzleHigh ? (bN > 0 ? bSum / bN : mx) : (aN > 0 ? aSum / aN : mn);
        var axV = Vector3.zero; axV[V] = 1f; U = endC[V] >= all[V] ? axV : -axV; // up points from the mass (grip/mag) toward the barrel line
        muzzleLocal = endC; muzzleLocal[L] = muzzleHigh ? mx[L] : mn[L];
        Debug.Log("WEAPON_AXES long=" + "XYZ"[L] + " vertical=" + "XYZ"[V] + " endSpread=" + spreadA.ToString("0.000") + "/" + spreadB.ToString("0.000") + " forward=" + F + " up=" + U + " via=" + how);
        return true;
    }
    static void AttachWeaponModel(GameObject player)
    {
        var cam = player.GetComponentInChildren<Camera>(); if (!cam) return;
        cam.nearClipPlane = 0.03f;
        foreach (var path in GunCandidates())
        {
            var pf = AssetDatabase.LoadAssetAtPath<GameObject>(path); if (pf == null || pf.GetComponentsInChildren<Renderer>(true).Length == 0) continue;
            var vis = Object.Instantiate(pf); vis.name = "GunModel"; StripBehaviour(vis);
            foreach (var c in vis.GetComponentsInChildren<Collider>(true)) Object.DestroyImmediate(c);
            foreach (var lg in vis.GetComponentsInChildren<LODGroup>(true)) Object.DestroyImmediate(lg);
            vis.transform.position = Vector3.zero; vis.transform.rotation = Quaternion.identity; vis.transform.localScale = Vector3.one;
            if (!GunAxes(vis, out var F, out var U, out var muz)) { Object.DestroyImmediate(vis); continue; }
            var nb = Bounds(vis); float big = Mathf.Max(nb.size.x, nb.size.y, nb.size.z); if (big < 1e-4f) { Object.DestroyImmediate(vis); continue; }
            foreach (var r in vis.GetComponentsInChildren<Renderer>(true)) { r.enabled = true; r.gameObject.SetActive(true); r.shadowCastingMode = UnityEngine.Rendering.ShadowCastingMode.Off; FixMat(r); }
            var holder = new GameObject("ViewGun"); holder.transform.SetParent(cam.transform, false);
            holder.transform.localPosition = new Vector3(0.22f, -0.2f, 0.45f); holder.transform.localRotation = Quaternion.identity;
            var pivot = new GameObject("GunPivot"); pivot.transform.SetParent(holder.transform, false);
            vis.transform.SetParent(pivot.transform, false);
            vis.transform.localScale = Vector3.one * (0.62f / big);
            vis.transform.localRotation = Quaternion.Inverse(Quaternion.LookRotation(F, U)); // muzzle -> camera forward, barrel line up
            vis.transform.localPosition = Vector3.zero;
            var wb = Bounds(vis); vis.transform.position += holder.transform.position - wb.center;
            var muzzle = new GameObject("Muzzle"); muzzle.transform.SetParent(holder.transform, true); muzzle.transform.position = vis.transform.TransformPoint(muz);
            float fwd = Vector3.Dot(muzzle.transform.position - Bounds(vis).center, cam.transform.forward);
            Debug.Log((fwd > 0 ? "WEAPON_FORWARD_OK" : "WEAPON_FORWARD_BAD") + " dot=" + fwd.ToString("0.000") + " model=" + path);
            if (fwd <= 0f) { Object.DestroyImmediate(holder); Debug.LogWarning("WEAPON_SKIPPED_SIDEWAYS " + path + " - trying the next gun model"); continue; }
            Debug.Log("WEAPON_MODEL " + path);
            return;
        }
        Debug.LogWarning("WEAPON_NONE (no gun model owned) - simple placeholder gun");
    }

    // ------------------------------------------------------------------ the FPS level
    static void BuildFpsWorld()
    {
        var scene = UnityEditor.SceneManagement.EditorSceneManager.NewScene(UnityEditor.SceneManagement.NewSceneSetup.DefaultGameObjects, UnityEditor.SceneManagement.NewSceneMode.Single);
        AddConfig("fps"); _mode = "fps"; _ownedCache = null; _dressCount = 0; _dressUsed.Clear(); _blocked.Clear(); _coverPool = null; _matConv.Clear(); _matConvN = 0; _matTexN = 0;
        var root = DressRoot(); const float S = 260f, arena = 58f;
        WorldTerrain(S, arena);
        WorldBuildings(root, arena);
        WorldCover(root, arena);
        WorldExtras(root, arena);
        WorldTrees(root, S, arena);
        WorldBounds(arena + 12f);
        WorldEnemies(10, arena);
        var crates = CoverPool().FindAll(p => Regex.IsMatch(AssetDatabase.GetAssetPath(p).ToLower(), "crate|box|barrel|container|case|bin"));
        for (int i = 0; i < 6; i++)
        {
            var p = OnGround(-30 + i * 12, 2 + (i % 2) * 18) + Vector3.up * 0.5f;
            var a = Box("AmmoCrate_" + i, p, Vector3.one * 0.8f, new Color(0.9f, 0.75f, 0.1f)); a.GetComponent<Collider>().isTrigger = true; a.AddComponent<AmmoPickup>();
            if (crates.Count > 0) { var cv = Spawn(crates[i % crates.Count], a.transform, false); FitTo(cv, p, Vector3.one * 0.8f, true); cv.transform.SetParent(a.transform, true); a.GetComponent<Renderer>().enabled = false; }
        }
        var sp = OnGround(0, -48f); var player = MakeWalker(sp + Vector3.up * 1.1f); player.transform.rotation = Quaternion.identity;
        player.AddComponent<GunController>(); AttachWeaponModel(player);
        WorldAudio(true);
        RenderSettings.fog = true; RenderSettings.fogMode = FogMode.Linear; RenderSettings.fogStartDistance = 60f; RenderSettings.fogEndDistance = 190f; RenderSettings.fogColor = new Color(0.68f, 0.74f, 0.8f);
        var sun = Object.FindAnyObjectByType<Light>(); if (sun && sun.type == LightType.Directional) { sun.intensity = 1.15f; sun.shadows = LightShadows.Soft; sun.transform.rotation = Quaternion.Euler(48, -35, 0); }
        if (AMap().placeholders != null && AMap().placeholders.Length > 0) Debug.Log("WORLD_PLACEHOLDERS (creator chose) " + string.Join(", ", AMap().placeholders));
        try { FinalMatPass(); PolishLook(); } catch (System.Exception e) { Debug.LogWarning("LOOK_FAIL " + e); }
        LogDress();
        new GameObject("HUD").AddComponent<GameHUD>();
        new GameObject("Pause").AddComponent<PauseMenu>();
        UnityEditor.SceneManagement.EditorSceneManager.SaveScene(scene, GamePath);
    }
}

public static partial class SceneBuilder
{
    /// <summary>Lift everything a builder placed at y=0 onto the terrain surface.</summary>
    static void SnapAllToTerrain(Transform dressRoot)
    {
        if (!_terr) return; int n = 0;
        var skip = new HashSet<string> { "Terrain", "Directional Light", "WorldBounds", "GenreConfig", "StormWall", "Main Camera", "HUD", "Pause", "GameAudio" };
        var list = new List<Transform>();
        if (dressRoot) foreach (Transform c in dressRoot) list.Add(c);
        foreach (var go in UnityEngine.SceneManagement.SceneManager.GetActiveScene().GetRootGameObjects()) if (go.transform != dressRoot && !skip.Contains(go.name) && !go.GetComponent<Terrain>() && !go.GetComponent<Light>()) list.Add(go.transform);
        int skipped = 0;
        foreach (var t in list)
        {
            var p = t.position; float g = GroundY(p);
            // idempotent (review fix 6): things already placed with OnGround() sit at/above the terrain - don't lift them twice
            if (p.y >= g - 0.05f) { skipped++; continue; }
            t.position = new Vector3(p.x, p.y + g, p.z); n++;
        }
        Debug.Log("SNAP_TO_TERRAIN " + n + " already_on_ground=" + skipped);
    }
}
