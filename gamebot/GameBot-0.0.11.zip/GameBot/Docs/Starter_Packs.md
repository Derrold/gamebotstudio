# Game Bot starter packs (free Unity Asset Store)

Verified free on 2026-11-16 (Unity 6 / URP check of public Asset Store pages). Add to My Assets on your Unity account, then Game Bot downloads and imports them.

## Basic
- [First Person + Third Person | Character Controllers](https://assetstore.unity.com/packages/3d/characters/first-person-third-person-character-controllers-196526), characters
- [POLYGON - Starter Pack - Art by Synty](https://assetstore.unity.com/packages/3d/environments/polygon-starter-pack-art-by-synty-156819), env
- [Fantasy Skybox FREE](https://assetstore.unity.com/packages/2d/textures-materials/sky/fantasy-skybox-free-18353), env
- [2D Casual UI HD](https://assetstore.unity.com/packages/2d/gui/icons/2d-casual-ui-hd-82080), UI
- [FREE Casual Game SFX Pack](https://assetstore.unity.com/packages/audio/sound-fx/free-casual-game-sfx-pack-54116), audio
- [Low Poly Weapons VOL.1](https://assetstore.unity.com/packages/3d/props/guns/low-poly-weapons-vol-1-151980), weapons
- [RPG Monster Duo PBR Polyart](https://assetstore.unity.com/packages/3d/characters/creatures/rpg-monster-duo-pbr-polyart-157762), enemies
- [Cartoon FX Remaster Free](https://assetstore.unity.com/packages/vfx/particles/cartoon-fx-remaster-free-109565), VFX

## Action
- [Low Poly Dungeons Lite](https://assetstore.unity.com/packages/3d/environments/dungeons/low-poly-dungeons-lite-177937), env
- [RPG Monster Duo PBR Polyart](https://assetstore.unity.com/packages/3d/characters/creatures/rpg-monster-duo-pbr-polyart-157762), enemies
- [Human Basic Motions FREE](https://assetstore.unity.com/packages/3d/animations/human-basic-motions-free-154271), characters
- [Brawler Animations - Free](https://assetstore.unity.com/packages/3d/animations/brawler-animations-free-305932), characters
- [Cartoon FX Remaster Free](https://assetstore.unity.com/packages/vfx/particles/cartoon-fx-remaster-free-109565), VFX

## Adventure
- [Fantasy Forest Environment - Free Demo](https://assetstore.unity.com/packages/3d/environments/fantasy/fantasy-forest-environment-free-demo-35361), env
- [Low-Poly Simple Nature Pack](https://assetstore.unity.com/packages/3d/environments/landscapes/low-poly-simple-nature-pack-162153), env
- [Slavic Medieval Village Free – Modular Environment Kit](https://assetstore.unity.com/packages/3d/environments/fantasy/slavic-medieval-village-free-modular-environment-kit-167010), env
- [Skybox Series Free](https://assetstore.unity.com/packages/2d/textures-materials/sky/skybox-series-free-103633), env
- [Simple Gems and Items Ultimate Animated Customizable Pack](https://assetstore.unity.com/packages/3d/props/simple-gems-and-items-ultimate-animated-customizable-pack-73764), env

## RPG
- [RPG Poly Pack - Lite](https://assetstore.unity.com/packages/3d/environments/landscapes/rpg-poly-pack-lite-148410), env
- [RPG Monster Duo PBR Polyart](https://assetstore.unity.com/packages/3d/characters/creatures/rpg-monster-duo-pbr-polyart-157762), enemies
- [Mini Legion Rock Golem PBR HP Polyart](https://assetstore.unity.com/packages/3d/characters/humanoids/fantasy/mini-legion-rock-golem-pbr-hp-polyart-94707), enemies
- [Fantasy Wooden GUI : Free](https://assetstore.unity.com/packages/2d/gui/fantasy-wooden-gui-free-103811), UI
- [Free Music Tracks For Games](https://assetstore.unity.com/packages/audio/music/free-music-tracks-for-games-156413), audio

## Shooter / FPS
- [Sci-Fi Styled Modular Pack](https://assetstore.unity.com/packages/3d/environments/sci-fi/sci-fi-styled-modular-pack-82913), env
- [Low Poly Shooter Pack - Free Sample](https://assetstore.unity.com/packages/templates/systems/low-poly-shooter-pack-free-sample-144839), weapons
- [Low Poly Weapons VOL.1](https://assetstore.unity.com/packages/3d/props/guns/low-poly-weapons-vol-1-151980), weapons
- [Weapons of Choice - FREE](https://assetstore.unity.com/packages/audio/sound-fx/weapons/weapons-of-choice-free-101807), audio
- [Sci-fi Guns SFX Pack](https://assetstore.unity.com/packages/audio/sound-fx/sci-fi-guns-sfx-pack-181144), audio
- [Robot Kyle | URP](https://assetstore.unity.com/packages/3d/characters/robots/robot-kyle-urp-4696), enemies

## Strategy
- [Low-Poly Medieval Strategy Pack](https://assetstore.unity.com/packages/3d/low-poly-medieval-strategy-pack-71644), characters
- [Toon RTS Units - Demo](https://assetstore.unity.com/packages/3d/characters/humanoids/fantasy/toon-rts-units-demo-69687), characters
- [Toon RTS Units - Orcs Demo](https://assetstore.unity.com/packages/3d/characters/humanoids/fantasy/toon-rts-units-orcs-demo-101359), enemies
- [Toon RTS Units - Undead Demo](https://assetstore.unity.com/packages/3d/characters/humanoids/fantasy/toon-rts-units-undead-demo-95640), enemies
- [Slavic Medieval Village Free – Modular Environment Kit](https://assetstore.unity.com/packages/3d/environments/fantasy/slavic-medieval-village-free-modular-environment-kit-167010), env

## Simulation
- [Pandazole - City Town Lowpoly Pack](https://assetstore.unity.com/packages/3d/props/exterior/pandazole-city-town-lowpoly-pack-205787), env
- [Simple Town Lite - Cartoon Assets](https://assetstore.unity.com/packages/3d/environments/simple-town-lite-cartoon-assets-43480), env
- [CITYBUILDER - FREE - Modular Low Poly City Kit](https://assetstore.unity.com/packages/3d/environments/urban/citybuilder-free-modular-low-poly-city-kit-414228), env
- [Nature Starter Kit 2](https://assetstore.unity.com/packages/3d/environments/nature-starter-kit-2-52977), env

## Sports
- [Football Essentials 3D](https://assetstore.unity.com/packages/3d/environments/football-essentials-3d-310051), env — **Built-in only** (Asset Store: URP not compatible on 2022.3). No suitable free 3D URP football pack found; paid URP stadium packs exist. Convert materials if you import this into a URP Unity 6 project.
- [Low Polygon Soccer Ball](https://assetstore.unity.com/packages/3d/low-polygon-soccer-ball-84382), props
- [Human Basic Motions FREE](https://assetstore.unity.com/packages/3d/animations/human-basic-motions-free-154271), characters
- [Character Pack: Free Sample](https://assetstore.unity.com/packages/3d/characters/humanoids/character-pack-free-sample-79870), characters

## Racing
- [ARCADE: FREE Racing Car](https://assetstore.unity.com/packages/3d/vehicles/land/arcade-free-racing-car-161085), vehicles
- [Karting Microgame | 3D Sample Project](https://assetstore.unity.com/packages/templates/packs/karting-microgame-3d-sample-project-150956), env
- [Simple Town Lite - Cartoon Assets](https://assetstore.unity.com/packages/3d/environments/simple-town-lite-cartoon-assets-43480), env
- [Pandazole - City Town Lowpoly Pack](https://assetstore.unity.com/packages/3d/props/exterior/pandazole-city-town-lowpoly-pack-205787), env

## Fighting
- [Martial Art Animations - Sample](https://assetstore.unity.com/packages/3d/animations/martial-art-animations-sample-299378), characters
- [Brawler Animations - Free](https://assetstore.unity.com/packages/3d/animations/brawler-animations-free-305932), characters
- [Fighting Motions Vol.1](https://assetstore.unity.com/packages/3d/animations/fighting-motions-vol-1-76699), characters
- [Character Pack: Free Sample](https://assetstore.unity.com/packages/3d/characters/humanoids/character-pack-free-sample-79870), characters
- [Cartoon FX Remaster Free](https://assetstore.unity.com/packages/vfx/particles/cartoon-fx-remaster-free-109565), VFX

## Horror
- [PBR - Hospital Horror Pack. Free](https://assetstore.unity.com/packages/3d/environments/pbr-hospital-horror-pack-free-80117), env
- [Spooky Graveyard Pack](https://assetstore.unity.com/packages/3d/environments/fantasy/spooky-graveyard-pack-156860), env
- [Flooded Grounds](https://assetstore.unity.com/packages/3d/environments/flooded-grounds-48529), env
- [Character Pack: Zombie Sample](https://assetstore.unity.com/packages/3d/characters/humanoids/fantasy/character-pack-zombie-sample-131604), enemies
- [Skeleton Ghost (FREE)](https://assetstore.unity.com/packages/3d/characters/creatures/skeleton-ghost-free-226070), enemies

## Platformer
- [Lowpoly Platformer Kit – Free Modular Stylized Blocks](https://assetstore.unity.com/packages/3d/environments/lowpoly-platformer-kit-free-modular-stylized-blocks-319018), env
- [Platformer | GameDev Starter Kit [Free Edition]](https://assetstore.unity.com/packages/3d/environments/platformer-gamedev-starter-kit-free-edition-240260), env
- [Simple Gems and Items Ultimate Animated Customizable Pack](https://assetstore.unity.com/packages/3d/props/simple-gems-and-items-ultimate-animated-customizable-pack-73764), env
- [3D Game Kit | 3D Sample Project](https://assetstore.unity.com/packages/templates/packs/3d-game-kit-3d-sample-project-115747), env
- [FREE Casual Game SFX Pack](https://assetstore.unity.com/packages/audio/sound-fx/free-casual-game-sfx-pack-54116), audio

## Puzzle
- [2D puzzle blocks textures](https://assetstore.unity.com/packages/2d/textures-materials/2d-puzzle-blocks-textures-140764), env
- [Simple Gems and Items Ultimate Animated Customizable Pack](https://assetstore.unity.com/packages/3d/props/simple-gems-and-items-ultimate-animated-customizable-pack-73764), env
- [2D Casual UI HD](https://assetstore.unity.com/packages/2d/gui/icons/2d-casual-ui-hd-82080), UI
- [FREE Casual Game SFX Pack](https://assetstore.unity.com/packages/audio/sound-fx/free-casual-game-sfx-pack-54116), audio

## Open World
- [Terrain Asset Pack | Terrain Sample](https://assetstore.unity.com/packages/3d/environments/landscapes/terrain-asset-pack-terrain-sample-145808), env
- [Nature Starter Kit 2](https://assetstore.unity.com/packages/3d/environments/nature-starter-kit-2-52977), env
- [Environmental Asset Pack](https://assetstore.unity.com/packages/3d/environments/environmental-asset-pack-170036), env
- [Free HDR Sky](https://assetstore.unity.com/packages/2d/textures-materials/sky/free-hdr-sky-61217), env
- [Slavic Medieval Village Free – Modular Environment Kit](https://assetstore.unity.com/packages/3d/environments/fantasy/slavic-medieval-village-free-modular-environment-kit-167010), env

## Survival
- [Low-Poly Survival Asset Pack (Props & Items)](https://assetstore.unity.com/packages/3d/props/low-poly-survival-asset-pack-props-items-386898), env
- [Item Pack: Survival](https://assetstore.unity.com/packages/3d/props/item-pack-survival-131598), env
- [Environmental Asset Pack](https://assetstore.unity.com/packages/3d/environments/environmental-asset-pack-170036), env
- [Character Pack: Zombie Sample](https://assetstore.unity.com/packages/3d/characters/humanoids/fantasy/character-pack-zombie-sample-131604), enemies
- [Flooded Grounds](https://assetstore.unity.com/packages/3d/environments/flooded-grounds-48529), env

## Sandbox
- [POLYGON - Starter Pack - Art by Synty](https://assetstore.unity.com/packages/3d/environments/polygon-starter-pack-art-by-synty-156819), env
- [Nature Starter Kit 2](https://assetstore.unity.com/packages/3d/environments/nature-starter-kit-2-52977), env
- [Simple Town Lite - Cartoon Assets](https://assetstore.unity.com/packages/3d/environments/simple-town-lite-cartoon-assets-43480), env
- [Yughues Free Ground Materials](https://assetstore.unity.com/packages/2d/textures-materials/nature/yughues-free-ground-materials-13001), env

## Stealth
- [Pandazole - City Town Lowpoly Pack](https://assetstore.unity.com/packages/3d/props/exterior/pandazole-city-town-lowpoly-pack-205787), env
- [PBR - Hospital Horror Pack. Free](https://assetstore.unity.com/packages/3d/environments/pbr-hospital-horror-pack-free-80117), env
- [Character Pack: Free Sample](https://assetstore.unity.com/packages/3d/characters/humanoids/character-pack-free-sample-79870), characters
- [Human Basic Motions FREE](https://assetstore.unity.com/packages/3d/animations/human-basic-motions-free-154271), characters
- [Weapons Pack - Realistic LowPoly](https://assetstore.unity.com/packages/3d/props/guns/weapons-pack-realistic-lowpoly-200967), weapons

## Battle Royale
- [Guns Pack: Low Poly Guns Collection](https://assetstore.unity.com/packages/3d/props/guns/guns-pack-low-poly-guns-collection-192553), weapons
- [Low Poly Weapons VOL.1](https://assetstore.unity.com/packages/3d/props/guns/low-poly-weapons-vol-1-151980), weapons
- [Terrain Asset Pack | Terrain Sample](https://assetstore.unity.com/packages/3d/environments/landscapes/terrain-asset-pack-terrain-sample-145808), env
- [Simple Town Lite - Cartoon Assets](https://assetstore.unity.com/packages/3d/environments/simple-town-lite-cartoon-assets-43480), env
- [Free Weapon Sound Effects](https://assetstore.unity.com/packages/audio/sound-fx/weapons/free-weapon-sound-effects-388474), audio

## MOBA
- [Toon RTS Units - Demo](https://assetstore.unity.com/packages/3d/characters/humanoids/fantasy/toon-rts-units-demo-69687), characters
- [Toon RTS Units - Orcs Demo](https://assetstore.unity.com/packages/3d/characters/humanoids/fantasy/toon-rts-units-orcs-demo-101359), enemies
- [Toon RTS Units - Undead Demo](https://assetstore.unity.com/packages/3d/characters/humanoids/fantasy/toon-rts-units-undead-demo-95640), enemies
- [RPG Monster Duo PBR Polyart](https://assetstore.unity.com/packages/3d/characters/creatures/rpg-monster-duo-pbr-polyart-157762), enemies
- [Mini Legion Rock Golem PBR HP Polyart](https://assetstore.unity.com/packages/3d/characters/humanoids/fantasy/mini-legion-rock-golem-pbr-hp-polyart-94707), enemies
- [Cartoon FX Remaster Free](https://assetstore.unity.com/packages/vfx/particles/cartoon-fx-remaster-free-109565), VFX

## MMORPG
- [Slavic Medieval Village Free – Modular Environment Kit](https://assetstore.unity.com/packages/3d/environments/fantasy/slavic-medieval-village-free-modular-environment-kit-167010), env
- [RPG Poly Pack - Lite](https://assetstore.unity.com/packages/3d/environments/landscapes/rpg-poly-pack-lite-148410), env
- [RPG Monster Duo PBR Polyart](https://assetstore.unity.com/packages/3d/characters/creatures/rpg-monster-duo-pbr-polyart-157762), enemies
- [Fantasy Wooden GUI : Free](https://assetstore.unity.com/packages/2d/gui/fantasy-wooden-gui-free-103811), UI
- [Fantasy Forest Environment - Free Demo](https://assetstore.unity.com/packages/3d/environments/fantasy/fantasy-forest-environment-free-demo-35361), env
- [Free Music Tracks For Games](https://assetstore.unity.com/packages/audio/music/free-music-tracks-for-games-156413), audio

## Unity 6 / URP notes (verified 2026-11-16, public Asset Store pages only)

Replaced (Asset Store listed Built-in only, no URP):
- Simulation env: Free Low Poly Simple Urban City 3D Asset Pack (239474, Built-in only on 2021.3) → CITYBUILDER - FREE - Modular Low Poly City Kit (414228, Unity 6000.4.2 Built-in + URP + HDRP, still free).
- Survival enemies: Apocalypse series: Zombie character FREE (272407, Built-in only on 2022.3) → Character Pack: Zombie Sample (131604, URP + Built-in on 2022.3; already used in Horror). Official table has no Unity 6 row.

Flagged, not replaced:
- Sports env: Football Essentials 3D (310051) is Built-in only on 2022.3. No suitable **free** 3D URP football/stadium pack was listed on the Asset Store (URP stadium/pitch packs checked were paid). Grand Stadium v2.0 (254584) is also free but Built-in only. Convert materials if you import 310051 into URP.

Many older packs have no official Unity 6 compatibility table. Packs that list URP on 2021/2022 were kept. Audio, UI, and texture packs typically have no pipeline table and were kept.
