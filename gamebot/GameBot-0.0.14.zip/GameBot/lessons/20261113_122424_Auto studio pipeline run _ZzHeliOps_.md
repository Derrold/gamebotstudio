# Auto studio pipeline run (ZzHeliOps)

Tags: auto studio pipeline
Saved: 2026-11-13T12:24:24

run_auto_game_pipeline created 34 files under C:\Users\ExtremeHybrid\Documents\GameProjects\ZzHeliOps and UNITY 6000.6.5f1: background job started -> create ZzHeliOpsUnity -> Shooter / FPS game (gameplay template: fps; menu, settings, achievements, owned genre kit) . Next: check Builds\auto_unity_status.txt, then work TaskBoard 'Auto next actions' with tools.
