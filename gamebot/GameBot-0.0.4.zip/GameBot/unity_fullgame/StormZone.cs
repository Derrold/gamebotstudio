using UnityEngine;
/// <summary>Battle royale storm: safe circle shrinks in phases; outside it hurts the player and bots.</summary>
public class StormZone : MonoBehaviour
{
    public static StormZone I; public Vector3 center; public float radius = 95f; public int Dps => 3 + GenreState.Phase * 2;
    float[] radii = { 95f, 65f, 40f, 20f, 6f }; float phaseStart; float from; float hurtAcc;
    void Start() { I = this; center = transform.position; phaseStart = Time.timeSinceLevelLoad; from = radius; }
    public bool Outside(Vector3 p) { var d = p - center; d.y = 0; return d.magnitude > radius; }
    void Update()
    {
        if (GameState.Won || GameState.Lost || PauseMenu.IsPaused || MainMenuUI.InMenu) return;
        float t = Time.timeSinceLevelLoad - phaseStart; int ph = GenreState.Phase;
        if (ph < radii.Length - 1) { if (t > 30f) { float k = Mathf.Clamp01((t - 30f) / 25f); radius = Mathf.Lerp(radii[ph], radii[ph + 1], k); if (k >= 1) { GenreState.Phase++; phaseStart = Time.timeSinceLevelLoad; GameHUD.Flash("Storm phase " + (GenreState.Phase + 1) + " - the circle is closing!"); } } }
        GenreState.StormRadius = radius; transform.localScale = new Vector3(radius * 2f, 30f, radius * 2f);
        var p = GameObject.FindGameObjectWithTag("Player"); if (p && Outside(p.transform.position)) { hurtAcc += Dps * Time.deltaTime; if (hurtAcc >= 1) { int d = (int)hurtAcc; hurtAcc -= d; GbCombat.HurtPlayer(d); } }
    }
}
