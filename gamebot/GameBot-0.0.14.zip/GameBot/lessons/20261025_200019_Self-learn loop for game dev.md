# Self-learn loop for game dev

Tags: learning,meta
Saved: 2026-10-25T20:00:19

search_playbooks/list_lessons first -> act with tools -> verify (exists/size/exit/log) -> on failure research_error/firefox_search official docs -> patch + retry once -> teach_self (symptom, cause, fix, verify, source URL; 3-8 lines, no copied manuals). Playbook: self-learn-loop.md
