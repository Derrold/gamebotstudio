﻿using UnityEngine;
using UnityEngine.SceneManagement;

/// <summary>Score, lives, story flags, continue slot. PlayerPrefs-backed.</summary>
public static class GameState
{
    const string P = "TFG_";
    public static int Coins;
    public static int Lives = 3;
    public static int Deaths;
    public static bool IntroShown;
    public static bool Won;
    public static bool Lost;

    public static void ResetRun()
    {
        Coins = 0; Lives = 3; Deaths = 0; Won = false; Lost = false; IntroShown = false;
    }
    public static void SaveContinue()
    {
        PlayerPrefs.SetInt(P+"Has", 1);
        PlayerPrefs.SetInt(P+"Coins", Coins);
        PlayerPrefs.SetInt(P+"Lives", Lives);
        PlayerPrefs.SetInt(P+"Deaths", Deaths);
        PlayerPrefs.Save();
    }
    public static bool HasContinue() => PlayerPrefs.GetInt(P+"Has", 0) == 1;
    public static void LoadContinue()
    {
        Coins = PlayerPrefs.GetInt(P+"Coins", 0);
        Lives = PlayerPrefs.GetInt(P+"Lives", 3);
        Deaths = PlayerPrefs.GetInt(P+"Deaths", 0);
        Won = false; Lost = false; IntroShown = true;
    }
    public static void ClearContinue() { PlayerPrefs.DeleteKey(P+"Has"); PlayerPrefs.Save(); }
    public static void Die()
    {
        Deaths++; Lives--;
        AchievementSystem.NotifyDeath();
        if (Lives <= 0) { Lost = true; ClearContinue(); }
        else SaveContinue();
    }
}
