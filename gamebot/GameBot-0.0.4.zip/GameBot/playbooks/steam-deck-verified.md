# Steam Deck Verified checklist
- Resolution 1280x800 (16:10) default on Deck, UI legible: min text 9 px at 1280x800 (aim 12+). Test at 1280x800 window.
- Full controller support: every action on gamepad, correct Deck/Xbox glyphs, no mouse-only menus, no launcher.
- On-screen keyboard: call SteamUtils.ShowGamepadTextInput (or ShowFloatingGamepadTextInput) for text fields.
- Performance: stable 30+ fps at a Deck preset (Low/Deck), 40 Hz option nice; shader cache/precompile to avoid stutter; no anti-cheat incompatible with Proton.
- Proton: test the Windows build under Proton (no native Linux build needed). Avoid launchers, kernel anti-cheat, unsupported video codecs (use VP9/H.264 in WebM/MP4).
- Suspend/resume safe; Steam Cloud saves on.
- Valve tests and assigns the badge after release (human/Valve gate). Bot prepares: Deck preset in settings, 1280x800 UI pass, glyphs, QA matrix row in fps_passes.md.
