using UnityEngine;
/// <summary>Horror flashlight: F toggles, battery drains while on, recharges slowly when off.</summary>
public class FlashlightController : MonoBehaviour
{
    public static bool On = true; Light l;
    void Start()
    {
        var cam = GetComponentInChildren<Camera>(); var go = new GameObject("Flashlight"); go.transform.SetParent(cam ? cam.transform : transform, false); go.transform.localPosition = new Vector3(0.25f, -0.2f, 0.1f); go.transform.localRotation = Quaternion.Euler(6f, -2f, 0);
        l = go.AddComponent<Light>(); l.type = LightType.Spot; l.range = 26; l.spotAngle = 62; l.innerSpotAngle = 28; l.intensity = 45; l.shadows = LightShadows.Soft; l.color = new Color(1f, 0.95f, 0.8f); On = true;
    }
    void Update()
    {
        if (PauseMenu.IsPaused || MainMenuUI.InMenu) return;
        if (Input.GetKeyDown(KeyCode.F)) On = !On;
        GenreState.Battery = Mathf.Clamp(GenreState.Battery + (On ? -2.2f : 1.2f) * Time.deltaTime, 0, 100);
        if (GenreState.Battery <= 0) On = false;
        l.enabled = On; l.intensity = 45f * (0.4f + 0.6f * GenreState.Battery / 100f) * (GenreState.Battery < 15 && Random.value < 0.1f ? 0.2f : 1f);
    }
}
