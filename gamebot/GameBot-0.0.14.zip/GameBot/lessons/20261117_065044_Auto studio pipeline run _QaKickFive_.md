# Auto studio pipeline run (QaKickFive)

Tags: auto studio pipeline
Saved: 2026-11-17T06:50:44

run_auto_game_pipeline created 34 files under C:\Users\Derrold PC\Documents\GameProjects\QaKickFive and UNITY 6000.6.5f1: background job started -> create QaKickFiveUnity -> Sports game (gameplay template: sports; menu, settings, achievements, owned genre kit) -> . Next: check Builds\auto_unity_status.txt, then work TaskBoard 'Auto next actions' with tools.
