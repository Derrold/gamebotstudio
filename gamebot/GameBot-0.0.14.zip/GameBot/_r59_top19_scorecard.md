# Game Bot r59 E2E scorecard — official top-19 + 2 hard chats

Started: 2026-11-11 02:25:37 AM CT  Updated: 2026-11-11 04:41:08 AM CT  Machine: ExtremeHybrid (3060 Laptop)  Model: gamebot-trained (r59, digest ba953dbfc9de…, parent gamebot-r59-5080-q4_k_m.gguf)

Live setup: r37 was backed up as `gamebot-r37-eh-backup` (digest 294ef87c0e64…). `gamebot-r37-5080` and `gamebot-r35-rollback` were not deleted.

Deletion policy: after each recorded test the project under Documents\GameProjects, its exe/installer, and its desktop shortcut were deleted, except **test 5 (QuartzFront)**, which is left intact for Derrold. OpenWorldPlus, OpenWorldPlusTwo, and Documents\UnityProjects were never touched.

| # | kind | genre | title | engine | ask name | ask engine | ask assets | DONE OK | genre-specific | minutes | notes |
|---|---|---|---|---|---|---|---|---|---|---|---|
| 1 | genre | action | AshHook | Unity | Y | Y | Y | Y | N | 7.3 | mode=action family=platformer — shared platformer template (expected family platformer) |
| 2 | genre | adventure | RiverKite | Unity | Y | Y | Y | Y | Y | 7.6 | mode=adventure family=adventure (dedicated template) |
| 3 | genre | rpg | ThornPsalm | Unity | Y | Y | Y | Y | Y | 5.7 | mode=rpg family=rpg (dedicated template) |
| 4 | genre | shooter | NickelLance | Unity | Y | Y | Y | Y | Y | 5.7 | mode=shooter family=fps (dedicated template) |
| 5 | genre | strategy | QuartzFront | Unity | Y | Y | Y | Y | N | 5.5 | mode=strategy family=platformer — shared platformer template (expected family platformer) |
| 6 | genre | simulation | CounterTill | Unity | Y | Y | Y | Y | Y | 6.6 | mode=simulation family=sim (dedicated template) |
| 7 | genre | sports | LaneBreaker | Unreal | Y | Y | Y | N | N | 1.8 | Unreal path copies the First Person template only; no genre-specific gameplay or packaged exe/installer/shortcut / Unreal scaffold only (no Windows package pipeline) |
| 8 | genre | racing | CopperHairpin | Unity | Y | Y | Y | Y | Y | 5.7 | mode=racing family=racing (dedicated template) |
| 9 | genre | fighting | JawlineRift | Unity | Y | Y | Y | Y | N | 6.1 | mode=fighting family=platformer — shared platformer template (expected family platformer) |
| 10 | genre | horror | PaleCistern | Unity | Y | Y | Y | Y | Y | 7.6 | mode=horror family=horror (dedicated template) |
| 11 | genre | platformer | Foxledge | Unity | Y | Y | Y | Y | Y | 5.5 | mode=platformer family=platformer (platformer is the native family) |
| 12 | genre | puzzle | GlyphLatch | Unity | Y | Y | Y | Y | Y | 5.4 | mode=puzzle family=puzzle (dedicated template) |
| 13 | genre | open_world | WideMeridian | Unreal | Y | Y | Y | N | N | 1.7 | Unreal path copies the First Person template only; no genre-specific gameplay or packaged exe/installer/shortcut / Unreal scaffold only (no Windows package pipeline) |
| 14 | genre | survival | EmberCamp | Unity | Y | Y | Y | Y | Y | 5.6 | mode=survival family=survival (dedicated template) |
| 15 | genre | sandbox | BrickLumen | Unity | Y | Y | Y | Y | Y | 5.4 | mode=sandbox family=survival (dedicated template) |
| 16 | genre | stealth | SoftLatch | Unity | Y | Y | Y | Y | Y | 9.2 | mode=stealth family=horror (dedicated template) |
| 17 | genre | battle_royale | RingAshen | Unity | Y | Y | Y | Y | Y | 5.9 | mode=battle_royale family=fps (dedicated template) |
| 18 | genre | moba | TwinSpire | Unity | Y | Y | Y | Y | N | 5.9 | mode=moba family=platformer — shared platformer template (expected family platformer) |
| 19 | genre | mmorpg | VaultHearth | Unity | Y | Y | Y | Y | Y | 6.8 | mode=mmorpg family=rpg (dedicated template) |
| 20 | hard_multi | horror | Open Horror Plus | Unity | N | Y | Y | Y | Y | 7.9 | did not ask title / mode=horror family=horror (dedicated template) |
| 21 | hard_assets | simulation | Packlane Mart | Unity | Y | Y | Y | Y | Y | 7.9 | used owned pack #1; mode=simulation family=sim (dedicated template) |

**Genre builds:** 19/19 recorded, DONE OK 17/19 (all 17 Unity Y; both Unreal N), genre-specific 13/19.
**Hard chats:** 2/2 recorded, both DONE OK and genre-specific.
**Wall clock:** 02:25:37 AM CT to 04:41:08 AM CT (2h 16m). Recorded minutes sum 126.8.

## Left intact for Derrold (test 5)
- Title: **QuartzFront** (genre strategy, Unity)
- Project: `C:\Users\ExtremeHybrid\Documents\GameProjects\QuartzFront`
- Shortcut: `C:\Users\ExtremeHybrid\Desktop\QuartzFront.lnk`
- Exe: `C:\Users\ExtremeHybrid\Documents\GameProjects\QuartzFront\Builds\Windows\QuartzFront.exe`
- Installer: `C:\Users\ExtremeHybrid\Documents\GameProjects\QuartzFront\Builds\Installer\QuartzFront_Windows.zip`

## Transcripts
Per-test logs are in `C:\Users\ExtremeHybrid\ollama-web\_r59_e2e_logs`.

## Bugs fixed this run
- Unity exe picker in `auto_studio.py` (embedded `auto_unity.ps1`): `Get-ChildItem ... -Filter *.exe | Select-Object -First 1` could pick `UnityCrashHandler64.exe` and then point the desktop shortcut at it. Seen on test 19 VaultHearth (real `VaultHearth.exe` existed; status/shortcut targeted the crash handler). Driver still scored DONE OK because it filtered the crash handler.
- Backup: `C:\Users\ExtremeHybrid\ollama-web\auto_studio.py.bak_e2e_exefix_20261111`
- New picker prefers `Builds\Windows\__NAME__.exe`, else the first `*.exe` whose name does not match `^UnityCrashHandler`.
- Already-written scripts also patched: `OpenHorrorPlus\Tools\auto_unity.ps1` and `PacklaneMart\Tools\auto_unity.ps1`. Tests 20 and 21 status correctly used `OpenHorrorPlus.exe` and `PacklaneMart.exe`.
- Game Bot was not restarted mid-run (would have dropped the live chat/Unity jobs). The running process still holds the old `auto_studio` in memory; new projects created after a restart will get the fixed script automatically.
- Unreal delete: `rmtree(..., ignore_errors=True)` reported success but left `Content` / `DerivedDataCache` / `Saved` until UnrealEditor released locks. Leftovers for LaneBreaker and WideMeridian were removed manually after the editor exited. Not a code fix.

## Platformer-fallback genres (Unity)
These official intake genres map to the shared platformer family (`SceneBuilder.FamilyFor` / `auto_studio.builder_family`). Gameplay was not genre-specific. Templates were not rewritten mid-run.
- action (AshHook)
- strategy (QuartzFront) — kept for Derrold
- fighting (JawlineRift)
- moba (TwinSpire)

Sports is also in that Unity fallback family, but this run requested Unreal for LaneBreaker, so it never used the Unity platformer template.

## Related family mappings (scored genre-specific because a dedicated family was used, but the loop is not unique to the requested genre)
- sandbox (BrickLumen) -> survival
- stealth (SoftLatch) -> horror
- battle_royale (RingAshen) -> fps (via the "battle" substring)
- mmorpg (VaultHearth) -> rpg (because "rpg" is a substring of "mmorpg")

## Unreal packaging gap
Both Unreal tests (sports LaneBreaker, open_world WideMeridian) only scaffolded the First Person template (`TP_FirstPersonBP`). The pipeline writes a `.uproject` (hardcoded Description "hunting game"), launches UnrealEditor, and writes `Builds\auto_unreal_status.txt`. There is no Windows package, exe, installer, or desktop shortcut. Not a small mid-run fix.

## Blockers before early access
- Missing dedicated Unity gameplay families for action, strategy, fighting, and moba (all fall back to the shared platformer template). Sports would too on the Unity path.
- Sandbox, stealth, battle_royale, and mmorpg reuse another genre's dedicated family rather than a unique loop.
- Unreal path does not package a playable Windows build (no exe / installer / shortcut) and does not apply a genre-specific template.
- The installer/shortcut still ship whatever `$exe` the picker selected; the crash-handler bug is fixed on disk but Game Bot must be restarted before new projects inherit it from memory.
- Depot/installer must ship r59 (gamebot-trained), not the base Qwen / older r37 image.
- Store page and checkout ($89.99 EA) still need Derrold's explicit yes before taking money.

## Packlane Mart (hard owned-assets) notes
Intake asked engine, title, and assets. Driver answered the first asset question with "1" (it matched "Asset question 1/5") instead of first saying "my assets"; Game Bot still queued owned pack #1 `heavycrosss - Harbor Props Pack vol1` (32.6 MB). First player build DONE OK at 4:38:16 AM CT with `PacklaneMart.exe`; status then flipped to RUNNING for the owned-pack import + rebuild at 4:38:36; second DONE OK at 4:40:53 with the same correct exe. Also fetched CC0 Gothic Cabinet 01 for the props question. Project, exe/installer, and shortcut were deleted after record.

## Stale pointer cleanup
After PacklaneMart was deleted, `Documents\GameProjects\.current` still pointed at it. That pointer file was removed at 4:44 AM CT. QuartzFront, OpenWorldPlus, and OpenWorldPlusTwo were not touched.
