using UnityEngine;
/// <summary>Puzzle player: pushes blocks it walks into; R resets room.</summary>
public class BlockPusher : MonoBehaviour
{
    float next;
    void OnControllerColliderHit(ControllerColliderHit h)
    {
        var b = h.collider.GetComponent<PushBlock>(); if (!b || Time.time < next) return;
        if (b.TryPush(h.moveDirection)) next = Time.time + 0.35f;
    }
    void Update()
    {
        if (Input.GetKeyDown(KeyCode.R) && !PauseMenu.IsPaused) foreach (var b in FindObjectsByType<PushBlock>(FindObjectsSortMode.None)) b.ResetBlock();
    }
}
