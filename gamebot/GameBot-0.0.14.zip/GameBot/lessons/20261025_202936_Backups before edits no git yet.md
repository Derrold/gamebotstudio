# Backups before edits no git yet

Tags: git lfs backup hygiene
Saved: 2026-10-25T20:29:36

copy Scripts to Backups/<tag>_<time> before edits; if git added (user OK) use Unity.gitignore + LFS for fbx/blend/png/wav. Source: https://github.com/github/gitignore/blob/main/Unity.gitignore
