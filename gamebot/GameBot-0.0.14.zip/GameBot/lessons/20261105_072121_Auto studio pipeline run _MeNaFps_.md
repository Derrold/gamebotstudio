# Auto studio pipeline run (MeNaFps)

Tags: auto studio pipeline
Saved: 2026-11-05T07:21:21

run_auto_game_pipeline created 32 files under C:\Users\ExtremeHybrid\Documents\GameProjects\MeNaFps and UNITY 6000.6.5f1: background job started -> create MeNaFpsUnity -> Assets/Scenes/Slice01.unity (grey-box, player, goal, HUD) -> Builds\Windows\MeNaFps.exe. Stat. Next: check Builds\auto_unity_status.txt, then work TaskBoard 'Auto next actions' with tools.
