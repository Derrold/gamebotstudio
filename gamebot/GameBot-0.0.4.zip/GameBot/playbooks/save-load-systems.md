# Save / load systems
- Data: one serializable SaveData class (schemaVersion, profile, progression, inventory ids, settings refs, timestamps). JSON (JsonUtility/Newtonsoft) to Application.persistentDataPath\saves\slot<N>.json.
- Write atomically: write slot.tmp -> flush -> rename over slot.json; keep slot.bak (last good). On load failure fall back to .bak, never wipe.
- Migrations: `if (data.schemaVersion < 3) Migrate2to3(data)`; never delete unknown fields; add defaults for new keys.
- Settings separate from progress (settings.json or PlayerPrefs). PlayerPrefs only for small settings (Windows stores them in the registry).
- Autosave on checkpoints + quit (Application.quitting); throttle; show a saving icon; never save mid-transition.
- Steam Cloud: Auto-Cloud on the saves folder (Steamworks config, human gate for real AppID); Steam Deck needs cloud too.
- Tests: round-trip test (save -> load -> deep equal), corrupted-file test, migration test from every old version; tests must use a temp folder, NEVER the creator's or players' real saves.
- Anti-cheat for single player: not needed; checksum only to detect corruption.
