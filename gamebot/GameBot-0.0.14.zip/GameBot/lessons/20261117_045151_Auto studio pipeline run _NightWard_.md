# Auto studio pipeline run (NightWard)

Tags: auto studio pipeline
Saved: 2026-11-17T04:51:51

run_auto_game_pipeline created 34 files under C:\Users\Derrold PC\Documents\GameProjects\NightWard and UNITY: skipped (GAMEBOT_SKIP_UNITY=1). Run later: C:\Users\Derrold PC\Documents\GameProjects\NightWard\Tools\auto_unity.ps1. Next: check Builds\auto_unity_status.txt, then work TaskBoard 'Auto next actions' with tools.
