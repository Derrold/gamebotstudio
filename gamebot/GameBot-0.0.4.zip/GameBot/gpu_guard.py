"""GPU guard (0.0.4): never run the AI model and a Unity batchmode build/import on the GPU at the same time.

A tester's RX 6700 XT PC hard-rebooted while chatting during a build (GPU at full load). So:
- right before any Unity batchmode build/import starts, the model is unloaded from VRAM
  (Ollama /api/generate with keep_alive 0 for gamebot-trained and anything else loaded);
- while a Unity/Unreal build runs, chat gets status-only replies or is queued - no model load;
- the model reloads by itself on the next chat after the build ends.
"""
from __future__ import annotations

import json
import os
import threading
import time
import urllib.request
from pathlib import Path

PAUSE_MSG = "AI paused while Unity builds to protect your GPU"
_STATE = {"started": 0.0, "unloaded": 0.0, "last": []}
_GRACE_S = 45  # a just-started job may not show RUNNING yet


def _ollama() -> str:
    return os.environ.get("OLLAMA_HOST", "http://127.0.0.1:11434").rstrip("/")


def _model() -> str:
    return os.environ.get("OLLAMA_MODEL", "gamebot-trained")


def _post(path: str, body: dict, timeout: float = 15) -> bytes:
    req = urllib.request.Request(_ollama() + path, data=json.dumps(body).encode("utf-8"),
                                 headers={"Content-Type": "application/json"}, method="POST")
    with urllib.request.urlopen(req, timeout=timeout) as r:
        return r.read()


def loaded_models() -> list[str]:
    try:
        with urllib.request.urlopen(_ollama() + "/api/ps", timeout=5) as r:
            d = json.loads(r.read().decode("utf-8") or "{}")
        return [str(m.get("name") or m.get("model")) for m in d.get("models") or [] if m.get("name") or m.get("model")]
    except Exception:
        return []


def unload_model() -> list[str]:
    """Free VRAM: keep_alive 0 for gamebot-trained plus any other model Ollama has loaded. Never raises."""
    names = [_model()] + [m for m in loaded_models() if m != _model()]
    done = []
    for n in names:
        try:
            _post("/api/generate", {"model": n, "keep_alive": 0}, timeout=20)
            done.append(n)
        except Exception:
            pass
    _STATE.update(unloaded=time.time(), last=done)
    return done


def before_unity(wait: bool = True) -> list[str]:
    """Call right before a Unity/Unreal batchmode process starts: marks the pause and unloads the model."""
    _STATE["started"] = time.time()
    if wait:
        return unload_model()
    threading.Thread(target=unload_model, daemon=True).start()
    return []


def building() -> str:
    """Name of the game whose background Unity/Unreal job is queued/running ('' when none)."""
    try:
        from auto_studio import unity_job_running
        from gamedev_core import GAME_PROJECTS
        gp = Path(os.environ.get("GAMEBOT_PROJECTS") or GAME_PROJECTS)
        for d in gp.iterdir():
            if d.is_dir() and not d.name.startswith(".") and unity_job_running(d):
                return d.name
    except Exception:
        pass
    return ""


def paused() -> str:
    """Non-empty (game name or 'Unity') while the AI must stay off the GPU."""
    if os.environ.get("GAMEBOT_GPU_GUARD", "1") == "0":
        return ""
    b = building()
    if b:
        return b
    if time.time() - float(_STATE.get("started") or 0) < _GRACE_S:
        return "Unity"
    return ""


def status_line() -> str:
    return PAUSE_MSG if paused() else ""


def paused_reply(n_queued: int = 0) -> str:
    q = (f" I queued your message (#{n_queued} in line) and will answer it as soon as the build finishes."
         if n_queued else " Ask \"status\" any time; I'll pick up as soon as the build finishes.")
    return PAUSE_MSG + "." + q


def wait_until_clear(poll_s: float = 5.0, max_s: float = 6 * 3600) -> bool:
    t0 = time.time()
    while paused():
        if time.time() - t0 > max_s:
            return False
        time.sleep(poll_s)
    return True
