# Unreal UMG and Blueprints vs C++

Tags: unreal,ui,code
Saved: 2026-10-25T20:00:16

Core systems in C++ (UCLASS/UPROPERTY/UFUNCTION BlueprintCallable), Blueprints subclass for tuning/content; data in DataAssets/DataTables. UI = Widget Blueprint + CreateWidget + AddToViewport; LNK2019 -> add module (UMG, EnhancedInput) to Build.cs. Sources: https://dev.epicgames.com/documentation/en-us/unreal-engine/umg-ui-designer-for-unreal-engine https://dev.epicgames.com/documentation/en-us/unreal-engine/blueprints-visual-scripting-in-unreal-engine
