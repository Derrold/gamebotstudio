using System.IO;
using UnityEditor;
using UnityEditor.SceneManagement;
using UnityEngine;
using UnityEngine.SceneManagement;

// Game Bot full-game scene builder: MainMenu + Game + Windows player. Also ImportOwnedPackage.
public static partial class SceneBuilder
{
    const string MenuPath = "Assets/Scenes/MainMenu.unity";
    const string GamePath = "Assets/Scenes/Game.unity";

    [MenuItem("GameBot/Build Scenes")]
    public static void Build()
    {
        ResetStatics();
        Directory.CreateDirectory("Assets/Scenes");
        string game = System.Environment.GetEnvironmentVariable("GAMEBOT_GAME_NAME");
        if (!string.IsNullOrEmpty(game)) PlayerSettings.productName = game;
        ForceBothInput();
        BuildMainMenu();
        BuildGame();
        EditorBuildSettings.scenes = new[]
        {
            new EditorBuildSettingsScene(MenuPath, true),
            new EditorBuildSettingsScene(GamePath, true)
        };
        AssetDatabase.SaveAssets();
        Debug.Log("SCENEBUILDER_OK " + MenuPath + " " + GamePath);
    }

    public static void BuildWindows()
    {
        Build();
        string outDir = System.Environment.GetEnvironmentVariable("GAMEBOT_BUILD_DIR");
        if (string.IsNullOrEmpty(outDir)) outDir = Path.GetFullPath("../Builds/Windows");
        Directory.CreateDirectory(outDir);
        var opts = new BuildPlayerOptions
        {
            scenes = new[] { MenuPath, GamePath },
            locationPathName = Path.Combine(outDir, PlayerSettings.productName + ".exe"),
            target = BuildTarget.StandaloneWindows64,
            options = BuildOptions.None
        };
        string qa = QaGate();
        if (qa != null)
        {
            Debug.LogError("QA_FAIL " + qa);
            try { File.WriteAllText(Path.Combine(outDir, "..", "qa_fail.txt"), qa); } catch { }
            EditorApplication.Exit(3);
            return;
        }
        var report = BuildPipeline.BuildPlayer(opts);
        Debug.Log("BUILD_RESULT " + report.summary.result + " " + opts.locationPathName);
        if (report.summary.result != UnityEditor.Build.Reporting.BuildResult.Succeeded) EditorApplication.Exit(1);
    }

    /// <summary>Review fix 6: every Build() starts clean - no stale brief, asset map, materials, pools or terrain
    /// from an earlier build in the same editor session (e.g. ImportAndRebuild).</summary>
    static void ResetStatics()
    {
        _briefLoaded = false; _brief = null; _amapLoaded = false; _amap = null;
        _matConv.Clear(); _nameTex.Clear(); _matConvN = 0; _matTexN = 0;
        _coverPool = null; _terr = null; _ownedCache = null; _ctrl.Clear();
        _dressCount = 0; _dressUsed.Clear(); _blocked.Clear(); _mode = "";
    }

    /// <summary>Review fix 6: refuse to ship a broken game. Returns a plain-English reason, or null when OK.</summary>
    static string QaGate()
    {
        if (!File.Exists(GamePath)) return "the game scene was not created (" + GamePath + ").";
        var scene = EditorSceneManager.OpenScene(GamePath, OpenSceneMode.Single);
        var probs = new System.Collections.Generic.List<string>();
        if (Object.FindObjectsByType<Camera>(FindObjectsSortMode.None).Length == 0) probs.Add("there is no camera, so the screen would be black");
        if (Object.FindObjectsByType<AudioListener>(FindObjectsSortMode.None).Length == 0) probs.Add("there is no AudioListener, so the game would have no sound");
        int rends = Object.FindObjectsByType<Renderer>(FindObjectsSortMode.None).Length;
        if (rends < 10) probs.Add("the level is almost empty (" + rends + " visible objects)");
        int missing = 0;
        foreach (var go in Object.FindObjectsByType<GameObject>(FindObjectsInactive.Include, FindObjectsSortMode.None))
            missing += GameObjectUtility.GetMonoBehavioursWithMissingScriptCount(go);
        if (missing > 0) Debug.LogWarning("QA_WARN " + missing + " missing-script components (usually demo scripts inside an asset pack)");
        foreach (var g in Object.FindObjectsByType<GunController>(FindObjectsSortMode.None))
        {
            var cam = g.GetComponentInChildren<Camera>(); var m = cam ? cam.transform.Find("ViewGun/Muzzle") : null; var vg = cam ? cam.transform.Find("ViewGun") : null;
            if (m && vg)
            {
                var b = new Bounds(vg.position, Vector3.zero); foreach (var r in vg.GetComponentsInChildren<Renderer>()) b.Encapsulate(r.bounds);
                if (Vector3.Dot(m.position - b.center, cam.transform.forward) <= 0f) probs.Add("the gun model points sideways or backwards");
            }
        }
        if (probs.Count == 0) { Debug.Log("QA_OK renderers=" + rends); return null; }
        return "The build was stopped because " + string.Join("; ", probs) + ".";
    }

    public static void ImportOwnedPackage()
    {
        string pkg = System.Environment.GetEnvironmentVariable("GAMEBOT_IMPORT_PACKAGE");
        if (string.IsNullOrEmpty(pkg) || !File.Exists(pkg))
        {
            Debug.LogError("IMPORT_FAIL missing " + pkg);
            EditorApplication.Exit(2);
            return;
        }
        Directory.CreateDirectory("Assets/Art/Imports");
        AssetDatabase.ImportPackage(pkg, false);
        AssetDatabase.Refresh();
        Debug.Log("IMPORT_OK " + pkg);
    }

    public static void ImportAndRebuild()
    {
        ImportOwnedPackage();
        BuildWindows();
    }

    static void ForceBothInput()
    {
        try
        {
            var objs = AssetDatabase.LoadAllAssetsAtPath("ProjectSettings/ProjectSettings.asset");
            if (objs == null || objs.Length == 0) return;
            var so = new SerializedObject(objs[0]);
            var p = so.FindProperty("activeInputHandler");
            if (p != null) { p.intValue = 2; so.ApplyModifiedPropertiesWithoutUndo(); }
        }
        catch (System.Exception e) { Debug.LogWarning("input handler: " + e.Message); }
    }

    static void BuildMainMenu()
    {
        var scene = EditorSceneManager.NewScene(NewSceneSetup.DefaultGameObjects, NewSceneMode.Single);
        var cam = GameObject.Find("Main Camera");
        if (cam != null) cam.transform.position = new Vector3(0, 2, -8);
        AddConfig(Genre());
        new GameObject("MainMenuUI").AddComponent<MainMenuUI>();
        // backdrop cubes
        for (int i = 0; i < 8; i++)
        {
            var b = GameObject.CreatePrimitive(PrimitiveType.Cube);
            b.name = "Decor_" + i;
            float a = i * 45f * Mathf.Deg2Rad;
            b.transform.position = new Vector3(Mathf.Cos(a) * 6f, 0.5f + (i % 3), Mathf.Sin(a) * 6f);
        }
        EditorSceneManager.SaveScene(scene, MenuPath);
    }

    /// <summary>Creator's intake brief written by auto_studio (Tools/game_brief.json). Single source for genre + story.</summary>
    [System.Serializable]
    public class Brief
    {
        public string title = "", display_title = "", genre = "", genre_label = "", family = "";
        public string loop = "", story = "", setting = "", style = "";
        public string[] goals = new string[0];
        public string[] ach_ids = new string[0], ach_titles = new string[0], ach_descs = new string[0];
    }
    static Brief _brief; static bool _briefLoaded;
    static Brief LoadBrief()
    {
        if (_briefLoaded) return _brief;
        _briefLoaded = true;
        string p = System.Environment.GetEnvironmentVariable("GAMEBOT_BRIEF");
        if (string.IsNullOrEmpty(p) || !File.Exists(p)) p = "../Tools/game_brief.json";
        try { if (File.Exists(p)) _brief = JsonUtility.FromJson<Brief>(File.ReadAllText(p)); }
        catch (System.Exception e) { Debug.LogWarning("BRIEF_FAIL " + e.Message); }
        if (_brief != null) Debug.Log("GAMEBOT_BRIEF genre=" + _brief.genre + " family=" + _brief.family + " goals=" + (_brief.goals == null ? 0 : _brief.goals.Length));
        return _brief;
    }

    /// <summary>Intake genre id the creator picked (open_world, survival, ...).</summary>
    static string IntakeGenre()
    {
        var b = LoadBrief();
        if (b != null && !string.IsNullOrEmpty(b.genre)) return b.genre.ToLower();
        string g = (System.Environment.GetEnvironmentVariable("GAMEBOT_GENRE") ?? "").ToLower();
        if (string.IsNullOrEmpty(g) && File.Exists("../Tools/genre.txt")) g = File.ReadAllText("../Tools/genre.txt").Trim().ToLower();
        return g;
    }

    /// <summary>Gameplay family (which builder) that implements the intake genre.</summary>
    static string Genre()
    {
        var b = LoadBrief();
        if (b != null && !string.IsNullOrEmpty(b.family)) return b.family.ToLower();
        return FamilyFor(IntakeGenre());
    }
    // FamilyFor (exact + priority routing) lives in SceneBuilderGenres.cs

    static void AddConfig(string mode)
    {
        var cfg = new GameObject("GenreConfig").AddComponent<GenreConfig>();
        var b = LoadBrief();
        string ig = IntakeGenre();
        cfg.family = mode;
        cfg.mode = string.IsNullOrEmpty(ig) ? mode : ig;
        cfg.title = (b != null && !string.IsNullOrEmpty(b.display_title)) ? b.display_title : PlayerSettings.productName;
        if (b != null)
        {
            cfg.story = b.story ?? ""; cfg.setting = b.setting ?? ""; cfg.loop = b.loop ?? ""; cfg.style = b.style ?? "";
            cfg.goals = b.goals ?? new string[0];
            cfg.achIds = b.ach_ids ?? new string[0]; cfg.achTitles = b.ach_titles ?? new string[0]; cfg.achDescs = b.ach_descs ?? new string[0];
        }
    }

    static Material Mat(Color c) { var u = UnityEngine.Rendering.GraphicsSettings.currentRenderPipeline != null ? Shader.Find("Universal Render Pipeline/Lit") : null; var m = new Material(u ?? Shader.Find("Standard")) { color = c }; if (u) m.SetColor("_BaseColor", c); return m; }

    static GameObject Box(string n, Vector3 p, Vector3 s, Color c, Transform parent = null)
    {
        var b = GameObject.CreatePrimitive(PrimitiveType.Cube); b.name = n; b.transform.position = p; b.transform.localScale = s;
        b.GetComponent<Renderer>().sharedMaterial = Mat(c); if (parent) b.transform.SetParent(parent, true); return b;
    }

    static void BuildGame()
    {
        string g = Genre();
        Debug.Log("GAMEBOT_GENRE_MODE " + g + " intake=" + IntakeGenre());
        if (BuildExtra(g)) return;
        if (g == "fps") { BuildFps(); return; }
        if (g == "racing") { BuildRacing(); return; }
        if (g == "horror") { BuildHorror(); return; }
        if (g == "rpg") { BuildRpg(); return; }
        if (g == "puzzle") { BuildPuzzle(); return; }
        if (g == "survival") { BuildSurvival(); return; }
        if (g == "adventure") { BuildAdventure(); return; }
        if (g == "sim") { BuildSim(); return; }
        if (g == "roguelike") { BuildRogue(); return; }
        BuildPlatformer();
    }

    static void BuildFps() { BuildFpsWorld(); }

    static GameObject MakeWalker(Vector3 pos)
    {
        var player = GameObject.CreatePrimitive(PrimitiveType.Capsule);
        player.name = "Player"; player.tag = "Player"; player.transform.position = pos;
        Object.DestroyImmediate(player.GetComponent<CapsuleCollider>());
        var cc = player.AddComponent<CharacterController>(); cc.height = 2f; cc.center = new Vector3(0, 1f, 0);
        player.AddComponent<GamePlayer>();
        player.GetComponent<MeshRenderer>().enabled = false;
        var camGo = GameObject.Find("Main Camera");
        if (camGo != null) { camGo.transform.SetParent(player.transform, false); camGo.transform.localPosition = new Vector3(0f, 1.6f, 0f); camGo.transform.localRotation = Quaternion.identity; }
        return player;
    }

    static void BuildRacing()
    {
        var scene = EditorSceneManager.NewScene(NewSceneSetup.DefaultGameObjects, NewSceneMode.Single);
        AddConfig("racing");
        var ground = GameObject.CreatePrimitive(PrimitiveType.Plane); ground.name = "Grass"; ground.transform.localScale = new Vector3(40f, 1f, 40f);
        ground.GetComponent<Renderer>().sharedMaterial = Mat(new Color(0.25f, 0.5f, 0.2f));
        // oval track: road segments + barriers + ordered checkpoints
        var track = new GameObject("Track").transform;
        float rx = 90f, rz = 55f; int segs = 48; int cps = 8;
        for (int i = 0; i < segs; i++)
        {
            float a0 = i * Mathf.PI * 2f / segs, a1 = (i + 1) * Mathf.PI * 2f / segs;
            Vector3 p0 = new Vector3(Mathf.Cos(a0) * rx, 0, Mathf.Sin(a0) * rz), p1 = new Vector3(Mathf.Cos(a1) * rx, 0, Mathf.Sin(a1) * rz);
            Vector3 mid = (p0 + p1) / 2f, dir = (p1 - p0); float len = dir.magnitude + 0.6f;
            var rot = Quaternion.LookRotation(dir.normalized);
            var road = Box("Road_" + i, mid + Vector3.up * 0.05f, new Vector3(14f, 0.1f, len), new Color(0.18f, 0.18f, 0.2f), track); road.transform.rotation = rot;
            Vector3 right = rot * Vector3.right;
            var b1 = Box("BarrierOut_" + i, mid + right * 7.5f + Vector3.up * 0.6f, new Vector3(0.6f, 1.2f, len), i % 2 == 0 ? Color.red : Color.white, track); b1.transform.rotation = rot;
            var b2 = Box("BarrierIn_" + i, mid - right * 7.5f + Vector3.up * 0.6f, new Vector3(0.6f, 1.2f, len), i % 2 == 0 ? Color.white : Color.red, track); b2.transform.rotation = rot;
            if (i % (segs / cps) == 0)
            {
                int idx = i / (segs / cps);
                var cp = new GameObject(idx == 0 ? "Checkpoint_0_StartFinish" : "Checkpoint_" + idx);
                cp.transform.SetPositionAndRotation(p0 + Vector3.up * 2f, rot);
                var bc = cp.AddComponent<BoxCollider>(); bc.isTrigger = true; bc.size = new Vector3(14f, 4f, 1.5f);
                cp.AddComponent<RaceCheckpoint>().index = idx;
                // visible gate arch
                Box("GatePostL", p0 + right * 7.2f + Vector3.up * 2.5f, new Vector3(0.5f, 5f, 0.5f), idx == 0 ? Color.white : Color.cyan, cp.transform);
                Box("GatePostR", p0 - right * 7.2f + Vector3.up * 2.5f, new Vector3(0.5f, 5f, 0.5f), idx == 0 ? Color.white : Color.cyan, cp.transform);
                var top = Box("GateTop", p0 + Vector3.up * 5f, new Vector3(15f, 0.6f, 0.5f), idx == 0 ? Color.black : Color.cyan, cp.transform); top.transform.rotation = rot;
                foreach (var c in cp.GetComponentsInChildren<Collider>()) if (c.gameObject != cp) Object.DestroyImmediate(c);
            }
        }
        // car: Ezereal truck visual if owned+imported, else primitive body
        var car = new GameObject("PlayerCar"); car.tag = "Player";
        float sa = 3f * Mathf.PI * 2f / segs;
        Vector3 sp = new Vector3(Mathf.Cos(sa) * rx, 0.8f, Mathf.Sin(sa) * rz);
        Vector3 sp2 = new Vector3(Mathf.Cos(sa + 0.05f) * rx, 0.8f, Mathf.Sin(sa + 0.05f) * rz);
        car.transform.SetPositionAndRotation(sp, Quaternion.LookRotation(sp2 - sp));
        var col = car.AddComponent<BoxCollider>(); col.size = new Vector3(2f, 1.2f, 4.2f); col.center = new Vector3(0, 0.6f, 0);
        car.AddComponent<Rigidbody>();
        car.AddComponent<CarController>();
        if (!AttachCarVisual(car))
        {
            Box("Body", car.transform.position + Vector3.up * 0.6f, new Vector3(2f, 0.8f, 4f), new Color(0.9f, 0.4f, 0.1f), car.transform).transform.rotation = car.transform.rotation;
            Box("Cabin", car.transform.position + Vector3.up * 1.2f - car.transform.forward * 0.3f, new Vector3(1.6f, 0.6f, 2f), new Color(0.2f, 0.2f, 0.25f), car.transform).transform.rotation = car.transform.rotation;
            foreach (var c in car.GetComponentsInChildren<Collider>()) if (c != col) Object.DestroyImmediate(c);
        }
        var cam = GameObject.Find("Main Camera"); if (cam) cam.transform.position = car.transform.position - car.transform.forward * 8f + Vector3.up * 3.5f;
        ScatterOwnedProps(Vector3.zero, 150f, 30, false, rx, rz);
        _mode = "racing"; _ovalX = rx; _ovalZ = rz; _ownedCache = null; try { Dress(); } catch (System.Exception e) { Debug.LogWarning("DRESS_FAIL " + e); }
        new GameObject("HUD").AddComponent<GameHUD>();
        new GameObject("Pause").AddComponent<PauseMenu>();
        EditorSceneManager.SaveScene(scene, GamePath);
    }

    static bool AttachCarVisual(GameObject car)
    {
        foreach (var g in AssetDatabase.FindAssets("t:Prefab"))
        {
            var path = AssetDatabase.GUIDToAssetPath(g); var low = path.ToLower();
            if (!(low.Contains("truck") || low.Contains("car") || low.Contains("vehicle"))) continue;
            if (low.Contains("logic only") || low.Contains("tire") || low.Contains("rack") || low.Contains("controller.prefab")) continue;
            var prefab = AssetDatabase.LoadAssetAtPath<GameObject>(path); if (prefab == null) continue;
            if (prefab.GetComponentsInChildren<MeshRenderer>(true).Length == 0) continue;
            var vis = Object.Instantiate(prefab); vis.name = "CarVisual";
            StripBehaviour(vis);
            foreach (var c in vis.GetComponentsInChildren<Collider>(true)) Object.DestroyImmediate(c);
            vis.transform.SetParent(car.transform, false); vis.transform.localPosition = Vector3.zero; vis.transform.localRotation = Quaternion.identity;
            var b = Bounds(vis); if (b.size.magnitude > 0.1f) { float sc = 4.4f / Mathf.Max(b.size.z, b.size.x); if (sc < 0.5f || sc > 2f) vis.transform.localScale = Vector3.one * sc; }
            Debug.Log("CAR_VISUAL " + path);
            return true;
        }
        return false;
    }

    static bool IsWeapon(string low) => low.Contains("weapon") || low.Contains("gun") || low.Contains("rifle") || low.Contains("pistol") || low.Contains("shotgun") || low.Contains("/ar/") || low.Contains("kalashnikov") || low.Contains("blaster") || low.Contains("plasma");

    // ---- pipeline-safe material conversion (fix5) --------------------------------------------------------
    // A URP/HDRP material in a Built-in project (or the reverse) loses its shader -> InternalErrorShader, and
    // m.HasProperty/_BaseMap return nothing, so textures vanished (gray enemies, white props). The values are
    // still in the .mat's serialized m_SavedProperties, so read them from there.
    static readonly string[] AlbedoNames = { "_BaseMap", "_BaseColorMap", "_MainTex", "_Albedo", "_AlbedoMap", "_AlbedoTexture", "_MainTexture", "_Diffuse", "_DiffuseMap", "_BaseTexture", "_BaseColorTexture", "_ColorMap", "_Texture", "_Tex" };
    static readonly string[] NormalNames = { "_BumpMap", "_NormalMap", "_Normal", "_NormalTex", "_NormalTexture" };
    static Texture SerTex(Material m, string[] names, bool anyAlbedo = false)
    {
        if (m == null) return null;
        try
        {
            var envs = new SerializedObject(m).FindProperty("m_SavedProperties.m_TexEnvs"); if (envs == null) return null;
            var map = new System.Collections.Generic.Dictionary<string, Texture>();
            for (int i = 0; i < envs.arraySize; i++)
            {
                var e = envs.GetArrayElementAtIndex(i); var f = e.FindPropertyRelative("first"); var t = e.FindPropertyRelative("second.m_Texture");
                if (f == null || t == null) continue; var tx = t.objectReferenceValue as Texture; if (tx) map[f.stringValue] = tx;
            }
            foreach (var n in names) if (map.ContainsKey(n)) return map[n];
            if (anyAlbedo) foreach (var kv in map) { var k = kv.Key.ToLower(); if ((k.Contains("albedo") || k.Contains("base") || k.Contains("main") || k.Contains("diffuse") || k.Contains("color")) && !k.Contains("normal") && !k.Contains("bump") && !k.Contains("mask") && !k.Contains("detail") && !k.Contains("emiss")) return kv.Value; }
        }
        catch { }
        return null;
    }
    static bool SerCol(Material m, string[] names, out Color c)
    {
        c = Color.white; if (m == null) return false;
        try
        {
            var cols = new SerializedObject(m).FindProperty("m_SavedProperties.m_Colors"); if (cols == null) return false;
            foreach (var n in names) for (int i = 0; i < cols.arraySize; i++) { var e = cols.GetArrayElementAtIndex(i); var f = e.FindPropertyRelative("first"); if (f != null && f.stringValue == n) { c = e.FindPropertyRelative("second").colorValue; return true; } }
        }
        catch { }
        return false;
    }
    static float SerFloat(Material m, string n, float def)
    {
        if (m == null) return def;
        try
        {
            var fl = new SerializedObject(m).FindProperty("m_SavedProperties.m_Floats"); if (fl == null) return def;
            for (int i = 0; i < fl.arraySize; i++) { var e = fl.GetArrayElementAtIndex(i); var f = e.FindPropertyRelative("first"); if (f != null && f.stringValue == n) return e.FindPropertyRelative("second").floatValue; }
        }
        catch { }
        return def;
    }
    // Material with no texture at all (FBX-embedded material, or a binary/legacy .mat whose texture link broke):
    // find the pack's own albedo by name (pinetree -> pinetree-albedo.tga) inside the same Assets/<Pack> folder.
    static readonly System.Collections.Generic.Dictionary<string, Texture> _nameTex = new System.Collections.Generic.Dictionary<string, Texture>();
    static Texture NameTex(Material m, Renderer r)
    {
        string mp = m ? AssetDatabase.GetAssetPath(m) : ""; if ((string.IsNullOrEmpty(mp) || !mp.StartsWith("Assets/")) && r) { var mf = r.GetComponent<MeshFilter>(); var mesh = mf ? mf.sharedMesh : (r is SkinnedMeshRenderer sk ? sk.sharedMesh : null); if (mesh) mp = AssetDatabase.GetAssetPath(mesh); }
        if (string.IsNullOrEmpty(mp) || !mp.StartsWith("Assets/")) return null;
        var parts = mp.Split('/'); if (parts.Length < 3) return null; string pack = parts[0] + "/" + parts[1];
        System.Func<string, string> norm = x => System.Text.RegularExpressions.Regex.Replace((x ?? "").ToLower(), "[^a-z0-9]", "");
        var keys = new System.Collections.Generic.List<string>();
        if (m) keys.Add(norm(m.name.Replace("(Instance)", "")));
        if (r) { var mf = r.GetComponent<MeshFilter>(); if (mf && mf.sharedMesh) keys.Add(norm(mf.sharedMesh.name)); keys.Add(norm(r.name)); }
        keys.Add(norm(System.IO.Path.GetFileNameWithoutExtension(mp)));
        keys.RemoveAll(k => k.Length < 3 || k == "default" || k == "defaultmaterial" || k == "nomaterial" || k.StartsWith("defaultmat") || k == "material" || k == "lambert1" || k == "standardsurface1");
        if (keys.Count == 0) return null;
        string ck = pack + "|" + string.Join(",", keys); if (_nameTex.TryGetValue(ck, out var hit)) return hit;
        var bad = new System.Text.RegularExpressions.Regex("normal|_nrm|_n$|bump|rough|metal|spec|gloss|height|_ao$|occlusion|mask|emiss|_disp|detail", System.Text.RegularExpressions.RegexOptions.IgnoreCase);
        Texture best = null; int bs = 0;
        foreach (var g in AssetDatabase.FindAssets("t:Texture2D", new[] { pack }))
        {
            var tp = AssetDatabase.GUIDToAssetPath(g); var fn = System.IO.Path.GetFileNameWithoutExtension(tp); if (bad.IsMatch(fn)) continue; var nf = norm(fn);
            foreach (var k in keys)
            {
                int sc = 0; string stem = k.Length > 4 ? System.Text.RegularExpressions.Regex.Replace(k, "[0-9]+[a-z]?$", "") : k;
                if (nf == k) sc = 100; else if (nf.StartsWith(k) || nf.Contains(k)) sc = 80; else if (stem.Length >= 3 && nf.Contains(stem)) sc = 60;
                if (sc > 0 && (nf.Contains("albedo") || nf.Contains("diffuse") || nf.Contains("color") || nf.Contains("basecolor"))) sc += 10;
                if (sc > bs) { bs = sc; best = AssetDatabase.LoadAssetAtPath<Texture2D>(tp); }
            }
        }
        _nameTex[ck] = best; if (best) Debug.Log("MAT_TEXRECOVER " + (m ? m.name : "-") + " <- " + AssetDatabase.GetAssetPath(best));
        return best;
    }
    static bool ShaderOk(Material m) => m != null && m.shader != null && m.shader.isSupported && !m.shader.name.Contains("InternalError");
    static readonly System.Collections.Generic.Dictionary<Material, Material> _matConv = new System.Collections.Generic.Dictionary<Material, Material>();
    static int _matConvN, _matTexN;
    static Material ConvertMat(Material m, bool urp, Shader urpLit, Renderer rr = null, bool forceCut = false)
    {
        if (m && _matConv.TryGetValue(m, out var hit) && hit) return hit;
        string nl = m ? m.name.ToLower() : "";
        bool cut = m != null && (SerFloat(m, "_AlphaClip", 0f) > 0.5f || System.Array.IndexOf(m.shaderKeywords ?? new string[0], "_ALPHATEST_ON") >= 0 || nl.Contains("leaf") || nl.Contains("leaves") || nl.Contains("foliage") || nl.Contains("grass") || (m.shader && (m.shader.name.Contains("Cutout") || m.shader.name.Contains("Leaves") || m.shader.name.Contains("Tree"))));
        Texture tex = null, nrm = null;
        if (m != null)
        {
            if (ShaderOk(m)) { foreach (var n in AlbedoNames) if (m.HasProperty(n) && m.GetTexture(n)) { tex = m.GetTexture(n); break; } }
            if (!tex) tex = SerTex(m, AlbedoNames, true);
            nrm = SerTex(m, NormalNames);
        }
        bool byName = false; if (!tex) { tex = NameTex(m, rr); byName = tex != null; }
        if (forceCut) cut = true;
        Color col;
        if (!SerCol(m, new[] { "_BaseColor", "_Color", "_MainColor", "_Tint", "_AlbedoColor" }, out col)) col = tex ? Color.white : new Color(0.55f, 0.55f, 0.57f);
        if (tex && col.maxColorComponent < 0.08f) col = Color.white; // black tint over a real texture = broken conversion
        col.a = 1f;
        Material nm;
        if (urp)
        {
            nm = new Material(urpLit); if (tex) nm.SetTexture("_BaseMap", tex); nm.SetColor("_BaseColor", col);
            if (nrm) { nm.SetTexture("_BumpMap", nrm); nm.EnableKeyword("_NORMALMAP"); }
            if (cut) { nm.SetFloat("_AlphaClip", 1f); nm.SetFloat("_Cutoff", 0.45f); nm.EnableKeyword("_ALPHATEST_ON"); nm.SetFloat("_Cull", 0f); }
        }
        else
        {
            var st = Shader.Find(cut ? "Legacy Shaders/Transparent/Cutout/Diffuse" : "Standard"); if (st == null) return m;
            nm = new Material(st); if (tex) nm.mainTexture = tex; nm.color = col;
            if (cut) nm.SetFloat("_Cutoff", 0.45f);
            if (nrm && !cut) { nm.SetTexture("_BumpMap", nrm); nm.EnableKeyword("_NORMALMAP"); }
            if (!cut) nm.SetFloat("_Glossiness", 0.15f);
        }
        nm.name = (m ? m.name : "gb") + "_gbconv";
        _matConvN++; if (tex) _matTexN++;
        if (m && !byName) _matConv[m] = nm;
        return nm;
    }
    static void FixMat(Renderer r)
    {
        var sh = Shader.Find("Universal Render Pipeline/Lit");
        var mats = r.sharedMaterials;
        bool urp = UnityEngine.Rendering.GraphicsSettings.currentRenderPipeline != null && sh != null;
        bool changed = false;
        for (int i = 0; i < mats.Length; i++)
        {
            var m = mats[i];
            bool ok = ShaderOk(m);
            string shn = ok ? m.shader.name : "";
            bool foreign = !ok || (urp ? !(shn.StartsWith("Universal") || shn.StartsWith("Shader Graphs") || shn.StartsWith("Sprites") || shn.StartsWith("UI/")) : (shn.StartsWith("Universal") || shn.StartsWith("HDRP") || shn.StartsWith("HDRenderPipeline")));
            // Supported shader but the albedo lives under a property it doesn't read (white props): convert too.
            bool lostTex = ok && !foreign && m.HasProperty("_MainTex") && !m.mainTexture && SerTex(m, AlbedoNames, true) != null && !shn.Contains("Nature") && !shn.Contains("Tree");
            // White, texture-less material (FBX-embedded / broken legacy link): recover the pack albedo by name.
            bool white = ok && !foreign && !lostTex && (!m.HasProperty("_MainTex") || !m.mainTexture) && !(m.HasProperty("_BaseMap") && m.GetTexture("_BaseMap")) && (!m.HasProperty("_Color") || m.color.grayscale > 0.85f) && NameTex(m, r) != null;
            // Nature/Tree Soft Occlusion + Tree Creator shaders render washed-out white on plain meshes (no Tree component): convert.
            bool natureLoose = ok && !foreign && (shn.StartsWith("Nature/Tree Soft Occlusion") || shn.StartsWith("Nature/Tree Creator")) && r.GetComponentInParent<Tree>() == null;
            // Glossy/specular foliage (e.g. Standard (Specular setup) bushes) mirrors the sky and looks white: matte cutout instead.
            var rn0 = (r.name + " " + (m ? m.name : "")).ToLower();
            bool fol0 = rn0.Contains("pine") || rn0.Contains("fern") || rn0.Contains("leaf") || rn0.Contains("leaves") || rn0.Contains("bush") || rn0.Contains("foliage") || rn0.Contains("grass") || rn0.Contains("conifer") || rn0.Contains("branch") || rn0.Contains("plant") || rn0.Contains("shrub");
            if (ok && !foreign && fol0 && (shn.StartsWith("Standard") || shn.StartsWith("Autodesk"))) natureLoose = true;
            if (natureLoose) foreign = true;
            if (!foreign && !lostTex && !white) continue;
            var rn = (r.name + " " + (m ? m.name : "")).ToLower();
            bool foliage = rn.Contains("pine") || rn.Contains("fern") || rn.Contains("leaf") || rn.Contains("leaves") || rn.Contains("bush") || rn.Contains("foliage") || rn.Contains("grass") || rn.Contains("conifer") || rn.Contains("branch");
            mats[i] = ConvertMat(m, urp, sh, r, (white || natureLoose) && foliage); changed = true;
        }
        if (changed) r.sharedMaterials = mats;
    }
    static void LogMatConv()
    {
        var seen = new System.Collections.Generic.HashSet<string>();
        foreach (var r in Object.FindObjectsByType<Renderer>(FindObjectsSortMode.None))
            foreach (var m in r.sharedMaterials)
            {
                if (!m) continue; bool tex = (m.HasProperty("_MainTex") && m.mainTexture) || (m.HasProperty("_BaseMap") && m.GetTexture("_BaseMap"));
                bool white = !m.HasProperty("_Color") || m.color.grayscale > 0.85f;
                if (tex || !white) continue; var mp = AssetDatabase.GetAssetPath(m); var mf = r.GetComponent<MeshFilter>(); var mesh = mf && mf.sharedMesh ? AssetDatabase.GetAssetPath(mf.sharedMesh) + ":" + mf.sharedMesh.name : "-";
                var key = m.name + "|" + mesh; if (seen.Add(key) && seen.Count < 40) Debug.Log("MAT_WHITE obj=" + r.name + " mat=" + m.name + " shader=" + (m.shader ? m.shader.name : "null") + " matpath=" + mp + " mesh=" + mesh);
            }
        var hist = new System.Collections.Generic.Dictionary<string, int>();
        foreach (var r in Object.FindObjectsByType<Renderer>(FindObjectsSortMode.None)) foreach (var m in r.sharedMaterials) if (m && m.shader) { var k = m.shader.name; hist[k] = hist.ContainsKey(k) ? hist[k] + 1 : 1; }
        var hs = new System.Collections.Generic.List<string>(); foreach (var kv in hist) hs.Add(kv.Key + "=" + kv.Value); Debug.Log("MAT_SHADERS " + string.Join(" | ", hs));
        LogMatConv0();
    }
    static void LogMatConv0() { Debug.Log("MAT_CONVERT converted=" + _matConvN + " textured=" + _matTexN + " pipeline=" + (UnityEngine.Rendering.GraphicsSettings.currentRenderPipeline != null ? "URP" : "Built-in")); }

    static void StripBehaviour(GameObject go)
    {
        foreach (var m in go.GetComponentsInChildren<MonoBehaviour>(true)) Object.DestroyImmediate(m);
        foreach (var x in go.GetComponentsInChildren<WheelCollider>(true)) Object.DestroyImmediate(x);
        foreach (var x in go.GetComponentsInChildren<Joint>(true)) Object.DestroyImmediate(x);
        foreach (var x in go.GetComponentsInChildren<Rigidbody>(true)) Object.DestroyImmediate(x);
        foreach (var x in go.GetComponentsInChildren<Camera>(true)) Object.DestroyImmediate(x.gameObject);
        foreach (var x in go.GetComponentsInChildren<AudioListener>(true)) Object.DestroyImmediate(x);
        foreach (var x in go.GetComponentsInChildren<AudioSource>(true)) Object.DestroyImmediate(x);
        foreach (var t in go.GetComponentsInChildren<Transform>(true)) GameObjectUtility.RemoveMonoBehavioursWithMissingScript(t.gameObject);
    }

    static Bounds Bounds(GameObject go)
    {
        var rs = go.GetComponentsInChildren<Renderer>(); if (rs.Length == 0) return new Bounds(go.transform.position, Vector3.zero);
        var b = rs[0].bounds; foreach (var r in rs) b.Encapsulate(r.bounds); return b;
    }

    /// <summary>Place owned/imported pack prefabs around the level so packs are actually used.</summary>
    static void ScatterOwnedProps(Vector3 center, float radius, int count, bool keepColliders, float ovalX = 0, float ovalZ = 0)
    {
        var picks = new System.Collections.Generic.List<GameObject>();
        var guids = new System.Collections.Generic.List<string>(AssetDatabase.FindAssets("t:Prefab"));
        guids.AddRange(AssetDatabase.FindAssets("t:Model"));
        foreach (var g in guids)
        {
            var path = AssetDatabase.GUIDToAssetPath(g); var low = path.ToLower();
            if (IsWeapon(low) || low.Contains("/scripts/")) continue;
            if (!low.StartsWith("assets/") || low.Contains("/editor/") || low.Contains("tutorialinfo") || low.Contains("/scenes/")) continue;
            if (low.Contains("wall") || low.Contains("floor") || low.Contains("ceiling") || low.Contains("pillar") || low.Contains("roof") || low.Contains("molding") || low.Contains("tile_") || low.Contains("frame") || low.Contains("plane") || low.Contains("filler") || low.Contains("base scene")) continue;
            if (low.Contains("projector") || low.Contains("canvas") || low.Contains("/demo") || low.Contains("example") || low.Contains("character") || low.Contains("monster")) continue;
            if (low.Contains("camera") || low.Contains("logic only") || low.Contains("ready to drive") || low.Contains("player") || low.Contains("/ui/")) continue;
            var pf = AssetDatabase.LoadAssetAtPath<GameObject>(path); if (pf == null) continue;
            if (pf.GetComponentsInChildren<Renderer>(true).Length == 0) continue;
            if (pf.GetComponentsInChildren<Terrain>(true).Length > 0) continue;
            picks.Add(pf); if (picks.Count >= 60) break;
        }
        if (picks.Count == 0) { Debug.Log("PROPS_PLACED 0 (no imported prefabs)"); return; }
        var root = new GameObject("OwnedAssetProps").transform; var rnd = new System.Random(11); int placed = 0;
        for (int i = 0; i < count * 3 && placed < count; i++)
        {
            Vector3 p;
            if (ovalX > 0)
            {   // ring just outside the track
                float a = (float)rnd.NextDouble() * Mathf.PI * 2f; float k = rnd.Next(0, 2) == 0 ? 0.6f : 1.35f;
                p = new Vector3(Mathf.Cos(a) * ovalX * k, 0, Mathf.Sin(a) * ovalZ * k);
            }
            else p = center + new Vector3((float)(rnd.NextDouble() * 2 - 1) * radius, 0, (float)(rnd.NextDouble() * 2 - 1) * radius);
            if (ovalX == 0 && Mathf.Abs(p.x) < 6 && p.z < -30) continue; // keep spawn clear
            var pf = picks[placed % picks.Count];
            var go = (GameObject)PrefabUtility.InstantiatePrefab(pf);
            if (go == null) go = Object.Instantiate(pf);
            PrefabUtility.UnpackPrefabInstance(go, PrefabUnpackMode.Completely, InteractionMode.AutomatedAction);
            StripBehaviour(go); foreach (var rr in go.GetComponentsInChildren<Renderer>(true)) FixMat(rr);
            if (!keepColliders) foreach (var c in go.GetComponentsInChildren<Collider>(true)) Object.DestroyImmediate(c);
            var b = Bounds(go); float big = Mathf.Max(b.size.x, b.size.y, b.size.z);
            if (big > 25f) go.transform.localScale *= 25f / big; else if (big < 0.3f && big > 0) go.transform.localScale *= 1.5f / big;
            go.transform.position = p; go.transform.rotation = Quaternion.Euler(0, rnd.Next(0, 360), 0);
            go.transform.SetParent(root, true); placed++;
            Debug.Log("PROP_PLACED " + AssetDatabase.GetAssetPath(pf));
        }
        Debug.Log("PROPS_PLACED " + placed + " from " + picks.Count + " prefabs");
    }

    // ---------- Owned-asset dressing: swap grey boxes for imported pack models ----------
    static string _mode = ""; static float _ovalX = 60, _ovalZ = 100;
    static System.Collections.Generic.List<GameObject> _ownedCache;
    static System.Collections.Generic.List<GameObject> OwnedAll()
    {
        if (_ownedCache != null) return _ownedCache;
        _ownedCache = new System.Collections.Generic.List<GameObject>();
        var guids = new System.Collections.Generic.List<string>(AssetDatabase.FindAssets("t:Prefab"));
        guids.AddRange(AssetDatabase.FindAssets("t:Model"));
        var seen = new System.Collections.Generic.HashSet<string>();
        foreach (var g in guids)
        {
            var path = AssetDatabase.GUIDToAssetPath(g); var low = path.ToLower();
            if (!seen.Add(path)) continue;
            if (!low.StartsWith("assets/") || low.Contains("/editor/") || low.Contains("tutorialinfo") || low.Contains("/scenes/") || low.Contains("/scripts/")) continue;
            if (low.Contains("camera") || low.Contains("/ui/") || low.Contains("setup") || low.EndsWith("apartment_kit.prefab")) continue;
            var pf = AssetDatabase.LoadAssetAtPath<GameObject>(path); if (pf == null) continue;
            if (pf.GetComponentsInChildren<Renderer>(true).Length == 0 || pf.GetComponentsInChildren<Terrain>(true).Length > 0) continue;
            _ownedCache.Add(pf);
        }
        return _ownedCache;
    }
    static System.Collections.Generic.List<GameObject> Owned(string[] any, string[] none = null)
    {
        var r = new System.Collections.Generic.List<GameObject>();
        foreach (var pf in OwnedAll())
        {
            var low = AssetDatabase.GetAssetPath(pf).ToLower(); var file = System.IO.Path.GetFileNameWithoutExtension(low);
            if (IsWeapon(low)) continue;
            bool ok = false; foreach (var k in any) if (file.Contains(k)) { ok = true; break; }
            if (ok && none != null) foreach (var k in none) if (file.Contains(k)) { ok = false; break; }
            if (ok) r.Add(pf);
        }
        return r;
    }
    static GameObject Spawn(GameObject pf, Transform parent, bool colliders)
    {
        var go = (GameObject)PrefabUtility.InstantiatePrefab(pf); if (go == null) go = Object.Instantiate(pf);
        if (PrefabUtility.IsPartOfPrefabInstance(go)) PrefabUtility.UnpackPrefabInstance(go, PrefabUnpackMode.Completely, InteractionMode.AutomatedAction);
        FixTreeCreator(go, AssetDatabase.GetAssetPath(pf)); StripBehaviour(go); foreach (var r in go.GetComponentsInChildren<Renderer>(true)) FixMat(r);
        if (!colliders) foreach (var c in go.GetComponentsInChildren<Collider>(true)) Object.DestroyImmediate(c);
        if (parent) go.transform.SetParent(parent, true); return go;
    }
    /// <summary>Fit a model into a target box. uniform=true keeps proportions and sits it on the box bottom.</summary>
    static void FitTo(GameObject go, Vector3 center, Vector3 size, bool uniform, float yaw = 0)
    {
        go.transform.position = Vector3.zero; go.transform.rotation = Quaternion.identity; go.transform.localScale = Vector3.one;
        var b = Bounds(go); if (b.size.sqrMagnitude < 1e-4f) return;
        bool pfX = b.size.x >= b.size.z, tX = size.x >= size.z;
        var tgt = (pfX == tX) ? size : new Vector3(size.z, size.y, size.x);
        Vector3 sc;
        if (uniform) { float s = Mathf.Min(b.size.x > 0.05f ? tgt.x / b.size.x : 99, b.size.y > 0.05f ? tgt.y / b.size.y : 99, b.size.z > 0.05f ? tgt.z / b.size.z : 99); if (s > 98) s = 1; sc = Vector3.one * s; }
        else sc = new Vector3(b.size.x > 0.05f ? tgt.x / b.size.x : 1, b.size.y > 0.05f ? tgt.y / b.size.y : 1, b.size.z > 0.05f ? tgt.z / b.size.z : 1);
        var q = Quaternion.Euler(0, ((pfX == tX) ? 0 : 90) + yaw, 0);
        go.transform.localScale = sc; go.transform.rotation = q;
        var pos = center - q * Vector3.Scale(b.center, sc);
        if (uniform) pos.y = center.y - size.y / 2f - (b.center.y - b.extents.y) * sc.y;
        go.transform.position = pos;
    }
    static int SkinBox(GameObject box, System.Collections.Generic.List<GameObject> pool, System.Random rnd, float seg, bool uniform, Transform root)
    {
        if (box == null || pool.Count == 0) return 0;
        var r = box.GetComponent<Renderer>(); var c = box.transform.position; var s = box.transform.lossyScale;
        bool alongX = s.x >= s.z; float L = alongX ? s.x : s.z; int n = seg > 0 ? Mathf.Max(1, Mathf.RoundToInt(L / seg)) : 1; int made = 0;
        for (int i = 0; i < n; i++)
        {
            float off = -L / 2 + L / n * (i + 0.5f);
            var cc = c + (alongX ? new Vector3(off, 0, 0) : new Vector3(0, 0, off));
            var ss = alongX ? new Vector3(L / n, s.y, s.z) : new Vector3(s.x, s.y, L / n);
            var go = Spawn(pool[rnd.Next(pool.Count)], root, false); FitTo(go, cc, ss, uniform); made++;
        }
        if (r) r.enabled = false; return made;
    }
    static int SkinFlat(Vector3 center, float sx, float sz, float y, float thick, System.Collections.Generic.List<GameObject> pool, System.Random rnd, float cell, Transform root, bool flip = false)
    {
        if (pool.Count == 0) return 0; int nx = Mathf.Max(1, Mathf.RoundToInt(sx / cell)), nz = Mathf.Max(1, Mathf.RoundToInt(sz / cell)); int made = 0;
        for (int i = 0; i < nx; i++) for (int k = 0; k < nz; k++)
        {
            var cc = new Vector3(center.x - sx / 2 + sx / nx * (i + 0.5f), y, center.z - sz / 2 + sz / nz * (k + 0.5f));
            var go = Spawn(pool[rnd.Next(pool.Count)], root, false); FitTo(go, cc, new Vector3(sx / nx, thick, sz / nz), false); if (flip) go.transform.RotateAround(cc, Vector3.right, 180f); made++;
        }
        return made;
    }
    static int Furnish(System.Collections.Generic.List<GameObject> pool, float half, int count, float maxDim, System.Random rnd, Transform root)
    {
        if (pool.Count == 0) return 0; int made = 0;
        for (int i = 0; i < count; i++)
        {
            int side = rnd.Next(4); float t = (float)(rnd.NextDouble() * 2 - 1) * (half - 3f); float inset = half - 1.6f;
            Vector3 p = side == 0 ? new Vector3(t, 0, inset) : side == 1 ? new Vector3(t, 0, -inset) : side == 2 ? new Vector3(inset, 0, t) : new Vector3(-inset, 0, t);
            if (Mathf.Abs(p.x) < 4f && Mathf.Abs(p.z) > half - 4f) continue; // keep doors clear
            if (Physics.CheckSphere(p + Vector3.up, 0.9f)) continue;
            var go = Spawn(pool[rnd.Next(pool.Count)], root, true);
            FitTo(go, p + Vector3.up * maxDim / 2f, new Vector3(maxDim, maxDim, maxDim), true, side == 0 ? 180 : side == 1 ? 0 : side == 2 ? 270 : 90);
            if (go.GetComponentInChildren<Collider>() == null) { var bb = Bounds(go); var bc = go.AddComponent<BoxCollider>(); bc.center = go.transform.InverseTransformPoint(bb.center); var ls = go.transform.lossyScale; bc.size = new Vector3(bb.size.x / Mathf.Max(ls.x, 1e-3f), bb.size.y / Mathf.Max(ls.y, 1e-3f), bb.size.z / Mathf.Max(ls.z, 1e-3f)); }
            made++;
        }
        return made;
    }
    static System.Collections.Generic.List<GameObject> Pick1(System.Collections.Generic.List<GameObject> l)
    {
        if (l.Count < 2) return l; l.Sort((a, b) => { int ia = System.IO.Path.GetFileName(AssetDatabase.GetAssetPath(a)).ToLower().StartsWith("int") ? 0 : 1, ib = System.IO.Path.GetFileName(AssetDatabase.GetAssetPath(b)).ToLower().StartsWith("int") ? 0 : 1; if (ia != ib) return ia - ib; return string.Compare(AssetDatabase.GetAssetPath(a), AssetDatabase.GetAssetPath(b), System.StringComparison.OrdinalIgnoreCase); });
        return new System.Collections.Generic.List<GameObject> { l[0] };
    }
    static Material OwnedMat(string[] keys, Color tint, string[] none = null)
    {
        bool urpOn = UnityEngine.Rendering.GraphicsSettings.currentRenderPipeline != null && Shader.Find("Universal Render Pipeline/Lit") != null;
        if (!urpOn) return OwnedMatBuiltin(keys, tint, none);
        var sh = Shader.Find("Universal Render Pipeline/Lit");
        foreach (var k in keys) foreach (var g in AssetDatabase.FindAssets("t:Material"))
        {
            var p = AssetDatabase.GUIDToAssetPath(g); var file = System.IO.Path.GetFileNameWithoutExtension(p).ToLower();
            if (!p.StartsWith("Assets/") || p.Contains("/Settings/") || System.Text.RegularExpressions.Regex.IsMatch(p.ToLower(), "car controller|truck|vehicle|weapon|gun") || !file.Contains(k) || file.Contains("skybox")) continue;
            if (none != null) { bool bad = false; foreach (var x in none) if (file.Contains(x)) bad = true; if (bad) continue; }
            var m = AssetDatabase.LoadAssetAtPath<Material>(p); if (m == null) continue;
            Debug.Log("DRESS_MATPICK " + p);
            if (m.shader && m.shader.name.StartsWith("Universal")) return m;
            var nm = new Material(sh); if (m.HasProperty("_MainTex") && m.mainTexture) nm.SetTexture("_BaseMap", m.mainTexture); if (m.HasProperty("_Color")) nm.SetColor("_BaseColor", m.color); return nm;
        }
        foreach (var k in keys) foreach (var g in AssetDatabase.FindAssets("t:Texture2D"))
        {
            var p = AssetDatabase.GUIDToAssetPath(g); var file = System.IO.Path.GetFileNameWithoutExtension(p).ToLower();
            if (!p.StartsWith("Assets/") || !file.Contains(k) || file.Contains("normal") || file.Contains("_n") && file.EndsWith("_n") || file.Contains("rough") || file.Contains("height") || file.Contains("ao") && file.EndsWith("ao") || file.Contains("icon")) continue;
            var tx = AssetDatabase.LoadAssetAtPath<Texture2D>(p); if (tx == null) continue;
            Debug.Log("DRESS_MATPICK tex " + p); var tm = new Material(sh); tm.SetTexture("_BaseMap", tx); tm.SetFloat("_Smoothness", 0.15f); return tm;
        }
        var t = new Material(sh); t.SetColor("_BaseColor", tint); Debug.Log("DRESS_MATPICK tint " + tint); return t;
    }
    // Built-in pipeline twin of OwnedMat (URP/Lit is missing there -> new Material(null) threw / rendered white).
    static Material OwnedMatBuiltin(string[] keys, Color tint, string[] none)
    {
        var st = Shader.Find("Standard");
        foreach (var k in keys) foreach (var g in AssetDatabase.FindAssets("t:Material"))
        {
            var p = AssetDatabase.GUIDToAssetPath(g); var file = System.IO.Path.GetFileNameWithoutExtension(p).ToLower();
            if (!p.StartsWith("Assets/") || p.Contains("/Settings/") || System.Text.RegularExpressions.Regex.IsMatch(p.ToLower(), "car controller|truck|vehicle|weapon|gun") || !file.Contains(k) || file.Contains("skybox")) continue;
            if (none != null) { bool bad = false; foreach (var x in none) if (file.Contains(x)) bad = true; if (bad) continue; }
            var m = AssetDatabase.LoadAssetAtPath<Material>(p); if (m == null) continue;
            Debug.Log("DRESS_MATPICK " + p);
            if (ShaderOk(m) && !m.shader.name.StartsWith("Universal") && !m.shader.name.StartsWith("HDRP") && (m.mainTexture || SerTex(m, AlbedoNames, true) == null)) return m;
            return ConvertMat(m, false, null);
        }
        foreach (var k in keys) foreach (var g in AssetDatabase.FindAssets("t:Texture2D"))
        {
            var p = AssetDatabase.GUIDToAssetPath(g); var file = System.IO.Path.GetFileNameWithoutExtension(p).ToLower();
            if (!p.StartsWith("Assets/") || !file.Contains(k) || file.Contains("normal") || file.Contains("_n") && file.EndsWith("_n") || file.Contains("rough") || file.Contains("height") || file.Contains("ao") && file.EndsWith("ao") || file.Contains("icon")) continue;
            var tx = AssetDatabase.LoadAssetAtPath<Texture2D>(p); if (tx == null) continue;
            Debug.Log("DRESS_MATPICK tex " + p); var tm = new Material(st); tm.mainTexture = tx; tm.SetFloat("_Glossiness", 0.15f); return tm;
        }
        var t = new Material(st) { color = tint }; Debug.Log("DRESS_MATPICK tint " + tint); return t;
    }
    static Material Tiled(Material m, float u, float v)
    {
        var c = new Material(m); var sc = new Vector2(Mathf.Max(1, u), Mathf.Max(1, v));
        if (c.HasProperty("_BaseMap")) c.SetTextureScale("_BaseMap", sc); if (c.HasProperty("_MainTex")) c.SetTextureScale("_MainTex", sc);
        return c;
    }
    static void Dress()
    {
                var rnd = new System.Random(7); var root = new GameObject("OwnedAssetDressing").transform;
        bool indoor = _mode == "horror" || _mode == "sim" || _mode == "puzzle" || _mode == "roguelike" || _mode == "fps";
        var walls = Owned(new[] { "_wall_0", "wall_0", "_wall_double" }, new[] { "shelf", "cabinet", "window", "extrude", "tile", "corner" });
        var floors = Owned(new[] { "floor" }, new[] { "lamp", "molding", "round" });
        var ceils = Owned(new[] { "ceiling" }, new[] { "molding", "lamp", "fan" });
        var shelves = Owned(new[] { "shelf", "shelv", "rack", "storage", "barcabinet" }, new[] { "wallshelf" });
        var counters = Owned(new[] { "counter", "cabinet_base", "desk", "table_dining", "bar_" });
        var smalls = Owned(new[] { "bottle", "vase", "glass", "jar", "can_", "box", "carton", "book" }, new[] { "skybox", "collider" });
        var crates = Owned(new[] { "crate", "carton", "box", "barrel", "hamper" }, new[] { "skybox", "collider" });
        var chars = Owned(new[] { "zombie", "character", "human", "soldier", "enemy", "creature", "mannequin", "man_", "woman", "stylized", "player", "monster", "ghost", "humanoid" }, new[] { "controller", "animator", "doorframe", "_sign", "icon", "first person", "spawn", "camera" });
        if (chars.Count == 0) chars = Owned(new[] { "lamp_floor", "coat", "statue", "dresser closet" }); // eerie tall prop fallback
        var furn = Owned(new[] { "sofa", "chair", "table", "bed_", "dresser", "cabinet", "shelf", "bench", "fridge", "stove", "toilet", "vanity", "lamp", "barrel", "crate", "bathtub", "hamper" }, new[] { "wall_", "setup" });
        walls = Pick1(walls); floors = Pick1(floors); ceils = Pick1(ceils);
        if (_mode == "sim") { walls.Clear(); furn.RemoveAll(x => System.Text.RegularExpressions.Regex.IsMatch(x.name.ToLower(), "toilet|bathtub|vanity|bed_|shower|sink")); } // shop: one-sided apartment walls look black from inside; use owned wall material instead
        int w = 0, f = 0, ce = 0, sh = 0, fu = 0, ch = 0, sm = 0;
        foreach (var t in Object.FindObjectsByType<Transform>(FindObjectsSortMode.None))
        {
            if (t == null || t.IsChildOf(root)) continue; var n = t.name; var go = t.gameObject;
            if (go.GetComponent<MeshRenderer>() == null && !n.StartsWith("Stalker")) continue;
            if (n.StartsWith("Wall_") || n.StartsWith("HallWall")) w += SkinBox(go, walls, rnd, 3f, false, root);
            else if (n == "Ceiling") { if (ceils.Count > 0) { var s = t.lossyScale; ce += SkinFlat(t.position, s.x, s.z, t.position.y, s.y, ceils, rnd, 4f, root, true); go.GetComponent<Renderer>().enabled = false; } }
            else if (n.StartsWith("Shelf_")) sh += SkinBox(go, shelves, rnd, 0, true, root);
            else if (n == "Counter") sh += SkinBox(go, counters.Count > 0 ? counters : shelves, rnd, 2.6f, true, root);
            else if (n == "Goods") sm += SkinBox(go, smalls, rnd, 0, true, root);
            else if (n == "StockCrate") sm += SkinBox(go, crates, rnd, 0, true, root);
            else if (n.StartsWith("Cover_") && crates.Count > 0) sm += SkinBox(go, crates, rnd, 0, true, root);
            else if (n.StartsWith("Platform_") || n.StartsWith("Cover_")) { var pm = OwnedMat(new[] { "wood", "plank", "concrete", "stone", "floor_tiled" }, new Color(0.42f, 0.36f, 0.3f), new[] { "marble", "car", "trunk", "ground", "grass", "nature" }); var ls = t.lossyScale; go.GetComponent<Renderer>().sharedMaterial = Tiled(pm, Mathf.Max(1f, Mathf.Max(ls.x, ls.z) / 4f), Mathf.Max(1f, ls.y / 2f)); w++; }
            else if (n.StartsWith("Stalker_") && chars.Count > 0)
            {
                var v = Spawn(chars[rnd.Next(chars.Count)], t, false); FitTo(v, t.position, new Vector3(1.2f, 1.9f, 1.2f), true);
                v.transform.SetParent(t, true); var cr = go.GetComponent<Renderer>(); if (cr) cr.enabled = false; ch++;
            }
        }
        var ground = GameObject.Find("Ground");
        Physics.SyncTransforms();
        if (indoor && ground && floors.Count > 0)
        {
            float half = 0; foreach (var t in Object.FindObjectsByType<Transform>(FindObjectsSortMode.None)) if (t.name == "Wall_N") half = t.position.z;
            if (half > 1) { f = SkinFlat(Vector3.zero, half * 2, half * 2, -0.05f, 0.1f, floors, rnd, 4f, root); ground.GetComponent<Renderer>().enabled = false; }
        }
        if (indoor && furn.Count > 0)
        {
            float half = 0; foreach (var t in Object.FindObjectsByType<Transform>(FindObjectsSortMode.None)) if (t.name == "Wall_N") half = t.position.z;
            if (half > 4) fu = Furnish(furn, half, _mode == "sim" ? 8 : 22, _mode == "sim" ? 1.6f : 2.0f, rnd, root);
        }
        // Material fallback: no owned wall/floor meshes -> skin the grey boxes with an owned material (or a tint), never leave default grey.
        int mw = 0, mf = 0;
        if (indoor)
        {
            if (f == 0 && ground && ground.GetComponent<Renderer>().enabled) { var fm = OwnedMat(new[] { "floor_tiled", "(mat)floor", "floor", "parquet", "tile", "wood" }, new Color(0.45f, 0.36f, 0.27f)); var gs = ground.transform.lossyScale; ground.GetComponent<Renderer>().sharedMaterial = Tiled(fm, gs.x * 10f / 3f, gs.z * 10f / 3f); mf = 1; }
            if (w == 0)
            {
                var wm = OwnedMat(new[] { "gradientbeige", "plaster", "wallpaint", "brick", "paint", "wall_", "wood_plank", "planks", "wood", "concrete" }, new Color(0.78f, 0.72f, 0.62f), new[] { "rack", "rail", "shelf", "marble", "floor", "tile", "canvas", "painting", "picture", "frame" });
                foreach (var t in Object.FindObjectsByType<Transform>(FindObjectsSortMode.None))
                    if ((t.name.StartsWith("Wall_") || t.name.StartsWith("HallWall")) && t.GetComponent<Renderer>() && !t.IsChildOf(root)) { var ls = t.lossyScale; t.GetComponent<Renderer>().sharedMaterial = Tiled(wm, Mathf.Max(1.5f, Mathf.Max(ls.x, ls.z) / 8f), Mathf.Max(1.5f, ls.y / 4f)); mw++; }
            }
            Debug.Log($"DRESS_MAT floors={mf} walls={mw}");
        }
        // Outdoor dressing: owned houses replace village boxes; owned trees/rocks/street props ring the play space.
        int hs = 0, nat = 0, rel = 0, npcs = 0;
        if (_mode == "rpg" || _mode == "racing" || _mode == "fps" || _mode == "platformer")
        {
            var houses = Owned(new[] { "house", "cottage", "cabin", "hut" }, new[] { "interior", "light", "door", "window", "roof", "wall", "floor" });
            var trees = Owned(new[] { "tree", "pine", "conifer" }, new[] { "terrain", "leaf", "leaves", "billboard", "lod", "branch", "impostor", "dead", "bare", "dry", "stump" });
            var smallN = Owned(new[] { "bush", "rock", "stone", "fern", "plant", "grass patch", "foliage" }, new[] { "terrain", "lod", "billboard" });
            var street = Owned(new[] { "lamp", "bench", "bin", "hydrant", "sign", "cone", "barrier", "bollard", "garbage" }, new[] { "terrain", "lod" });
            if (_mode == "rpg")
            {
                foreach (var t in Object.FindObjectsByType<Transform>(FindObjectsSortMode.None))
                {
                    if (t.IsChildOf(root)) continue;
                    if (houses.Count > 0 && System.Text.RegularExpressions.Regex.IsMatch(t.name, "^House_\\d+$") && t.GetComponent<Renderer>())
                    {
                        var hp = t.position; hp.y = 0; float sc = 0.85f + 0.08f * (hs % 4); var hg = Spawn(houses[hs % houses.Count], root, true);
                        FitTo(hg, hp + Vector3.up * 3.5f * sc, new Vector3(9, 7, 9) * sc, true, Mathf.Atan2(-hp.x, -hp.z) * Mathf.Rad2Deg + (hs % 3 - 1) * 12f);
                        if (hs % 2 == 1) foreach (var r in hg.GetComponentsInChildren<Renderer>()) { var ms = r.sharedMaterials; for (int i = 0; i < ms.Length; i++) if (ms[i]) { var m = new Material(ms[i]); var tint = new Color(0.85f, 0.78f, 0.7f); if (m.HasProperty("_BaseColor")) m.SetColor("_BaseColor", m.GetColor("_BaseColor") * tint); ms[i] = m; } r.sharedMaterials = ms; }
                        t.GetComponent<Renderer>().enabled = false; var rf = GameObject.Find("Roof_" + t.name.Substring(6)); if (rf) rf.SetActive(false); hs++;
                    }
                }
                var people = Owned(new[] { "stylized", "character", "human", "villager", "player" }, new[] { "first person", "controller", "camera", "spawn", "animation" });
                if (people.Count == 0) people = Owned(new[] { "player" }, new[] { "first person" });
                var elder = GameObject.Find("VillageElder");
                if (elder && people.Count > 0) { var v = Spawn(people[0], null, false); FitTo(v, elder.transform.position, new Vector3(1.2f, 2f, 1.2f), true, 180); v.transform.SetParent(elder.transform, true); foreach (var r in elder.GetComponents<Renderer>()) r.enabled = false; foreach (Transform c in elder.transform) if (c.GetComponent<Renderer>() && !c.IsChildOf(v.transform)) c.GetComponent<Renderer>().enabled = false; npcs++; }
                var relicPf = Owned(new[] { "crystal", "gem", "rock", "stone" }, new[] { "large", "group", "terrain" });
                foreach (var t in Object.FindObjectsByType<Transform>(FindObjectsSortMode.None))
                    if (relicPf.Count > 0 && t.name.StartsWith("EmberRelic_") && t.GetComponent<Renderer>())
                    {
                        var rv = Spawn(relicPf[rel % relicPf.Count], null, false); FitTo(rv, t.position, Vector3.one * 0.9f, true, rel * 40);
                        foreach (var r in rv.GetComponentsInChildren<Renderer>()) { var m = new Material(Shader.Find("Universal Render Pipeline/Lit")); m.SetColor("_BaseColor", new Color(1f, 0.45f, 0.15f)); m.EnableKeyword("_EMISSION"); m.SetColor("_EmissionColor", new Color(1f, 0.35f, 0.05f) * 2.5f); r.sharedMaterial = m; }
                        rv.transform.SetParent(t, true); t.GetComponent<Renderer>().enabled = false; rel++;
                    }
                var animals = Owned(new[] { "chicken", "dog", "horse", "deer", "kitty", "cat_", "sheep", "cow", "pig" });
                for (int i = 0; i < 8 && animals.Count > 0; i++) { float a = i * 45 * Mathf.Deg2Rad + 0.3f; var ap = new Vector3(Mathf.Cos(a) * 9f, 0, Mathf.Sin(a) * 9f); var an = Spawn(animals[i % animals.Count], root, false); var nm = an.name.ToLower(); float hz = nm.Contains("horse") || nm.Contains("deer") ? 1.7f : nm.Contains("dog") || nm.Contains("tiger") ? 0.8f : 0.45f; FitTo(an, ap + Vector3.up * hz / 2, new Vector3(hz * 1.6f, hz, hz * 1.6f), true, i * 67); npcs++; }
            }
            int nTree = _mode == "racing" ? 220 : _mode == "fps" ? 40 : _mode == "platformer" ? 60 : 90;
            int nSmall = _mode == "racing" ? 40 : _mode == "fps" ? 30 : _mode == "platformer" ? 20 : 70;
            int nStreet = _mode == "racing" ? 24 : _mode == "fps" ? 28 : _mode == "platformer" ? 10 : 0;
            for (int i = 0; i < nTree + nSmall + nStreet; i++)
            {
                var pool = i < nTree ? trees : i < nTree + nSmall ? smallN : street; if (pool.Count == 0) continue;
                Vector3 p; float a = (float)rnd.NextDouble() * Mathf.PI * 2f;
                if (_mode == "racing") { bool st = i >= nTree + nSmall; float k = st ? (rnd.Next(0, 2) == 0 ? 0.82f : 1.18f) : rnd.Next(0, 2) == 0 ? Mathf.Lerp(0.3f, 0.72f, (float)rnd.NextDouble()) : Mathf.Lerp(1.25f, 1.9f, (float)rnd.NextDouble()); p = new Vector3(Mathf.Cos(a) * _ovalX * k, 0, Mathf.Sin(a) * _ovalZ * k); }
                else if (_mode == "fps") { p = new Vector3((float)(rnd.NextDouble() * 2 - 1) * 46f, 0, (float)(rnd.NextDouble() * 2 - 1) * 46f); if (Mathf.Abs(p.x) < 6 && p.z < -30) continue; }
                else if (_mode == "platformer") { p = new Vector3((float)(rnd.NextDouble() * 2 - 1) * 18f, 0, Mathf.Lerp(5f, 90f, (float)rnd.NextDouble())); }
                else { float d = Mathf.Lerp(22f, 62f, (float)rnd.NextDouble()); p = new Vector3(Mathf.Cos(a) * d, 0, Mathf.Sin(a) * d); }
                var pf = pool[rnd.Next(pool.Count)]; var nm = pf.name.ToLower();
                float hgt = i < nTree ? Mathf.Lerp(6f, 12f, (float)rnd.NextDouble()) : i < nTree + nSmall ? Mathf.Lerp(0.6f, 1.8f, (float)rnd.NextDouble()) : (nm.Contains("lamp") ? 4.5f : nm.Contains("sign") ? 2.4f : nm.Contains("bench") ? 0.9f : nm.Contains("bin") || nm.Contains("garbage") ? 1.1f : 0.9f);
                var go = Spawn(pf, root, _mode == "rpg"); FitTo(go, p + Vector3.up * hgt / 2f, new Vector3(hgt * 3, hgt, hgt * 3), true, rnd.Next(0, 360)); nat++;
            }
        }
        int lamps = 0;
        if (_mode == "horror" && (w > 0 || f > 0))
        {
            var lampPf = Owned(new[] { "lamp_ceiling" }); lampPf = Pick1(lampPf);
            for (float lx = -21; lx <= 21; lx += 14) for (float lz = -21; lz <= 21; lz += 14)
            {
                var pl = new GameObject("DressLamp").AddComponent<Light>(); pl.type = LightType.Point; pl.transform.SetParent(root, false); pl.transform.position = new Vector3(lx, 3.6f, lz);
                pl.range = 10f; pl.intensity = ((int)(lx + lz) % 3 == 0) ? 0.6f : 2.2f; pl.color = new Color(1f, 0.82f, 0.6f); pl.shadows = LightShadows.None; lamps++;
                if (lampPf.Count > 0) { var lg = Spawn(lampPf[0], root, false); FitTo(lg, new Vector3(lx, 3.8f, lz), new Vector3(0.8f, 0.6f, 0.8f), true); }
            }
        }
        if (walls.Count > 0) Debug.Log("DRESS_WALL " + AssetDatabase.GetAssetPath(walls[0])); if (floors.Count > 0) Debug.Log("DRESS_FLOOR " + AssetDatabase.GetAssetPath(floors[0])); if (chars.Count > 0) Debug.Log("DRESS_CHAR " + AssetDatabase.GetAssetPath(chars[0]));
        Debug.Log($"DRESS mode={_mode} owned={OwnedAll().Count} walls={w} floors={f} ceilings={ce} fixtures={sh} smallprops={sm} furniture={fu} characters={ch} lamps={lamps} houses={hs} nature={nat} relics={rel} npcs={npcs}");
    }

    static void BuildPlatformer()
    {
        var scene = EditorSceneManager.NewScene(NewSceneSetup.DefaultGameObjects, NewSceneMode.Single);
        var ground = GameObject.CreatePrimitive(PrimitiveType.Plane);
        ground.name = "Ground";
        ground.transform.localScale = new Vector3(12f, 1f, 20f);

        // platforms trail toward flag
        for (int i = 0; i < 14; i++)
        {
            var b = GameObject.CreatePrimitive(PrimitiveType.Cube);
            b.name = "Platform_" + i;
            float z = 8f + i * 5f;
            float x = (i % 2 == 0 ? -1f : 1f) * (3f + (i % 3));
            float y = 0.5f + (i % 4) * 0.75f;
            b.transform.position = new Vector3(x, y, z);
            b.transform.localScale = new Vector3(3.2f, 1f, 3.2f);
        }

        // coins
        for (int i = 0; i < 12; i++)
        {
            var c = GameObject.CreatePrimitive(PrimitiveType.Sphere);
            c.name = "Coin_" + i;
            c.transform.position = new Vector3((i % 2 == 0 ? -2f : 2f), 1.6f + (i % 3) * 0.4f, 10f + i * 4.5f);
            c.transform.localScale = Vector3.one * 0.55f;
            c.GetComponent<Collider>().isTrigger = true;
            c.AddComponent<CoinPickup>();
            var r = c.GetComponent<Renderer>();
            if (r != null) r.sharedMaterial = new Material(Shader.Find("Universal Render Pipeline/Lit") ?? Shader.Find("Standard")) { color = Color.yellow };
        }

        // hazards
        for (int i = 0; i < 5; i++)
        {
            var h = GameObject.CreatePrimitive(PrimitiveType.Cube);
            h.name = "Hazard_" + i;
            h.transform.position = new Vector3(0f, 0.35f, 18f + i * 10f);
            h.transform.localScale = new Vector3(2.5f, 0.4f, 2.5f);
            h.GetComponent<Collider>().isTrigger = true;
            h.AddComponent<Hazard>();
            var r = h.GetComponent<Renderer>();
            if (r != null) r.sharedMaterial = new Material(Shader.Find("Universal Render Pipeline/Lit") ?? Shader.Find("Standard")) { color = Color.red };
        }

        var goal = GameObject.CreatePrimitive(PrimitiveType.Cylinder);
        goal.name = "GoalFlag";
        goal.transform.position = new Vector3(0f, 1.5f, 85f);
        goal.transform.localScale = new Vector3(2.2f, 1.5f, 2.2f);
        goal.GetComponent<Collider>().isTrigger = true;
        goal.AddComponent<GoalFlag>();
        var gr = goal.GetComponent<Renderer>();
        if (gr != null) gr.sharedMaterial = new Material(Shader.Find("Universal Render Pipeline/Lit") ?? Shader.Find("Standard")) { color = Color.green };

        // Prefer an imported humanoid/mesh under Assets if present; else capsule
        var player = GameObject.CreatePrimitive(PrimitiveType.Capsule);
        player.name = "Player";
        player.tag = "Player";
        player.transform.position = new Vector3(0f, 1.1f, 0f);
        Object.DestroyImmediate(player.GetComponent<CapsuleCollider>());
        var cc = player.AddComponent<CharacterController>();
        cc.height = 2f; cc.center = new Vector3(0, 1f, 0);
        player.AddComponent<GamePlayer>();
        AttachCharacter(player); // owned character pack only (was TryAttachImportedVisual: first t:Model in Assets, e.g. a CC0 fort wall, parented to the player)

        var camGo = GameObject.Find("Main Camera");
        if (camGo != null)
        {
            camGo.transform.SetParent(player.transform, false);
            camGo.transform.localPosition = new Vector3(0f, 2.6f, -5f); // third-person so the character model is visible
            camGo.transform.localRotation = Quaternion.Euler(12f, 0f, 0f);
        }

        AddConfig("platformer");
        ScatterOwnedProps(new Vector3(0, 0, 40), 55f, 16, true);
        _mode = "platformer"; _ownedCache = null; try { Dress(); } catch (System.Exception e) { Debug.LogWarning("DRESS_FAIL " + e); }
        new GameObject("HUD").AddComponent<GameHUD>();
        new GameObject("Pause").AddComponent<PauseMenu>();

        EditorSceneManager.SaveScene(scene, GamePath);
    }


    // ======== extra genre builders ========
    static UnityEngine.SceneManagement.Scene Begin(string mode, Color groundCol, float size)
    {
        var scene = EditorSceneManager.NewScene(NewSceneSetup.DefaultGameObjects, NewSceneMode.Single);
        AddConfig(mode); _mode = mode; _ownedCache = null;
        var ground = GameObject.CreatePrimitive(PrimitiveType.Plane); ground.name = "Ground"; ground.transform.localScale = new Vector3(size, 1f, size);
        ground.GetComponent<Renderer>().sharedMaterial = Mat(groundCol);
        return scene;
    }
    static void End(UnityEngine.SceneManagement.Scene scene)
    {
        try { Dress(); } catch (System.Exception e) { Debug.LogWarning("DRESS_FAIL " + e); }
        try { FinalMatPass(); PolishLook(); } catch (System.Exception e) { Debug.LogWarning("LOOK_FAIL " + e); }
        new GameObject("HUD").AddComponent<GameHUD>();
        new GameObject("Pause").AddComponent<PauseMenu>();
        EditorSceneManager.SaveScene(scene, GamePath);
    }
    static GameObject Pickup(string n, PrimitiveType t, Vector3 p, Color c, string kind, float sz = 0.6f)
    {
        var o = GameObject.CreatePrimitive(t); o.name = n; o.transform.position = p; o.transform.localScale = Vector3.one * sz;
        o.GetComponent<Renderer>().sharedMaterial = Mat(c); o.GetComponent<Collider>().isTrigger = true; o.AddComponent<QuestItem>().kind = kind;
        var l = new GameObject("Glow").AddComponent<Light>(); l.transform.SetParent(o.transform, false); l.color = c; l.range = 4; l.intensity = 2;
        return o;
    }
    static GameObject Trigger(string n, Vector3 p, Vector3 size)
    {
        var o = new GameObject(n); o.transform.position = p; var bc = o.AddComponent<BoxCollider>(); bc.isTrigger = true; bc.size = size; return o;
    }
    static void Walls(Transform root, float half, float h, Color c)
    {
        Box("Wall_N", new Vector3(0, h / 2, half), new Vector3(half * 2, h, 1), c, root); Box("Wall_S", new Vector3(0, h / 2, -half), new Vector3(half * 2, h, 1), c, root);
        Box("Wall_E", new Vector3(half, h / 2, 0), new Vector3(1, h, half * 2), c, root); Box("Wall_W", new Vector3(-half, h / 2, 0), new Vector3(1, h, half * 2), c, root);
    }

    static void BuildHorror()
    {
        var scene = Begin("horror", new Color(0.12f, 0.12f, 0.13f), 6f);
        RenderSettings.ambientMode = UnityEngine.Rendering.AmbientMode.Flat; RenderSettings.ambientLight = new Color(0.11f, 0.10f, 0.12f); RenderSettings.defaultReflectionMode = UnityEngine.Rendering.DefaultReflectionMode.Custom; RenderSettings.customReflectionTexture = null; RenderSettings.reflectionIntensity = 0.05f; RenderSettings.skybox = null;
        RenderSettings.fog = true; RenderSettings.fogColor = Color.black; RenderSettings.fogDensity = 0.04f; RenderSettings.fogMode = FogMode.ExponentialSquared;
        var sun = GameObject.Find("Directional Light"); if (sun) Object.DestroyImmediate(sun);
        var cam0 = GameObject.Find("Main Camera"); if (cam0) { var c = cam0.GetComponent<Camera>(); c.clearFlags = CameraClearFlags.SolidColor; c.backgroundColor = Color.black; }
        var halls = new GameObject("Halls").transform; var wc = new Color(0.3f, 0.28f, 0.25f);
        Walls(halls, 28, 4, wc);
        // corridor maze: interior walls
        for (int i = -2; i <= 2; i++) { Box("HallWallX_" + i, new Vector3(i * 10 + (i % 2 == 0 ? 4 : -4), 2, i * 3), new Vector3(16, 4, 0.6f), wc, halls); Box("HallWallZ_" + i, new Vector3(i * 10, 2, -i * 4 + 6), new Vector3(0.6f, 4, 12), wc, halls); }
        Box("Ceiling", new Vector3(0, 4.2f, 0), new Vector3(56, 0.3f, 56), new Color(0.08f, 0.08f, 0.08f), halls);
        Vector3[] fuses = { new Vector3(-22, 1, 20), new Vector3(20, 1, 22), new Vector3(22, 1, -6), new Vector3(-20, 1, -12), new Vector3(4, 1, 14) };
        for (int i = 0; i < fuses.Length; i++) Pickup("Fuse_" + i, PrimitiveType.Cylinder, fuses[i], new Color(1f, 0.85f, 0.2f), "fuse", 0.5f);
        var exit = Box("ExitDoor", new Vector3(0, 1.5f, 27.3f), new Vector3(3, 3, 0.4f), new Color(0.6f, 0.05f, 0.05f)); exit.GetComponent<Collider>().isTrigger = true; exit.AddComponent<ExitGate>();
        var el = new GameObject("ExitSign").AddComponent<Light>(); el.transform.position = new Vector3(0, 3.5f, 26.5f); el.color = Color.red; el.range = 6; el.intensity = 3;
        for (int i = 0; i < 2; i++) { var st = GameObject.CreatePrimitive(PrimitiveType.Capsule); st.name = "Stalker_" + i; st.transform.position = new Vector3(i == 0 ? 15 : -15, 1, 10); st.transform.localScale = new Vector3(0.8f, 1.3f, 0.8f); st.GetComponent<Renderer>().sharedMaterial = Mat(new Color(0.02f, 0.02f, 0.02f)); Object.DestroyImmediate(st.GetComponent<Collider>()); st.AddComponent<Stalker>(); }
        for (int i = 0; i < 4; i++) Trigger("ScareTrigger_" + i, new Vector3(-18 + i * 12, 1, -4 + (i % 2) * 14), new Vector3(3, 3, 3)).AddComponent<ScareTrigger>().text = new[] { "A door slams somewhere...", "Footsteps. Close.", "The lights flicker - it knows.", "Breathing behind the wall..." }[i];
        var player = MakeWalker(new Vector3(0, 1.1f, -24f)); player.AddComponent<FlashlightController>();
        ScatterOwnedProps(Vector3.zero, 24f, 14, true);
        End(scene);
    }

    static void BuildRpg()
    {
        var scene = Begin("rpg", new Color(0.3f, 0.55f, 0.25f), 12f);
        var village = new GameObject("Village").transform;
        for (int i = 0; i < 6; i++) { float a = i * 60 * Mathf.Deg2Rad; var hp = new Vector3(Mathf.Cos(a) * 14, 0, Mathf.Sin(a) * 14); Box("House_" + i, hp + Vector3.up * 1.5f, new Vector3(4, 3, 4), new Color(0.6f, 0.45f, 0.3f), village); var roof = Box("Roof_" + i, hp + Vector3.up * 3.4f, new Vector3(4.6f, 0.8f, 4.6f), new Color(0.6f, 0.15f, 0.1f), village); roof.transform.rotation = Quaternion.Euler(0, 45, 0); }
        var npc = GameObject.CreatePrimitive(PrimitiveType.Capsule); npc.name = "VillageElder"; npc.transform.position = new Vector3(0, 1, 4); npc.GetComponent<Renderer>().sharedMaterial = Mat(new Color(0.4f, 0.2f, 0.7f));
        var hat = GameObject.CreatePrimitive(PrimitiveType.Cylinder); Object.DestroyImmediate(hat.GetComponent<Collider>()); hat.transform.SetParent(npc.transform, false); hat.transform.localPosition = new Vector3(0, 1.1f, 0); hat.transform.localScale = new Vector3(1.2f, 0.1f, 1.2f); hat.GetComponent<Renderer>().sharedMaterial = Mat(Color.yellow);
        var t = Trigger("TalkZone", npc.transform.position, new Vector3(4, 3, 4)); t.AddComponent<QuestNpc>();
        var nl = new GameObject("ElderLight").AddComponent<Light>(); nl.transform.position = npc.transform.position + Vector3.up * 3; nl.color = new Color(0.7f, 0.5f, 1f); nl.range = 8;
        Vector3[] relics = { new Vector3(-40, 1, 30), new Vector3(38, 1, 34), new Vector3(42, 1, -30), new Vector3(-36, 1, -38), new Vector3(0, 1, 50), new Vector3(-50, 1, 0) };
        for (int i = 0; i < relics.Length; i++) { Pickup("EmberRelic_" + i, PrimitiveType.Sphere, relics[i], new Color(1f, 0.4f, 0.1f), "relic", 0.8f); Box("RelicPlinth_" + i, relics[i] - Vector3.up * 0.6f, new Vector3(1.4f, 0.4f, 1.4f), Color.gray); }
        MakeWalker(new Vector3(0, 1.1f, -6f));
        ScatterOwnedProps(Vector3.zero, 55f, 24, true);
        End(scene);
    }

    static void BuildPuzzle()
    {
        var scene = Begin("puzzle", new Color(0.55f, 0.5f, 0.42f), 3f);
        var room = new GameObject("Vault").transform; Walls(room, 13, 3, new Color(0.45f, 0.4f, 0.35f));
        // grid tiles (tile = 2)
        for (int x = -5; x <= 5; x++) for (int z = -5; z <= 5; z++) if ((x + z) % 2 == 0) Box("Tile", new Vector3(x * 2, 0.01f, z * 2), new Vector3(1.95f, 0.02f, 1.95f), new Color(0.5f, 0.46f, 0.38f), room).GetComponent<Collider>().enabled = false;
        Vector3[] blocks = { new Vector3(-4, 1, 2), new Vector3(2, 1, 4), new Vector3(4, 1, -2), new Vector3(-2, 1, -4) };
        Vector3[] pads = { new Vector3(-8, 0.05f, 2), new Vector3(2, 0.05f, 10), new Vector3(10, 0.05f, -2), new Vector3(-2, 0.05f, -8) };
        for (int i = 0; i < blocks.Length; i++)
        {
            var b = Box("PushBlock_" + i, blocks[i], new Vector3(1.9f, 1.9f, 1.9f), new Color(0.75f, 0.6f, 0.35f)); var rb = b.AddComponent<Rigidbody>(); rb.isKinematic = true; b.AddComponent<PushBlock>();
            var p = Box("Pad_" + i, pads[i], new Vector3(1.9f, 0.1f, 1.9f), new Color(0.2f, 0.5f, 1f)); Object.DestroyImmediate(p.GetComponent<Collider>()); p.AddComponent<PressurePad>();
        }
        Box("Pillar_A", new Vector3(6, 1, 6), new Vector3(1.9f, 2, 1.9f), Color.gray, room); Box("Pillar_B", new Vector3(-6, 1, -6), new Vector3(1.9f, 2, 1.9f), Color.gray, room);
        var player = MakeWalker(new Vector3(0, 1.1f, -10f)); player.AddComponent<BlockPusher>();
        var cam = player.GetComponentInChildren<Camera>(); if (cam) { cam.transform.localPosition = new Vector3(0, 4f, -4f); }
        ScatterOwnedProps(new Vector3(0, 0, 30), 10f, 8, false);
        End(scene);
    }

    static void BuildSurvival()
    {
        var scene = Begin("survival", new Color(0.32f, 0.42f, 0.22f), 14f);
        RenderSettings.ambientLight = new Color(0.25f, 0.22f, 0.3f);
        var sun = GameObject.Find("Directional Light"); if (sun) { var l = sun.GetComponent<Light>(); l.color = new Color(1f, 0.55f, 0.35f); l.intensity = 0.6f; sun.transform.rotation = Quaternion.Euler(8, 30, 0); }
        var forest = new GameObject("Forest").transform; var rnd = new System.Random(3);
        for (int i = 0; i < 22; i++)
        {
            var p = new Vector3(rnd.Next(-60, 60), 0, rnd.Next(-60, 60)); if (p.magnitude < 6) continue;
            var tr = new GameObject("Tree_" + i); tr.transform.position = p; tr.transform.SetParent(forest);
            Box("Trunk", p + Vector3.up * 1.5f, new Vector3(0.6f, 3, 0.6f), new Color(0.4f, 0.25f, 0.1f), tr.transform);
            var crown = GameObject.CreatePrimitive(PrimitiveType.Sphere); crown.transform.position = p + Vector3.up * 3.6f; crown.transform.localScale = Vector3.one * 2.6f; crown.GetComponent<Renderer>().sharedMaterial = Mat(new Color(0.15f, 0.4f, 0.15f)); crown.transform.SetParent(tr.transform, true); Object.DestroyImmediate(crown.GetComponent<Collider>());
            var bc = tr.AddComponent<BoxCollider>(); bc.isTrigger = true; bc.size = new Vector3(2.5f, 3, 2.5f); bc.center = Vector3.up * 1.5f; tr.AddComponent<ResourceNode>().kind = "wood";
        }
        for (int i = 0; i < 12; i++)
        {
            var p = new Vector3(rnd.Next(-50, 50), 0.5f, rnd.Next(-50, 50));
            var bush = GameObject.CreatePrimitive(PrimitiveType.Sphere); bush.name = "BerryBush_" + i; bush.transform.position = p; bush.transform.localScale = new Vector3(1.4f, 1f, 1.4f);
            bush.GetComponent<Renderer>().sharedMaterial = Mat(new Color(0.6f, 0.1f, 0.3f)); bush.GetComponent<Collider>().isTrigger = true; bush.AddComponent<ResourceNode>().kind = "food";
        }
        Box("Tent", new Vector3(3, 0.8f, 3), new Vector3(2.5f, 1.6f, 3), new Color(0.7f, 0.6f, 0.3f));
        var player = MakeWalker(new Vector3(0, 1.1f, 0)); player.AddComponent<SurvivalController>();
        ScatterOwnedProps(Vector3.zero, 60f, 20, true);
        End(scene);
    }

    static void BuildAdventure()
    {
        var scene = Begin("adventure", new Color(0.62f, 0.55f, 0.38f), 14f);
        var ruins = new GameObject("Ruins").transform; var rnd = new System.Random(5);
        for (int i = 0; i < 18; i++) { var p = new Vector3(rnd.Next(-55, 55), 0, rnd.Next(-55, 20)); float h = 1 + rnd.Next(0, 5); Box("RuinPillar_" + i, p + Vector3.up * h / 2, new Vector3(1.5f, h, 1.5f), new Color(0.55f, 0.5f, 0.45f), ruins); }
        // sealed courtyard with gate at z=30
        var court = new GameObject("ShrineCourt").transform; var cc = new Color(0.5f, 0.45f, 0.4f);
        Box("CourtWall_W", new Vector3(-14, 2.5f, 40), new Vector3(1, 5, 20), cc, court); Box("CourtWall_E", new Vector3(14, 2.5f, 40), new Vector3(1, 5, 20), cc, court);
        Box("CourtWall_N", new Vector3(0, 2.5f, 50), new Vector3(29, 5, 1), cc, court);
        Box("CourtWall_SW", new Vector3(-8.5f, 2.5f, 30), new Vector3(12, 5, 1), cc, court); Box("CourtWall_SE", new Vector3(8.5f, 2.5f, 30), new Vector3(12, 5, 1), cc, court);
        var gate = Box("SealedGate", new Vector3(0, 2.5f, 30), new Vector3(5, 5, 0.8f), new Color(0.35f, 0.2f, 0.1f)); gate.AddComponent<ExitGate>().isDoor = true;
        var shrine = Box("Shrine", new Vector3(0, 1.5f, 44), new Vector3(3, 3, 3), new Color(0.9f, 0.8f, 0.3f)); shrine.GetComponent<Collider>().isTrigger = true; shrine.AddComponent<ExitGate>();
        var key = Pickup("GateKey", PrimitiveType.Cube, new Vector3(-45, 1.2f, -40), new Color(1f, 0.85f, 0.1f), "key", 0.7f);
        for (int i = 0; i < 4; i++) Pickup("Treasure_" + i, PrimitiveType.Sphere, new Vector3(-40 + i * 25, 1, -10 + (i % 2) * 20), new Color(0.2f, 0.9f, 0.9f), "treasure", 0.6f);
        var marker = GameObject.CreatePrimitive(PrimitiveType.Cylinder); marker.name = "ObjectiveMarker"; Object.DestroyImmediate(marker.GetComponent<Collider>()); marker.transform.localScale = new Vector3(0.5f, 1.5f, 0.5f); marker.GetComponent<Renderer>().sharedMaterial = Mat(new Color(0.1f, 1f, 0.3f));
        var om = marker.AddComponent<ObjectiveMarker>(); om.key = key.transform; om.shrine = shrine.transform;
        var ml = new GameObject("MarkerLight").AddComponent<Light>(); ml.transform.SetParent(marker.transform, false); ml.color = Color.green; ml.range = 10; ml.intensity = 4;
        MakeWalker(new Vector3(0, 1.1f, -20f));
        ScatterOwnedProps(new Vector3(0, 0, -15), 50f, 22, true);
        End(scene);
    }

    static void BuildSim()
    {
        var scene = Begin("sim", new Color(0.7f, 0.68f, 0.62f), 4f);
        var shop = new GameObject("Shop").transform; var wc = new Color(0.85f, 0.8f, 0.7f);
        Walls(shop, 14, 4, wc);
        Box("Counter", new Vector3(0, 0.6f, 2), new Vector3(8, 1.2f, 1.2f), new Color(0.5f, 0.3f, 0.15f), shop);
        for (int i = 0; i < 4; i++) { Box("Shelf_" + i, new Vector3(-10 + i * 6.6f, 1.2f, 12), new Vector3(4, 2.4f, 1), new Color(0.6f, 0.4f, 0.2f), shop); for (int k = 0; k < 4; k++) Box("Goods", new Vector3(-11.4f + i * 6.6f + k * 0.9f, 1.6f, 11.4f), Vector3.one * 0.5f, Color.HSVToRGB(k * 0.22f, 0.7f, 0.9f), shop); }
        var counter = Trigger("ServeZone", new Vector3(0, 1, 4.2f), new Vector3(8, 3, 2.5f)); var sc = counter.AddComponent<ShopCounter>();
        var door = new GameObject("ShopDoor"); door.transform.position = new Vector3(0, 1, -13); sc.door = door.transform;
        var sp = new GameObject("CustomerSpot"); sp.transform.position = new Vector3(0, 1, 0.6f); sc.servePoint = sp.transform;
        var crate = Box("StockCrate", new Vector3(11, 0.6f, 10), new Vector3(1.6f, 1.2f, 1.6f), new Color(0.9f, 0.7f, 0.2f)); crate.GetComponent<Collider>().isTrigger = true; crate.AddComponent<StockCrate>();
        Box("DoorFrame", new Vector3(0, 3.5f, -13.4f), new Vector3(4, 1, 0.5f), Color.white, shop);
        var player = MakeWalker(new Vector3(6f, 1.1f, 9f)); player.transform.rotation = Quaternion.Euler(0, 205, 0);
        ScatterOwnedProps(new Vector3(0, 0, -35), 18f, 12, false);
        End(scene);
    }

    static void BuildRogue()
    {
        var scene = Begin("roguelike", new Color(0.2f, 0.18f, 0.22f), 8f);
        RenderSettings.ambientLight = new Color(0.2f, 0.15f, 0.25f);
        var dungeon = new GameObject("Dungeon").transform; var wc = new Color(0.35f, 0.3f, 0.4f);
        Walls(dungeon, 36, 4, wc);
        // procedural-ish room grid: random interior walls with doorways (seed changes per build)
        var rnd = new System.Random(System.Environment.TickCount);
        var pts = new System.Collections.Generic.List<Transform>();
        for (int rx = -1; rx <= 1; rx++) for (int rz = -1; rz <= 1; rz++)
        {
            Vector3 c = new Vector3(rx * 24, 0, rz * 24);
            if (rnd.Next(0, 2) == 0) Box("RoomWallX", c + new Vector3(-7, 2, 12), new Vector3(10, 4, 0.8f), wc, dungeon);
            if (rnd.Next(0, 2) == 0) Box("RoomWallZ", c + new Vector3(12, 2, 7), new Vector3(0.8f, 4, 10), wc, dungeon);
            for (int k = 0; k < rnd.Next(1, 4); k++) Box("Rubble", c + new Vector3(rnd.Next(-8, 8), 0.6f, rnd.Next(-8, 8)), new Vector3(1.5f, 1.2f, 1.5f), new Color(0.3f, 0.25f, 0.25f), dungeon);
            if (rx != 0 || rz != -1) { var sp = new GameObject("SpawnPoint"); sp.transform.position = c; pts.Add(sp.transform); var tl = new GameObject("Torch").AddComponent<Light>(); tl.transform.position = c + Vector3.up * 3; tl.color = new Color(1f, 0.5f, 0.2f); tl.range = 14; tl.intensity = 2; }
        }
        var ws = new GameObject("WaveSpawner").AddComponent<WaveSpawner>(); ws.points = pts.ToArray();
        for (int i = 0; i < 4; i++) { var a = Box("AmmoCrate_" + i, new Vector3(-20 + i * 13, 0.5f, -20 + (i % 2) * 40), Vector3.one * 0.8f, new Color(0.9f, 0.75f, 0.1f)); a.GetComponent<Collider>().isTrigger = true; a.AddComponent<AmmoPickup>(); }
        var player = MakeWalker(new Vector3(0, 1.1f, -24f)); player.AddComponent<GunController>(); AttachWeaponModel(player);
        ScatterOwnedProps(Vector3.zero, 32f, 14, true);
        End(scene);
    }

    // TryAttachImportedVisual removed (B-fix): it attached the first imported model of ANY kind to the player.
}




