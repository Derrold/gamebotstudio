# $env:CUDA_VISIBLE_DEVICES removed: Ollama auto-detects GPUs (old "1" hid the 3060 at index 0)
$env:OLLAMA_FLASH_ATTENTION = "0"
$env:OLLAMA_MODEL = "qwen-fast"
$env:PYTHONIOENCODING = "utf-8"
$env:PYTHONUTF8 = "1"
Remove-Item Env:OLLAMA_API_KEY -ErrorAction SilentlyContinue
$app = "$env:LOCALAPPDATA\Programs\Ollama\ollama app.exe"
if (-not (Get-Process "ollama app" -EA SilentlyContinue)) { Start-Process $app; Start-Sleep 3 }
Set-Location "$env:USERPROFILE\ollama-web"
python qwen_firefox_chat.py
pause
