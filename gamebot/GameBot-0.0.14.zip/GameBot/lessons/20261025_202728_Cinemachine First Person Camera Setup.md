# Cinemachine First Person Camera Setup

Tags: camera-cinemachine
Saved: 2026-10-25T20:27:28

To set up a first-person camera in Unity using Cinemachine 3 with Hard Lock to Target and Pan Tilt, follow the official documentation on dev.epicgames.com and docs.unity3d.com. Ensure that the Tracking Target is set to the head/eye pivot of your character model.
