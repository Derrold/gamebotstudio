# Customer support + patch notes
- Intake: Steam discussions/bug-report forum, email from the website, in-game "Report a bug" (copies Player.log path + system info to clipboard/file; opt-in only).
- Logs: Windows %USERPROFILE%\AppData\LocalLow\<Company>\<Product>\Player.log (read-only); ask players for it, never collect silently.
- Triage in Docs\Bugs.md: severity (crash/blocker/major/minor), repro steps, build version, platform; fix order by severity x frequency.
- Patch flow: fix -> regression gate -> bump bundleVersion -> build -> SteamPipe to beta branch -> test -> set live (human click) -> notes.
- Patch notes template (Docs\Store\patch_notes_<ver>.md): Highlights / Fixes / Balance / Known issues; plain language; credit reporters if they agree.
- Replies: drafts only; the creator posts (public posting is a human gate). Never share player data.
