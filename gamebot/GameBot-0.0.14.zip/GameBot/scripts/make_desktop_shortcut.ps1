param(
  [Parameter(Mandatory=$true)][string]$Name,
  [Parameter(Mandatory=$true)][string]$TargetPath,
  [string]$WorkingDirectory = "",
  [string]$IconPath = "",
  [string]$Description = "",
  [string]$AppUserModelID = "AlphaMaxStudios.GameBot",
  [string]$ShortcutPath = ""
)
$desk = [Environment]::GetFolderPath('Desktop')
if (-not $WorkingDirectory) { $WorkingDirectory = Split-Path -Parent $TargetPath }
if (-not $ShortcutPath) { $ShortcutPath = Join-Path $desk ($Name + ".lnk") }
$W = New-Object -ComObject WScript.Shell
$s = $W.CreateShortcut($ShortcutPath)
$s.TargetPath = $TargetPath
$s.WorkingDirectory = $WorkingDirectory
if ($IconPath) { $s.IconLocation = "$IconPath,0" }
if ($Description) { $s.Description = $Description }
$s.Save()
[void][System.Runtime.InteropServices.Marshal]::FinalReleaseComObject($s)
[void][System.Runtime.InteropServices.Marshal]::FinalReleaseComObject($W)
[GC]::Collect()
[GC]::WaitForPendingFinalizers()
Start-Sleep -Milliseconds 200
# COM shortcut object does not expose System.AppUserModel.ID; stamp it next.
$set = Join-Path $PSScriptRoot "Set-ShortcutAumid.ps1"
if ($AppUserModelID -and (Test-Path -LiteralPath $set)) {
  & $set -Path $ShortcutPath -Aumid $AppUserModelID
}
Write-Output "SHORTCUT $ShortcutPath Target=$TargetPath Icon=$IconPath AUMID=$AppUserModelID"
