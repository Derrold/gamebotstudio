"""Parse tool / function calls from any provider, including untrained models.

Native Ollama / OpenAI tool_calls are preferred. If the model writes a tool
call as JSON or XML in the text instead, we recover it. Malformed output
returns no tool calls so the existing deterministic pipelines can run.
"""
from __future__ import annotations

import json
import re
from typing import Any

_FENCE = re.compile(r"```(?:json|tool|tool_call)?\s*([\s\S]*?)```", re.I)
_XML = re.compile(
    r"<(?:tool_call|function_call|invoke)\s+name=['\"]([^'\"]+)['\"][^>]*>([\s\S]*?)</(?:tool_call|function_call|invoke)>",
    re.I,
)
_XML_PARAM = re.compile(r"<parameter\s+name=['\"]([^'\"]+)['\"]\s*>([\s\S]*?)</parameter>", re.I)
_FN_LINE = re.compile(r"(?:call|use|run)\s+tool\s+([a-zA-Z_][\w]*)\s*(?:\(|:)\s*(\{[\s\S]*?\})", re.I)


def _args(val: Any) -> dict:
    if isinstance(val, dict):
        return val
    if isinstance(val, str):
        s = val.strip()
        if not s:
            return {}
        try:
            parsed = json.loads(s)
            return parsed if isinstance(parsed, dict) else {}
        except Exception:
            return {}
    return {}


def _ok_name(name: Any, allowed: set[str] | None) -> str:
    n = str(name or "").strip()
    if not n or n in (".", "null", "none"):
        return ""
    if allowed is not None and n not in allowed:
        return ""
    return n


def _one(name: Any, arguments: Any, allowed: set[str] | None) -> dict | None:
    n = _ok_name(name, allowed)
    if not n:
        return None
    return {"function": {"name": n, "arguments": _args(arguments)}}


def from_native(msg: dict, allowed: set[str] | None = None) -> list[dict]:
    """Normalize Ollama / OpenAI / Anthropic-style tool_calls on a message."""
    if not isinstance(msg, dict):
        return []
    out: list[dict] = []
    for tc in msg.get("tool_calls") or []:
        if not isinstance(tc, dict):
            continue
        fn = tc.get("function") if isinstance(tc.get("function"), dict) else tc
        # OpenAI: {id, type, function:{name, arguments}}
        # Anthropic-like already flattened: {name, input} or {name, arguments}
        name = fn.get("name") or tc.get("name")
        args = fn.get("arguments") if "arguments" in fn else fn.get("input", tc.get("input", tc.get("arguments")))
        one = _one(name, args, allowed)
        if one:
            out.append(one)
    # Anthropic content blocks
    content = msg.get("content")
    if isinstance(content, list):
        for blk in content:
            if not isinstance(blk, dict):
                continue
            if str(blk.get("type") or "") in ("tool_use", "function"):
                one = _one(blk.get("name"), blk.get("input") or blk.get("arguments"), allowed)
                if one:
                    out.append(one)
    return out


def _from_obj(obj: Any, allowed: set[str] | None) -> list[dict]:
    found: list[dict] = []
    if isinstance(obj, dict):
        if "tool_calls" in obj and isinstance(obj["tool_calls"], list):
            found.extend(from_native(obj, allowed))
        name = obj.get("name") or obj.get("tool") or obj.get("function") or (obj.get("function") or {}).get("name") if isinstance(obj.get("function"), dict) else obj.get("name") or obj.get("tool")
        if not name and isinstance(obj.get("function"), str):
            name = obj.get("function")
        args = obj.get("arguments") or obj.get("parameters") or obj.get("input") or obj.get("args") or {}
        if isinstance(obj.get("function"), dict):
            name = name or obj["function"].get("name")
            args = obj["function"].get("arguments", args)
        one = _one(name, args, allowed)
        if one:
            found.append(one)
        # {"run_auto_game_pipeline": {"request": "..."}}
        if allowed:
            for k, v in obj.items():
                if k in allowed and k not in ("name", "tool", "function", "arguments", "parameters"):
                    one = _one(k, v if isinstance(v, dict) else {}, allowed)
                    if one:
                        found.append(one)
    elif isinstance(obj, list):
        for item in obj:
            found.extend(_from_obj(item, allowed))
    return found


def from_text(text: str, allowed: set[str] | None = None) -> list[dict]:
    """Recover tool calls written as JSON / XML in the assistant text."""
    if not text or not str(text).strip():
        return []
    s = str(text)
    found: list[dict] = []
    seen = set()

    def add(items: list[dict]) -> None:
        for it in items:
            key = json.dumps(it, sort_keys=True)
            if key not in seen:
                seen.add(key)
                found.append(it)

    for m in _FENCE.finditer(s):
        body = (m.group(1) or "").strip()
        if not body:
            continue
        try:
            add(_from_obj(json.loads(body), allowed))
        except Exception:
            pass
    # bare JSON object/array in the message
    for chunk in re.findall(r"(\{[\s\S]*\}|\[[\s\S]*\])", s):
        try:
            add(_from_obj(json.loads(chunk), allowed))
        except Exception:
            continue
    for m in _XML.finditer(s):
        args = {}
        for pm in _XML_PARAM.finditer(m.group(2) or ""):
            args[pm.group(1)] = pm.group(2).strip()
        if not args:
            try:
                args = json.loads((m.group(2) or "").strip() or "{}")
            except Exception:
                args = {}
        one = _one(m.group(1), args, allowed)
        if one:
            add([one])
    for m in _FN_LINE.finditer(s):
        one = _one(m.group(1), m.group(2), allowed)
        if one:
            add([one])
    return found


def extract(msg: dict, allowed: set[str] | None = None) -> tuple[list[dict], bool]:
    """Return (tool_calls, malformed).

    malformed=True when the model clearly tried to call a tool but the output
    could not be parsed — callers should fall back to deterministic pipelines
    and ignore the raw text as a tool plan.
    """
    native = from_native(msg or {}, allowed)
    if native:
        return native, False
    content = (msg or {}).get("content")
    text = content if isinstance(content, str) else ""
    if isinstance(content, list):
        parts = []
        for blk in content:
            if isinstance(blk, str):
                parts.append(blk)
            elif isinstance(blk, dict) and blk.get("type") in ("text", "output_text"):
                parts.append(str(blk.get("text") or blk.get("content") or ""))
        text = "\n".join(parts)
    recovered = from_text(text, allowed)
    if recovered:
        return recovered, False
    # Looks like a botched tool call (code fence + tool-ish keys) but unreadable.
    low = (text or "").lower()
    tried = ("tool_calls" in low or "<tool_call" in low or "function_call" in low
             or ("```" in (text or "") and any(k in low for k in ("arguments", "\"name\"", "invoke"))))
    return [], bool(tried)
