# Epic Games Store + EOS overview
Sources: https://dev.epicgames.com/docs/epic-online-services | https://dev.epicgames.com/docs/epic-games-store | https://dev.epicgames.com/docs/epic-games-store/publishing-tools/uploading-binaries/bpt-instructions-150 | https://dev.epicgames.com/docs/epic-account-services

## EGS publishing (summary)
- Epic Developer Portal: organization, product, store page offers, age ratings (IARC), payout/tax (human-only).
- Upload: BuildPatchTool (BPT) with Client ID/Secret from portal - upload build folder to an artifact, label it for a sandbox (Dev -> Stage -> Live). Launch command + args configured in portal.
- Store page: assets sizes from portal checklist; achievements optional (via EOS).

## EOS (optional, free, cross-platform)
- Services: Achievements, Stats, Leaderboards, Lobbies/P2P, Player Data Storage, Easy Anti-Cheat. Works on Steam builds too.
- Unity: EOS Plugin for Unity (PlayEveryWare, open source) or C# SDK. Init with ProductId/SandboxId/DeploymentId/ClientCredentials - NEVER invent IDs; the creator creates them in the portal.
- Epic Account Services (EAS) needed for user login with Epic account; Connect interface for Steam-auth players.

## When to use
- Skip EOS on Steam-only builds.
