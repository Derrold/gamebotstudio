"""Local Qwen + Firefox — act like a research assistant (real lookups, not scripts)."""
import os
import sys
import json
import urllib.request

# CUDA_VISIBLE_DEVICES left unset: Ollama auto-detects GPUs (hard-coded "1" hid the only NVIDIA GPU, index 0)
os.environ.pop("OLLAMA_API_KEY", None)
try:
    sys.stdout.reconfigure(encoding="utf-8")
except Exception:
    pass

from firefox_tools import firefox_search, firefox_open, ebay_search, firefox_close

MODEL = os.environ.get("OLLAMA_MODEL", "qwen-fast")
OLLAMA = os.environ.get("OLLAMA_HOST", "http://127.0.0.1:11434")

TOOLS = [
    {
        "type": "function",
        "function": {
            "name": "ebay_search",
            "description": "Find products on eBay sorted cheapest first (Buy It Now). Use when user asks for cheapest/price on eBay.",
            "parameters": {
                "type": "object",
                "properties": {
                    "query": {"type": "string"},
                    "max_results": {"type": "integer"},
                },
                "required": ["query"],
            },
        },
    },
    {
        "type": "function",
        "function": {
            "name": "firefox_search",
            "description": "General web search in local Firefox (DuckDuckGo).",
            "parameters": {
                "type": "object",
                "properties": {
                    "query": {"type": "string"},
                    "max_results": {"type": "integer"},
                },
                "required": ["query"],
            },
        },
    },
    {
        "type": "function",
        "function": {
            "name": "firefox_open",
            "description": "Open a URL in local Firefox and read the page.",
            "parameters": {
                "type": "object",
                "properties": {"url": {"type": "string"}},
                "required": ["url"],
            },
        },
    },
]

DISPATCH = {
    "ebay_search": lambda **a: ebay_search(a.get("query", ""), a.get("max_results", 8)),
    "firefox_search": lambda **a: firefox_search(a.get("query", ""), a.get("max_results", 5)),
    "firefox_open": lambda **a: firefox_open(a.get("url", "")),
}

SYSTEM = (
    "You are a hands-on research assistant like Grok. You run on this PC with local Firefox tools. "
    "When the user asks to find, price, compare, or look up anything online: CALL A TOOL immediately. "
    "For eBay / cheapest listing questions, call ebay_search first. "
    "NEVER write scraping scripts, NEVER tell them to visit a website themselves, NEVER give step-by-step how to search. "
    "Return real titles, prices, and links from tool results. Be concise. Cite URLs."
)


def chat_once(messages):
    body = {
        "model": MODEL,
        "messages": messages,
        "stream": False,
        "tools": TOOLS,
        "options": {"num_ctx": 8192, "temperature": 0.2},
    }
    req = urllib.request.Request(
        f"{OLLAMA}/api/chat",
        data=json.dumps(body).encode("utf-8"),
        headers={"Content-Type": "application/json"},
        method="POST",
    )
    with urllib.request.urlopen(req, timeout=300) as resp:
        return json.loads(resp.read().decode("utf-8"))


def run_turn(messages):
    for _ in range(8):
        data = chat_once(messages)
        msg = data.get("message") or {}
        messages.append(msg)
        tool_calls = msg.get("tool_calls") or []
        if tool_calls:
            for tc in tool_calls:
                fn = tc.get("function") or {}
                name = fn.get("name")
                args = fn.get("arguments") or {}
                if isinstance(args, str):
                    try:
                        args = json.loads(args)
                    except Exception:
                        args = {}
                print(f"\n>> {name}({args})")
                try:
                    out = DISPATCH.get(name, lambda **k: f"Unknown tool {name}")(**args)
                except Exception as e:
                    out = f"Error: {e}"
                print(f"   ({len(str(out))} chars)")
                messages.append({"role": "tool", "content": str(out)[:10000]})
            continue
        content = msg.get("content") or ""
        # If it answered without tools on a lookup-y prompt, force one search once
        if content and not any(m.get("role") == "tool" for m in messages[-6:]):
            last_user = next((m["content"] for m in reversed(messages) if m.get("role") == "user"), "")
            lu = (last_user or "").lower()
            if any(w in lu for w in ("ebay", "cheapest", "price", "find online", "look up", "search")):
                print("\n>> (auto) ebay_search / firefox_search")
                if "ebay" in lu:
                    out = ebay_search(last_user, 8)
                    name = "ebay_search"
                else:
                    out = firefox_search(last_user, 5)
                    name = "firefox_search"
                messages.append({"role": "assistant", "content": "", "tool_calls": [{"function": {"name": name, "arguments": {"query": last_user}}}]})
                messages.append({"role": "tool", "content": str(out)[:10000]})
                continue
        if content:
            print("\n" + content + "\n")
        break
    return messages


def main():
    print(f"Qwen + Firefox (Grok-style lookups) — {MODEL}")
    print("Uses YOUR Firefox. No cloud API caps.")
    print("IMPORTANT: use this window, not plain 'ollama run'.\n")
    messages = [{"role": "system", "content": SYSTEM}]
    while True:
        try:
            user = input("You> ").strip()
        except (EOFError, KeyboardInterrupt):
            print()
            break
        if not user:
            continue
        if user.lower() in {"/bye", "/exit", "quit"}:
            break
        messages.append({"role": "user", "content": user})
        messages = run_turn(messages)
    try:
        firefox_close()
    except Exception:
        pass


if __name__ == "__main__":
    main()
