# Auto studio pipeline run (CloudLeap)

Tags: auto studio pipeline
Saved: 2026-11-05T07:48:40

run_auto_game_pipeline created 32 files under C:\Users\ExtremeHybrid\Documents\GameProjects\CloudLeap and UNITY 6000.6.5f1: background job started -> create CloudLeapUnity -> Assets/Scenes/Slice01.unity (grey-box, player, goal, HUD) -> Builds\Windows\CloudLeap.exe. . Next: check Builds\auto_unity_status.txt, then work TaskBoard 'Auto next actions' with tools.
