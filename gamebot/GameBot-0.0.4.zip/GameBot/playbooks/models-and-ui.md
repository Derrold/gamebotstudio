# Models & UI playbook (Blender modelling, UV/PBR, Unity Canvas/UI Toolkit, Unreal UMG)
Sources: https://docs.blender.org/manual/en/latest/modeling/index.html · https://docs.blender.org/manual/en/latest/modeling/modifiers/index.html · https://docs.blender.org/api/current/bpy.ops.uv.html · https://docs.unity3d.com/Packages/com.unity.ugui@latest · https://docs.unity3d.com/Manual/UIElements.html · https://docs.unity3d.com/Packages/com.unity.textmeshpro@latest · https://dev.epicgames.com/documentation/en-us/unreal-engine/umg-ui-designer-for-unreal-engine

## Hard-surface (guns, tools, vehicles) via bpy
- Block out from primitives (bpy.ops.mesh.primitive_cylinder_add / cube_add) at real dimensions (barrel length, receiver size from public spec sheets — shapes only, no logos/brand marks).
- Bevel modifier (width 0.5–2 mm, segments 2–3, limit by angle 30°) + Weighted Normal modifier + auto smooth for clean shading; Boolean for cuts, then apply.
- Separate parts that animate (bolt, trigger, magazine, cylinder, lever) as child objects with origins at their pivot.
## Organic (animals, characters)
- Low-poly base + Subdivision Surface, sculpt detail, retopo to game budget, bake normal map from high to low. Skeleton with deform bones; weight paint; test poses before export.
## UV & PBR
- Mark seams on hidden edges; Smart UV Project (bpy.ops.uv.smart_project(angle_limit=66deg, island_margin=0.02)) for props; consistent texel density; pack with margin.
- Bake: Cycles bake (normal, AO) from high to low; textures named T_<asset>_BC/_N/_ORM. See assets-pipeline.md for channel packing per engine.
## Verify a model
- Script prints: dimensions (obj.dimensions), tri count, material count, UV layers. Render a preview PNG (bpy.ops.render.render(write_still=True)) and look at it (blender preview tools exist in ollama-web\scripts).

## Unity UI (uGUI)
- Canvas (Screen Space - Overlay for HUD), CanvasScaler Scale With Screen Size (1920x1080, match 0.5). EventSystem required for clicks. Text via TextMeshPro (TMP_Text).
- Anchors: HUD corners anchored to corners; menus centred. Split static and frequently-updated UI into separate Canvases (rebuild cost).
- Gamepad: set Selectable navigation + EventSystem.firstSelectedGameObject on each screen open.
## Unity UI Toolkit
- UXML (layout) + USS (style) + UIDocument component; query with root.Q<Button>("play").clicked += ...; good for menus/inventory/editor tools.
## Unreal UMG
- Widget Blueprint (Designer + Graph), CreateWidget + AddToViewport; bind via C++ UPROPERTY(meta=(BindWidget)). Use Common UI plugin for gamepad-friendly menus.

## Screens every game needs
- HUD: health/stamina or tool state, ammo, compass/minimap, interaction prompt, hit/kill feedback, toasts.
- Menus: main, pause, settings (graphics/audio/controls with rebinding), loadout, shop, inventory (grid, stack counts, tooltips, compare), map, results.
- Reuse those styles instead of inventing new ones.
