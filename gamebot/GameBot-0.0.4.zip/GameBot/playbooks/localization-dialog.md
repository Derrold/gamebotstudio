﻿# Localization / dialogue
String tables (en first); UTF-8; font fallbacks; dialogue ScriptableObjects or yarn-like CSV; never hardcode player-facing English in code after first pass.
