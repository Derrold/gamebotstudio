﻿using UnityEngine;

public class CoinPickup : MonoBehaviour
{
    void Update() { transform.Rotate(0f, 90f * Time.deltaTime, 0f); }
    void OnTriggerEnter(Collider other)
    {
        if (!other.CompareTag("Player")) return;
        GameState.Coins++;
        AchievementSystem.NotifyCoin(GameState.Coins);
        GameState.SaveContinue();
        Destroy(gameObject);
    }
}
