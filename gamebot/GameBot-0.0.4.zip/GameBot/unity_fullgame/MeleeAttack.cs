using UnityEngine;
/// <summary>Action family: melee swing cone (LMB / J) with combo chain, Shift dash. Hits EnemyTarget and IGbDamage.</summary>
public class MeleeAttack : MonoBehaviour
{
    public float range = 2.8f, arc = 75f, cd = 0.32f, dashCd = 1.1f; public int damage = 1;
    float next, nextDash, comboUntil; int chain; Transform weapon; float swingT;
    CharacterController cc;
    void Start() { cc = GetComponent<CharacterController>(); weapon = transform.Find("CharacterVisual/Weapon") ?? transform.Find("Weapon"); }
    void Update()
    {
        if (GameState.Won || GameState.Lost || PauseMenu.IsPaused || MainMenuUI.InMenu) return;
        if (weapon) { swingT = Mathf.MoveTowards(swingT, 0, Time.deltaTime * 6f); weapon.localRotation = Quaternion.Euler(-90f * swingT, 30f * swingT, 0); }
        if ((Input.GetMouseButtonDown(0) || Input.GetKeyDown(KeyCode.J) || GameBotQA.AutoFire) && Time.time >= next)
        {
            next = Time.time + cd; swingT = 1f;
            chain = Time.time < comboUntil ? chain + 1 : 1; comboUntil = Time.time + 1.0f;
            if (chain > GenreState.Combo) GenreState.Combo = chain; if (chain >= 5) AchievementSystem.Unlock("combo_5");
            int dmg = damage + (chain % 3 == 0 ? 1 : 0); int hits = 0;
            foreach (var e in FindObjectsByType<EnemyTarget>(FindObjectsSortMode.None))
            {
                Vector3 to = e.transform.position - transform.position; to.y = 0;
                if (to.magnitude <= range && Vector3.Angle(transform.forward, to) <= arc) { e.Hit(dmg); e.transform.position += to.normalized * 0.8f; hits++; }
            }
            if (hits > 0 && chain % 3 == 0) GameHUD.Flash("Combo x" + chain + "!");
        }
        if (Input.GetKeyDown(KeyCode.LeftShift) && Time.time >= nextDash && cc) { nextDash = Time.time + dashCd; cc.Move(transform.forward * 5f); }
    }
}
