﻿"""Self-teaching: save lessons from successful work so future turns improve."""
from __future__ import annotations

import json
from datetime import datetime
from pathlib import Path

ROOT = Path(__file__).resolve().parent
LESSONS = ROOT / "lessons"
LESSONS.mkdir(exist_ok=True)
INDEX = LESSONS / "index.json"


def _load_index() -> list:
    if INDEX.exists():
        try:
            return json.loads(INDEX.read_text(encoding="utf-8"))
        except Exception:
            return []
    return []


def _save_index(items: list) -> None:
    INDEX.write_text(json.dumps(items[-400:], indent=2, ensure_ascii=False), encoding="utf-8")


def teach_self(title: str, lesson: str, tags: str = "") -> str:
    """Save a lesson Game Bot learned (what worked / what to avoid). Use after a successful pattern or user correction."""
    title = (title or "lesson").strip()
    lesson = (lesson or "").strip()
    if not lesson:
        return "Empty lesson."
    safe = "".join(c if c.isalnum() or c in "-_ " else "_" for c in title)[:60].strip() or "lesson"
    stamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    path = LESSONS / f"{stamp}_{safe}.md"
    body = f"# {title}\n\nTags: {tags}\nSaved: {datetime.now().isoformat(timespec='seconds')}\n\n{lesson}\n"
    path.write_text(body, encoding="utf-8")
    items = _load_index()
    items.append({"title": title, "tags": tags, "path": str(path), "saved": stamp})
    _save_index(items)
    return f"Saved lesson: {path.name}"


def list_lessons(query: str = "") -> str:
    """List saved self-taught lessons. Optional query filters title/tags."""
    items = _load_index()
    q = (query or "").lower().strip()
    if q:
        items = [i for i in items if q in (i.get("title", "") + " " + i.get("tags", "")).lower()]
    if not items:
        return "No lessons saved yet." if not q else f"No lessons matching '{query}'."
    lines = []
    for i in items[-30:]:
        lines.append(f"- {i.get('title')} [{i.get('tags','')}] → {Path(i.get('path','')).name}")
    return "Lessons:\n" + "\n".join(lines)


def read_lesson(title_or_filename: str) -> str:
    """Read a saved lesson by title substring or filename."""
    key = (title_or_filename or "").lower().strip()
    if not key:
        return "Give a title or filename."
    # direct file
    p = LESSONS / title_or_filename
    if p.exists():
        return p.read_text(encoding="utf-8")[:10000]
    for f in sorted(LESSONS.glob("*.md"), reverse=True):
        if key in f.name.lower() or key in f.read_text(encoding="utf-8", errors="replace")[:200].lower():
            return f.read_text(encoding="utf-8")[:10000]
    return f"Lesson not found: {title_or_filename}"


def lessons_for_prompt(limit: int = 8) -> str:
    """Compact recent lessons for system prompt injection."""
    items = _load_index()[-limit:]
    if not items:
        return "(none yet)"
    chunks = []
    for i in reversed(items):
        path = Path(i.get("path", ""))
        if path.exists():
            text = path.read_text(encoding="utf-8", errors="replace")
            # strip header, keep body short
            body = text.split("\n\n", 2)[-1] if "\n\n" in text else text
            chunks.append(f"• {i.get('title')}: {body.strip()[:400]}")
    return "\n".join(chunks) if chunks else "(none yet)"


# ---- 2026-10-25: relevance-based recall over lessons + playbooks (game-dev training) ----
import re as _re

PLAYBOOKS = ROOT / "playbooks"
_STOP = set("the a an and or to of in on for with is are be it this that my me you your do does how what why when can i we from at as by".split())


def _words(s: str) -> list[str]:
    return [w for w in _re.findall(r"[a-z0-9_.#+]+", (s or "").lower()) if len(w) > 1 and w not in _STOP]


def _score(qwords: list[str], title: str, tags: str, body: str) -> float:
    t, g, b = title.lower(), tags.lower(), body.lower()
    s = 0.0
    for w in qwords:
        if w in t: s += 3
        if w in g: s += 2
        if w in b: s += 1 + min(b.count(w), 5) * 0.2
    return s


def relevant_lessons(query: str, k: int = 5, chars: int = 350) -> str:
    """Lessons most relevant to the query (keyword score), newest wins ties."""
    q = _words(query)
    files = sorted(LESSONS.glob("*.md"), reverse=True)
    scored = []
    for f in files:
        txt = f.read_text(encoding="utf-8", errors="replace")
        title = txt.splitlines()[0].lstrip("# ").strip() if txt else f.stem
        m = _re.search(r"^Tags:(.*)$", txt, _re.M)
        tags = m.group(1) if m else ""
        body = txt.split("\n\n", 2)[-1]
        s = _score(q, title, tags, body) if q else 0
        if s > 0:
            scored.append((s, f.name, title, body))
    scored.sort(key=lambda x: x[1], reverse=True)  # newest first
    scored.sort(key=lambda x: -x[0])  # stable: best score, newest wins ties
    out = [f"• {t}: {b.strip()[:chars]}" for _, _, t, b in scored[:k]]
    return "\n".join(out) if out else "(no matching lessons)"


def search_playbooks(query: str, k: int = 3, chars: int = 900) -> str:
    """Search playbooks/*.md by keywords; returns best matching sections (heading + text)."""
    q = _words(query)
    if not PLAYBOOKS.exists():
        return "No playbooks folder."
    hits = []
    for f in PLAYBOOKS.glob("*.md"):
        txt = f.read_text(encoding="utf-8", errors="replace")
        for sec in _re.split(r"\n(?=## )", txt):
            head = sec.splitlines()[0] if sec else ""
            s = _score(q, f.stem + " " + head, "", sec)
            if s > 0:
                hits.append((s, f.name, sec.strip()))
    if not hits:
        return f"No playbook section matches '{query}'. Try firefox_search on official docs, then teach_self."
    hits.sort(key=lambda x: -x[0])
    return "\n\n".join(f"[{n}]\n{sec[:chars]}" for _, n, sec in hits[:k])


def read_playbook(name: str) -> str:
    """Read a playbook by filename or name fragment (e.g. 'unity-workflow')."""
    key = (name or "").lower().strip().replace(".md", "")
    for f in sorted(PLAYBOOKS.glob("*.md")):
        if key and key in f.stem.lower():
            return f.read_text(encoding="utf-8", errors="replace")[:9000]
    return "Playbooks: " + ", ".join(sorted(p.name for p in PLAYBOOKS.glob("*.md")))
