# Unity Profiler Standalone Process Performance-Profiling

Tags: Unity, Profiler, Performance, Standalone Process
Saved: 2026-10-25T20:28:44

To profile a Unity development build using the standalone process for performance analysis, follow these steps:

1. Ensure you are working with a standalone build (not in the Editor) to avoid overhead and inaccuracies.
2. Use the FrameTimingManager class to capture frame timings during gameplay or specific scenarios.
3. Configure vsync off and targetFrameRate uncapped for accurate FPS measurement.
4. Attach the Unity Profiler via Autoconnect Profiler or use the standalone process method as described in the official documentation: https://docs.unity.com/Manual/profiler-standalone.html
