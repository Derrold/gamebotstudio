param($proj,[string[]]$packs)
$unity=(python -c "import auto_studio as a;print(a.find_unity())")
foreach($pk in $packs){ $f=Get-ChildItem "$env:APPDATA\Unity\Asset Store-5.x" -Recurse -Filter "$pk.unitypackage" | select -First 1
 $env:GAMEBOT_IMPORT_PACKAGE=$f.FullName
 $p=Start-Process $unity -ArgumentList @("-batchmode","-nographics","-quit","-projectPath","`"$proj`"","-importPackage","`"$($f.FullName)`"","-logFile","`"$proj\..\Builds\import_$($pk -replace '\W','_').log`"") -Wait -PassThru -WindowStyle Hidden
 "$pk exit $($p.ExitCode)" }

