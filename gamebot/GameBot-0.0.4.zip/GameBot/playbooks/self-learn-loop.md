# Game Bot self-learning loop (how Game Bot gets smarter on its own)
Sources: https://docs.unity3d.com/ScriptReference/ · https://dev.epicgames.com/documentation/en-us/unreal-engine/API · https://docs.blender.org/api/current/ · https://github.com/ollama/ollama/blob/main/docs/api.md

## The loop (every task)
1. Recall: list_lessons / search_playbooks(query) — use what you already learned.
2. Act with tools (run_powershell, run_blender_script, write_text_file, Unity batchmode). Never answer with a tutorial when a tool can do it.
3. Verify: file exists + size, exit code, log grep ('error CS', 'Exception', 'BUILD SUCCESSFUL').
4. If it failed or you were unsure of an API: firefox_search "<exact error or API> site:docs.unity3d.com" (or dev.epicgames.com / docs.blender.org), firefox_open the best official hit, read it.
5. Patch and retry ONCE. Still failing -> report the exact error + what you tried.
6. teach_self(title, lesson, tags): 3–8 lines: symptom -> cause -> fix command -> how to verify -> source URL. No copied manuals.

## What makes a good lesson
- Title = the problem in searchable words ("Unity CS0246 UnityEditor in runtime script").
- Body starts with the action ("Move file to Assets/Editor or wrap in #if UNITY_EDITOR").
- Include the success check and source URL. Tags: unity, unreal, blender, design, ui, build, fix.

## Search tips
- Prefer official docs: docs.unity3d.com/ScriptReference/<Class>.<Member>.html, docs.unity3d.com/Manual/, dev.epicgames.com/documentation, docs.blender.org/api/current/bpy.ops.<module>.html.
- Then forums: discussions.unity.com, forums.unrealengine.com, blender.stackexchange.com. Check the version (Unity 6 / UE 5.x / Blender 4–5).
- Quote the exact compiler error code + message.

## Limits (be honest)
- Local model has ~6k context: keep lessons short; load playbooks by search, not all at once.
- Web reading is limited to ~6000 chars per page; open 1–3 pages max per problem.
