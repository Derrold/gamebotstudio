"""Launch Windows child processes at medium integrity (not Administrator).

Unity shows 'Unity is not designed to run with Administrator privileges' when
Game Bot itself is elevated and starts Unity.exe / Unity Hub with a Popen that
inherits the admin token. This helper starts those children with the unelevated
Explorer token (CreateProcessWithTokenW). No UAC prompt is shown — we only drop
privileges, we never request them.
"""
from __future__ import annotations

import os
import subprocess
import sys
from pathlib import Path

CREATE_NO_WINDOW = 0x08000000
CREATE_NEW_PROCESS_GROUP = 0x00000200
DETACHED_PROCESS = 0x00000008
CREATE_UNICODE_ENVIRONMENT = 0x00000400


def is_elevated() -> bool:
    if sys.platform != "win32":
        return False
    import ctypes
    try:
        return bool(ctypes.windll.shell32.IsUserAnAdmin())
    except Exception:
        return False


def _popen(args: list, cwd=None, hidden: bool = True, env=None):
    flags = CREATE_NEW_PROCESS_GROUP
    si = None
    if os.name == "nt":
        if hidden:
            flags |= CREATE_NO_WINDOW
            si = subprocess.STARTUPINFO()
            si.dwFlags |= subprocess.STARTF_USESHOWWINDOW
            si.wShowWindow = 0
    return subprocess.Popen(
        args,
        cwd=str(cwd) if cwd else None,
        env=env,
        creationflags=flags if os.name == "nt" else 0,
        startupinfo=si,
        stdin=subprocess.DEVNULL,
        stdout=subprocess.DEVNULL,
        stderr=subprocess.DEVNULL,
        close_fds=True,
    )


def _explorer_token():
    """Primary token of an unelevated explorer.exe in this session, or None."""
    import ctypes
    from ctypes import wintypes
    kernel32 = ctypes.windll.kernel32
    advapi32 = ctypes.windll.advapi32
    kernel32.ProcessIdToSessionId.argtypes = [wintypes.DWORD, ctypes.POINTER(wintypes.DWORD)]
    kernel32.ProcessIdToSessionId.restype = wintypes.BOOL
    mysid = wintypes.DWORD()
    if not kernel32.ProcessIdToSessionId(kernel32.GetCurrentProcessId(), ctypes.byref(mysid)):
        return None

    # Toolhelp snapshot of processes
    class PROCESSENTRY32W(ctypes.Structure):
        _fields_ = [
            ("dwSize", wintypes.DWORD),
            ("cntUsage", wintypes.DWORD),
            ("th32ProcessID", wintypes.DWORD),
            ("th32DefaultHeapID", ctypes.POINTER(ctypes.c_ulong)),
            ("th32ModuleID", wintypes.DWORD),
            ("cntThreads", wintypes.DWORD),
            ("th32ParentProcessID", wintypes.DWORD),
            ("pcPriClassBase", ctypes.c_long),
            ("dwFlags", wintypes.DWORD),
            ("szExeFile", wintypes.WCHAR * 260),
        ]
    TH32CS_SNAPPROCESS = 0x00000002
    kernel32.CreateToolhelp32Snapshot.restype = wintypes.HANDLE
    snap = kernel32.CreateToolhelp32Snapshot(TH32CS_SNAPPROCESS, 0)
    if snap in (0, wintypes.HANDLE(-1).value if hasattr(wintypes.HANDLE(-1), "value") else 0):
        # INVALID_HANDLE_VALUE
        pass
    if not snap or snap == wintypes.HANDLE(-1).value:
        # try anyway with 0xFFFFFFFF
        if snap == kernel32.CreateToolhelp32Snapshot.__doc__:
            return None

    INVALID = 0xFFFFFFFFFFFFFFFF if ctypes.sizeof(ctypes.c_void_p) == 8 else 0xFFFFFFFF
    if snap is None or int(snap) in (0, INVALID, -1):
        return None

    pe = PROCESSENTRY32W()
    pe.dwSize = ctypes.sizeof(PROCESSENTRY32W)
    pids = []
    if kernel32.Process32FirstW(snap, ctypes.byref(pe)):
        while True:
            if pe.szExeFile.lower() == "explorer.exe":
                sid = wintypes.DWORD()
                if kernel32.ProcessIdToSessionId(pe.th32ProcessID, ctypes.byref(sid)) and sid.value == mysid.value:
                    pids.append(int(pe.th32ProcessID))
            if not kernel32.Process32NextW(snap, ctypes.byref(pe)):
                break
    kernel32.CloseHandle(snap)

    PROCESS_QUERY_INFORMATION = 0x0400
    PROCESS_QUERY_LIMITED_INFORMATION = 0x1000
    TOKEN_ASSIGN_PRIMARY = 0x0001
    TOKEN_DUPLICATE = 0x0002
    TOKEN_QUERY = 0x0008
    TOKEN_IMPERSONATE = 0x0004
    want = TOKEN_ASSIGN_PRIMARY | TOKEN_DUPLICATE | TOKEN_QUERY | TOKEN_IMPERSONATE
    SecurityImpersonation = 2
    TokenPrimary = 1

    class TOKEN_ELEVATION(ctypes.Structure):
        _fields_ = [("TokenIsElevated", wintypes.DWORD)]

    for pid in pids:
        hp = kernel32.OpenProcess(PROCESS_QUERY_INFORMATION | PROCESS_QUERY_LIMITED_INFORMATION, False, pid)
        if not hp:
            hp = kernel32.OpenProcess(PROCESS_QUERY_LIMITED_INFORMATION, False, pid)
        if not hp:
            continue
        try:
            tok = wintypes.HANDLE()
            if not advapi32.OpenProcessToken(hp, TOKEN_DUPLICATE | TOKEN_QUERY, ctypes.byref(tok)):
                continue
            ev = TOKEN_ELEVATION()
            ret = wintypes.DWORD()
            advapi32.GetTokenInformation(tok, 20, ctypes.byref(ev), ctypes.sizeof(ev), ctypes.byref(ret))
            if ev.TokenIsElevated:
                kernel32.CloseHandle(tok)
                continue
            dup = wintypes.HANDLE()
            ok = advapi32.DuplicateTokenEx(tok, want, None, SecurityImpersonation, TokenPrimary, ctypes.byref(dup))
            kernel32.CloseHandle(tok)
            if ok and dup:
                return dup
        finally:
            kernel32.CloseHandle(hp)
    return None



def _explorer_pid():
    """PID of an unelevated explorer.exe in this session, or None."""
    import ctypes
    from ctypes import wintypes
    kernel32 = ctypes.windll.kernel32
    mysid = wintypes.DWORD()
    kernel32.ProcessIdToSessionId.argtypes = [wintypes.DWORD, ctypes.POINTER(wintypes.DWORD)]
    kernel32.ProcessIdToSessionId.restype = wintypes.BOOL
    if not kernel32.ProcessIdToSessionId(kernel32.GetCurrentProcessId(), ctypes.byref(mysid)):
        return None
    import subprocess
    r = subprocess.run(
        ["powershell", "-NoProfile", "-Command",
         "Get-Process explorer -EA SilentlyContinue | ForEach-Object { $_.Id }"],
        capture_output=True, text=True, timeout=15, creationflags=CREATE_NO_WINDOW,
    )
    for tok in (r.stdout or "").split():
        if not tok.strip().isdigit():
            continue
        pid = int(tok)
        sid = wintypes.DWORD()
        if kernel32.ProcessIdToSessionId(pid, ctypes.byref(sid)) and sid.value == mysid.value:
            # prefer a non-elevated explorer
            el = pid_is_elevated(pid)
            if el is False or el is None:
                return pid
    return None


def _launch_as_explorer_child(args: list, cwd=None, hidden: bool = True, env=None):
    """Create the child with Explorer as its parent so it inherits medium integrity."""
    import ctypes
    from ctypes import wintypes
    exp = _explorer_pid()
    if not exp:
        raise OSError("no unelevated explorer.exe in this session")
    kernel32 = ctypes.windll.kernel32
    PROCESS_CREATE_PROCESS = 0x0080
    kernel32.OpenProcess.argtypes = [wintypes.DWORD, wintypes.BOOL, wintypes.DWORD]
    kernel32.OpenProcess.restype = wintypes.HANDLE
    hparent = kernel32.OpenProcess(PROCESS_CREATE_PROCESS, False, int(exp))
    if not hparent:
        raise OSError(ctypes.GetLastError(), "OpenProcess(PROCESS_CREATE_PROCESS) on explorer failed")

    class STARTUPINFOW(ctypes.Structure):
        _fields_ = [
            ("cb", wintypes.DWORD),
            ("lpReserved", wintypes.LPWSTR),
            ("lpDesktop", wintypes.LPWSTR),
            ("lpTitle", wintypes.LPWSTR),
            ("dwX", wintypes.DWORD), ("dwY", wintypes.DWORD),
            ("dwXSize", wintypes.DWORD), ("dwYSize", wintypes.DWORD),
            ("dwXCountChars", wintypes.DWORD), ("dwYCountChars", wintypes.DWORD),
            ("dwFillAttribute", wintypes.DWORD),
            ("dwFlags", wintypes.DWORD),
            ("wShowWindow", wintypes.WORD),
            ("cbReserved2", wintypes.WORD),
            ("lpReserved2", ctypes.POINTER(ctypes.c_byte)),
            ("hStdInput", wintypes.HANDLE),
            ("hStdOutput", wintypes.HANDLE),
            ("hStdError", wintypes.HANDLE),
        ]

    class STARTUPINFOEXW(ctypes.Structure):
        _fields_ = [("StartupInfo", STARTUPINFOW), ("lpAttributeList", ctypes.c_void_p)]

    class PROCESS_INFORMATION(ctypes.Structure):
        _fields_ = [
            ("hProcess", wintypes.HANDLE),
            ("hThread", wintypes.HANDLE),
            ("dwProcessId", wintypes.DWORD),
            ("dwThreadId", wintypes.DWORD),
        ]

    EXTENDED_STARTUPINFO_PRESENT = 0x00080000
    PROC_THREAD_ATTRIBUTE_PARENT_PROCESS = 0x00020000
    STARTF_USESHOWWINDOW = 0x00000001

    size = ctypes.c_size_t(0)
    kernel32.InitializeProcThreadAttributeList.argtypes = [ctypes.c_void_p, wintypes.DWORD, wintypes.DWORD, ctypes.POINTER(ctypes.c_size_t)]
    kernel32.InitializeProcThreadAttributeList.restype = wintypes.BOOL
    kernel32.InitializeProcThreadAttributeList(None, 1, 0, ctypes.byref(size))
    buf = ctypes.create_string_buffer(size.value)
    if not kernel32.InitializeProcThreadAttributeList(buf, 1, 0, ctypes.byref(size)):
        kernel32.CloseHandle(hparent)
        raise OSError(ctypes.GetLastError(), "InitializeProcThreadAttributeList failed")
    kernel32.UpdateProcThreadAttribute.argtypes = [
        ctypes.c_void_p, wintypes.DWORD, ctypes.c_size_t, ctypes.c_void_p,
        ctypes.c_size_t, ctypes.c_void_p, ctypes.c_void_p,
    ]
    kernel32.UpdateProcThreadAttribute.restype = wintypes.BOOL
    parent_holder = wintypes.HANDLE(hparent)
    ok = kernel32.UpdateProcThreadAttribute(
        buf, 0, PROC_THREAD_ATTRIBUTE_PARENT_PROCESS,
        ctypes.byref(parent_holder), ctypes.sizeof(parent_holder), None, None,
    )
    if not ok:
        err = ctypes.GetLastError()
        kernel32.DeleteProcThreadAttributeList(buf)
        kernel32.CloseHandle(hparent)
        raise OSError(err, "UpdateProcThreadAttribute failed")

    siex = STARTUPINFOEXW()
    siex.StartupInfo.cb = ctypes.sizeof(STARTUPINFOEXW)
    siex.StartupInfo.dwFlags = STARTF_USESHOWWINDOW
    siex.StartupInfo.wShowWindow = 0 if hidden else 1
    siex.lpAttributeList = ctypes.cast(buf, ctypes.c_void_p)
    pi = PROCESS_INFORMATION()

    def q(a: str) -> str:
        if not a or any(ch in a for ch in ' \t"'):
            return '"' + a.replace('"', '\\"') + '"'
        return a
    cmd = " ".join(q(str(a)) for a in args)
    cmd_buf = ctypes.create_unicode_buffer(cmd)
    exe = str(args[0])
    flags = CREATE_UNICODE_ENVIRONMENT | CREATE_NEW_PROCESS_GROUP | EXTENDED_STARTUPINFO_PRESENT
    if hidden:
        flags |= CREATE_NO_WINDOW
    env_block = None
    if env is not None:
        parts = [f"{k}={v}" for k, v in env.items() if v is not None]
        raw = "\0".join(parts) + "\0\0"
        env_block = ctypes.create_unicode_buffer(raw)
    cwd_s = str(cwd) if cwd else None
    kernel32.CreateProcessW.argtypes = [
        wintypes.LPCWSTR, wintypes.LPWSTR, ctypes.c_void_p, ctypes.c_void_p,
        wintypes.BOOL, wintypes.DWORD, ctypes.c_void_p, wintypes.LPCWSTR,
        ctypes.c_void_p, ctypes.POINTER(PROCESS_INFORMATION),
    ]
    kernel32.CreateProcessW.restype = wintypes.BOOL
    created = kernel32.CreateProcessW(
        exe, cmd_buf, None, None, False, flags, env_block, cwd_s,
        ctypes.byref(siex), ctypes.byref(pi),
    )
    err = ctypes.GetLastError()
    kernel32.DeleteProcThreadAttributeList(buf)
    kernel32.CloseHandle(hparent)
    if not created:
        raise OSError(err, f"CreateProcessW(parent=explorer) failed ({err}) for {exe}")
    kernel32.CloseHandle(pi.hThread)
    return _Proc(int(pi.dwProcessId), pi.hProcess)


def _launch_with_token(token, args: list, cwd=None, hidden: bool = True, env=None):
    import ctypes
    from ctypes import wintypes

    class STARTUPINFOW(ctypes.Structure):
        _fields_ = [
            ("cb", wintypes.DWORD),
            ("lpReserved", wintypes.LPWSTR),
            ("lpDesktop", wintypes.LPWSTR),
            ("lpTitle", wintypes.LPWSTR),
            ("dwX", wintypes.DWORD), ("dwY", wintypes.DWORD),
            ("dwXSize", wintypes.DWORD), ("dwYSize", wintypes.DWORD),
            ("dwXCountChars", wintypes.DWORD), ("dwYCountChars", wintypes.DWORD),
            ("dwFillAttribute", wintypes.DWORD),
            ("dwFlags", wintypes.DWORD),
            ("wShowWindow", wintypes.WORD),
            ("cbReserved2", wintypes.WORD),
            ("lpReserved2", ctypes.POINTER(ctypes.c_byte)),
            ("hStdInput", wintypes.HANDLE),
            ("hStdOutput", wintypes.HANDLE),
            ("hStdError", wintypes.HANDLE),
        ]

    class PROCESS_INFORMATION(ctypes.Structure):
        _fields_ = [
            ("hProcess", wintypes.HANDLE),
            ("hThread", wintypes.HANDLE),
            ("dwProcessId", wintypes.DWORD),
            ("dwThreadId", wintypes.DWORD),
        ]

    STARTF_USESHOWWINDOW = 0x00000001
    SW_HIDE = 0
    SW_SHOWNORMAL = 1
    si = STARTUPINFOW()
    si.cb = ctypes.sizeof(STARTUPINFOW)
    si.dwFlags = STARTF_USESHOWWINDOW
    si.wShowWindow = SW_HIDE if hidden else SW_SHOWNORMAL
    pi = PROCESS_INFORMATION()

    exe = str(args[0])
    # Quote command line
    def q(a: str) -> str:
        if not a or any(ch in a for ch in ' \t"'):
            return '"' + a.replace('"', '\\"') + '"'
        return a
    cmd = " ".join(q(str(a)) for a in args)
    cmd_buf = ctypes.create_unicode_buffer(cmd)

    flags = CREATE_UNICODE_ENVIRONMENT | CREATE_NEW_PROCESS_GROUP
    if hidden:
        flags |= CREATE_NO_WINDOW

    # Environment block (Unicode, null-separated, double-null terminated)
    env_block = None
    if env is not None:
        parts = [f"{k}={v}" for k, v in env.items() if v is not None]
        raw = "\0".join(parts) + "\0\0"
        env_block = ctypes.create_unicode_buffer(raw)

    cwd_s = str(cwd) if cwd else None
    CreateProcessWithTokenW = ctypes.windll.advapi32.CreateProcessWithTokenW
    CreateProcessWithTokenW.restype = wintypes.BOOL
    ok = CreateProcessWithTokenW(
        token,
        0,  # no extra logon flags (do not trigger UAC)
        exe,
        cmd_buf,
        flags,
        env_block,
        cwd_s,
        ctypes.byref(si),
        ctypes.byref(pi),
    )
    if not ok:
        err = ctypes.GetLastError()
        raise OSError(err, f"CreateProcessWithTokenW failed ({err}) for {exe}")
    pid = int(pi.dwProcessId)
    # We don't need the handles; wrap as Popen-like via pid
    ctypes.windll.kernel32.CloseHandle(pi.hThread)
    # Keep hProcess? Popen needs a wait handle. Return a simple box.
    return _Proc(pid, pi.hProcess)


class _Proc:
    """Minimal process handle so callers can use .pid / .poll / .wait / .terminate."""

    def __init__(self, pid: int, handle):
        self.pid = pid
        self._handle = handle
        self.returncode = None

    def poll(self):
        import ctypes
        from ctypes import wintypes
        STILL_ACTIVE = 259
        code = wintypes.DWORD()
        if not ctypes.windll.kernel32.GetExitCodeProcess(self._handle, ctypes.byref(code)):
            return self.returncode
        if int(code.value) == STILL_ACTIVE:
            return None
        self.returncode = int(code.value)
        return self.returncode

    def wait(self, timeout=None):
        import ctypes
        INFINITE = 0xFFFFFFFF
        ms = INFINITE if timeout is None else max(0, int(float(timeout) * 1000))
        r = ctypes.windll.kernel32.WaitForSingleObject(self._handle, ms)
        if r == 0:  # WAIT_OBJECT_0
            return self.poll()
        if timeout is not None:
            raise subprocess.TimeoutExpired(cmd=f"pid={self.pid}", timeout=timeout)
        return self.poll()

    def terminate(self):
        import ctypes
        ctypes.windll.kernel32.TerminateProcess(self._handle, 1)

    kill = terminate


def launch(args: list, cwd=None, hidden: bool = True, env=None, unelevated: bool = True):
    """Start a process. When unelevated=True and this process is elevated, the
    child is created with the medium-integrity Explorer token so Unity/Hub
    never inherit Administrator privileges.
    """
    args = [str(a) for a in args]
    if not unelevated or sys.platform != "win32" or not is_elevated():
        return _popen(args, cwd=cwd, hidden=hidden, env=env)
    errors = []
    try:
        return _launch_as_explorer_child(args, cwd=cwd, hidden=hidden, env=env)
    except Exception as e:
        errors.append(f"explorer-parent: {e}")
    token = None
    try:
        token = _explorer_token()
        if token:
            return _launch_with_token(token, args, cwd=cwd, hidden=hidden, env=env)
        errors.append("no explorer token")
    except Exception as e:
        errors.append(f"token: {e}")
    finally:
        if token:
            import ctypes
            ctypes.windll.kernel32.CloseHandle(token)
    # Last resort: do not silently start Unity elevated.
    raise OSError("unelevated launch failed: " + "; ".join(errors))


def launch_and_wait(args: list, cwd=None, hidden: bool = True, env=None, timeout=None, unelevated: bool = True):
    proc = launch(args, cwd=cwd, hidden=hidden, env=env, unelevated=unelevated)
    if proc is None:
        raise RuntimeError("launch returned None")
    try:
        return proc.wait(timeout=timeout)
    except subprocess.TimeoutExpired:
        try:
            proc.terminate()
        except Exception:
            pass
        raise


def maybe_relaunch_unelevated(script: str | None = None, extra_args: list | None = None) -> bool:
    """If this process is elevated, start an unelevated copy of the same Python
    script and return True (caller should exit). Never shows UAC.
    Set GAMEBOT_ALLOW_ELEVATED=1 to skip (tests / explicit override).
    """
    if os.environ.get("GAMEBOT_ALLOW_ELEVATED") == "1":
        return False
    if not is_elevated():
        return False
    py = sys.executable
    # Prefer pythonw when this is a windowed app
    cand = Path(py).with_name("pythonw.exe")
    if cand.is_file():
        py = str(cand)
    if script is None:
        script = sys.argv[0]
    args = [py, str(script)]
    if extra_args:
        args.extend(str(a) for a in extra_args)
    elif len(sys.argv) > 1:
        args.extend(sys.argv[1:])
    # Child must not think it still has to relaunch (it won't — it is unelevated).
    env = os.environ.copy()
    cwd = str(Path(script).resolve().parent) if script else os.getcwd()
    launch(args, cwd=cwd, hidden=True, env=env, unelevated=True)
    return True


def pid_is_elevated(pid: int) -> bool | None:
    """True/False if the token can be read, else None."""
    if sys.platform != "win32":
        return None
    import ctypes
    from ctypes import wintypes
    kernel32 = ctypes.windll.kernel32
    advapi32 = ctypes.windll.advapi32
    hp = kernel32.OpenProcess(0x0400 | 0x1000, False, int(pid))
    if not hp:
        return None
    try:
        tok = wintypes.HANDLE()
        if not advapi32.OpenProcessToken(hp, 0x0008, ctypes.byref(tok)):
            return None
        try:
            class TOKEN_ELEVATION(ctypes.Structure):
                _fields_ = [("TokenIsElevated", wintypes.DWORD)]
            ev = TOKEN_ELEVATION()
            ret = wintypes.DWORD()
            ok = advapi32.GetTokenInformation(tok, 20, ctypes.byref(ev), ctypes.sizeof(ev), ctypes.byref(ret))
            if not ok:
                return None
            return bool(ev.TokenIsElevated)
        finally:
            kernel32.CloseHandle(tok)
    finally:
        kernel32.CloseHandle(hp)


def ensure_input_system(proj) -> str:
    """Point a Unity project at the Input System package and handler=1 (not Both).

    Handler 2 (Both) still enables the deprecated Input Manager and Unity logs
    'This project uses Input Manager, which is marked for deprecation.'
    """
    import json
    import re
    proj = Path(proj)
    notes = []
    mf = proj / "Packages" / "manifest.json"
    if mf.is_file():
        try:
            data = json.loads(mf.read_text(encoding="utf-8-sig"))
        except Exception:
            data = {}
        deps = data.setdefault("dependencies", {})
        if "com.unity.inputsystem" not in deps:
            deps["com.unity.inputsystem"] = "1.20.0"
            mf.write_text(json.dumps(data, indent=2) + "\n", encoding="utf-8")
            notes.append("added com.unity.inputsystem")
        else:
            notes.append("com.unity.inputsystem " + str(deps.get("com.unity.inputsystem")))
    else:
        notes.append("no manifest.json")
    ps = proj / "ProjectSettings" / "ProjectSettings.asset"
    if ps.is_file():
        text = ps.read_text(encoding="utf-8", errors="replace")
        if re.search(r"activeInputHandler:\s*\d", text):
            new = re.sub(r"activeInputHandler:\s*\d", "activeInputHandler: 1", text, count=1)
        else:
            new = text.rstrip() + "\n  activeInputHandler: 1\n"
        if new != text:
            ps.write_text(new, encoding="utf-8")
        notes.append("activeInputHandler=1 (Input System)")
    else:
        notes.append("no ProjectSettings.asset")
    return "; ".join(notes)


def main(argv: list[str] | None = None) -> int:
    """CLI: python gamebot_proc.py launch [--hidden] [--cwd DIR] [--print-pid] -- exe [args...]"""
    argv = list(sys.argv[1:] if argv is None else argv)
    if not argv or argv[0] in ("-h", "--help"):
        sys.stdout.write("usage: gamebot_proc.py launch [--hidden] [--cwd DIR] [--print-pid] -- exe [args...]\n")
        return 2
    if argv[0] == "ensure-input":
        if len(argv) < 2:
            sys.stdout.write("missing project path\n")
            return 2
        sys.stdout.write(ensure_input_system(argv[1]) + "\n")
        return 0
    if argv[0] != "launch":
        sys.stdout.write("unknown command\n")
        return 2
    argv = argv[1:]
    hidden = False
    cwd = None
    print_pid = False
    wait = False
    args: list[str] = []
    i = 0
    while i < len(argv):
        a = argv[i]
        if a == "--":
            args = argv[i + 1:]
            break
        if a == "--hidden":
            hidden = True
        elif a == "--print-pid":
            print_pid = True
        elif a == "--wait":
            wait = True
        elif a == "--cwd" and i + 1 < len(argv):
            i += 1
            cwd = argv[i]
        elif a.startswith("--"):
            sys.stdout.write("unknown flag " + a + "\n")
            return 2
        else:
            args = argv[i:]
            break
        i += 1
    if not args:
        sys.stdout.write("missing exe\n")
        return 2
    proc = launch(args, cwd=cwd, hidden=hidden, unelevated=True)
    if print_pid:
        sys.stdout.write(f"PID {proc.pid}\n")
        sys.stdout.flush()
    if wait:
        code = proc.wait()
        return int(code or 0)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
