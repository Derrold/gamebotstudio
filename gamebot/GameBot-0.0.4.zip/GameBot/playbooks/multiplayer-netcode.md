# Multiplayer & netcode - decision first
Sources: https://docs-multiplayer.unity3d.com/netcode/current/about/ | https://docs.unity.com/ugs/en-us/manual/relay/manual/introduction | https://dev.epicgames.com/docs/epic-online-services | https://partner.steamgames.com/doc/features/multiplayer

## Default: DON'T
- Multiplayer multiplies scope (sync, cheating, servers, matchmaking, QA x N). Only start if the creator explicitly asks.
- Cheaper social: Steam leaderboards, achievements, shared screenshots, async challenges (best buck of the week) - no netcode.

## If asked later
- Co-op 2-4 players: Unity Netcode for GameObjects (NGO) host/client, NetworkObject/NetworkVariable/RPCs; transport via Unity Relay or Steam Networking Sockets (Facepunch/Steamworks.NET) or EOS P2P.
- Fast action/large worlds: Netcode for Entities (DOTS) - bigger learning curve.
- Server authority for hits/kills; client prediction for movement; lag compensation for shots.
- Lobby/matchmaking: Steam Lobbies or EOS Lobbies (cross-platform).
- Budget: plan a separate vertical slice for netcode; test with simulated latency (Network Simulator) and 2 machines.

## Security/legal
- Anti-cheat (EAC via EOS free), privacy policy updates, chat moderation if voice/text.
