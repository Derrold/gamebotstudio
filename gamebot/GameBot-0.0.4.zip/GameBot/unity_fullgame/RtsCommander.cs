using UnityEngine;
/// <summary>Strategy family: top-down camera, box select, right-click orders, training at HQ, income from capture points, enemy raid waves.</summary>
public class RtsCommander : MonoBehaviour
{
    public GameObject soldierTpl, guardianTpl, enemyTpl; public Transform hq, enemyKeep; public float waveEvery = 32f;
    Vector2 dragStart; bool dragging; float income; Camera cam; float zoom = 34f;
    void Start() { cam = Camera.main; Cursor.lockState = CursorLockMode.None; Cursor.visible = true; GenreState.PointsTotal = FindObjectsByType<CapturePoint>(FindObjectsSortMode.None).Length; GenreState.NextWave = Time.timeSinceLevelLoad + 45f; }
    void Update()
    {
        if (GameState.Won || GameState.Lost || PauseMenu.IsPaused || MainMenuUI.InMenu) return;
        Cursor.lockState = CursorLockMode.None; Cursor.visible = true;
        // camera
        Vector3 pan = Vector3.zero; if (Input.GetKey(KeyCode.W) || Input.mousePosition.y > Screen.height - 6) pan.z += 1; if (Input.GetKey(KeyCode.S) || Input.mousePosition.y < 6) pan.z -= 1; if (Input.GetKey(KeyCode.D) || Input.mousePosition.x > Screen.width - 6) pan.x += 1; if (Input.GetKey(KeyCode.A) || Input.mousePosition.x < 6) pan.x -= 1;
        zoom = Mathf.Clamp(zoom - Input.mouseScrollDelta.y * 3f, 14f, 60f);
        var p = transform.position + pan * 30f * Time.deltaTime; p.x = Mathf.Clamp(p.x, -60, 60); p.z = Mathf.Clamp(p.z, -70, 60); p.y = zoom; transform.position = p; transform.rotation = Quaternion.Euler(58, 0, 0);
        // income
        GenreState.PointsOwned = CapturePoint.Owned(0); income += (2f + 4f * GenreState.PointsOwned) * Time.deltaTime; if (income >= 1) { int i = (int)income; income -= i; GenreState.Quartz += i; }
        if (GenreState.PointsOwned >= GenreState.PointsTotal && GenreState.PointsTotal > 0) AchievementSystem.Unlock("all_points");
        // training
        if (Input.GetKeyDown(KeyCode.Alpha1)) Train(soldierTpl, 50); if (Input.GetKeyDown(KeyCode.Alpha2)) Train(guardianTpl, 110);
        // selection
        if (Input.GetMouseButtonDown(0)) { dragStart = Input.mousePosition; dragging = true; }
        if (Input.GetMouseButtonUp(0) && dragging) { dragging = false; Select(dragStart, Input.mousePosition); }
        if (Input.GetMouseButtonDown(1)) Order();
        // enemy waves
        if (Time.timeSinceLevelLoad >= GenreState.NextWave && enemyKeep && enemyTpl)
        {
            GenreState.WaveNo++; GenreState.NextWave = Time.timeSinceLevelLoad + waveEvery; int n = 2 + GenreState.WaveNo;
            for (int i = 0; i < n; i++) { var e = Instantiate(enemyTpl, enemyKeep.position + new Vector3(Random.Range(-5f, 5f), 0, -8 + Random.Range(-2f, 2f)), Quaternion.identity); e.SetActive(true); var u = e.GetComponent<RtsUnit>(); var tgt = NearestPointNotOwnedBy(1); u.moveTo = tgt; u.attackMove = true; }
            GameHUD.Flash("Raid wave " + GenreState.WaveNo + " incoming from the north!"); if (GenreState.WaveNo >= 3) AchievementSystem.Unlock("hold_3");
        }
    }
    Vector3 NearestPointNotOwnedBy(int team)
    {
        Vector3 best = hq ? hq.position : Vector3.zero; float bd = 1e9f;
        foreach (var c in FindObjectsByType<CapturePoint>(FindObjectsSortMode.None)) if (c.owner != team) { float d = Vector3.Distance(c.transform.position, enemyKeep.position); if (d < bd) { bd = d; best = c.transform.position; } }
        return bd < 1e8f ? best : (hq ? hq.position : Vector3.zero);
    }
    void Train(GameObject tpl, int cost)
    {
        if (!tpl || !hq) return; if (GenreState.Quartz < cost) { GameHUD.Flash("Not enough quartz (" + cost + ")"); return; }
        GenreState.Quartz -= cost; var u = Instantiate(tpl, hq.position + new Vector3(Random.Range(-4f, 4f), 0, 7f), Quaternion.identity); u.SetActive(true); GenreState.Units++; AchievementSystem.Unlock("first_unit");
    }
    void Select(Vector2 a, Vector2 b)
    {
        var r = Rect.MinMaxRect(Mathf.Min(a.x, b.x), Mathf.Min(a.y, b.y), Mathf.Max(a.x, b.x), Mathf.Max(a.y, b.y)); bool click = r.width < 6 && r.height < 6;
        RtsUnit clicked = null; if (click && Physics.Raycast(cam.ScreenPointToRay(Input.mousePosition), out var hit, 500f)) clicked = hit.collider.GetComponentInParent<RtsUnit>();
        foreach (var u in FindObjectsByType<RtsUnit>(FindObjectsSortMode.None))
        {
            if (u.team != 0 || u.Structure) { u.selected = false; continue; }
            if (click) u.selected = u == clicked; else { var sp = cam.WorldToScreenPoint(u.transform.position); u.selected = sp.z > 0 && r.Contains(new Vector2(sp.x, sp.y)); }
        }
    }
    void Order()
    {
        if (!Physics.Raycast(cam.ScreenPointToRay(Input.mousePosition), out var hit, 500f)) return;
        var en = hit.collider.GetComponentInParent<RtsUnit>(); int n = 0;
        foreach (var u in FindObjectsByType<RtsUnit>(FindObjectsSortMode.None)) if (u.selected && u.team == 0) { u.moveTo = (en && en.team == 1 ? en.transform.position : hit.point) + new Vector3((n % 4) * 1.4f - 2f, 0, (n / 4) * 1.4f); u.attackMove = en != null; n++; }
    }
    void OnGUI()
    {
        if (MainMenuUI.InMenu) return;
        if (dragging) { var a = dragStart; Vector2 b = Input.mousePosition; var r = Rect.MinMaxRect(Mathf.Min(a.x, b.x), Screen.height - Mathf.Max(a.y, b.y), Mathf.Max(a.x, b.x), Screen.height - Mathf.Min(a.y, b.y)); GUI.color = new Color(0.3f, 1f, 0.4f, 0.25f); GUI.DrawTexture(r, Texture2D.whiteTexture); GUI.color = Color.white; }
        var s = new GUIStyle(GUI.skin.box) { fontSize = 18 };
        if (GUI.Button(new Rect(16, Screen.height - 64, 220, 48), "1: Soldier (50)", s)) Train(soldierTpl, 50);
        if (GUI.Button(new Rect(246, Screen.height - 64, 220, 48), "2: Guardian (110)", s)) Train(guardianTpl, 110);
    }
}
