"""Start the local Ollama server if it is not already running. Never changes saved env vars; on AMD-only PCs the server it starts gets OLLAMA_VULKAN=1."""
from __future__ import annotations

import os
import shutil
import subprocess
import time
import urllib.request


def ollama_base() -> str:
    host = (os.environ.get("OLLAMA_HOST") or "http://127.0.0.1:11434").rstrip("/")
    if not host.startswith("http"):
        host = "http://" + host
    return host


def ollama_up(timeout: float = 2.0) -> bool:
    try:
        with urllib.request.urlopen(ollama_base() + "/api/tags", timeout=timeout) as r:
            return 200 <= getattr(r, "status", 200) < 300
    except Exception:
        return False


def find_ollama() -> str | None:
    local = os.environ.get("LOCALAPPDATA") or ""
    pf = os.environ.get("ProgramFiles") or r"C:\Program Files"
    pf86 = os.environ.get("ProgramFiles(x86)") or r"C:\Program Files (x86)"
    candidates = [
        os.path.join(local, "Programs", "Ollama", "ollama app.exe"),
        os.path.join(local, "Programs", "Ollama", "ollama.exe"),
        os.path.join(pf, "Ollama", "ollama app.exe"),
        os.path.join(pf, "Ollama", "ollama.exe"),
        os.path.join(pf86, "Ollama", "ollama app.exe"),
        os.path.join(pf86, "Ollama", "ollama.exe"),
    ]
    which = shutil.which("ollama")
    if which:
        candidates.append(which)
    seen = set()
    for path in candidates:
        if not path:
            continue
        key = os.path.normcase(os.path.abspath(path))
        if key in seen:
            continue
        seen.add(key)
        if os.path.isfile(path):
            return path
    return None


def _launch(path: str) -> None:
    name = os.path.basename(path).lower()
    args = [path, "serve"] if name == "ollama.exe" else [path]
    kwargs = {
        "args": args,
        "cwd": os.path.dirname(path) or None,
        "stdin": subprocess.DEVNULL,
        "stdout": subprocess.DEVNULL,
        "stderr": subprocess.DEVNULL,
        "close_fds": True,
    }
    if os.name == "nt":
        flags = getattr(subprocess, "DETACHED_PROCESS", 0) | getattr(subprocess, "CREATE_NEW_PROCESS_GROUP", 0)
        if name == "ollama.exe":
            flags |= getattr(subprocess, "CREATE_NO_WINDOW", 0)
        kwargs["creationflags"] = flags
    else:
        kwargs["start_new_session"] = True
    subprocess.Popen(**kwargs)


# ---- 0.0.7: AMD auto-GPU. A working NVIDIA card (nvidia-smi answers) -> CUDA, untouched. Only AMD -> Ollama with Vulkan on.
NO_WINDOW = 0x08000000
_GPU = {"info": None}


def gpu_mode(refresh: bool = False) -> dict:
    """{'mode': 'cuda'|'vulkan'|'cpu', 'vram_gb', 'name'}. GAMEBOT_OLLAMA_BACKEND=cuda|vulkan|cpu overrides."""
    if _GPU["info"] is not None and not refresh:
        return _GPU["info"]
    forced = (os.environ.get("GAMEBOT_OLLAMA_BACKEND") or "").strip().lower()
    info = {"mode": "cpu", "vram_gb": 0.0, "name": ""}
    try:
        import gpu_detect as gd
        nv = [] if forced in ("vulkan", "cpu") else gd.nvidia_gpus()
        if nv:
            info = {"mode": "cuda", "vram_gb": max(float(g.get("vram_gb") or 0) for g in nv), "name": str(nv[0].get("name") or "")}
        elif forced != "cpu":
            amd = [a for a in gd.windows_adapters() if a.get("vendor") == "amd"]
            if amd:
                b = max(amd, key=lambda a: float(a.get("vram_gb") or 0))
                info = {"mode": "vulkan", "vram_gb": float(b.get("vram_gb") or 0), "name": str(b.get("name") or "")}
    except Exception:
        pass
    if forced == "cuda":
        info["mode"] = "cuda"
    _GPU["info"] = info
    return info


def amd_defaults(info: dict | None = None) -> None:
    """Safe AMD defaults: 8 GB-class AMD cards get num_ctx 8192."""
    info = info or gpu_mode()
    if info.get("mode") == "vulkan" and 0 < float(info.get("vram_gb") or 0) <= 10.5:
        try:
            cur = int(os.environ.get("GAMEBOT_NUM_CTX") or 8192)
        except ValueError:
            cur = 8192
        os.environ["GAMEBOT_NUM_CTX"] = str(min(cur, 8192))


def _vulkan_disabled_in_env() -> bool:
    vals = [os.environ.get("OLLAMA_VULKAN")]
    if os.name == "nt":
        try:
            import winreg
            for hive, key in ((winreg.HKEY_CURRENT_USER, "Environment"),
                              (winreg.HKEY_LOCAL_MACHINE, r"SYSTEM\CurrentControlSet\Control\Session Manager\Environment")):
                try:
                    with winreg.OpenKey(hive, key) as k:
                        vals.append(str(winreg.QueryValueEx(k, "OLLAMA_VULKAN")[0]))
                except OSError:
                    pass
        except Exception:
            pass
    return any(str(v).strip().lower() in ("0", "false", "no", "off") for v in vals if v is not None)


def _state_path() -> str:
    return os.path.join(os.environ.get("LOCALAPPDATA") or ".", "GameBot", "ollama_vulkan.json")


def _pid_alive(pid: int) -> bool:
    try:
        out = subprocess.run(["tasklist", "/FI", f"PID eq {int(pid)}", "/NH"], capture_output=True, text=True,
                             timeout=10, creationflags=NO_WINDOW if os.name == "nt" else 0).stdout
        return "ollama" in out.lower()
    except Exception:
        return False


def ensure_vulkan(timeout: float = 30.0) -> str:
    """AMD-only PC: make sure the Ollama server runs with Vulkan on (only for the server Game Bot starts). '' when not needed."""
    import json
    info = gpu_mode()
    if info.get("mode") != "vulkan":
        return ""
    amd_defaults(info)
    try:
        st = json.loads(open(_state_path(), encoding="utf-8").read())
    except Exception:
        st = {}
    if st.get("pid") and _pid_alive(st["pid"]) and ollama_up():
        return "vulkan (running)"
    if ollama_up() and not _vulkan_disabled_in_env():
        return "vulkan (ollama default)"
    path = find_ollama()
    if not path:
        return ""
    exe = os.path.join(os.path.dirname(path), "ollama.exe")
    if not os.path.isfile(exe):
        return ""
    for im in ("ollama app.exe", "ollama.exe"):  # the tray app's server runs with Vulkan off (CPU only on this PC)
        try:
            subprocess.run(["taskkill", "/F", "/IM", im], capture_output=True, timeout=15, creationflags=NO_WINDOW)
        except Exception:
            pass
    time.sleep(1.5)
    os.makedirs(os.path.dirname(_state_path()), exist_ok=True)
    log = open(os.path.join(os.path.dirname(_state_path()), "ollama_vulkan.log"), "ab")
    env = dict(os.environ, OLLAMA_VULKAN="1")
    flags = getattr(subprocess, "DETACHED_PROCESS", 0) | getattr(subprocess, "CREATE_NEW_PROCESS_GROUP", 0) | NO_WINDOW
    p = subprocess.Popen([exe, "serve"], cwd=os.path.dirname(exe), env=env, stdin=subprocess.DEVNULL, stdout=log, stderr=log,
                         creationflags=flags, close_fds=True)
    with open(_state_path(), "w", encoding="utf-8") as f:
        json.dump({"pid": p.pid, "started": time.time(), "gpu": info.get("name", "")}, f)
    deadline = time.time() + max(1.0, float(timeout))
    while time.time() < deadline and not ollama_up():
        time.sleep(0.5)
    return "vulkan (started)"


def ensure_ollama(timeout: float = 30.0) -> tuple[bool, str]:
    """If Ollama is down, launch it and wait up to timeout seconds. Returns (ok, reason)."""
    if os.name == "nt":
        try:
            ensure_vulkan(timeout)  # 0.0.7: AMD-only PCs
        except Exception:
            pass
    if ollama_up():
        return True, ""
    path = find_ollama()
    if not path:
        return False, "Ollama was not found. Install Ollama or add ollama.exe to PATH."
    try:
        _launch(path)
    except Exception as e:
        return False, f"could not launch {path}: {e}"
    deadline = time.time() + max(1.0, float(timeout))
    while time.time() < deadline:
        if ollama_up():
            return True, ""
        time.sleep(0.5)
    return False, f"launched {path} but it did not come up on {ollama_base()} within {int(timeout)}s"
