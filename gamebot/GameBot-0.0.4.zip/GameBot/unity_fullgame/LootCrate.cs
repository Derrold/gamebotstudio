using UnityEngine;
/// <summary>Battle royale loot: ammo, medkit or armor plating.</summary>
public class LootCrate : MonoBehaviour
{
    public string kind = "ammo";
    void OnTriggerEnter(Collider o)
    {
        if (!o.CompareTag("Player")) return;
        if (kind == "ammo") { GenreState.Reserve += 36; GameHUD.Flash("Ammo +36"); }
        else if (kind == "med") { GenreState.Health = Mathf.Min(GenreState.MaxHealth, GenreState.Health + 50); GameHUD.Flash("Medkit +50 HP"); }
        else { GenreState.MaxHealth = Mathf.Min(175, GenreState.MaxHealth + 25); GenreState.Health += 25; GameHUD.Flash("Armor +25"); }
        AchievementSystem.Unlock("looter"); Destroy(gameObject);
    }
}
