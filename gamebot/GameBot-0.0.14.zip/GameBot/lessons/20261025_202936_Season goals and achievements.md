# Season goals and achievements

Tags: quest objectives achievements
Saved: 2026-10-25T20:29:36

Objectives = event bus (OnHarvest/OnShot/OnDayEnd) + conditions; reuse RangeAch pattern; map to Steam API names in Docs/Steam/achievements.csv. Dialogue: ink or Yarn Spinner. Source: https://partner.steamgames.com/doc/features/achievements
