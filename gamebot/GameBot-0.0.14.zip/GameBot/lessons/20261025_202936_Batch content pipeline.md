# Batch content pipeline

Tags: pipeline automation batch
Saved: 2026-10-25T20:29:36

Blender -b --python export; AssetPostprocessor enforces import settings; Addressables for DLC/streaming. Source: https://docs.unity3d.com/Manual/CommandLineArguments.html
