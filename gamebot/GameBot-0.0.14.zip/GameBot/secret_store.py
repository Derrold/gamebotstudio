"""Local secret storage for optional cloud API keys.

Keys are encrypted with Windows DPAPI (CryptProtectData, current user) and
kept under %LOCALAPPDATA%\\GameBot\\secrets\\ — never in work/, never in
bug-report zips, never logged. Plaintext exists only in memory while a
request is built, then is discarded.
"""
from __future__ import annotations

import json
import os
from pathlib import Path

# CRYPTPROTECT_UI_FORBIDDEN: never show a DPAPI prompt (headless app).
_UI_FORBIDDEN = 0x01


def secrets_dir() -> Path:
    base = os.environ.get("GAMEBOT_SECRETS_DIR") or os.environ.get("LOCALAPPDATA") or ""
    if not base:
        base = str(Path.home() / "AppData" / "Local")
    return Path(base) / "GameBot" / "secrets"


def _path() -> Path:
    return secrets_dir() / "keys.dpapi"


def _protect(data: bytes) -> bytes:
    if os.name != "nt":
        # Tests on non-Windows only: a clearly marked non-secret wrapper.
        return b"GBPLAIN:" + data
    import ctypes
    from ctypes import wintypes

    class DATA_BLOB(ctypes.Structure):
        _fields_ = [("cbData", wintypes.DWORD), ("pbData", ctypes.POINTER(ctypes.c_byte))]

    crypt32 = ctypes.windll.crypt32
    kernel32 = ctypes.windll.kernel32
    blob_in = DATA_BLOB(len(data), ctypes.cast(ctypes.create_string_buffer(data, len(data)), ctypes.POINTER(ctypes.c_byte)))
    blob_out = DATA_BLOB()
    if not crypt32.CryptProtectData(ctypes.byref(blob_in), None, None, None, None, _UI_FORBIDDEN, ctypes.byref(blob_out)):
        raise OSError("DPAPI CryptProtectData failed")
    try:
        out = ctypes.string_at(blob_out.pbData, blob_out.cbData)
    finally:
        kernel32.LocalFree(blob_out.pbData)
    return out


def _unprotect(data: bytes) -> bytes:
    if data.startswith(b"GBPLAIN:"):
        return data[len(b"GBPLAIN:"):]
    if os.name != "nt":
        raise OSError("encrypted keys can only be read on Windows")
    import ctypes
    from ctypes import wintypes

    class DATA_BLOB(ctypes.Structure):
        _fields_ = [("cbData", wintypes.DWORD), ("pbData", ctypes.POINTER(ctypes.c_byte))]

    crypt32 = ctypes.windll.crypt32
    kernel32 = ctypes.windll.kernel32
    buf = ctypes.create_string_buffer(data, len(data))
    blob_in = DATA_BLOB(len(data), ctypes.cast(buf, ctypes.POINTER(ctypes.c_byte)))
    blob_out = DATA_BLOB()
    if not crypt32.CryptUnprotectData(ctypes.byref(blob_in), None, None, None, None, _UI_FORBIDDEN, ctypes.byref(blob_out)):
        raise OSError("DPAPI CryptUnprotectData failed")
    try:
        out = ctypes.string_at(blob_out.pbData, blob_out.cbData)
    finally:
        kernel32.LocalFree(blob_out.pbData)
    return out


def load() -> dict:
    """Return {provider: key} for stored keys. Empty dict if none / unreadable."""
    p = _path()
    try:
        if not p.is_file():
            return {}
        raw = _unprotect(p.read_bytes())
        data = json.loads(raw.decode("utf-8"))
        if not isinstance(data, dict):
            return {}
        return {str(k): str(v) for k, v in data.items() if str(v).strip()}
    except Exception:
        return {}


def get(provider: str) -> str:
    return (load().get((provider or "").strip().lower()) or "").strip()


def set_key(provider: str, key: str) -> None:
    """Store or delete (empty key) one provider's API key."""
    name = (provider or "").strip().lower()
    if not name:
        return
    data = load()
    val = (key or "").strip()
    if val:
        data[name] = val
    else:
        data.pop(name, None)
    _save(data)


def _save(data: dict) -> None:
    d = secrets_dir()
    d.mkdir(parents=True, exist_ok=True)
    raw = json.dumps(data, indent=0).encode("utf-8")
    blob = _protect(raw)
    p = _path()
    tmp = p.with_suffix(".tmp")
    tmp.write_bytes(blob)
    tmp.replace(p)
    try:
        os.chmod(p, 0o600)
    except Exception:
        pass


def has_key(provider: str) -> bool:
    return bool(get(provider))


def redact_text(text: str) -> str:
    """Replace any stored key value that appears in text. Used as a last pass."""
    if not text:
        return text
    out = text
    try:
        for v in load().values():
            if v and len(v) >= 8 and v in out:
                out = out.replace(v, "[REDACTED_KEY]")
    except Exception:
        pass
    return out
