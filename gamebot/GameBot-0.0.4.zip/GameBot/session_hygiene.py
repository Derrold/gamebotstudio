# Copyright (c) 2026 Alphamax Studios. All rights reserved. Proprietary software - licensed, not sold. Use requires a valid Game Bot license on one PC (see EULA.md). Copying, sharing, reselling, redistributing, reverse engineering, or bypassing license checks is prohibited.
"""Session hygiene: context meter + ASK-before-clean for long chats (owner rule, Nov 3 2026).

Game Bot never cleans on its own. When the stored chat reaches warn_pct of the session budget it explains the
pressure (used / available tokens, what would be summarized, what stays) and asks. Only after the creator says yes
are older turns summarized into one short [SESSION STATE] note; the raw old turns are archived to
sessions_archive/ (nothing is deleted) and dropped from the active context. Budget scales with GPU VRAM + system RAM.

Prefs (config/install_prefs.json, written by Install; env overrides win):
  session_budget_tokens  GAMEBOT_SESSION_BUDGET      session size the meter shows as "available"
  session_warn_pct       GAMEBOT_SESSION_WARN_PCT    ask-to-clean threshold (default 0.80)
  session_keep_turns     GAMEBOT_SESSION_KEEP_TURNS  recent user turns kept verbatim after a clean
  session_hygiene        GAMEBOT_SESSION_HYGIENE     0 = meter only, never ask
"""
from __future__ import annotations

import json
import os
import re
import time
import urllib.request
import uuid
from pathlib import Path

ROOT = Path(__file__).resolve().parent
PREFS = ROOT / "config" / "install_prefs.json"
ARCHIVE = ROOT / "sessions_archive"
CHARS_PER_TOKEN = 4.3          # same estimate fit_ctx uses (measured ~4.4 on gamebot-trained)
STATE_TAG = "[SESSION STATE]"
_TOOLS_TOK: dict = {}


# ---------- budget (scales with VRAM + RAM) ----------
def session_budget(vram_gb: float, ram_gb: float, num_ctx: int = 0) -> dict:
    """score = VRAM GB + system RAM GB / 4  (RAM counts 1/4: KV spill to RAM works but is slower than VRAM).
         score <  8 -> 16k tokens, keep 4 turns      (CPU-only / tiny GPU)
         score < 16 -> 24k, keep 4                   (8 GB GPU + 16-32 GB RAM)
         score < 24 -> 32k, keep 6                   (8 GB GPU + 64 GB RAM, 12 GB + 32 GB)
         score < 32 -> 48k, keep 6                   (16 GB GPU + 32-64 GB RAM)
         else       -> 64k, keep 8                   (16 GB+ GPU + 64 GB+, 24 GB cards)
    Never below 2 x num_ctx (so one full model window always fits). warn at 80%."""
    score = float(vram_gb or 0) + float(ram_gb or 0) / 4.0
    for lim, bud, keep in ((8, 16384, 4), (16, 24576, 4), (24, 32768, 6), (32, 49152, 6)):
        if score < lim:
            break
    else:
        bud, keep = 65536, 8
    bud = max(bud, 2 * int(num_ctx or 0))
    return {"session_budget_tokens": bud, "session_warn_pct": 0.80, "session_keep_turns": keep,
            "session_hygiene": True, "session_score": round(score, 1)}


def _prefs() -> dict:
    try:
        return json.loads(PREFS.read_text(encoding="utf-8-sig"))
    except Exception:
        return {}


def settings() -> dict:
    p = _prefs()
    if not p.get("session_budget_tokens"):
        try:
            import gpu_detect
            vram = float(p.get("vram_gb") or gpu_detect.detect().get("vram_gb") or 0)
            ram = float(p.get("system_ram_gb") or gpu_detect.system_ram_gb() or 0)
        except Exception:
            vram, ram = float(p.get("vram_gb") or 0), float(p.get("system_ram_gb") or 0)
        p.update(session_budget(vram, ram, int(p.get("num_ctx") or 0)))
    env = os.environ.get

    def num(v, default, lo, hi, kind=int):  # bad env/prefs values never crash the meter
        for x in v:
            try:
                if x not in (None, ""):
                    return max(lo, min(hi, kind(x)))
            except (TypeError, ValueError):
                continue
        return default
    return {
        "budget": num((env("GAMEBOT_SESSION_BUDGET"), p.get("session_budget_tokens")), 24576, 2048, 1048576),
        "warn_pct": num((env("GAMEBOT_SESSION_WARN_PCT"), p.get("session_warn_pct")), 0.80, 0.3, 0.99, float),
        "keep_turns": num((env("GAMEBOT_SESSION_KEEP_TURNS"), p.get("session_keep_turns")), 4, 1, 50),
        "enabled": str(env("GAMEBOT_SESSION_HYGIENE") or p.get("session_hygiene", True)).lower() not in ("0", "false", "no"),
        "num_ctx": num((env("GAMEBOT_NUM_CTX"), p.get("num_ctx")), 12288, 2048, 262144),
        "vram_gb": p.get("vram_gb", 0), "system_ram_gb": p.get("system_ram_gb", 0),
    }


# ---------- meter ----------
def _tools_tokens() -> int:
    if "n" not in _TOOLS_TOK:
        try:
            from agent_core import model_tools
            _TOOLS_TOK["n"] = int(len(json.dumps(model_tools())) / CHARS_PER_TOKEN)
        except Exception:
            _TOOLS_TOK["n"] = 0
    return _TOOLS_TOK["n"]


def est_tokens(messages: list[dict]) -> int:
    return int(len(json.dumps(messages or [], ensure_ascii=False)) / CHARS_PER_TOKEN) + _tools_tokens()


def _k(n: int) -> str:
    return f"{n / 1024:.0f}k" if n >= 1024 else str(n)


def meter(messages: list[dict]) -> dict:
    s = settings()
    used = est_tokens(messages)
    pct = used / max(1, s["budget"])
    state = "full" if pct >= 0.95 else "warn" if pct >= s["warn_pct"] else "ok"
    return {"label": "Context", "used": used, "available": s["budget"], "pct": round(pct, 3), "state": state,
            "text": f"Chat {_k(used)} / {_k(s['budget'])} · model sees last {_k(s['num_ctx'])}", "num_ctx": s["num_ctx"], "keep_turns": s["keep_turns"],
            "warn_pct": s["warn_pct"], "turns": sum(1 for m in messages or [] if m.get("role") == "user"),
            "basis": f"{s['vram_gb']} GB VRAM + {s['system_ram_gb']} GB RAM"}


# ---------- what a clean would do ----------
def _split(messages: list[dict], keep_turns: int):
    """-> (head system msgs, older non-system msgs, recent msgs starting at the Nth-from-last user turn)."""
    head = [m for m in messages if m.get("role") == "system"]
    body = [m for m in messages if m.get("role") != "system"]
    users = [i for i, m in enumerate(body) if m.get("role") == "user"]
    if len(users) <= keep_turns:
        return head, [], body
    cut = users[-keep_turns]
    return head, body[:cut], body[cut:]


def plan(messages: list[dict]) -> dict:
    s = settings()
    head, old, recent = _split(messages, s["keep_turns"])
    return {"old_msgs": len(old), "old_turns": sum(1 for m in old if m.get("role") == "user"),
            "old_tokens": int(len(json.dumps(old, ensure_ascii=False)) / CHARS_PER_TOKEN),
            "keep_turns": s["keep_turns"], "recent_msgs": len(recent)}


def proposal(messages: list[dict]) -> str:
    m, p = meter(messages), plan(messages)
    if not p["old_msgs"]:
        return (f"Context: {m['text']} ({int(m['pct'] * 100)}%). Only the last {p['keep_turns']} turns are here, so there is "
                "nothing older to clean yet. Starting a New chat is the way to free more room.")
    return (f"Heads up - this chat is using a lot of context: {m['text']} ({int(m['pct'] * 100)}% of the budget for this PC, "
            f"{m['basis']}). Long sessions make me slower and I start losing early details.\n"
            f"If you want, I can clean it up: summarize the older {p['old_turns']} turns ({p['old_msgs']} messages, "
            f"~{_k(p['old_tokens'])} tokens incl. tool output) into one short STATE note (game, engine, decisions, "
            f"what's done, open tasks), keep the last {p['keep_turns']} turns word-for-word, and save the full old log "
            f"to sessions_archive (nothing is deleted).\n"
            "Say 'clean up chat' to do it, or 'not now' to keep going as-is.")


YES_RX = re.compile(r"^\s*(yes|yep|yeah|y|ok(ay)?|sure|do it|go ahead|please do)\b.{0,30}$|\b(clean ?up|clear|tidy|compact|summari[sz]e)\b.{0,20}\b(chat|context|session|log|history|it)\b", re.I)
NO_RX = re.compile(r"^\s*(no|nope|not now|later|skip|don'?t|keep (it|going))\b", re.I)
ASK_RX = re.compile(r"\b(clean ?up|compact|summari[sz]e)\b.{0,12}\b(this |the |my )?(chat|context|session)\b|\bcontext (meter|usage|left|size)\b", re.I)


def is_yes(text: str) -> bool:
    return bool(YES_RX.search(text or "")) and not NO_RX.search(text or "")


def is_no(text: str) -> bool:
    return bool(NO_RX.search(text or ""))


def wants_cleanup(text: str) -> bool:
    return bool(ASK_RX.search(text or ""))


# ---------- the clean (only after the creator says yes) ----------
def _digest(old: list[dict], max_chars: int) -> str:
    lines = []
    for m in old:
        r = m.get("role")
        c = " ".join(str(m.get("content") or "").split())
        if r == "assistant" and m.get("tool_calls"):
            names = ",".join(str((t.get("function") or {}).get("name")) for t in m["tool_calls"])
            lines.append(f"TOOL CALL: {names}")
            continue
        if not c:
            continue
        cap = 220 if r == "tool" else 500
        lines.append(f"{r.upper()}: {c[:cap]}")
    txt = "\n".join(lines)
    return txt[-max_chars:]


def _summarize(old: list[dict], prev_state: str, num_ctx: int) -> str:
    ollama = os.environ.get("OLLAMA_HOST", "http://127.0.0.1:11434").rstrip("/")
    if not ollama.startswith("http"):
        ollama = "http://" + ollama
    try:
        from agent_core import MODEL
    except Exception:
        MODEL = os.environ.get("OLLAMA_MODEL", "gamebot-trained")
    room = max(4000, int((min(num_ctx, 16384) - 900) * CHARS_PER_TOKEN) - 1500)
    prompt = ("Write a SESSION STATE note (max 180 words, plain bullet lines) from this Game Bot chat so work can continue "
              "without the old messages. Keep: game title(s) and project path, engine, creator decisions and preferences, "
              "what was built or fixed (only what tools proved), open tasks / next step, errors still unresolved. "
              "No greetings, no advice.\n\n" + (f"Previous state:\n{prev_state}\n\n" if prev_state else "") +
              "Chat:\n" + _digest(old, room))
    body = {"model": MODEL, "stream": False, "messages": [{"role": "user", "content": prompt}],
            "options": {"num_ctx": min(num_ctx, 16384), "temperature": 0.1, "num_predict": 320}}
    try:
        from ollama_ensure import ensure_ollama
        ensure_ollama(timeout=30)
        req = urllib.request.Request(f"{ollama}/api/chat", data=json.dumps(body).encode("utf-8"),
                                     headers={"Content-Type": "application/json"}, method="POST")
        with urllib.request.urlopen(req, timeout=180) as r:
            out = (json.loads(r.read().decode("utf-8")).get("message") or {}).get("content") or ""
        out = re.sub(r"<think>.*?</think>", "", out, flags=re.S).strip()
        if len(out) > 40:
            return out[:2000]
    except Exception:
        pass
    # Fallback (model busy/offline): extractive - creator requests + last answers.
    ups = [" ".join(str(m.get("content") or "").split())[:160] for m in old if m.get("role") == "user"]
    ans = [" ".join(str(m.get("content") or "").split())[:200] for m in old if m.get("role") == "assistant" and m.get("content")]
    return ((prev_state + "\n") if prev_state else "") + "Creator asked: " + " | ".join(ups[-8:]) + ("\nLast results: " + " | ".join(ans[-3:]) if ans else "")


def clean(messages: list[dict], sid: str = "") -> tuple[list[dict], str]:
    """Summarize older turns into one [SESSION STATE] system note; archive + drop the raw old turns. Call ONLY after
    the creator approved. Returns (new_messages, report)."""
    s = settings()
    before = est_tokens(messages)
    head, old, recent = _split(messages, s["keep_turns"])
    if not old:
        return messages, "Nothing older than the last few turns to clean."
    prev = "\n".join(str(m.get("content", ""))[len(STATE_TAG):].strip() for m in head if str(m.get("content", "")).startswith(STATE_TAG))
    head = [m for m in head if not str(m.get("content", "")).startswith(STATE_TAG)]
    # Keep a full untrimmed copy on disk so later turns can recall early details.
    try:
        import chat_store as _cs
        if sid:
            _cs.merge_full_messages(sid, (messages or []) + (old or []))
    except Exception:
        pass
    ARCHIVE.mkdir(parents=True, exist_ok=True)
    _sid = re.sub(r"[^A-Za-z0-9_-]+", "", sid or "") or "session"
    arc = ARCHIVE / f"{time.strftime('%Y%m%d_%H%M%S')}_{uuid.uuid4().hex[:6]}__{_sid}.jsonl"  # full sid, never collides
    with arc.open("x", encoding="utf-8") as f:
        f.write(json.dumps({"_sid": _sid}) + "\n")
        for m in old:
            f.write(json.dumps(m, ensure_ascii=False) + "\n")
    note = _summarize(old, prev, s["num_ctx"])
    new = head + [{"role": "system", "content": f"{STATE_TAG} Summary of earlier turns in this chat (raw log archived):\n{note}"}] + recent
    after = est_tokens(new)
    return new, (f"Cleaned up: {_k(before)} -> {_k(after)} tokens (budget {_k(s['budget'])}). Summarized "
                 f"{sum(1 for m in old if m.get('role') == 'user')} older turns into a STATE note, kept the last "
                 f"{s['keep_turns']} turns as-is. Full old log saved: {arc.name}")


RECALL_TAG = "[RECALL]"
_STOP = frozenset((
    "a","an","the","and","or","but","if","to","of","in","on","for","with","is","are","was","were",
    "be","been","being","it","this","that","those","these","you","we","they","i","me","my","your",
    "our","their","what","who","when","where","why","how","do","did","does","can","could","would",
    "should","will","just","not","no","yes","ok","okay","please","thanks","thank","well","also",
    "than","then","so","as","at","by","from","into","over","out","up","down","about","after",
    "before","again","more","most","some","any","all","both","few","other","too","very","say",
    "said","tell","told","ask","asked","make","made","want","need","use","used","like","know",
    "get","got","go","going","one","two",
))


def _safe_chat_dir(sid: str) -> Path:
    s = re.sub(r"[^A-Za-z0-9._-]+", "", sid or "")[:80]
    return ROOT / "work" / "chats" / s


def _msg_key(m: dict) -> tuple:
    return (str(m.get("role") or ""), str(m.get("content") or ""))


def _load_full_messages(sid: str) -> list[dict]:
    """Full untrimmed chat from disk: messages_full.json, else messages.json, plus sessions_archive for this sid."""
    sid = re.sub(r"[^A-Za-z0-9._-]+", "", sid or "")[:80]
    if not sid:
        return []
    out: list[dict] = []
    seen: set[tuple] = set()

    def _add(rows):
        for m in rows or []:
            if not isinstance(m, dict):
                continue
            if str(m.get("content") or "").startswith(RECALL_TAG):
                continue
            key = _msg_key(m)
            if key in seen or not key[1].strip():
                continue
            seen.add(key)
            out.append(m)

    d = _safe_chat_dir(sid)
    for name in ("messages_full.json", "messages.json"):
        p = d / name
        if not p.is_file():
            continue
        try:
            data = json.loads(p.read_text(encoding="utf-8"))
            if isinstance(data, list):
                _add(data)
        except Exception:
            pass
    try:
        if ARCHIVE.is_dir():
            for p in sorted(ARCHIVE.glob("*__" + sid + ".jsonl")):  # full-sid names only (old 8-char names could be another chat's)
                try:
                    rows = [json.loads(line) for line in p.read_text(encoding="utf-8").splitlines() if line.strip()]
                    if rows and rows[0].get("_sid") not in (None, sid):
                        continue
                    _add(rows)
                except Exception:
                    continue
    except Exception:
        pass
    return out


def _keywords(text: str) -> list[str]:
    words = re.findall(r"[a-z0-9][a-z0-9'-]{1,40}", (text or "").lower())
    keys = []
    seen = set()
    for w in words:
        if w in _STOP or w in seen:
            continue
        if w.isdigit() and len(w) < 2:
            continue
        seen.add(w)
        keys.append(w)
    return keys


def _score_msg(content: str, keys: list[str]) -> int:
    blob = (content or "").lower()
    if not blob or not keys:
        return 0
    score = 0
    for k in keys:
        n = blob.count(k)
        if n:
            score += n * (2 if len(k) >= 5 or k.isdigit() else 1)
    return score


def _context_is_trimmed(messages: list[dict], full: list[dict]) -> bool:
    if any(str(m.get("content") or "").startswith(STATE_TAG) for m in messages or []):
        return True
    active = {_msg_key(m) for m in messages or []}
    extra = [m for m in full if _msg_key(m) not in active and m.get("role") in ("user", "assistant")]
    return len(extra) >= 1


def _snippet(m: dict, cap: int = 500) -> str:
    role = str(m.get("role") or "msg").upper()
    text = " ".join(str(m.get("content") or "").split())
    if role == "ASSISTANT" and m.get("tool_calls") and not text:
        names = ",".join(str((t.get("function") or {}).get("name")) for t in m["tool_calls"])
        text = "(called " + names + ")"
    return role + ": " + text[:cap]


def inject_recall(messages: list[dict], sid: str = "", user_text: str = "", token_budget: int = 0) -> list[dict]:
    """If this chat has been trimmed, keyword-search the on-disk full log for the latest user message
    and inject the top few matching snippets as a [RECALL] system note, within the token budget."""
    if not messages:
        return messages
    kept = [m for m in messages if not (m.get("role") == "system" and str(m.get("content") or "").startswith(RECALL_TAG))]
    if kept is not messages:
        messages[:] = kept
    sid = sid or ""
    user_text = user_text or next((str(m.get("content") or "") for m in reversed(messages) if m.get("role") == "user"), "")
    keys = _keywords(user_text)
    if not sid or not keys:
        return messages
    full = _load_full_messages(sid)
    if not _context_is_trimmed(messages, full):
        return messages
    active = {_msg_key(m) for m in messages}
    scored = []
    for m in full:
        if _msg_key(m) in active:
            continue
        if m.get("role") not in ("user", "assistant"):
            continue
        c = str(m.get("content") or "")
        if c.startswith("SYSTEM NOTE"):
            continue
        sc = _score_msg(c, keys)
        if sc > 0:
            scored.append((sc, m))
    if not scored:
        return messages
    scored.sort(key=lambda x: (-x[0], -len(str(x[1].get("content") or ""))))
    s = settings()
    budget_tok = int(token_budget or 0) or min(800, max(400, int((s.get("num_ctx") or 12288) * 0.08)))
    budget_chars = int(budget_tok * CHARS_PER_TOKEN)
    lines = []
    used = 0
    for sc, m in scored[:8]:
        bit = _snippet(m, cap=500)
        if used + len(bit) + 1 > budget_chars:
            if not lines:
                lines.append(bit[:budget_chars])
            break
        lines.append(bit)
        used += len(bit) + 1
        if len(lines) >= 4:
            break
    if not lines:
        return messages
    block = (
        RECALL_TAG + " Relevant excerpts from earlier in this chat, not in the current window. "
        "Use them if they help answer the latest message; ignore them if they do not.\n" + "\n".join(lines)
    )
    insert_at = 0
    for i, m in enumerate(messages):
        if m.get("role") != "system":
            insert_at = i
            break
        insert_at = i + 1
    messages[insert_at:insert_at] = [{"role": "system", "content": block}]
    return messages

# ---------- fit what is SENT to the model into its window (stored chat is untouched) ----------
def fit_to_window(messages: list[dict], reserve: int = 1024) -> list[dict]:
    """Return a copy of messages that fits num_ctx minus a reply reserve: keeps every system note (prompt, summary,
    STATE, RECALL) and the newest turns; trims old tool output first, then drops the oldest turns. Never mutates."""
    s = settings()
    limit = max(1024, int(s["num_ctx"]) - reserve)
    if est_tokens(messages) <= limit:
        return messages
    head = [m for m in messages if m.get("role") == "system"]
    body = [dict(m) for m in messages if m.get("role") != "system"]
    for m in body[:-4]:
        if m.get("role") == "tool" and len(str(m.get("content") or "")) > 1200:
            m["content"] = str(m["content"])[:1200] + " ...[trimmed to fit the model window]"
    dropped = 0
    note = {"role": "system", "content": ""}
    while len(body) > 1 and est_tokens(head + [note] + body) > limit:
        body.pop(0)
        dropped += 1
        while len(body) > 1 and body[0].get("role") != "user":  # never start on an orphan tool/assistant turn
            body.pop(0)
            dropped += 1
    if not dropped:
        return head + body
    note["content"] = (f"[FIT] {dropped} older messages of this chat are outside the model window right now. They are still "
                       "saved on disk; the [GAME SUMMARY]/[RECALL] notes above carry the important parts.")
    return head + [note] + body


# ---------- per-session ask state (app.py) ----------
_ASK: dict[str, dict] = {}


def after_turn(sid: str, messages: list[dict]) -> str:
    """Returns the ask text to append to the answer when it's time to ask, else ''. Never cleans."""
    s = settings()
    if not s["enabled"]:
        return ""
    m = meter(messages)
    st = _ASK.setdefault(sid, {"pending": False, "snooze_until": 0.0})
    if m["pct"] < s["warn_pct"] or m["pct"] < st["snooze_until"]:
        return ""
    if not plan(messages)["old_msgs"]:
        return ""
    st["pending"] = True
    st["snooze_until"] = max(0.95, m["pct"] + 0.10)  # ask once at 80%; only ask again if it reaches ~95% (full)
    return proposal(messages)


def pending(sid: str) -> bool:
    return bool(_ASK.get(sid, {}).get("pending"))


def decline(sid: str, messages: list[dict]) -> str:
    st = _ASK.setdefault(sid, {"pending": False, "snooze_until": 0.0})
    st["pending"] = False
    st["snooze_until"] = meter(messages)["pct"] + 0.10
    return "OK - keeping the full chat. I'll ask again if it grows more. Say 'clean up chat' any time."


def clear_pending(sid: str) -> None:
    if sid in _ASK:
        _ASK[sid]["pending"] = False


# ---------- internal tools (Game Bot can call these) ----------
_LIVE: dict = {}


def tool_context_status(**_):
    msgs = _LIVE.get("messages") or []
    m = meter(msgs)
    return json.dumps({k: m[k] for k in ("label", "text", "used", "available", "pct", "state", "num_ctx", "basis")})


def tool_request_context_cleanup(confirmed: bool = False, **_):
    """confirmed=False -> returns the explanation to show the creator (ask first). confirmed=True only after the
    creator said yes this turn; the clean runs right after the turn finishes."""
    msgs = _LIVE.get("messages") or []
    sid = _LIVE.get("sid", "")
    if not confirmed:
        _ASK.setdefault(sid, {"pending": False, "snooze_until": 0.0})["pending"] = True
        return "ASK THE CREATOR FIRST (do not clean yet). Tell them:\n" + proposal(msgs)
    if not (pending(sid) or wants_cleanup(_LIVE.get("last_user", "")) or is_yes(_LIVE.get("last_user", ""))):
        return "NOT ALLOWED: the creator has not approved a clean-up. Call with confirmed=false and ask them first."
    _LIVE["approved"] = True
    return "Approved - Game Bot will summarize older turns and archive the raw log right after this reply."


TOOL_SCHEMAS = [
    {"type": "function", "function": {"name": "context_status", "description": "Show how much chat context is used vs available on this PC (tokens).",
                                      "parameters": {"type": "object", "properties": {}}}},
    {"type": "function", "function": {"name": "request_context_cleanup",
                                      "description": "Long chat: explain context pressure and ASK the creator before cleaning. confirmed=true only after they said yes.",
                                      "parameters": {"type": "object", "properties": {"confirmed": {"type": "boolean"}}}}},
]
DISPATCH = {"context_status": tool_context_status, "request_context_cleanup": tool_request_context_cleanup}
