# Unreal Engine 5 workflow
Sources: https://dev.epicgames.com/documentation/unreal-engine/packaging-and-cooking-games-in-unreal-engine · https://dev.epicgames.com/documentation/en-us/unreal-engine/gameplay-framework-in-unreal-engine · https://dev.epicgames.com/documentation/en-us/unreal-engine/blueprints-visual-scripting-in-unreal-engine · https://dev.epicgames.com/documentation/en-us/unreal-engine/unreal-engine-materials · https://dev.epicgames.com/documentation/en-us/unreal-engine/umg-ui-designer-for-unreal-engine · https://unrealcommunity.wiki/how-to-package-your-game-with-commands-uq8b4tix

## Status on this PC (checked 2026-10-25)
- Unreal Engine is NOT installed (only Epic Launcher at C:\Program Files\Epic Games\Launcher). Installing UE5 is a ~60+ GB download via the Epic Games Launcher and needs the creator's OK. Until then: write plans/C++/Blueprint designs, do not claim UE builds ran.
- Default engine for his projects = Unity. Use Unreal only when asked.

## Project structure
- <Proj>.uproject, Config/ (DefaultEngine.ini, DefaultGame.ini, DefaultInput.ini), Content/ (.uasset/.umap — binary, edit in editor), Source/<Proj>/ (C++ modules, *.Build.cs), Plugins/, Saved/ (logs: Saved/Logs/<Proj>.log), Intermediate/ & Binaries/ (generated — safe to delete to force rebuild).
- Gameplay framework: GameMode (rules, server only) -> GameState -> PlayerController (input/possession) -> Pawn/Character -> PlayerState; HUD/UMG widgets for UI.

## Blueprints vs C++
- C++ for core systems, performance, reusable base classes (UCLASS/UPROPERTY/UFUNCTION(BlueprintCallable)); Blueprints subclass them for tuning, content, level logic. Data: DataAssets / DataTables (CSV import) — Unreal's ScriptableObject equivalent.
- Rule: never invent UPROPERTY specifiers or engine functions — search dev.epicgames.com API docs first.

## Content Browser / import
- Import FBX (Static or Skeletal), units cm, X forward Z up. Use UCX_ collision, LOD groups, Nanite for high-poly static meshes (UE5), Lumen for GI.
- Materials: Material (graph) -> Material Instances (parameters) for variants; textures BaseColor sRGB, Normal (DirectX green), ORM packed with sRGB OFF.

## Command line
- Editor: "<UE>\Engine\Binaries\Win64\UnrealEditor.exe" "<Proj>.uproject"  (UnrealEditor-Cmd.exe for headless commandlets, e.g. -run=cook -targetplatform=Windows).
- Build C++: "<UE>\Engine\Build\BatchFiles\Build.bat" <Proj>Editor Win64 Development -Project="<Proj>.uproject" -WaitMutex
- Package: "<UE>\Engine\Build\BatchFiles\RunUAT.bat" BuildCookRun -project="<Proj>.uproject" -noP4 -platform=Win64 -clientconfig=Shipping -build -cook -stage -pak -archive -archivedirectory="<out>" -unattended -utf8output
- Success = "BUILD SUCCESSFUL" and exit 0; errors in the UAT log + Saved/Logs. Cook errors usually = broken asset references (fix redirectors: Fix Up Redirectors in Content Browser).

## Common UE fixes
- "Modules are missing or built with a different engine version" -> delete Binaries/Intermediate, right-click .uproject -> Generate project files, rebuild.
- Unresolved external symbol LNK2019 -> missing module dependency in <Proj>.Build.cs PublicDependencyModuleNames (e.g. "UMG", "EnhancedInput").
- Pink/default checker material -> missing texture/material reference; Black UI -> widget not added to viewport (AddToViewport).
