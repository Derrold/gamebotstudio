"""Game Bot support: in-app bug reports and the update check on launch.

Bug reports: bug_reports\\<id>\\ + bug_reports\\GameBot-bug-<id>.zip (whole chat, game summary, logs, system info).
They open a pre-filled email to the support address (mailto, or webmail if no mail app) or send via SMTP if
gamebot.config.json has "smtp": {"host", "port", "user", "password", "from", "tls"}. Nothing is sent without the user's click.
Updates: version.json (shipped) vs the manifest at update_url (env GAMEBOT_UPDATE_URL, gamebot.config.json "update_url",
config\\update.json "update_url", default https://gamebotstudio.com/gamebot/version.json). Manifest:
  {"version": "0.0.2", "url": "GameBot-Setup-0.0.2.exe" or a .zip (relative to the manifest, or a URL/path),
   "sha256": "<hex, required>", "notes": "..."}   ("setup"/"package" are accepted for "url")
Installing runs update_gamebot.ps1, which backs up and restores all user data and never touches Documents\\GameProjects.
"""
from __future__ import annotations

import hashlib
import json
import os
import platform
import re
import shutil
import subprocess
import sys
import threading
import time
import urllib.request
from datetime import datetime
from pathlib import Path

ROOT = Path(__file__).resolve().parent
BUG_DIR = ROOT / "bug_reports"
_UPD: dict = {"checked": 0.0, "result": None, "installing": False}


def _read_json(p: Path) -> dict:
    try:
        d = json.loads(p.read_text(encoding="utf-8-sig"))
        return d if isinstance(d, dict) else {}
    except Exception:
        return {}


def current_version() -> str:
    return str(_read_json(ROOT / "version.json").get("version") or "0.0.0")


def _vtuple(v: str):
    return tuple(int(x) for x in re.findall(r"\d+", v or "0")[:4]) or (0,)


SUPPORT_EMAIL = "alphamaxstudios@gmail.com"
DEFAULT_UPDATE_URL = "https://gamebotstudio.com/gamebot/version.json"


def _cfg() -> dict:
    return _read_json(ROOT / "config" / "gamebot.config.json")


def support_email() -> str:
    return str(_cfg().get("support_email") or _read_json(ROOT / "config" / "update.json").get("support_email") or SUPPORT_EMAIL).strip()


# ---------------------------------------------------------------- system info
def _ram_gb() -> float:
    try:
        import ctypes

        class MS(ctypes.Structure):
            _fields_ = [("dwLength", ctypes.c_ulong), ("dwMemoryLoad", ctypes.c_ulong), ("ullTotalPhys", ctypes.c_ulonglong),
                        ("ullAvailPhys", ctypes.c_ulonglong), ("ullTotalPageFile", ctypes.c_ulonglong), ("ullAvailPageFile", ctypes.c_ulonglong),
                        ("ullTotalVirtual", ctypes.c_ulonglong), ("ullAvailVirtual", ctypes.c_ulonglong), ("ullAvailExtendedVirtual", ctypes.c_ulonglong)]
        m = MS(); m.dwLength = ctypes.sizeof(MS)
        ctypes.windll.kernel32.GlobalMemoryStatusEx(ctypes.byref(m))
        return round(m.ullTotalPhys / 1024 ** 3, 1)
    except Exception:
        return 0.0


def _gpus() -> list:
    out: list = []
    try:  # every GPU (NVIDIA, AMD, Intel) with real VRAM from the display-class registry
        import winreg
        base = r"SYSTEM\CurrentControlSet\Control\Class\{4d36e968-e325-11ce-bfc1-08002be10318}"
        with winreg.OpenKey(winreg.HKEY_LOCAL_MACHINE, base) as k:
            for i in range(64):
                try:
                    sub = winreg.EnumKey(k, i)
                except OSError:
                    break
                if not sub.isdigit():
                    continue
                try:
                    with winreg.OpenKey(k, sub) as s:
                        name = winreg.QueryValueEx(s, "DriverDesc")[0]
                        try:
                            vram = int(winreg.QueryValueEx(s, "HardwareInformation.qwMemorySize")[0])
                        except OSError:
                            try:
                                v = winreg.QueryValueEx(s, "HardwareInformation.MemorySize")[0]
                                vram = int.from_bytes(v, "little") if isinstance(v, bytes) else int(v)
                            except OSError:
                                vram = 0
                        try:
                            drv = winreg.QueryValueEx(s, "DriverVersion")[0]
                        except OSError:
                            drv = ""
                        if name and not any(g["name"] == name and g["vram_gb"] == round(vram / 1024 ** 3, 1) for g in out):
                            out.append({"name": name, "vram_gb": round(vram / 1024 ** 3, 1), "driver": drv})
                except OSError:
                    continue
    except Exception:
        pass
    present = []
    try:  # only adapters that are plugged in now (the registry also keeps old/removed cards)
        r = subprocess.run(["powershell", "-NoProfile", "-Command", "(Get-CimInstance Win32_VideoController).Name"],
                           capture_output=True, text=True, timeout=15, creationflags=0x08000000)
        present = [x.strip() for x in (r.stdout or "").splitlines() if x.strip()]
    except Exception:
        pass
    if present:
        best = {}
        for g in out:
            if g["name"] in present and g["vram_gb"] >= best.get(g["name"], {"vram_gb": -1})["vram_gb"]:
                best[g["name"]] = g
        out = [best.get(n) or {"name": n, "vram_gb": 0.0, "driver": ""} for n in dict.fromkeys(present)]
    try:  # NVIDIA live VRAM use if available
        r = subprocess.run(["nvidia-smi", "--query-gpu=name,memory.total,memory.used,driver_version", "--format=csv,noheader,nounits"],
                           capture_output=True, text=True, timeout=8, creationflags=0x08000000)
        nv = [g for g in out if "nvidia" in g["name"].lower()]
        for i, line in enumerate((r.stdout or "").splitlines()):
            q = [x.strip() for x in line.split(",")]
            if len(q) >= 4:
                tgt = nv[i] if i < len(nv) else None
                if tgt is None:
                    tgt = {"name": q[0]}; out.append(tgt)
                tgt.update(vram_gb=round(int(q[1]) / 1024, 1), vram_used_gb=round(int(q[2]) / 1024, 1), nvidia_driver=q[3])
    except Exception:
        pass
    return [g for g in out if "basic display" not in g["name"].lower() and "remote display" not in g["name"].lower()] or out


def system_info() -> dict:
    model = os.environ.get("OLLAMA_MODEL", "")
    try:
        from agent_core import MODEL as model  # noqa
    except Exception:
        pass
    edition = ""
    try:
        edition = str(_cfg().get("edition") or "")
    except Exception:
        pass
    return {
        "app_version": current_version(), "model": model, "edition": edition,
        "os": platform.platform(), "windows": platform.version(), "machine": platform.machine(),
        "cpu": platform.processor(), "cpu_cores": os.cpu_count(), "ram_gb": _ram_gb(),
        "gpus": _gpus(), "python": sys.version.split()[0],
    }


def _sys_line(si: dict) -> str:
    g = "; ".join(f"{x['name']} {x['vram_gb']} GB" for x in si.get("gpus") or []) or "unknown GPU"
    return f"Game Bot {si.get('app_version')} | {si.get('os')} | RAM {si.get('ram_gb')} GB | GPU {g} | model {si.get('model') or '-'}"


# ---------------------------------------------------------------- bug reports
_SECRET_RX = [
    (re.compile(r"(?i)\b(password|passwd|pwd|api[_-]?key|secret|token|license[_-]?key|smtp[_-]?pass)(\W{0,3}\s*[:=]\s*\W{0,2})([^\s\"',;}]{4,})"), r"\1\2[REDACTED]"),
    (re.compile(r"\b(sk-[A-Za-z0-9_-]{16,}|gh[pousr]_[A-Za-z0-9]{20,}|github_pat_[A-Za-z0-9_]{20,}|AKIA[0-9A-Z]{16}|xox[baprs]-[A-Za-z0-9-]{10,}|AIza[0-9A-Za-z_-]{30,}|-----BEGIN [A-Z ]*PRIVATE KEY-----[\s\S]*?-----END [A-Z ]*PRIVATE KEY-----)"), "[REDACTED_KEY]"),
    (re.compile(r"(?i)([A-Za-z]:(?:\\\\|\\|/)+Users(?:\\\\|\\|/)+)([^\\/\s\"':*?<>|]+)"), r"\1<user>"),
]


def redact(text: str) -> str:
    """Hide the Windows user name, PC name, other people's emails and obvious secrets before anything is packed."""
    t = str(text or "")
    for rx, sub in _SECRET_RX:
        t = rx.sub(sub, t)
    for env, tag in (("USERNAME", "<user>"), ("COMPUTERNAME", "<pc>")):
        v = os.environ.get(env, "").strip()
        if len(v) >= 3:
            t = re.sub(r"(?i)(?<![A-Za-z0-9])" + re.escape(v) + r"(?![A-Za-z0-9])", tag, t)
    sup = support_email().lower()
    t = re.sub(r"[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}", lambda m: m.group(0) if m.group(0).lower() == sup else "[email]", t)
    return t


def _wt(path: Path, text: str) -> None:
    path.write_text(redact(text), encoding="utf-8")


def _tail(p: Path, n: int = 400) -> str:
    try:
        lines = p.read_text(encoding="utf-8", errors="replace").splitlines()
        return "\n".join(lines[-n:])
    except Exception:
        return ""


def _transcript(messages: list) -> str:
    out = []
    for m in messages:
        role = m.get("role")
        if role not in ("user", "assistant"):
            continue
        out.append(("You" if role == "user" else "Game Bot") + ": " + str(m.get("content") or "").strip())
    return "\n\n".join(out)


def _mail_urls(rid: str, description: str, si: dict, messages: list, zip_path: Path) -> dict:
    from urllib.parse import quote
    to = support_email()
    description = redact(description)
    subject = f"Game Bot bug report {rid} (v{si.get('app_version')})"
    head = ("What went wrong:\n" + (description.strip() or "(no description)") + "\n\n" + _sys_line(si) + "\n\n"
            "Full chat, game summary, logs and system info are in this zip - please attach it:\n" + str(zip_path) + "\n\n"
            "--- Conversation ---\n")
    conv = redact(_transcript(messages))
    head = redact(head)
    limit = 1900  # Windows mail handlers cut mailto links around 2 KB
    body = head + conv

    def size(b):
        return len(f"mailto:{to}?subject={quote(subject)}&body={quote(b)}")

    if size(body) > limit:
        note = "[...earlier messages cut - the full chat is in the zip...]\n"
        lo, hi = 0, len(conv)
        while lo < hi:  # keep the most recent part of the chat that fits
            mid = (lo + hi) // 2
            if size(head + note + conv[mid:]) <= limit:
                hi = mid
            else:
                lo = mid + 1
        nxt = conv.find("\n\n", lo)
        start = 0 if lo == 0 else (nxt + 2 if nxt >= 0 else len(conv))  # start at a whole message
        body = head + note + conv[start:]
        if size(body) > limit:
            body = body[:300] + "\n[...cut - see zip...]"
    mailto = f"mailto:{to}?subject={quote(subject)}&body={quote(body)}"
    gmail = ("https://mail.google.com/mail/?view=cm&fs=1&to=" + quote(to) + "&su=" + quote(subject) + "&body=" + quote(body))
    return {"to": to, "subject": subject, "body": body, "mailto": mailto, "webmail": gmail}


def save_bug_report(description: str, sid: str = "", messages: list | None = None, include_chat: bool = True,
                    game_root: Path | None = None, extra_files: dict | None = None) -> dict:
    """Collect the WHOLE chat, game summary, logs and system info into bug_reports\\<id>\\ + a zip next to it.
    Returns {"id", "path", "zip", "mailto", "webmail", "subject", "to", "smtp"}. Nothing is sent from here."""
    import zipfile
    messages = list(messages or [])
    ts = datetime.now().strftime("%Y%m%d_%H%M%S")
    rid = ts + ("_" + re.sub(r"[^A-Za-z0-9]", "", sid)[:8] if sid else "")
    d = BUG_DIR / rid
    d.mkdir(parents=True, exist_ok=True)
    saved = {}
    try:
        import chat_store
        if sid:
            saved = chat_store.load_chat(sid) or {}
            if not messages:
                messages = saved.get("messages") or []
        if game_root is None:
            game_root = chat_store.chat_game_root(messages) if messages else None
    except Exception:
        pass
    summary = str(saved.get("summary") or "")
    if not summary and messages:
        try:
            import chat_store
            summary = chat_store.build_summary(sid, messages, game_root) or ""
        except Exception:
            summary = ""
    si = system_info()
    info = {"id": rid, "when": datetime.now().isoformat(timespec="seconds"), "version": si["app_version"], "session_id": sid,
            "title": saved.get("title") or "", "game": game_root.name if game_root else (saved.get("game") or ""),
            "messages": len(messages), "description": description}
    info["chat_included"] = bool(include_chat)
    info["redacted"] = "user name, PC name, user folder paths, other emails, passwords/keys/tokens"
    _wt(d / "report.json", json.dumps(info, indent=2, ensure_ascii=False))
    _wt(d / "system_info.json", json.dumps(si, indent=2, ensure_ascii=False))
    if include_chat:  # the entire chat, every message (incl. tool/system turns) + a readable transcript
        _wt(d / "chat_full.json", json.dumps(messages, indent=2, ensure_ascii=False, default=str))
        _wt(d / "chat.md", f"# Chat {saved.get('title') or sid}\n\n" + _transcript(messages))
        _wt(d / "game_summary.md", summary or "(no game summary yet)")
    md = [f"# Bug report {rid}", "", _sys_line(si), f"When: {info['when']}", f"Game: {info['game'] or '-'}",
          f"Chat: {info['title'] or sid} ({len(messages)} messages)", "", "## What happened", description.strip() or "(no description)"]
    _wt(d / "report.md", "\n".join(md))
    logs = {"app_err_live.log": ROOT / "app_err_live.log", "app_child.err.log": ROOT / "app_child.err.log",
            "app_child.out.log": ROOT / "app_child.out.log", "app_autostart.err.log": ROOT / "app_autostart.err.log",
            "desktop_window.log": ROOT / "desktop_window.log",
            "unity_Editor.log": Path(os.environ.get("LOCALAPPDATA", "")) / "Unity" / "Editor" / "Editor.log"}
    if game_root:
        b = game_root / "Builds"
        for name in ("auto_unity_status.txt", "build.log", "auto_unity.log", "unity_build.log"):
            logs["build_" + name] = b / name
        try:
            for p in sorted(b.glob("*.log"), key=lambda x: x.stat().st_mtime, reverse=True)[:4]:
                logs.setdefault("build_" + p.name, p)
        except Exception:
            pass
    for name, p in (extra_files or {}).items():
        logs[str(name)] = Path(p)
    ld = d / "logs"
    ld.mkdir(exist_ok=True)
    for name, p in logs.items():
        t = _tail(p, 600)
        if t:
            _wt(ld / name, t)
    zp = BUG_DIR / f"GameBot-bug-{rid}.zip"
    with zipfile.ZipFile(zp, "w", zipfile.ZIP_DEFLATED) as z:
        for p in sorted(d.rglob("*")):
            if p.is_file():
                z.write(p, f"{rid}/" + str(p.relative_to(d)).replace("\\", "/"))
    mail = _mail_urls(rid, description, si, messages if include_chat else [], zp)
    (d / "email.json").write_text(json.dumps(mail, indent=2, ensure_ascii=False), encoding="utf-8")
    files = [{"name": str(p.relative_to(d)).replace("\\", "/"), "bytes": p.stat().st_size}
             for p in sorted(d.rglob("*")) if p.is_file() and p.name != "email.json"]
    zsize = zp.stat().st_size if zp.exists() else 0
    return {"id": rid, "path": str(d), "zip": str(zp), "zip_name": zp.name, "zip_bytes": zsize, "files": files,
            "messages": len(messages) if include_chat else 0, "chat_included": bool(include_chat),
            "too_big_for_email": zsize >= 20 * 1024 * 1024, "smtp": smtp_configured()} | mail


def _report(rid: str) -> tuple[Path, dict]:
    rid = re.sub(r"[^A-Za-z0-9_]", "", rid or "")
    d = BUG_DIR / rid
    return d, _read_json(d / "email.json")


def _mailto_handler() -> bool:
    """True only if a mail app that is really installed handles mailto (a stale choice shows a 'Pick an app' box)."""
    try:
        import winreg
        try:
            with winreg.OpenKey(winreg.HKEY_CURRENT_USER, r"Software\Microsoft\Windows\Shell\Associations\UrlAssociations\mailto\UserChoice") as k:
                prog = winreg.QueryValueEx(k, "ProgId")[0]
        except OSError:
            prog = ""
        keys = [prog + r"\shell\open\command", prog + r"\Shell\open"] if prog else [r"mailto\shell\open\command"]
        for key in keys:
            try:
                with winreg.OpenKey(winreg.HKEY_CLASSES_ROOT, key):
                    return True
            except OSError:
                continue
    except Exception:
        pass
    return False


def open_bug_email(rid: str) -> dict:
    """Open the pre-filled email draft (mail app via mailto, or webmail compose if no mail app). Never sends."""
    d, mail = _report(rid)
    if not mail:
        return {"ok": False, "message": "Report not found."}
    zp = BUG_DIR / f"GameBot-bug-{d.name}.zip"
    try:
        if _mailto_handler():
            url, how = mail["mailto"], "mail app"
        else:
            url, how = mail["webmail"], "web browser (Gmail compose - no mail app is set up on this PC)"
        threading.Thread(target=lambda: os.startfile(url), daemon=True).start()  # noqa  (never block the UI)
        try:  # show the zip so it can be dragged into the email
            subprocess.Popen(["explorer", "/select,", str(zp)])
        except Exception:
            pass
        kb = max(1, (zp.stat().st_size if zp.exists() else 0) // 1024)
        return {"ok": True, "how": how, "zip": str(zp), "message": (
            f"Email opened in your {how}. The zip is NOT attached yet:\n"
            f"1. In the Explorer window that just opened, find {zp.name} ({kb} KB).\n"
            f"2. Drag it into the email (or click the paperclip and pick it).\n"
            f"3. Check the email shows the attachment, then press Send.")}
    except Exception as e:
        return {"ok": False, "message": f"Couldn't open an email ({type(e).__name__}). Email {mail.get('to')} and attach {zp}."}


def smtp_settings() -> dict:
    s = _cfg().get("smtp") or {}
    return s if isinstance(s, dict) else {}


def smtp_configured() -> bool:
    s = smtp_settings()
    return bool(s.get("host") and (s.get("from") or s.get("user")))


def send_bug_email(rid: str) -> dict:
    """Send the report with the zip attached via the SMTP server in config (gamebot.config.json "smtp")."""
    import smtplib
    from email.message import EmailMessage
    s = smtp_settings()
    if not smtp_configured():
        return {"ok": False, "message": "No email server set up - use Open email instead."}
    d, mail = _report(rid)
    if not mail:
        return {"ok": False, "message": "Report not found."}
    zp = BUG_DIR / f"GameBot-bug-{d.name}.zip"
    msg = EmailMessage()
    msg["From"] = s.get("from") or s.get("user")
    msg["To"] = mail["to"]
    msg["Subject"] = mail["subject"]
    msg.set_content(mail["body"])
    if not zp.exists():
        return {"ok": False, "message": "The report zip is missing - press Save again."}
    if zp.stat().st_size >= 20 * 1024 * 1024:
        return {"ok": False, "message": f"{zp.name} is over 20 MB, too big to email. Nothing was sent - untick 'Include this chat' and save again, or share the zip another way."}
    msg.add_attachment(zp.read_bytes(), maintype="application", subtype="zip", filename=zp.name)
    port = int(s.get("port") or 587)
    try:
        if port == 465 or s.get("ssl"):
            srv = smtplib.SMTP_SSL(s["host"], port, timeout=30)
        else:
            srv = smtplib.SMTP(s["host"], port, timeout=30)
            if s.get("tls", True):
                srv.starttls()
        with srv:
            if s.get("user"):
                srv.login(s["user"], s.get("password") or "")
            srv.send_message(msg)
        return {"ok": True, "message": f"Bug report sent to {mail['to']}."}
    except Exception as e:
        return {"ok": False, "message": f"Couldn't send ({type(e).__name__}). Use Open email instead."}



def preview_bug_report(rid: str, max_chars: int = 150000) -> dict:
    """Exactly what will go out (pre-sale fix): the email text plus every file in the zip, already redacted."""
    import zipfile
    d, mail = _report(rid)
    if not mail:
        return {"ok": False, "message": "Report not found."}
    zp = BUG_DIR / f"GameBot-bug-{d.name}.zip"
    files, left = [], max_chars
    order = ["report.md", "chat.md", "game_summary.md", "report.json", "system_info.json"]
    rank = lambda n: (order.index(n) if n in order else (len(order) + 1 if n == "chat_full.json" else len(order)), n)
    try:
        with zipfile.ZipFile(zp) as z:
            for zi in sorted((x for x in z.infolist() if not x.is_dir()), key=lambda x: rank(x.filename.split("/", 1)[-1])):
                txt = z.read(zi).decode("utf-8", errors="replace")
                cap = min(left, 12000)
                cut = len(txt) > cap
                show = txt[:max(0, cap)]
                left -= len(show)
                files.append({"name": zi.filename.split("/", 1)[-1], "bytes": zi.file_size, "text": show, "cut": cut})
    except Exception as e:
        return {"ok": False, "message": f"Couldn't read the report zip ({type(e).__name__})."}
    return {"ok": True, "id": d.name, "to": mail.get("to"), "subject": mail.get("subject"), "body": mail.get("body"),
            "zip": str(zp), "zip_name": zp.name, "zip_bytes": zp.stat().st_size, "files": files, "smtp": smtp_configured()}


def discard_bug_report(rid: str) -> dict:
    """Cancel: delete the report folder and zip so nothing is left to send."""
    d, _ = _report(rid)
    if not d.name or d.parent != BUG_DIR or not d.is_dir():
        return {"ok": False, "message": "Report not found."}
    shutil.rmtree(d, ignore_errors=True)
    try:
        (BUG_DIR / f"GameBot-bug-{d.name}.zip").unlink()
    except OSError:
        pass
    return {"ok": True, "message": "Cancelled - the report was deleted and nothing was sent."}


def list_bug_reports(limit: int = 20) -> list:
    if not BUG_DIR.is_dir():
        return []
    out = []
    for d in sorted((x for x in BUG_DIR.iterdir() if x.is_dir()), reverse=True)[:limit]:
        r = _read_json(d / "report.json")
        out.append({"id": d.name, "when": r.get("when"), "game": r.get("game"), "description": (r.get("description") or "")[:200]})
    return out


# ---------------------------------------------------------------- hang auto-reports
# The build watchdog (auto_unity.ps1) writes <game>\Builds\hang_report_<ts>.txt/.json when it skips a frozen import or a
# build stalls. The chat shows ONE card per stuck file per game; the report only leaves the PC when the user presses Send,
# through the same redacted bug-report zip/preview/send flow (to the support address).
HANG_SEEN = ROOT / "work" / "hang_prompts.json"


def _games_root() -> Path:
    try:
        import gamedev_core
        return Path(gamedev_core.GAME_PROJECTS)
    except Exception:
        return Path(os.environ.get("GAMEBOT_PROJECTS") or (Path.home() / "Documents" / "GameProjects"))


def _hang_key(game: str, file: str) -> str:
    return f"{game}|{(file or '(stall)').strip().lower()}"


def _hang_seen() -> dict:
    return _read_json(HANG_SEEN)


def pending_hang_reports(limit: int = 3) -> list:
    """New hang reports the user hasn't been asked about yet (at most one per file per game)."""
    seen, out, keys = _hang_seen(), [], set()
    root = _games_root()
    try:
        games = [d for d in root.iterdir() if d.is_dir() and not d.name.startswith(".")]
    except Exception:
        return []
    for d in games:
        b = d / "Builds"
        try:
            files = sorted(b.glob("hang_report_*.json"))
        except Exception:
            continue
        for j in files:
            r = _read_json(j)
            if not r:
                continue
            key = _hang_key(d.name, str(r.get("file") or ""))
            if key in seen or key in keys:
                continue
            keys.add(key)
            out.append({"key": key, "id": j.stem, "game": d.name, "kind": r.get("kind") or "import",
                        "file": r.get("file") or "", "pack": r.get("pack") or "", "stuck_seconds": int(r.get("stuck_seconds") or 0),
                        "unity": r.get("unity") or "", "when": r.get("when") or ""})
    return out[-limit:]


def ack_hang_report(key: str, state: str = "prompted") -> dict:
    key = str(key or "")[:400]
    if "|" not in key:
        return {"ok": False, "message": "bad key"}
    seen = _hang_seen()
    seen[key] = {"state": re.sub(r"[^a-z_]", "", state or "prompted")[:20] or "prompted", "when": datetime.now().isoformat(timespec="seconds")}
    HANG_SEEN.parent.mkdir(parents=True, exist_ok=True)
    HANG_SEEN.write_text(json.dumps(seen, indent=2), encoding="utf-8")
    return {"ok": True}


def _find_hang(key: str) -> tuple:
    game = str(key or "").split("|", 1)[0]
    if not game or re.search(r"[\\/:*?\"<>]|\.\.", game):
        return None, None, {}
    g = _games_root() / game
    for j in sorted((g / "Builds").glob("hang_report_*.json"), reverse=True):
        r = _read_json(j)
        if r and _hang_key(game, str(r.get("file") or "")) == key:
            return g, j, r
    return g, None, {}


def create_hang_bug_report(key: str) -> dict:
    """Pack the hang report (no chat) into a normal redacted bug report; returns what /api/bug_report returns. Sends nothing."""
    g, j, r = _find_hang(key)
    if not j:
        return {"ok": False, "error": "hang report not found"}
    what = (f"Unity froze importing {r.get('file')} (pack: {r.get('pack') or '-'})" if r.get("file")
            else "Unity stopped responding during a build (no import in progress)")
    desc = (f"[Automatic hang report] {what} for {r.get('stuck_seconds')} s in game {g.name}. "
            f"Game Bot skipped it and retried. Unity {r.get('unity')}, GPU {r.get('gpu')} ({r.get('vram_gb')} GB VRAM), RAM {r.get('ram_gb')} GB.")
    txt = j.with_suffix(".txt")
    res = save_bug_report(desc, "", [], include_chat=False, game_root=g,
                          extra_files={"hang_report.txt": txt, "hang_report.json": j})
    ack_hang_report(key, "report_created")
    return {"ok": True, "hang": r} | res


# ---------------------------------------------------------------- updates
# Signed updates (review fix 1): the manifest must be fetched over HTTPS, its package URL must be HTTPS, it must carry a
# SHA-256 of the package, and an Ed25519 "signature" (tools\\sign_release.py) made with the private key whose public half
# is pinned below. Feed overrides (env / gamebot.config.json / config\\update.json) and local paths are honoured ONLY in
# dev mode (env GAMEBOT_DEV=1), never on a buyer's PC.
UPDATE_PUBKEY_HEX = "ab2e52e6bcefc24b823506ec4b811361bc3398ff15734fbe591e8c926b62faee"


def _dev_mode() -> bool:
    return os.environ.get("GAMEBOT_DEV", "").strip() == "1"


def feed_location() -> str:
    if not _dev_mode():
        return DEFAULT_UPDATE_URL
    for env in ("GAMEBOT_UPDATE_URL", "GAMEBOT_UPDATE_FEED"):
        v = os.environ.get(env, "").strip()
        if v:
            return v
    c = _cfg()
    for k in ("update_url", "update_feed"):
        if str(c.get(k) or "").strip():
            return str(c[k]).strip()
    u = _read_json(ROOT / "config" / "update.json")
    for k in ("update_url", "feed"):
        if str(u.get(k) or "").strip():
            return str(u[k]).strip()
    return DEFAULT_UPDATE_URL


def _is_https(loc: str) -> bool:
    return bool(re.match(r"^https://", loc or "", re.I))


def _fetch(loc: str, timeout: float = 6.0) -> bytes:
    if _is_https(loc):
        import ssl
        req = urllib.request.Request(loc, headers={"User-Agent": "GameBot-Updater"})
        with urllib.request.urlopen(req, timeout=timeout, context=ssl.create_default_context()) as r:
            return r.read()
    if re.match(r"^[a-z][a-z0-9+.-]*://", loc or "", re.I):
        raise PermissionError("update feed must use https://")
    if not _dev_mode():
        raise PermissionError("local update feeds are only allowed in dev mode")
    p = Path(loc)
    if p.is_dir():
        p = p / "version.json" if (p / "version.json").exists() else p / "latest.json"
    return p.read_bytes()


def _join(feed: str, rel: str) -> str:
    if re.match(r"^(https?://|[A-Za-z]:\\|\\\\|/)", rel):
        return rel
    if re.match(r"^https?://", feed, re.I):
        return feed.rsplit("/", 1)[0] + "/" + rel
    base = Path(feed)
    return str((base if base.is_dir() else base.parent) / rel)


def manifest_message(info: dict) -> bytes:
    """Canonical bytes that the signature covers: every manifest field except "signature"."""
    body = {k: v for k, v in (info or {}).items() if k != "signature"}
    return json.dumps(body, sort_keys=True, separators=(",", ":"), ensure_ascii=False).encode("utf-8")


def verify_manifest(info: dict) -> bool:
    import base64
    import gb_ed25519
    if not re.fullmatch(r"[0-9a-f]{64}", UPDATE_PUBKEY_HEX or ""):
        return False
    try:
        sig = base64.b64decode(str((info or {}).get("signature") or ""), validate=True)
    except Exception:
        return False
    return gb_ed25519.verify(bytes.fromhex(UPDATE_PUBKEY_HEX), manifest_message(info), sig)


def any_build_running() -> str:
    """Name of a game whose background Unity/Unreal job is queued or running, else ''."""
    try:
        from auto_studio import unity_job_running
        from gamedev_core import GAME_PROJECTS
        for d in Path(GAME_PROJECTS).iterdir():
            if d.is_dir() and not d.name.startswith(".") and unity_job_running(d):
                return d.name
    except Exception:
        pass
    return ""


def check_update(force: bool = False) -> dict:
    if not force and _UPD["result"] is not None and time.time() - _UPD["checked"] < 3600:
        return _UPD["result"]
    cur = current_version()
    feed = feed_location()
    res = {"current": cur, "available": False, "latest": cur, "notes": "", "feed": bool(feed)}
    if not feed:
        res["reason"] = "no update feed configured"
    elif not _is_https(feed) and not (_dev_mode() and not re.match(r"^[a-z][a-z0-9+.-]*://", feed, re.I)):
        res["reason"] = "update refused: the update feed is not https"
    else:
        try:
            info = json.loads(_fetch(feed).decode("utf-8-sig"))
            latest = str(info.get("version") or "")
            res.update(latest=latest or cur, notes=str(info.get("notes") or "")[:600])
            pkg = info.get("url") or info.get("setup") or info.get("package")
            if latest and _vtuple(latest) > _vtuple(cur) and pkg:
                pkg = _join(feed, str(pkg))
                if not verify_manifest(info):
                    res["reason"] = "update refused: the update is not signed by Game Bot (missing or bad signature)"
                elif re.match(r"^[a-z][a-z0-9+.-]*://", pkg, re.I) and not _is_https(pkg):
                    res["reason"] = "update refused: the download link is not https"
                elif not re.fullmatch(r"[0-9a-fA-F]{64}", str(info.get("sha256") or "")):
                    res["reason"] = "update refused: no SHA-256 checksum"
                else:
                    res.update(available=True, package=pkg, sha256=str(info.get("sha256")), signed=True)
                    _UPD["manifest"] = info
        except PermissionError as e:
            res["reason"] = f"update refused: {e}"
        except Exception as e:
            res["reason"] = f"update check failed: {type(e).__name__}"
    _UPD.update(checked=time.time(), result=res)
    return res


def check_update_async() -> None:
    threading.Thread(target=lambda: check_update(force=True), daemon=True).start()


# ---- update-install progress (0.0.4): Downloading X% -> Verifying signature -> Backing up your data -> Installing -> Restarting
UPD_STAGES = ("Downloading", "Verifying signature", "Backing up your data", "Installing", "Restarting")


def _upd_dir() -> Path:
    return Path(os.environ.get("LOCALAPPDATA", str(ROOT))) / "GameBot" / "Downloads"


def upd_progress_path() -> Path:
    return _upd_dir() / "update_progress.json"


def _vdisp(v: str) -> str:
    p = str(v or "").split(".")
    return f"V{p[0]}.{p[1]}{p[2]}" if len(p) == 3 else f"V{v}"


def _set_upd(stage: str, pct: float, detail: str = "", state: str = "run", fresh: bool = False, **kw) -> dict:
    p = upd_progress_path()
    cur = {} if fresh else _read_json(p)
    now = time.time()
    cur.update(kw)
    cur.update(stage=stage, label=kw.get("label") or stage, pct=int(max(0, min(100, pct))), detail=detail,
               state=state, updated=now)
    cur.setdefault("started", now)
    try:
        p.parent.mkdir(parents=True, exist_ok=True)
        tmp = p.with_name(p.name + ".tmp")
        tmp.write_text(json.dumps(cur), encoding="utf-8")
        os.replace(tmp, p)
    except OSError:
        pass
    return cur


_UPD_SAFE = " Nothing was lost - your chats, settings, license and games are safe."
_UPD_RC = {
    2: "Backing up your data failed, so nothing was changed.",
    3: "Copying the new files failed, so the previous version was put back.",
    4: "Checking your data after the install found a problem. Your backup is kept in %LOCALAPPDATA%\\GameBot\\UserDataBackups.",
}


def _upd_fail(msg: str, **kw) -> dict:
    _UPD["installing"] = False
    return _set_upd("Update failed", 100, msg.rstrip() + _UPD_SAFE, state="fail", label="Update failed", **kw)


def update_progress() -> dict:
    """State for the in-app update bar. A restarted backend finishes the record (done/fail) from last_update.json."""
    d = _read_json(upd_progress_path())
    if not d or not d.get("stage"):
        return {"active": False}
    now = time.time()
    if d.get("state") == "run":
        mine = int(d.get("pid") or 0) == os.getpid()
        target = str(d.get("version") or "")
        if not mine and d.get("stage") in ("Backing up your data", "Installing", "Restarting"):
            last = last_update()
            rc = last.get("exit")
            if rc not in (None, 0, "0"):
                d = _upd_fail(_UPD_RC.get(int(rc) if str(rc).isdigit() else -1, f"The installer stopped (code {rc})."))
            elif target and current_version() == target:
                d = _set_upd("Update installed", 100, f"Game Bot updated to {_vdisp(target)}. Your chats, settings, license and games were kept.",
                             state="done", label="Update installed")
            elif now - float(d.get("updated") or now) > 120:
                d = _upd_fail(f"Game Bot {_vdisp(current_version())} is still installed - the update didn't finish.")
        elif not mine and d.get("stage") in ("Downloading", "Verifying signature"):
            d = _upd_fail("The update was interrupted before installing, so nothing was changed.")
        elif now - float(d.get("updated") or now) > 900:
            d = _upd_fail("The update stopped responding.")
    d = dict(d)
    d["active"] = d.get("state") == "run"
    d["recent"] = now - float(d.get("updated") or 0) < 180
    d["elapsed_s"] = int(now - float(d.get("started") or now))
    d["seen"] = bool(d.get("version")) and str(d.get("version")) in upd_ui()["seen"]  # 0.0.5
    return d


def install_update(wait: bool = False) -> dict:
    """Download/verify the package, then hand off to update_gamebot.ps1 in a detached helper that restarts Game Bot."""
    if _UPD["installing"]:
        return {"ok": False, "message": "An update is already installing."}
    busy = any_build_running()
    if busy:
        return {"ok": False, "message": f"A build is running for {busy}. Install the update after it finishes - nothing was changed."}
    res = check_update(force=True)
    if not res.get("available"):
        if res.get("reason", "").startswith("update refused"):
            return {"ok": False, "message": res["reason"][0].upper() + res["reason"][1:] + ". Nothing was installed."}
        return {"ok": False, "message": "Game Bot is up to date (" + res.get("current", "") + ")."}
    dl = Path(os.environ.get("LOCALAPPDATA", str(ROOT))) / "GameBot" / "Downloads"
    dl.mkdir(parents=True, exist_ok=True)
    if not re.fullmatch(r"[0-9a-fA-F]{64}", res.get("sha256") or ""):
        return {"ok": False, "message": "The update has no checksum, so it wasn't installed."}
    ext = ".exe" if str(res["package"]).lower().split("?")[0].endswith(".exe") else ".zip"
    pkg = dl / f"GameBot-{re.sub(r'[^0-9A-Za-z._-]', '', res['latest'])}{ext}"
    src = res["package"]
    if re.match(r"^[a-z][a-z0-9+.-]*://", src, re.I) and not _is_https(src):
        return {"ok": False, "message": "The update link is not https, so nothing was installed."}
    _UPD["installing"] = True
    _set_upd("Downloading", 1, f"Downloading Game Bot {_vdisp(res['latest'])}: 0%", fresh=True, label="Downloading 0%",
             version=res["latest"], pid=os.getpid(), from_version=res.get("current", ""))
    th = threading.Thread(target=_install_worker, args=(res, pkg, dl, dict(_UPD.get("manifest") or {})), daemon=True)
    th.start()
    if wait:
        th.join()
        d = update_progress()
        return {"ok": d.get("state") != "fail", "message": d.get("detail", ""), "progress": d}
    return {"ok": True, "message": f"Installing Game Bot {res['latest']}. Your chats, settings, license, bug reports and games are backed up first and kept. Game Bot restarts in a moment.",
            "progress": update_progress()}


def _install_worker(res: dict, pkg: Path, dl: Path, manifest: dict) -> None:
    v = _vdisp(res["latest"])
    try:
        src = res["package"]
        total = int(manifest.get("size") or 0)
        got, last = 0, 0.0

        def tick(n: int) -> None:
            nonlocal got, last
            got += n
            now = time.time()
            if now - last < 0.25 and not (total and got >= total):
                return
            last = now
            pct = int(got * 100 / total) if total else 0
            mb = f"{got / 1048576:.1f} of {total / 1048576:.1f} MB" if total else f"{got / 1048576:.1f} MB"
            _set_upd("Downloading", 1 + pct * 0.49, f"Downloading Game Bot {v}: {pct}% ({mb})", label=f"Downloading {pct}%", dl_pct=pct)

        with open(pkg, "wb") as f:
            if _is_https(src):
                with urllib.request.urlopen(urllib.request.Request(src, headers={"User-Agent": "GameBot-Updater"}), timeout=120) as r:
                    total = int(r.headers.get("Content-Length") or 0) or total
                    while True:
                        b = r.read(262144)
                        if not b:
                            break
                        f.write(b); tick(len(b))
            else:
                with open(src, "rb") as r:
                    total = total or os.path.getsize(src)
                    while True:
                        b = r.read(262144)
                        if not b:
                            break
                        f.write(b); tick(len(b))
                        if os.environ.get("GAMEBOT_UPD_SLOW"):  # test hook: slow local copy so the bar can be seen
                            time.sleep(float(os.environ["GAMEBOT_UPD_SLOW"]))
    except Exception as e:
        pkg.unlink(missing_ok=True)
        _upd_fail(f"Couldn't download the update ({type(e).__name__}), so nothing was changed.")
        return
    _set_upd("Verifying signature", 52, "Checking the Game Bot signature and the SHA-256 checksum of the download")
    if manifest and not verify_manifest(manifest):
        pkg.unlink(missing_ok=True)
        _upd_fail("The update is not signed by Game Bot, so it wasn't installed.")
        return
    hh = hashlib.sha256()
    with open(pkg, "rb") as f:
        for b in iter(lambda: f.read(1048576), b""):
            hh.update(b)
    if hh.hexdigest().lower() != str(res.get("sha256") or "").lower():
        pkg.unlink(missing_ok=True)
        _upd_fail("The update download failed its checksum, so nothing was installed.")
        return
    if os.environ.get("GAMEBOT_UPD_SLOW"):
        time.sleep(1.5)
    r = _start_helper(res, pkg, dl)
    if r:
        _upd_fail(r)
        return
    _set_upd("Backing up your data", 58, "Backing up your chats, settings, license and bug reports before installing")


def _start_helper(res: dict, pkg: Path, dl: Path) -> str:
    """Write + start the detached hidden helper. Returns '' or an error message."""
    helper = dl / "run_update.ps1"
    prog = upd_progress_path()
    py = Path(sys.executable)
    pyw = py.with_name("pythonw.exe") if py.with_name("pythonw.exe").exists() else py

    def psq(v) -> str:  # PowerShell single-quoted literal: safe for spaces, apostrophes, $ and backticks in paths
        return "'" + str(v).replace("'", "''") + "'"

    helper.write_text(
        "$ErrorActionPreference = 'Continue'\n"
        "Start-Sleep 2\n"
        f"$root = {psq(ROOT)}\n"
        f"$pkg = {psq(pkg)}\n"
        f"$pyw = {psq(pyw)}\n"
        "$upd = Join-Path $root 'update_gamebot.ps1'\n"
        "$res = Join-Path $root 'work\\last_update.json'\n"
        "$hlog = Join-Path (Split-Path $pkg) 'run_update.log'\n"
        f"$prog = {psq(prog)}\n"
        + _PS_PROG +
        "try {\n"
        "  & powershell -NoProfile -ExecutionPolicy Bypass -WindowStyle Hidden -File $upd -Package $pkg -InstallDir $root -ProgressFile $prog *>> $hlog\n"
        "  $rc = $LASTEXITCODE\n"
        "} catch { Add-Content -LiteralPath $hlog -Value (\"helper error: \" + $_); $rc = 99 }\n"
        "New-Item -ItemType Directory -Force (Split-Path $res) | Out-Null\n"
        f"[ordered]@{{exit = $rc; package = {psq(pkg.name)}; when = (Get-Date -f s)}} | ConvertTo-Json -Compress | Set-Content -LiteralPath $res -Encoding UTF8\n"
        "if ($rc -eq 0) { Prog 'Restarting' 96 'Restarting Game Bot with the new version...' }\n"
        "else { $why = @{2 = 'Backing up your data failed, so nothing was changed.'; 3 = 'Copying the new files failed, so the previous version was put back.'; "
        "4 = 'Checking your data after the install found a problem. Your backup is kept in %LOCALAPPDATA%\\GameBot\\UserDataBackups.'}[[int]$rc]; "
        "if (-not $why) { $why = \"The installer stopped (code $rc).\" }; "
        "Prog 'Update failed' 100 ($why + ' Nothing was lost - your chats, settings, license and games are safe.') 'fail' }\n"
        f"Stop-Process -Id {os.getpid()} -Force -ErrorAction SilentlyContinue\n"
        "Start-Sleep 2\n"
        "Start-Process -FilePath $pyw -ArgumentList ('\"' + (Join-Path $root 'app.py') + '\"') -WorkingDirectory $root -WindowStyle Hidden\n",
        encoding="utf-8-sig")
    cmd = ["powershell", "-NoProfile", "-ExecutionPolicy", "Bypass", "-WindowStyle", "Hidden", "-File", str(helper)]
    base = 0x08000000 | 0x00000200  # CREATE_NO_WINDOW | CREATE_NEW_PROCESS_GROUP (own console, survives this process)
    try:
        subprocess.Popen(cmd, cwd=str(ROOT), creationflags=base | 0x01000000, close_fds=True)  # + BREAKAWAY_FROM_JOB
    except OSError:
        try:
            subprocess.Popen(cmd, cwd=str(ROOT), creationflags=base, close_fds=True)
        except OSError as e:
            return f"Couldn't start the updater ({e}). Nothing was changed."
    return ""


# PowerShell: merge stage/pct/detail/state into the progress JSON (keeps version/pid/started). Literal paths: apostrophes OK.
_PS_PROG = (
    "function Prog($stage, $pct, $detail, $state = 'run') {\n"
    "  if (-not $prog) { return }\n"
    "  try {\n"
    "    $o = [ordered]@{}\n"
    "    if (Test-Path -LiteralPath $prog) { $j = Get-Content -LiteralPath $prog -Raw | ConvertFrom-Json; foreach ($p in $j.PSObject.Properties) { $o[$p.Name] = $p.Value } }\n"
    "    $o['stage'] = $stage; $o['label'] = $stage; $o['pct'] = [int]$pct; $o['detail'] = $detail; $o['state'] = $state\n"
    "    $o['updated'] = [DateTimeOffset]::UtcNow.ToUnixTimeMilliseconds() / 1000.0\n"
    "    $tmp = $prog + '.tmp'\n"
    "    [IO.File]::WriteAllText($tmp, ($o | ConvertTo-Json -Compress), (New-Object Text.UTF8Encoding $false))\n"
    "    Move-Item -LiteralPath $tmp -Destination $prog -Force\n"
    "  } catch {}\n"
    "}\n"
)


def last_update() -> dict:
    """Last install result. 0.0.5: tagged with the version it installed and whether that is the running version,
    so an old record never reads as 'just updated' and never blocks the update-available check."""
    d = _read_json(ROOT / "work" / "last_update.json")
    if not isinstance(d, dict) or not d:
        return {}
    d = dict(d)
    m = re.search(r"(\d+\.\d+\.\d+)", str(d.get("version") or d.get("package") or ""))
    v = m.group(1) if m else ""
    d["version"] = v
    try:
        d["is_current"] = bool(v) and v == current_version()
    except Exception:
        d["is_current"] = False
    return d


_UI_LOCK = threading.Lock()
_VER_RX = re.compile(r"\d+\.\d+\.\d+")


def _upd_ui_path() -> Path:
    return ROOT / "work" / "update_ui.json"


def upd_ui() -> dict:
    """Update-banner choices that must survive app restarts: versions whose 'updated' notice was seen, and the version put off with Later."""
    d = _read_json(_upd_ui_path())
    d = d if isinstance(d, dict) else {}
    seen = [str(x) for x in (d.get("seen") or []) if _VER_RX.fullmatch(str(x))][-20:]
    later = str(d.get("later") or "")
    return {"seen": seen, "later": later if _VER_RX.fullmatch(later) else ""}


def upd_ui_set(seen=None, later=None) -> dict:
    with _UI_LOCK:
        d = upd_ui()
        if seen is not None and _VER_RX.fullmatch(str(seen)) and str(seen) not in d["seen"]:
            d["seen"] = (d["seen"] + [str(seen)])[-20:]
        if later is not None and (later == "" or _VER_RX.fullmatch(str(later))):
            d["later"] = str(later)
        p = _upd_ui_path()
        try:
            p.parent.mkdir(parents=True, exist_ok=True)
            tmp = p.with_name(p.name + ".tmp")
            tmp.write_text(json.dumps(d), encoding="utf-8")
            os.replace(tmp, p)
        except OSError:
            pass
        return d
