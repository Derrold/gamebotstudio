﻿$Host.UI.RawUI.WindowTitle = "Game Bot"
& "$PSScriptRoot\start-game-bot.ps1"
