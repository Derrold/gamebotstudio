# Turnkey gap pack — assets, audio, Steam/Epic deep, capture

What Game Bot still needed beyond core Unity/Unreal/design. Act with tools; look up current portal UI via firefox_search when executing.

## A) Getting assets (buy / free / make)
**Make first** when unique IP (guns, brand props): Blender → FBX → project Assets/Models/... per assets-pipeline.md.

**Free CC0 / permissive (prefer for unlimited local):**
- Poly Haven (HDRIs, textures, models) — https://polyhaven.com
- Kenney.nl — UI/prototype packs
- OpenGameArt — check each license
- AmbientCG / CC0 textures

**Paid / gated (user account + license):**
- Unity Asset Store — keep invoice + license PDF in Docs/Licenses/
- Unreal Marketplace / Fab — same
- Quixel / Megascans (Fab) — watch redistribution rules
- Sketchfab — filter downloadable + license

**Rules:** download to Art\ThirdParty\<vendor>\<pack>\; write ATTRIBUTION.md (asset, author, license, URL, date); match scale (meters) and PBR convention; reject no-game-use packs.

## B) Audio
- Folders: Audio/Music, SFX, VO, Mix
- Hook Settings volumes; mute on focus loss
- Free: Freesound (per-file license), OpenGameArt; paid asset-store packs OK with ATTRIBUTION

## C) Steam deep checklist
Sources: https://partner.steamgames.com/doc/store/releasing · https://partner.steamgames.com/doc/store · https://partner.steamgames.com/doc/sdk/uploading

Store art: header 920x430, small 462x174, main 1232x706, vertical 748x896, library capsule 600x900, library hero 3840x1240 (no text), library logo transparent, 5+ screenshots 1920x1080+, trailer MP4.
Page: short+detailed desc, tags, genres, languages, sysreqs, content descriptors, age rating, legal, Coming Soon wishlists.
Build: depots, launch options, redistributables, steam_appid.txt for testing, beta then Default after Valve review.
Features: achievements (+64x64 icons), Steam Cloud, Steam Input + Deck 1280x800 gamepad pass.
Process: store checklist → review → build checklist → pricing/date → Release. Bot prepares; the creator confirms live.

## D) Epic deep
Epic Dev Portal product; BuildPatch upload; sandbox/stage/live; privacy URL; EOS only if online needed. Confirm CLI with firefox_search at run time.

## E) Trailer / capture
Unity Recorder or OBS; 1080p/4K; licensed music only; clean HUD screenshots.

## F) Saves, patches, Early Access
persistentDataPath saves; changelog Docs/Changelogs; SteamPipe patches via beta; honest EA timeline on store.

## G) Controllers and Deck
Gamepad from day one; no mouse-only critical paths; readable UI at 1280x800.

## H) Localization
String tables; English first; fonts for target scripts.

## I) Business
Steamworks/Epic tax/bank = user. Bot keeps Docs/Store/AppIds.json once IDs exist — never invent AppIDs.
