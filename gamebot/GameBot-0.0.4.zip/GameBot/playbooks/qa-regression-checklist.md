# QA regression
Boot→menu→new game→save→quit→load; pause; settings persist; crash log path;
