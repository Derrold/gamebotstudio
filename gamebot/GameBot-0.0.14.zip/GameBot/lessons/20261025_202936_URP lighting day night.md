# URP lighting day night

Tags: lighting postfx urp
Saved: 2026-10-25T20:29:36

Realtime sun for day/night; bake only static interiors with light probes; Motion blur off by default. Source: https://docs.unity3d.com/Manual/Lightmapping.html
