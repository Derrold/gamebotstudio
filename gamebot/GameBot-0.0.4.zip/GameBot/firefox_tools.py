﻿"""Local Firefox tools via Selenium - unlimited, no cloud search API."""
from __future__ import annotations

import atexit
import re
import time
from typing import Optional
from urllib.parse import parse_qs, quote_plus, unquote, urlparse

from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.firefox.options import Options
from selenium.webdriver.firefox.service import Service
from webdriver_manager.firefox import GeckoDriverManager

FF_PATH = r"C:\Program Files\Mozilla Firefox\firefox.exe"
_driver: Optional[webdriver.Firefox] = None


def _ensure():
    global _driver
    if _driver is not None:
        return _driver
    opts = Options()
    opts.binary_location = FF_PATH
    # Hidden by default — no Firefox popup windows
    opts.add_argument("-headless")
    opts.set_preference("dom.webdriver.enabled", False)
    service = Service(GeckoDriverManager().install())
    # Hide geckodriver console on Windows
    try:
        service.creation_flags = 0x08000000  # CREATE_NO_WINDOW
    except Exception:
        pass
    _driver = webdriver.Firefox(service=service, options=opts)
    _driver.set_page_load_timeout(60)
    return _driver


def _shutdown():
    global _driver
    if _driver is not None:
        try:
            _driver.quit()
        except Exception:
            pass
        _driver = None


atexit.register(_shutdown)


def _clean_ddg_url(href: str) -> str:
    if not href:
        return ""
    if "uddg=" in href:
        try:
            q = parse_qs(urlparse(href).query)
            if "uddg" in q:
                return unquote(q["uddg"][0])
        except Exception:
            pass
    return href


def firefox_search(query: str, max_results: int = 5) -> str:
    driver = _ensure()
    max_results = max(1, min(int(max_results or 5), 8))
    driver.get(f"https://html.duckduckgo.com/html/?q={quote_plus(query)}")
    time.sleep(1.2)
    results = []
    for a in driver.find_elements(By.CSS_SELECTOR, "a.result__a")[:max_results]:
        title = (a.text or "").strip()
        href = _clean_ddg_url(a.get_attribute("href") or "")
        snippet = ""
        try:
            parent = a.find_element(By.XPATH, "./ancestor::div[contains(@class,'result')][1]")
            sn = parent.find_elements(By.CSS_SELECTOR, ".result__snippet, a.result__snippet")
            if sn:
                snippet = (sn[0].text or "").strip()
        except Exception:
            pass
        results.append(f"- {title}\n  {href}\n  {snippet}")
    return f"Search: {query}\n" + ("\n".join(results) if results else "No results parsed.")


def firefox_open(url: str) -> str:
    driver = _ensure()
    if not url.startswith("http"):
        url = "https://" + url
    driver.get(url)
    time.sleep(1.2)
    title = driver.title
    try:
        text = driver.find_element(By.TAG_NAME, "body").text
    except Exception:
        text = ""
    text = " ".join((text or "").split())
    return f"Title: {title}\nURL: {driver.current_url}\n\n{text[:6000]}"


def firefox_close() -> str:
    _shutdown()
    return "Firefox closed."


def _parse_price(text: str) -> float:
    m = re.search(r"\$\s*([0-9,]+(?:\.[0-9]{1,2})?)", text or "")
    if not m:
        return 1e18
    try:
        return float(m.group(1).replace(",", ""))
    except Exception:
        return 1e18


def ebay_search(query: str, max_results: int = 10) -> str:
    """eBay Buy It Now cheapest-first. Filters junk and wrong models (e.g. 3060 vs 3060 Ti)."""
    driver = _ensure()
    max_results = max(1, min(int(max_results or 10), 15))
    q = quote_plus(query)
    url = f"https://www.ebay.com/sch/i.html?_nkw={q}&_sop=15&LH_BIN=1&_ipg=60"
    driver.get(url)
    time.sleep(2.8)
    page_title = driver.title or ""
    if any(x in page_title for x in ("Access Denied", "Pardon Our Interruption", "Error Page")):
        return f"eBay blocked/challenged. Title={page_title} URL={driver.current_url}"

    want = (query or "").lower()
    want_ti = ("3060 ti" in want) or ("3060ti" in want)
    want_plain_3060 = ("3060" in want) and (not want_ti) and ("ti" not in want.replace("3060", ""))

    junk_phrases = (
        "box only", "empty box", "heatsink", "backplate", "for part", "for parts", "not working",
        "broken", "defect", "display ports issue", "fan only", "riser only", "mounting bracket",
        "waterblock", "shop on ebay", "faster than rtx", "2070", "2080", "1660", "1650", "1050",
        "a2000", "quadro", "mxm",
    )

    rows = []
    cards = driver.find_elements(By.CSS_SELECTOR, "li.s-card, li.s-item")
    for card in cards:
        try:
            t_els = card.find_elements(By.CSS_SELECTOR, ".s-card__title, .s-item__title, h3")
            p_els = card.find_elements(By.CSS_SELECTOR, ".s-card__price, .s-item__price")
            a_els = card.find_elements(By.CSS_SELECTOR, "a.s-card__link, a.s-item__link, a[href*='/itm/']")
            if not t_els:
                continue
            title_txt = (t_els[0].text or "").strip()
            for noise in ("Opens in a new window or tab", "Opens in a new window", "Opens in a new tab"):
                title_txt = title_txt.replace(noise, "").strip()
            if not title_txt:
                continue
            low = title_txt.lower()
            if any(j in low for j in junk_phrases):
                continue
            if want_plain_3060:
                if "3060 ti" in low or "3060ti" in low:
                    continue
                if "3060" not in low:
                    continue
            elif want_ti:
                if "3060 ti" not in low and "3060ti" not in low:
                    continue
            price_txt = ""
            for pe in p_els:
                pt = (pe.text or "").strip().split("\n")[0]
                if "$" in pt:
                    price_txt = pt
                    break
            if not price_txt:
                continue
            href = ""
            for ae in a_els:
                h = ae.get_attribute("href") or ""
                if "/itm/" in h:
                    m = re.search(r"/itm/(?:[^/]+/)?(\d{8,})", h)
                    href = f"https://www.ebay.com/itm/{m.group(1)}" if m else h.split("?")[0]
                    break
            if not href:
                continue
            rows.append((_parse_price(price_txt), price_txt, title_txt, href))
        except Exception:
            continue

    rows.sort(key=lambda r: r[0])
    seen, clean = set(), []
    for row in rows:
        iid = row[3].rstrip("/").split("/")[-1]
        if iid in seen:
            continue
        seen.add(iid)
        clean.append(row)
        if len(clean) >= max_results:
            break

    if not clean:
        return f"No clean matching listings for '{query}'. Page={page_title}. Try 'RTX 3060 12GB'."

    lines = [f"eBay cheapest Buy It Now for: {query} (junk/wrong-model filtered, price-sorted)"]
    for i, (_, price, title, href) in enumerate(clean, 1):
        lines.append(f"{i}. {price} — {title}\n   {href}")
    lines.append(
        "ASSISTANT RULES: Lead with cheapest working match. Sort already done. "
        "Paste each full https URL. Never invent prices. Exclude for-parts/wrong GPUs."
    )
    return "\n".join(lines)
