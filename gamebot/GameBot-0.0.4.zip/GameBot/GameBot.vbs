' Game Bot launcher (no console). Live model = gamebot-trained.
Set sh = CreateObject("WScript.Shell")
Set fso = CreateObject("Scripting.FileSystemObject")
d = fso.GetParentFolderName(WScript.ScriptFullName)
sh.CurrentDirectory = d
sh.Environment("PROCESS")("OLLAMA_MODEL") = "gamebot-trained"
On Error Resume Next
sh.Run "pyw -3 """ & d & "\desktop_window.py""", 0, False
If Err.Number <> 0 Then
  Err.Clear
  sh.Run "pythonw """ & d & "\desktop_window.py""", 0, False
End If
If Err.Number <> 0 Then MsgBox "Game Bot needs Python 3.11+ (python.org) on PATH. See PREREQUISITES.txt.", 16, "Game Bot"