# Auto studio pipeline run (MARZ)

Tags: auto studio pipeline
Saved: 2026-11-13T18:59:20

run_auto_game_pipeline created 34 files under C:\Users\ExtremeHybrid\Documents\GameProjects\MARZ and UNITY 6000.6.5f1: background job started -> create MARZUnity -> Open World game (gameplay template: adventure; menu, settings, achievements, owned genre kit) ->. Next: check Builds\auto_unity_status.txt, then work TaskBoard 'Auto next actions' with tools.
