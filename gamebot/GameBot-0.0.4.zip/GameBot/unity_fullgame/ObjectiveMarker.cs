using UnityEngine;
/// <summary>Adventure objective beacon: points at the key until found, then at the shrine.</summary>
public class ObjectiveMarker : MonoBehaviour
{
    public static Transform Target; public Transform key, shrine;
    void Update() { Target = GenreState.HasKey || key == null ? shrine : key; if (Target) transform.position = Target.position + Vector3.up * (4f + Mathf.Sin(Time.time * 3f) * 0.4f); }
}
