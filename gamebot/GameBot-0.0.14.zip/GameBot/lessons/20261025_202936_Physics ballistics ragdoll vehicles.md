# Physics ballistics ragdoll vehicles

Tags: physics ragdoll vehicle
Saved: 2026-10-25T20:29:36

Bullets = stepped raycasts (Ballistics.cs), arrows Continuous rigidbody; DeathPose over ragdoll for deer; WheelCollider for vehicles; no shooting from vehicle. Source: https://docs.unity3d.com/Manual/class-WheelCollider.html
