"""Game Bot generic prop generator (Blender headless). Env: PROP_NAME, PROP_OUT, PROP_HINT.
Builds a clean low-poly blockout based on keywords (crate, barrel, rock, tree, table, chair, lamp, pillar, fence,
house, car/vehicle, sword) with named parts + simple materials, then exports FBX (Unity axes) and .blend."""
import bpy, os, math, random

NAME = os.environ.get("PROP_NAME", "Prop")
OUT = os.environ.get("PROP_OUT", os.path.join(os.path.expanduser("~"), "Documents", "GameProjects", "AssetLab", "Art", "Blender", "Exports"))
HINT = os.environ.get("PROP_HINT", NAME).lower() + " " + NAME.lower()
os.makedirs(OUT, exist_ok=True)
random.seed(len(NAME))

bpy.ops.object.select_all(action="SELECT")
bpy.ops.object.delete(use_global=False)
parts = []

def mat(name, rgb):
    m = bpy.data.materials.get(name) or bpy.data.materials.new(name)
    m.use_nodes = True
    bsdf = m.node_tree.nodes.get("Principled BSDF")
    if bsdf:
        bsdf.inputs["Base Color"].default_value = (*rgb, 1)
        bsdf.inputs["Roughness"].default_value = 0.7
    return m

def add(kind, n, loc, sc, rot=(0, 0, 0), m=None, **kw):
    getattr(bpy.ops.mesh, f"primitive_{kind}_add")(location=loc, rotation=rot, **kw)
    o = bpy.context.active_object
    o.name = f"{NAME}_{n}"
    o.scale = sc
    if m:
        o.data.materials.append(m)
    parts.append(o)
    return o

wood, metal, stone, leaf, paint, glow = (mat("Wood", (0.45, 0.28, 0.14)), mat("Metal", (0.5, 0.5, 0.55)),
    mat("Stone", (0.4, 0.4, 0.38)), mat("Leaf", (0.15, 0.4, 0.12)), mat("Paint", (0.7, 0.15, 0.1)), mat("Glow", (1.0, 0.85, 0.5)))

def has(*w):
    return any(x in HINT for x in w)

if has("crate", "box"):
    add("cube", "Body", (0, 0, 0.5), (0.5, 0.5, 0.5), m=wood)
    for z in (0.05, 0.95):
        add("cube", f"Band{z}", (0, 0, z), (0.52, 0.52, 0.04), m=metal)
elif has("barrel"):
    add("cylinder", "Body", (0, 0, 0.6), (0.4, 0.4, 0.6), m=wood, vertices=16)
    for z in (0.2, 1.0):
        add("cylinder", f"Hoop{z}", (0, 0, z), (0.42, 0.42, 0.04), m=metal, vertices=16)
elif has("rock", "boulder", "stone"):
    o = add("ico_sphere", "Rock", (0, 0, 0.5), (0.8, 0.6, 0.5), m=stone, subdivisions=2)
    for v in o.data.vertices:
        v.co *= 0.85 + random.random() * 0.3
elif has("tree", "pine"):
    add("cylinder", "Trunk", (0, 0, 1.0), (0.15, 0.15, 1.0), m=wood, vertices=8)
    for i, z in enumerate((2.0, 2.7, 3.3)):
        add("cone", f"Leaves{i}", (0, 0, z), (1.1 - i * 0.3, 1.1 - i * 0.3, 0.7), m=leaf, vertices=10)
elif has("table", "desk"):
    add("cube", "Top", (0, 0, 0.75), (0.8, 0.5, 0.03), m=wood)
    for x in (-0.72, 0.72):
        for y in (-0.42, 0.42):
            add("cube", f"Leg{x}{y}", (x, y, 0.37), (0.04, 0.04, 0.37), m=wood)
elif has("chair", "stool"):
    add("cube", "Seat", (0, 0, 0.45), (0.25, 0.25, 0.03), m=wood)
    add("cube", "Back", (0, -0.23, 0.75), (0.25, 0.03, 0.3), m=wood)
    for x in (-0.22, 0.22):
        for y in (-0.22, 0.22):
            add("cube", f"Leg{x}{y}", (x, y, 0.22), (0.03, 0.03, 0.22), m=wood)
elif has("lamp", "light", "lantern"):
    add("cylinder", "Base", (0, 0, 0.05), (0.25, 0.25, 0.05), m=metal, vertices=16)
    add("cylinder", "Pole", (0, 0, 0.9), (0.04, 0.04, 0.85), m=metal, vertices=8)
    add("uv_sphere", "Bulb", (0, 0, 1.8), (0.2, 0.2, 0.2), m=glow, segments=12, ring_count=8)
elif has("fence"):
    for i in range(4):
        add("cube", f"Post{i}", (i * 1.0 - 1.5, 0, 0.5), (0.06, 0.06, 0.5), m=wood)
    for z in (0.35, 0.75):
        add("cube", f"Rail{z}", (0, 0, z), (1.6, 0.03, 0.05), m=wood)
elif has("house", "hut", "cabin", "building"):
    add("cube", "Walls", (0, 0, 1.25), (2.0, 1.5, 1.25), m=wood)
    roof = add("cylinder", "Roof", (0, 0, 2.9), (1.0, 1.0, 1.0), rot=(math.pi / 2, 0, 0), m=paint, vertices=3)
    roof.scale = (1.3, 1.4, 1.6)
    add("cube", "Door", (0, -1.51, 0.9), (0.4, 0.02, 0.9), m=metal)
    for x in (-1.2, 1.2):
        add("cube", f"Window{x}", (x, -1.51, 1.5), (0.35, 0.02, 0.35), m=glow)
    add("cube", "Chimney", (1.2, 0.5, 3.4), (0.2, 0.2, 0.6), m=stone)
elif has("car", "vehicle", "truck", "kart"):
    add("cube", "Body", (0, 0, 0.6), (1.0, 2.0, 0.35), m=paint)
    add("cube", "Cabin", (0, -0.2, 1.1), (0.8, 1.0, 0.3), m=metal)
    for x in (-1.0, 1.0):
        for y in (-1.3, 1.3):
            add("cylinder", f"Wheel{x}{y}", (x, y, 0.35), (0.35, 0.35, 0.15), rot=(0, math.pi / 2, 0), m=metal, vertices=16)
elif has("sword", "blade"):
    add("cube", "Blade", (0, 0, 0.75), (0.04, 0.01, 0.55), m=metal)
    add("cube", "Guard", (0, 0, 0.2), (0.15, 0.03, 0.02), m=metal)
    add("cylinder", "Grip", (0, 0, 0.08), (0.02, 0.02, 0.1), m=wood, vertices=8)
elif has("castle", "fortress", "keep"):  # GB_EXTRA_SHAPES
    add("cube", "Keep", (0, 0, 4), (4, 4, 4), m=stone)
    for i, (x, y) in enumerate(((-6, -6), (6, -6), (-6, 6), (6, 6))):
        add("cylinder", f"Tower{i}", (x, y, 5), (1.6, 1.6, 5), m=stone, vertices=12)
        add("cone", f"TowerRoof{i}", (x, y, 11), (2.0, 2.0, 1.5), m=paint, vertices=12)
    for i, (x, y, sx, sy) in enumerate(((0, -6, 6, 0.5), (0, 6, 6, 0.5), (-6, 0, 0.5, 6), (6, 0, 0.5, 6))):
        add("cube", f"Wall{i}", (x, y, 2), (sx, sy, 2), m=stone)
        for k in range(-4, 5, 2):
            add("cube", f"Merlon{i}_{k}", (x + (k if sx > 1 else 0), y + (k if sy > 1 else 0), 4.4), (0.4, 0.4, 0.4), m=stone)
    add("cube", "Gate", (0, -6.55, 1.3), (1.4, 0.1, 1.3), m=wood)
elif has("tower"):
    add("cylinder", "Tower", (0, 0, 6), (2.2, 2.2, 6), m=stone, vertices=14)
    add("cone", "Roof", (0, 0, 13.5), (2.8, 2.8, 1.5), m=paint, vertices=14)
    add("cube", "Door", (0, -2.2, 1), (0.6, 0.1, 1), m=wood)
elif has("boat", "ship"):
    add("cube", "Hull", (0, 0, 0.6), (1.2, 3.5, 0.6), m=wood)
    add("cone", "Bow", (0, 4.2, 0.6), (1.2, 0.8, 0.6), rot=(math.pi / 2, 0, 0), m=wood, vertices=4)
    add("cylinder", "Mast", (0, 0, 3.5), (0.08, 0.08, 2.8), m=wood, vertices=8)
    add("cube", "Sail", (0, 0.1, 3.8), (1.0, 0.02, 1.6), m=paint)
elif has("dragon", "creature", "beast", "monster"):
    add("uv_sphere", "Body", (0, 0, 1.6), (1.0, 2.0, 0.9), m=paint, segments=16, ring_count=10)
    add("uv_sphere", "Head", (0, 2.6, 2.4), (0.5, 0.8, 0.5), m=paint, segments=12, ring_count=8)
    add("cone", "Tail", (0, -3.2, 1.3), (0.5, 0.5, 1.6), rot=(math.pi / 2, 0, 0), m=paint, vertices=10)
    for sx in (-1, 1):
        add("cube", f"Wing{sx}", (sx * 2.4, 0.2, 2.3), (1.6, 1.0, 0.05), rot=(0, sx * 0.35, 0), m=leaf)
        for y in (-1.0, 1.0):
            add("cylinder", f"Leg{sx}{y}", (sx * 0.7, y, 0.5), (0.22, 0.22, 0.5), m=paint, vertices=8)
elif has("robot", "mech", "droid"):
    add("cube", "Torso", (0, 0, 1.25), (0.35, 0.22, 0.4), m=metal)
    add("cube", "Head", (0, 0, 1.85), (0.18, 0.18, 0.15), m=metal)
    add("uv_sphere", "Eye", (0, -0.18, 1.88), (0.06, 0.03, 0.04), m=glow, segments=8, ring_count=6)
    for sx in (-1, 1):
        add("cube", f"Arm{sx}", (sx * 0.48, 0, 1.25), (0.09, 0.09, 0.38), m=metal)
        add("cube", f"Leg{sx}", (sx * 0.16, 0, 0.42), (0.1, 0.1, 0.42), m=metal)
elif has("tank"):
    add("cube", "Hull", (0, 0, 0.7), (1.6, 3.0, 0.5), m=metal)
    add("cube", "Turret", (0, -0.2, 1.5), (1.0, 1.2, 0.35), m=metal)
    add("cylinder", "Gun", (0, 2.2, 1.55), (0.12, 0.12, 1.8), rot=(math.pi / 2, 0, 0), m=metal, vertices=10)
    for sx in (-1.7, 1.7):
        add("cube", f"Track{sx}", (sx, 0, 0.45), (0.35, 3.1, 0.45), m=stone)
elif has("helicopter", "heli", "chopper"):  # fix5
    olive = mat("Olive", (0.24, 0.29, 0.16)); glass = mat("Glass", (0.12, 0.18, 0.22))
    add("uv_sphere", "Cabin", (0, 0.6, 1.4), (1.1, 1.9, 1.0), m=olive, segments=20, ring_count=12)
    add("uv_sphere", "Canopy", (0, 2.0, 1.55), (0.85, 0.7, 0.65), m=glass, segments=16, ring_count=10)
    add("cylinder", "TailBoom", (0, -3.3, 1.7), (0.22, 0.22, 2.6), rot=(math.pi / 2, 0, 0), m=olive, vertices=12)
    add("cube", "TailFin", (0, -5.8, 2.3), (0.06, 0.45, 0.7), m=olive)
    add("cube", "TailRotor", (0.2, -5.9, 2.4), (0.03, 0.08, 0.9), m=metal)
    add("cylinder", "Mast", (0, 0.6, 2.55), (0.12, 0.12, 0.25), m=metal, vertices=10)
    for a in (0.0, math.pi / 2):
        add("cube", f"Blade{a:.1f}", (0, 0.6, 2.82), (5.2, 0.16, 0.03), rot=(0, 0, a + 0.4), m=metal)
    for sx in (-1, 1):
        add("cube", f"Skid{sx}", (sx * 0.95, 0.5, 0.1), (0.07, 2.2, 0.07), m=metal)
        for y in (-0.5, 1.5):
            add("cube", f"Strut{sx}{y}", (sx * 0.8, y, 0.45), (0.05, 0.05, 0.38), rot=(0, sx * 0.35, 0), m=metal)
elif has("plane", "jet", "aircraft"):  # fix5
    add("cylinder", "Fuselage", (0, 0, 1.5), (0.6, 0.6, 4.0), rot=(math.pi / 2, 0, 0), m=metal, vertices=16)
    add("cone", "Nose", (0, 4.6, 1.5), (0.6, 0.6, 0.8), rot=(-math.pi / 2, 0, 0), m=metal, vertices=16)
    add("cube", "Wings", (0, 0.4, 1.4), (5.0, 0.9, 0.08), m=metal)
    add("cube", "Tail", (0, -3.6, 2.4), (0.06, 0.6, 0.9), m=metal)
    add("cube", "Stab", (0, -3.7, 1.6), (1.6, 0.4, 0.05), m=metal)
elif has("bridge"):  # fix5
    add("cube", "Deck", (0, 0, 2.0), (2.0, 8.0, 0.2), m=wood)
    for sx in (-1, 1):
        add("cube", f"Rail{sx}", (sx * 1.9, 0, 2.7), (0.08, 8.0, 0.06), m=wood)
        for y in (-7, -3.5, 0, 3.5, 7):
            add("cube", f"Pier{sx}{y}", (sx * 1.6, y, 1.0), (0.2, 0.2, 1.0), m=stone)
else:
    add("cylinder", "Base", (0, 0, 0.1), (0.5, 0.5, 0.1), m=stone, vertices=12)
    add("cube", "Body", (0, 0, 0.7), (0.3, 0.3, 0.5), m=paint)
    add("uv_sphere", "Top", (0, 0, 1.35), (0.25, 0.25, 0.25), m=metal, segments=12, ring_count=8)

for o in parts:
    o.select_set(True)
bpy.context.view_layer.objects.active = parts[0]
bpy.ops.object.transform_apply(location=False, rotation=True, scale=True)
bpy.ops.object.shade_flat()

fbx = os.path.join(OUT, NAME + ".fbx")
bpy.ops.export_scene.fbx(filepath=fbx, use_selection=False, apply_unit_scale=True, apply_scale_options="FBX_SCALE_UNITS",
                         axis_forward="-Z", axis_up="Y", bake_space_transform=False, object_types={"MESH"})
bpy.ops.wm.save_as_mainfile(filepath=os.path.join(OUT, NAME + ".blend"))
print("PROP_EXPORTED", fbx, os.path.exists(fbx), "parts", len(parts))
