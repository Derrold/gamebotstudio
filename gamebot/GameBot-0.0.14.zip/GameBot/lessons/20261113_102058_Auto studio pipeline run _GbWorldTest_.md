# Auto studio pipeline run (GbWorldTest)

Tags: auto studio pipeline
Saved: 2026-11-13T10:20:58

run_auto_game_pipeline created 34 files under C:\Users\ExtremeHybrid\Documents\GameProjects\GbWorldTest and UNITY 6000.6.5f1: background job started -> create GbWorldTestUnity -> Shooter / FPS game (gameplay template: fps; menu, settings, achievements, owned genre kit. Next: check Builds\auto_unity_status.txt, then work TaskBoard 'Auto next actions' with tools.
