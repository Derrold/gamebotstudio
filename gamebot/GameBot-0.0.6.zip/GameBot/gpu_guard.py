"""GPU guard - REVERTED in 0.0.6 (Derrold, Nov 14 2026: "nvidia only, put it back so it doesn't unload the model").
Game Bot Early Access is NVIDIA-only, so the AI model is no longer unloaded before Unity builds/imports and chat is
never paused or queued during builds. Same API as 0.0.4 so callers keep working; every call is a no-op."""
from __future__ import annotations

PAUSE_MSG = ""


def _post(path: str, body: dict, timeout: float = 15) -> bytes:  # kept for API compatibility, never called
    return b"{}"


def loaded_models() -> list[str]:
    return []


def unload_model() -> list[str]:
    return []


def before_unity(wait: bool = True) -> list[str]:
    return []


def building() -> str:
    return ""


def paused() -> str:
    return ""


def status_line() -> str:
    return ""


def paused_reply(n_queued: int = 0) -> str:
    return ""


def wait_until_clear(poll_s: float = 5.0, max_s: float = 0) -> bool:
    return True
