# Asset intake workflow (turnkey)

When user asks to get assets / download a pack / find free gun/tree/UI:
1. search_playbooks assets + firefox_search CC0 first.
3. Downloads → Art\ThirdParty + ATTRIBUTION.md + correct import scale/materials.
4. teach_self source + license one-liner.
5. Never invent store ownership or paste secrets.
