# VFX muzzle smoke blood stylized

Tags: vfx particles shader urp
Saved: 2026-10-25T20:29:36

Use Shuriken particles (pooled) for muzzle flash/smoke/impacts; Shader Graph for wind/fade; stylized blood with Reduced blood toggle for ratings. Playbook vfx-particles-shaders. Source: https://docs.unity3d.com/Manual/ParticleSystems.html
