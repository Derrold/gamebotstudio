# Analytics & telemetry - opt-in, privacy first
Sources: https://docs.unity.com/ugs/en-us/manual/analytics/manual/overview | https://partner.steamgames.com/doc/store/application/privacy | https://gdpr.eu/ | https://oag.ca.gov/privacy/ccpa

## Default for local-first games: NONE
- Use local logs + Steam's built-in stats (wishlists, sales, playtime) instead.

## If added
- Opt-in dialog at first launch; Settings toggle; privacy policy updated (legal-notices-and-menus.md); no personal data, no hardware IDs beyond aggregate; allow data deletion request.
- Unity Analytics (UGS): requires consent flow (AnalyticsService.Instance.StartDataCollection() only after consent); custom events (session_start, hunt_end, fps_bucket).
- Self-hosted alternative: post anonymous JSON to own endpoint; or write local CSV the user can send.
- Crash reporting: Unity Cloud Diagnostics or Backtrace/Sentry - also disclose.

## Useful events
- Funnel: tutorial steps completed, first hunt, first harvest, quits. Performance buckets: preset + avg fps (helps default preset choice). Keep event count small.
