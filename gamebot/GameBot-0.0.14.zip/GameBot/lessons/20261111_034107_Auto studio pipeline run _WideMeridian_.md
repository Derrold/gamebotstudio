# Auto studio pipeline run (WideMeridian)

Tags: auto studio pipeline
Saved: 2026-11-11T03:41:07

run_auto_game_pipeline created 33 files under C:\Users\ExtremeHybrid\Documents\GameProjects\WideMeridian and UNREAL: created C:\Users\ExtremeHybrid\Documents\GameProjects\WideMeridian\WideMeridian.uproject from TP_FirstPersonBP; launched UnrealEditor.exe. Next: check Builds\auto_unity_status.txt, then work TaskBoard 'Auto next actions' with tools.
