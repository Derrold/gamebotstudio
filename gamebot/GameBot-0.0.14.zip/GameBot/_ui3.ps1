param([string]$Text, [int]$X = 450, [int]$Y = 571)
# Types into the Game Bot pywebview window by posting messages to its WebView2 render HWND (no focus, no SendKeys).
Add-Type @'
using System; using System.Text; using System.Runtime.InteropServices; using System.Collections.Generic;
public class PW {
  public delegate bool EnumProc(IntPtr h, IntPtr l);
  [DllImport("user32.dll")] public static extern bool EnumChildWindows(IntPtr p, EnumProc f, IntPtr l);
  [DllImport("user32.dll")] public static extern int GetClassName(IntPtr h, StringBuilder s, int n);
  [DllImport("user32.dll")] public static extern bool PostMessage(IntPtr h, uint m, IntPtr w, IntPtr l);
  [DllImport("user32.dll")] public static extern bool SetForegroundWindow(IntPtr h);
  [DllImport("user32.dll")] public static extern IntPtr GetForegroundWindow();
  [DllImport("user32.dll")] public static extern bool ShowWindow(IntPtr h, int c);
  [DllImport("user32.dll")] public static extern bool GetWindowRect(IntPtr h, out R r);
  [DllImport("user32.dll")] public static extern bool ScreenToClient(IntPtr h, ref P p);
  public struct R { public int L, T, Ri, B; } public struct P { public int X, Y; }
  public static List<IntPtr> Render(IntPtr top) { var l = new List<IntPtr>(); EnumChildWindows(top, (h, x) => { var sb = new StringBuilder(256); GetClassName(h, sb, 256); if (sb.ToString() == "Chrome_RenderWidgetHostHWND") l.Add(h); return true; }, IntPtr.Zero); return l; }
}
'@
$p = Get-Process pythonw -ErrorAction SilentlyContinue | ? { $_.MainWindowTitle -eq 'Game Bot' } | Select -First 1
if (-not $p) { throw "Game Bot window not found" }
$top = $p.MainWindowHandle
$rw = [PW]::Render($top); "render hwnds: $($rw.Count)"
if ($rw.Count -lt 1) { throw "no WebView2 render hwnd" }
$h = $rw[0]
[PW]::ShowWindow($top, 9) | Out-Null; [PW]::SetForegroundWindow($top) | Out-Null; Start-Sleep -Milliseconds 400
$fg = [PW]::GetForegroundWindow(); "foreground is Game Bot: $($fg -eq $top)"
$r = New-Object PW+R; [PW]::GetWindowRect($top, [ref]$r) | Out-Null
$pt = New-Object PW+P; $pt.X = $r.L + $X; $pt.Y = $r.T + $Y; [PW]::ScreenToClient($h, [ref]$pt) | Out-Null
$lp = [IntPtr](($pt.Y -shl 16) -bor ($pt.X -band 0xFFFF))
[PW]::PostMessage($h, 0x0201, [IntPtr]1, $lp) | Out-Null; Start-Sleep -Milliseconds 60; [PW]::PostMessage($h, 0x0202, [IntPtr]0, $lp) | Out-Null
Start-Sleep -Milliseconds 300
foreach ($c in $Text.ToCharArray()) { [PW]::PostMessage($h, 0x0102, [IntPtr][int]$c, [IntPtr]1) | Out-Null; Start-Sleep -Milliseconds 8 }
Start-Sleep -Milliseconds 300
[PW]::PostMessage($h, 0x0100, [IntPtr]0x0D, [IntPtr]0x001C0001) | Out-Null
[PW]::PostMessage($h, 0x0102, [IntPtr]0x0D, [IntPtr]0x001C0001) | Out-Null
[PW]::PostMessage($h, 0x0101, [IntPtr]0x0D, [IntPtr]0xC01C0001) | Out-Null
"posted '$Text' to Game Bot hwnd $top (render $h) at client $($pt.X),$($pt.Y)"
