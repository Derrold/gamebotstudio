# Auto studio pipeline run (ZzThrowawayRange)

Tags: auto studio pipeline
Saved: 2026-11-13T12:01:35

run_auto_game_pipeline created 34 files under C:\Users\ExtremeHybrid\Documents\GameProjects\ZzThrowawayRange and UNITY 6000.6.5f1: background job started -> create ZzThrowawayRangeUnity -> Shooter / FPS game (gameplay template: fps; menu, settings, achievements, owned genr. Next: check Builds\auto_unity_status.txt, then work TaskBoard 'Auto next actions' with tools.
