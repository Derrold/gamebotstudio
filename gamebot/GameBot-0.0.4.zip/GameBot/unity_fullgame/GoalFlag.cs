﻿using UnityEngine;

public class GoalFlag : MonoBehaviour
{
    void OnTriggerEnter(Collider other)
    {
        if (!other.CompareTag("Player")) return;
        if (GameState.Won) return;
        GameState.Won = true;
        AchievementSystem.NotifyGoal();
        GameState.ClearContinue();
        Cursor.lockState = CursorLockMode.None;
        Cursor.visible = true;
    }
}
