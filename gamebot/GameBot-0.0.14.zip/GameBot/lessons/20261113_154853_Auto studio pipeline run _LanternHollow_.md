# Auto studio pipeline run (LanternHollow)

Tags: auto studio pipeline
Saved: 2026-11-13T15:48:53

run_auto_game_pipeline created 34 files under C:\Users\ExtremeHybrid\Documents\GameProjects\LanternHollow and UNITY 6000.6.5f1: background job started -> create LanternHollowUnity -> Battle Royale game (gameplay template: battle_royale; menu, settings, achievements, own. Next: check Builds\auto_unity_status.txt, then work TaskBoard 'Auto next actions' with tools.
