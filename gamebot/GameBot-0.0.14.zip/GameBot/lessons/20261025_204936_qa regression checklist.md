# qa regression checklist

Tags: qa-regression-checklist
Saved: 2026-10-25T20:49:36

﻿# QA regression
Boot→menu→new game→save→quit→load; pause; settings persist; crash log path;
