﻿using UnityEngine;

[RequireComponent(typeof(CharacterController))]
public class GamePlayer : MonoBehaviour
{
    public float speed = 7f, gravity = -22f, jump = 7.5f;
    float vy, pitch;
    CharacterController cc;
    Transform cam;
    Vector3 spawn;

    void Start()
    {
        cc = GetComponent<CharacterController>();
        var c = GetComponentInChildren<Camera>();
        if (c != null) cam = c.transform;
        spawn = transform.position;
        lookSensApply();
        Cursor.lockState = CursorLockMode.Locked;
        Cursor.visible = false;
    }
    void lookSensApply() { /* look uses GameSettings.LookSens */ }

    void Update()
    {
        if (GameState.Won || GameState.Lost) return;
        if (PauseMenu.IsPaused || MainMenuUI.InMenu) return;
        float h = 0f, v = 0f;
        if (Input.GetKey(GameSettings.KeyLeft)) h -= 1f;
        if (Input.GetKey(GameSettings.KeyRight)) h += 1f;
        if (Input.GetKey(GameSettings.KeyBack)) v -= 1f;
        if (Input.GetKey(GameSettings.KeyForward)) v += 1f;
        float sens = GameSettings.LookSens;
        transform.Rotate(0f, Input.GetAxis("Mouse X") * sens, 0f);
        pitch = Mathf.Clamp(pitch - Input.GetAxis("Mouse Y") * sens, -80f, 80f);
        if (cam != null) cam.localEulerAngles = new Vector3(pitch, 0f, 0f);
        bool jumpPressed = Input.GetKeyDown(GameSettings.KeyJump);
        if (cc.isGrounded) vy = jumpPressed ? jump : -1f; else vy += gravity * Time.deltaTime;
        Vector3 move = (transform.right * h + transform.forward * v).normalized * speed;
        move.y = vy;
        cc.Move(move * Time.deltaTime);
        if (transform.position.y < -20f) Respawn();
    }

    public void Respawn()
    {
        GameState.Die();
        if (GameState.Lost) return;
        cc.enabled = false;
        transform.position = spawn;
        cc.enabled = true;
        vy = 0f;
    }
}
