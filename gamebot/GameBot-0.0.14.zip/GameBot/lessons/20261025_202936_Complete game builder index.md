# Complete game builder index

Tags: index pipeline studio
Saved: 2026-10-25T20:29:36

Start any 'build/ship a game' request by read_playbook complete-game-builder-index: pipeline concept -> vertical slice -> production -> polish/perf/QA -> ship -> live. Human-only: Steam/Epic fees, tax/bank, real AppIDs, ratings submit, Release click, public posts.
