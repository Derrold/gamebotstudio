# B-fix scorecard (EH, 2026-11-11, lean mode)

## Live-teach build (one random weak genre via the real Game Bot chat, port 7870, gamebot-trained)
- Genre: **fighting** (random pick from action/strategy/fighting/moba/sandbox/stealth/battle_royale/mmorpg/sports)
- Build: DONE OK. createProject 12:13:55, build 12:15:30 to 12:19:17 CT (about 5.5 min end to end), 0 error CS lines, installer zip and desktop icon made
- Routing: genre=fighting, family=fighting (exact match), GAMEBOT_GENRE_MODE fighting
- Genre gameplay: yes. 2.5D 1v1 with J light / K heavy / L block, AI rival, HP bars, 60 s rounds, best of 3. The QA dump shows p1=72 after a few seconds, so the AI is hitting.
- Owned packs (genre kit auto-imported): Stylized Player Character Free (fighters and crowd), Free Street Props (5 prefabs), Polygon City Pack (252 prefabs)
- GENRE_DRESS placed=34. Prefabs: Polygon City Barrel/Box/Metall box/Bench/Light/Tree_5..35/Big stone_4/Little Stone_1,4,6; Street Props firehydrant_01_a_02, bollard_d_05; StylizedWoodMonsters Player.prefab
- inspect_scene: 44 renderers = 38 pack + 6 primitive (ring floor, ground plane, 4 corner posts); WARN none; no FOLLOWS_PLAYER / FOLLOWS_CAMERA
- Screenshot: _bfix_fight_shot.jpg (two real character models in the ring, HP bars, round timer, owned props and crowd)
- Verdict: **PASS** (not primitives-only, no following wall, genre-specific)
- Weak: one Polygon City "Big stone" is placed at a huge scale behind the ring; the ring and posts are still primitive cubes; crowd models stand in T-pose; the giant tree trunk is a bit odd.

## Following wall
- Repro (old template + Free House 01 in Art/CC0, platformer, project WallRepro) → inspect_scene:
  `WARN FOLLOWS_PLAYER: 'Player/ImportedVisual' mesh=Building (CC0) size=[7.28,7.67,7.78] is parented under the player so it moves with them`
- Cause: SceneBuilder.TryAttachImportedVisual attached the FIRST t:Model under Assets as the player's visual.
- Fix: the method is removed. The platformer now uses AttachCharacter (owned character packs only, env words excluded) plus a third-person camera. No other template called it. The new families all use AttachCharacter/Dressed.

## Unreal (parked per lean mode; probes only)
- TP_ThirdPersonBP + Variant_Platforming (no extra plugins): RunUAT BuildCookRun Win64 Shipping DONE OK in 3 min 13 s, 627 MB
- TP_VehicleAdvBP + Variant_Timetrial (ChaosVehicles + GameInputWindows): the first run failed at cook (missing project Editor.target). After adding `-unrealexe=<UE>\Engine\Binaries\Win64\UnrealEditor-Cmd.exe` it was DONE OK. The game target compiled with the UE AutoSDK toolchain in UESDK.
- Pipeline code is deployed: start_unreal_pipeline maps genre → template + variant, writes a .uproject description, background ps1, exe, zip, shortcut and DONE. No full chat-driven Unreal genre build has been done yet.
