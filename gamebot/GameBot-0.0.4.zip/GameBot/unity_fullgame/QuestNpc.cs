using UnityEngine;
/// <summary>RPG quest giver: first visit gives quest, returning with all relics completes it.</summary>
public class QuestNpc : MonoBehaviour
{
    void Update() { transform.Rotate(0, 20f * Time.deltaTime, 0); }
    void OnTriggerEnter(Collider o)
    {
        if (!o.CompareTag("Player")) return;
        if (!GenreState.QuestTaken) { GenreState.QuestTaken = true; GenreState.AddXp(40); GameHUD.Flash("Elder: Bring me the " + GenreState.ItemsTotal + " ember relics, hero."); return; }
        if (GenreState.Items >= GenreState.ItemsTotal) { GenreState.AddXp(200); AchievementSystem.Unlock("quest_done"); GenreState.Win(); }
        else GameHUD.Flash("Elder: " + (GenreState.ItemsTotal - GenreState.Items) + " relics remain.");
    }
}
