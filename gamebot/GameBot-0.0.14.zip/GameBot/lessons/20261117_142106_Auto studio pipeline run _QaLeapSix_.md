# Auto studio pipeline run (QaLeapSix)

Tags: auto studio pipeline
Saved: 2026-11-17T14:21:06

run_auto_game_pipeline created 34 files under C:\Users\Derrold PC\Documents\GameProjects\QaLeapSix and UNREAL 5.8: background job started -> QaLeapSix.uproject (QaLeapSix - Platformer game (Platforming gameplay)) from TP_ThirdPersonBP + Platforming variant -> Run. Next: check Builds\auto_unity_status.txt, then work TaskBoard 'Auto next actions' with tools.
