# Terrain & open-world building
Sources: https://docs.unity3d.com/Manual/terrain-UsingTerrains.html | https://docs.unity3d.com/Manual/terrain-Layers.html | https://docs.unity3d.com/Manual/LevelOfDetail.html | https://docs.unity3d.com/Manual/OcclusionCulling.html | https://docs.unity3d.com/Manual/terrain-Grass.html

## Unity terrain
- Heightmap from real DEM (USGS 3DEP for US land, check license) or sculpt; resolution 513-2049 per tile; multiple tiles via Terrain Tools neighbors.
- Terrain Layers = splatmap textures (grass, dirt, mud, rock, snow); keep <=4 per tile for one pass (each 4 = extra pass).
- Trees: tree prototypes with LODGroup + billboard;
- Detail/grass: instanced detail meshes; density + distance are top perf knobs (Gfx presets dd/dens).

## Open-world budgeting
- Streaming: additive scenes per region or Addressables; load/unload by player distance; avoid loading hitches (async, spread across frames).
- Occlusion culling: helps cabins/towns, not open forest; bake per scene.
- Static batching for props; GPU instancing for repeated rocks/stumps.

## Worldbuilding craft
- Landmarks for navigation, readable deer sign (rubs, scrapes, trails, bedding), funnels/pinch points, water, food plots, elevation changes; regions with distinct ground tint.
- Blockout first (greybox) -> playtest -> art pass.

## Verify
- FPS pass at dense forest (fps-performance-passes.md); no seams between tiles; NavMesh bakes.
