"""Game Bot VRAM editions Ã¢â‚¬â€ selected automatically via gpu_auto (hidden from UI)."""
from __future__ import annotations

import json
import os
from pathlib import Path

ROOT = Path(__file__).resolve().parent
EDITIONS_DIR = ROOT / "config" / "editions"
DEFAULT_ID = "12gb"


def list_editions() -> list[dict]:
    out = []
    if not EDITIONS_DIR.exists():
        return out
    for p in sorted(EDITIONS_DIR.glob("*.json")):
        if p.stem in ("4gb", "6gb"):
            continue
        try:
            out.append(json.loads(p.read_text(encoding="utf-8-sig")))
        except Exception:
            pass
    return out


FALLBACK_MODELS = ["gamebot-trained", "gamebot-r37-5080"]


def installed_models() -> list[str]:
    """Names from the local Ollama server (empty list if it can't be reached)."""
    try:
        import urllib.request
        host = os.environ.get("OLLAMA_HOST", "http://127.0.0.1:11434").rstrip("/")
        with urllib.request.urlopen(host + "/api/tags", timeout=5) as r:
            tags = json.loads(r.read().decode("utf-8"))
        return [m.get("name", "") for m in tags.get("models", [])]
    except Exception:
        return []


def resolve_model(wanted: str) -> str:
    """Return `wanted` if Ollama has it, else the best installed fallback (never a 404 model)."""
    have = installed_models()
    if not have:
        return wanted  # Ollama not reachable yet - keep the edition model
    norm = {h.split(":")[0] if h.endswith(":latest") else h: h for h in have}
    base = lambda n: n[:-7] if n.endswith(":latest") else n
    if base(wanted) not in FALLBACK_MODELS:
        wanted = "gamebot-trained"
    if base(wanted) in norm or wanted in have:
        return wanted
    for m in FALLBACK_MODELS:
        if base(m) in norm or m in have:
            os.environ["GAMEBOT_MODEL_FALLBACK"] = f"{wanted} missing -> {m}"
            return m
    return "gamebot-trained"  # never qwen / deleted tags / have[0]


def load_edition(edition_id: str | None = None) -> dict:
    # Always drop stale CUDA_VISIBLE_DEVICES (e.g. "1" with only GPU 0) so Ollama can see a GPU.
    # Full edition auto-pick still skipped when locked or an explicit id is passed.
    try:
        from gpu_auto import apply_auto_gpu, _drop_stale_cuda_visible, _nvidia_gpus
        if edition_id is None and not os.environ.get("GAMEBOT_EDITION_LOCK"):
            apply_auto_gpu()
        else:
            _drop_stale_cuda_visible(_nvidia_gpus())
    except Exception:
        pass

    eid = (edition_id or os.environ.get("GAMEBOT_EDITION") or "").strip().lower()
    if eid in ("12", "12gb+", "12+"):
        eid = "12gb"
    if eid in ("4gb", "6gb", "8", "8gb+"):
        eid = "8gb"  # 4GB/6GB builds retired - 8GB is the minimum edition
    if not eid:
        eid = DEFAULT_ID
    path = EDITIONS_DIR / f"{eid}.json"
    if not path.exists():
        path = EDITIONS_DIR / "8gb.json"
    data = json.loads(path.read_text(encoding="utf-8-sig"))
    os.environ["OLLAMA_MODEL"] = resolve_model(os.environ.get("OLLAMA_MODEL") or data.get("model") or "gamebot-trained")
    os.environ["GAMEBOT_EDITION"] = data.get("id", eid)
    os.environ["GAMEBOT_NUM_CTX"] = str(data.get("num_ctx", 4096))
    # Always show plain product name Ã¢â‚¬â€ editions stay hidden
    os.environ["GAMEBOT_TITLE"] = "Game Bot"
    os.environ.setdefault("GAMEBOT_PORT", str(data.get("port", 7870)))  # an explicit GAMEBOT_PORT wins
    return data


def apply_to_agent_options(options: dict | None = None) -> dict:
    opts = dict(options or {})
    try:
        opts["num_ctx"] = int(os.environ.get("GAMEBOT_NUM_CTX", opts.get("num_ctx", 4096)))
    except Exception:
        opts["num_ctx"] = 4096
    opts.setdefault("temperature", 0.1)
    return opts