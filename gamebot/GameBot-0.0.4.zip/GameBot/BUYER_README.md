# Game Bot - automatic local game studio

> **NVIDIA RTX 20 series or newer, or AMD RX 5000 series or newer, with at least 8 GB of video memory. 12 GB or more is recommended.**


Describe a game. Game Bot runs the studio pipeline on your own PC: design docs, task board, legal and QA docs, concept brief, website stub, Steam/Epic ship prep, Blender props and a Unity grey-box slice built in batchmode. It uses tools and does not write tutorials. It stops only at steps a human must do.

## 1. Requirements (Windows 10/11 x64)
- **Python 3.11+** (python.org; tick "Add to PATH"), then: `pip install -r requirements.txt`
- **Ollama** (https://ollama.com/download). Pull a tool-calling model:
  - `ollama pull qwen2.5:7b` (8 GB+ VRAM), or `ollama pull qwen2.5:3b` (low VRAM)
  - Optional faster alias with a 6k context: create a `Modelfile` with
    `FROM qwen2.5:7b` / `PARAMETER num_ctx 6144`, then `ollama create qwen-fast -f Modelfile`
  - Set `OLLAMA_MODEL` to the model name you use (default `qwen-fast`).
- **Unity Hub + Unity 6000.x editor** (default 6000.6.5f1 or newest 6000.x) with Windows Build Support (Mono/IL2CPP).
- **Blender 4.x/5.x** (blender.org) for generated props.
- **Firefox** (optional, used for web research by the bot).
- Disk: about 10 GB per Unity project. Unreal is optional and a manual install (~60 GB).

## 2. Configure paths
Copy `config\gamebot.config.example.json` to `config\gamebot.config.json`. Empty paths are detected automatically on first start.
```json
{ "projects_root": "%USERPROFILE%/Documents/GameProjects",
  "unity_editor": "C:/Program Files/Unity/Hub/Editor/<version>/Editor/Unity.exe",
  "blender": "C:/Program Files/Blender Foundation/Blender <version>/blender.exe" }
```
Environment overrides: `GAMEBOT_PROJECTS`, `GAMEBOT_UNITY`, `GAMEBOT_BLENDER`. Set `GAMEBOT_SKIP_UNITY=1` to write the Unity files without running Unity.

## 3. Start
- Run `start-game-bot.ps1` (right click > Run with PowerShell), or run `python app.py` in this folder.
- Open http://127.0.0.1:7870/ in your browser. Health check: http://127.0.0.1:7870/api/health

## 4. First prompt
> Make a game called Neon Drift, a top-down arcade racer, and do the whole studio setup automatically.

Output goes to `<projects_root>\NeonDrift\`:
- `Docs\` holds the Pitch, GDD, TaskBoard, Legal, QA and Site.
- `Art\Concept`, `Store\` (capsule specs, Steam checklist, PLACEHOLDER VDFs, Epic stub) and `Tools\`.
- A background Unity job builds `NeonDriftUnity\` and then `Builds\Windows\NeonDrift.exe`. Its progress is in `Builds\auto_unity_status.txt` (RUNNING / DONE OK / DONE FAIL).

Other prompts: "make blender props: crate, barrel, lamp", "prep Steam ship for Neon Drift", "add a shotgun item to Neon Drift", "run an FPS pass".

## 5. Human gates (Game Bot never does these)
- Store accounts, fees and tax/bank interviews (Steamworks, Epic, Apple, Google).
- Real Steam AppIDs/DepotIDs and EOS IDs. Files keep `PLACEHOLDER_*` until you paste the real ones.
- Age-rating questionnaires (IARC etc.), store review submission and the final Release/Go Live click.
- Buying paid assets, installing big engines (Unreal), public posting, deploying websites.
- Legal review of the EULA and Privacy policy.

## 6. Safety
- Game Bot only writes inside `projects_root\<GameName>` and its own folder. It backs up files before editing them.
- It never uploads your projects or personal data. It never touches saves or projects you did not name.
- Lessons it learns are saved locally in `lessons\`. Playbooks are in `playbooks\` (start with `complete-game-builder-index.md`).

## GPU and AI model (automatic)
Game Bot picks the right AI model for your PC automatically from your GPU's video memory - there is nothing to choose. NVIDIA RTX 20 series or newer, or AMD RX 5000 series or newer, with at least 8 GB of video memory. 12 GB or more is recommended. Cards with 12 GB or more automatically get a larger model. If the expected model isn't installed, Game Bot falls back to an installed one instead of erroring. Install the model once from Setup ("Download the recommended AI model for this PC") or Start menu > Game Bot > Set up AI model. One desktop shortcut: Game Bot.
