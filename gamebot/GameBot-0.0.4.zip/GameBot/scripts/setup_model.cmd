@echo off
rem Game Bot model setup - creates gamebot-trained offline from the bundled r59 GGUF.
setlocal
cd /d "%~dp0.."
title Game Bot - AI model setup
set "MF=%cd%\models\Modelfile"
set "GG=%cd%\models\gamebot-r59.gguf"

if not exist "%GG%" (
  echo Bundled model file missing: models\gamebot-r59.gguf
  echo Reinstall Game Bot, or contact support.
  pause
  exit /b 1
)
if not exist "%MF%" (
  echo Bundled Modelfile missing: models\Modelfile
  pause
  exit /b 1
)

:findollama
where ollama >nul 2>nul && goto haveollama
if exist "%LOCALAPPDATA%\Programs\Ollama\ollama.exe" set "PATH=%LOCALAPPDATA%\Programs\Ollama;%PATH%" & goto haveollama
echo Ollama is not installed yet.
echo Install Ollama from https://ollama.com/download then press any key...
start "" "https://ollama.com/download"
pause >nul
goto findollama

:haveollama
ollama list >nul 2>nul || (start "" /min ollama serve & timeout /t 8 >nul)
echo Creating gamebot-trained from the bundled r59 model (offline, no download)...
ollama create gamebot-trained -f "%MF%" || goto fail
echo.
echo Done - gamebot-trained (r59) is ready. Start Game Bot from the Desktop icon.
pause
exit /b 0

:fail
echo.
echo Model setup failed. Make sure Ollama is running, then try Start menu ^> Game Bot ^> Set up AI model again.
pause
exit /b 1