# Launch on Steam, Epic, and mobile

Action playbook for Game Bot. Store accounts/tax/bank are human + partner portals — bot prepares builds, configs, store assets, and upload scripts; the creator confirms live release.

## Steam (PC)
Sources: https://partner.steamgames.com/doc/gettingstarted · https://partner.steamgames.com/doc/sdk/uploading · https://partner.steamgames.com/doc/store/application/builds

1. Steamworks partner signup (legal entity, tax, bank) — user action.
2. Create Application + depots (Windows first).
3. Download Steamworks SDK → `tools\ContentBuilder\`.
4. Copy shipping build into `content\<depot>\` (Unity `Builds\Stage_<ver>` output).
5. Write `app_build_<appid>.vdf` + depot VDF (ContentRoot, LocalPath `*`, FileExclusion patterns for PDBs).
6. Upload: `steamcmd.exe +login <user> +run_app_build ..\scripts\app_build.vdf +quit`
7. SteamPipe → Builds: set build live on **private beta** branch first; smoke test; then Default when approved.
8. Store presence: capsules, screenshots, trailer, description, pricing, age rating questionnaire, build + page for Valve review.
9. Optional SDK features: achievements, cloud, workshop — integrate before upload if needed.
10. Recurring updates: same SteamPipe path; never wipe depots blindly.

## Epic Games Store
Sources: Epic Developer Portal / BuildPatch Tool docs (look up current URL with firefox_search when executing).

1. Epic Games org + product create (user).
2. Artifact/build upload via Epic BuildPatch Tool / Dev Portal.
3. Sandbox → Stage → Live; configure entitlements, store page, age rating.
4. EOS SDK only if online services needed; offline single-player can ship thinner.

## Mobile (iOS / Android) — Unity path
1. Switch platform: Android or iOS player settings (bundle id, icons, splash, IL2CPP, ARM64).
2. **Android:** keystore (vault secrets — never paste passwords in chat); Build App Bundle (.aab); Google Play Console → internal testing → production; content rating, store listing, privacy policy URL.
3. **iOS:** Apple Developer + App Store Connect; Mac required to archive; certificates/profiles; TestFlight then Review. Privacy nutrition labels.
4. Touch UI: replace mouse HUD paths; virtual sticks; safe areas.
5. Performance: lower foliage/shadows presets; thermal budgets.
6. Platform policies: hunting/weapons content may be restricted — check store guidelines before investing.

## Shared store checklist
- [ ] Shipping build + version string
- [ ] Capsule/key art + screenshots from concept pipeline
- [ ] Trailer slot
- [ ] EULA / Privacy URLs (site + in-game)
- [ ] Age rating forms
- [ ] Installer/desktop icons for PC sideload still work
- [ ] Changelog notes for each build

## Bot rules
- Prepare folders, VDFs, HTML presskit, and command lines locally.
- Never invent AppIDs — read from partner portal or user-provided config file.
- For live "Set Default / Submit for Review", confirm with the creator first.
