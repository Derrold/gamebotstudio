# Addressables + content updates
- Use Addressables (com.unity.addressables) when content is large or patched often (levels, cosmetics, DLC). Small games: Resources/direct references are fine.
- Groups: Local_Static (ships in build), Local_DLC, Remote (CDN). Labels for batch loading. Addressables.LoadAssetAsync / InstantiateAsync; always Release handles.
- Build: Addressables "Build > New Build > Default Build Script" in batchmode via AddressableAssetSettings.BuildPlayerContent() before BuildPlayer.
- Content update: keep addressables_content_state.bin per release (Builds\Release_<ver>\), run "Update a Previous Build" -> only changed bundles. Steam depots handle delta patching anyway; for Steam-only games local groups are enough.
- DLC on Steam: separate depot per DLC, check ownership with SteamApps.BIsDlcInstalled(appId) before loading its group (real DLC AppIDs = human gate).
- Test: fresh install + update from previous version on a clean machine.
