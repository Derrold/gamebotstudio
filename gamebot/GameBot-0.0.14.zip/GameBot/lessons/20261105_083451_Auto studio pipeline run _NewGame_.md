# Auto studio pipeline run (NewGame)

Tags: auto studio pipeline
Saved: 2026-11-05T08:34:51

run_auto_game_pipeline created 1 files under C:\Users\ExtremeHybrid\Documents\GameProjects\NewGame and UNITY 6000.6.5f1: background job started -> create NewGameUnity -> Assets/Scenes/Slice01.unity (grey-box, player, goal, HUD) -> Builds\Windows\NewGame.exe. Stat. Next: check Builds\auto_unity_status.txt, then work TaskBoard 'Auto next actions' with tools.
