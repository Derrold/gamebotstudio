# Custom item/weapon pipeline

Tags: unity weapon item pipeline
Saved: 2026-10-25T20:53:13

Model (make_asset) -> ScriptableObject def + prefab -> Editor script registration -> unlock/shop entry -> batchmode bake -> grep 'error CS' -> restore backups on failure. Patch code registries with exact-needle insert, backup + sanity gate + atomic replace, keep BOM.
