using UnityEngine;
/// <summary>Stealth guard: walks waypoints, vision cone (raycast + angle), raises detection; full detection = alarm. 3 alarms = mission failed.</summary>
public class GuardPatrol : MonoBehaviour
{
    public Vector3[] points; public float speed = 2.2f, view = 13f, fov = 60f; int idx; float wait; Transform p; MeshRenderer coneR; static float lastAlarm;
    void Start()
    {
        var g = GameObject.FindGameObjectWithTag("Player"); if (g) p = g.transform;
        var cone = new GameObject("VisionCone"); cone.transform.SetParent(transform, false); cone.transform.localPosition = new Vector3(0, -0.85f, 0);
        var mf = cone.AddComponent<MeshFilter>(); coneR = cone.AddComponent<MeshRenderer>(); var m = new Mesh(); int seg = 16; var v = new Vector3[seg + 2]; var t = new int[seg * 3]; v[0] = Vector3.zero;
        for (int i = 0; i <= seg; i++) { float a = Mathf.Deg2Rad * (-fov + 2 * fov * i / seg); v[i + 1] = new Vector3(Mathf.Sin(a), 0, Mathf.Cos(a)) * view; }
        for (int i = 0; i < seg; i++) { t[i * 3] = 0; t[i * 3 + 1] = i + 1; t[i * 3 + 2] = i + 2; }
        m.vertices = v; m.triangles = t; m.RecalculateNormals(); mf.sharedMesh = m;
        coneR.material = new Material(Shader.Find("Sprites/Default")); coneR.material.color = new Color(1f, 1f, 0.3f, 0.18f); coneR.shadowCastingMode = UnityEngine.Rendering.ShadowCastingMode.Off;
    }
    void Update()
    {
        if (GameState.Won || GameState.Lost || PauseMenu.IsPaused || MainMenuUI.InMenu || points == null || points.Length == 0) return;
        bool sees = Sees();
        if (!sees)
        {
            var tgt = points[idx]; tgt.y = transform.position.y; Vector3 to = tgt - transform.position;
            if (to.magnitude < 0.3f) { wait += Time.deltaTime; if (wait > 1.2f) { wait = 0; idx = (idx + 1) % points.Length; } }
            else { transform.position += to.normalized * speed * Time.deltaTime; transform.rotation = Quaternion.Slerp(transform.rotation, Quaternion.LookRotation(to), Time.deltaTime * 4f); }
        }
        else { Vector3 to = p.position - transform.position; to.y = 0; transform.rotation = Quaternion.Slerp(transform.rotation, Quaternion.LookRotation(to), Time.deltaTime * 6f); }
        coneR.material.color = sees ? new Color(1f, 0.15f, 0.1f, 0.3f) : new Color(1f, 1f, 0.3f, 0.16f);
    }
    bool Sees()
    {
        if (!p) return false; Vector3 eye = transform.position + Vector3.up * 0.7f, head = p.position + Vector3.up * (GenreState.Crouched ? 0.6f : 1.4f);
        Vector3 to = head - eye; float d = to.magnitude; float range = view * (GenreState.Crouched ? 0.65f : 1f) * (GenreState.InCover ? 0.35f : 1f);
        if (d > range || Vector3.Angle(transform.forward, new Vector3(to.x, 0, to.z)) > fov) return false;
        if (Physics.Raycast(eye, to.normalized, out var hit, d, ~0, QueryTriggerInteraction.Ignore) && !hit.collider.transform.IsChildOf(p)) return false;
        GenreState.Detection += Time.deltaTime * (1.6f - d / range) * 0.9f;
        if (GenreState.Detection >= 1f && Time.time - lastAlarm > 1f)
        {
            lastAlarm = Time.time; GenreState.Detection = 0; GenreState.Alarms++; GameHUD.Flash("ALARM! You were spotted (" + GenreState.Alarms + "/3)");
            if (GenreState.Alarms >= 3) { GenreState.Lose("Three alarms - the job is blown"); return true; }
            var gp = p.GetComponent<GamePlayer>(); if (gp) { var cc = p.GetComponent<CharacterController>(); cc.enabled = false; p.position = StealthPlayer.Spawn; cc.enabled = true; }
        }
        return true;
    }
}
