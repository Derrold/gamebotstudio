# Automated in-player test runner (generic CHECK-style harness)
Pattern: a test MonoBehaviour that runs inside a dev build (or Editor PlayMode) when launched with `-runChecks`, walks scripted steps, and prints machine-readable lines.
- Output lines: `[PASS] <name> <detail>` / `[FAIL] <name> <detail>` / `PERF <scene/spot> <preset> avg=<fps> p1=<fps> cpu=<ms> gpu=<ms>`; summary `CHECKS done pass=N fail=M`; then Application.Quit(fail>0?1:0).
- Parse from Player.log (%USERPROFILE%\AppData\LocalLow\<Company>\<Product>\Player.log) or -logFile.
- Steps: boot -> menu -> load slice -> teleport player to fixed spots -> warm up 3 s -> measure 10 s with FrameTimingManager (cpuFrameTime/gpuFrameTime) -> test systems (spawn item, fire, save/load round-trip in a TEMP profile) -> results.
- Before/after comparisons: same build, same spot, same preset; toggle the setting under test inside the run (A/B) so hardware noise cancels.
- Save safety: snapshot settings/PlayerPrefs keys before the run and restore after; use a dedicated test profile/slot; never touch real player saves.
- Never kill a running game the creator is playing; run checks only on a separate build or when no instance is running.
- Feed results into Docs\QA\fps_passes.md and the release regression gate; teach_self any finding.
