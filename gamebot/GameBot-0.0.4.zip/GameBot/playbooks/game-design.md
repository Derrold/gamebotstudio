# Game design playbook (loops, progression, economy, weapons, seasons, difficulty, UX)
Sources: https://www.gamedeveloper.com/design/the-chemistry-of-game-design · https://lizengland.com/blog/2014/04/the-door-problem/ · https://machinations.io/ (economy simulation) · https://lostgarden.com/2012/04/30/loops-and-arcs/ · https://www.gdcvault.com (design talks)

## Core loop -> meta loop
- Core loop (seconds–minutes): the verb repeated most.
- Meta loop (hours): earn XP/cash -> rank up -> unlock gear -> new maps/seasons. Write both loops as one sentence each at the top of every GDD.
- Test: if the core loop is not fun in a grey-box with placeholder art, more content will not save it.

## Progression
- XP curve: XP(n) = base * n^1.5 (or table). Aim: first unlock in < 10 min, a new unlock every 20–40 min early, slowing later. Unl gates items by rank then price.
- Every unlock should change how you play (new range, new tactic), not just +5%.

## Economy
- List sources (hunt payouts, job invoices, achievements) and sinks (guns, ammo, licences, tools, upgrades, fuel). Spreadsheet: expected income per hour vs price of next goal = hours to goal (target 0.5–2 h early game).
- Avoid inflation: consumable sinks (ammo, refrigerant, fuel) scale with play.

## Weapons & loadouts
- Each weapon needs a role: range band, damage/energy, handling (ADS time, recoil), capacity, legality (season).
- Balance with numbers, not feel alone: muzzle energy at 100/200/300 yd vs ethical-kill threshold; time-to-ADS; price/rank.

## Seasons & calendar
- Use events/limited seasons for retention, never FOMO-punish.

## Difficulty
- Separate knobs: animal senses (wind/hearing), aim assist/ballistics, economy. Presets + custom. Use dynamic help (tracking hints) not stat cheats.

## UX flow
- Main menu -> profile -> hub (cabin / shop) -> loadout -> map -> play -> results -> hub. Max 3 clicks from launch to gameplay for returning players. Every screen: back/escape works, gamepad focus visible, key hints shown.
- Onboarding: teach by doing (Tutorial), one new verb per minute, skip option.

## GDD template (write to Docs/GDD.md)
Pitch (2 lines) · Pillars (3) · Core loop · Meta loop · Player verbs · Content list (maps, items, enemies/animals) · Progression/economy tables · UX flow · Tech (engine, targets, budgets) · Art direction · Audio · Milestones · Risks · IP guardrails (no trademarks/ripped assets).
