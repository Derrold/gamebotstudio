using UnityEngine;
/// <summary>Sim shop: player behind counter = serving; spawns a stream of customers.</summary>
public class ShopCounter : MonoBehaviour
{
    public static bool Serving; public Transform door, servePoint; float next; int n;
    void OnTriggerStay(Collider o) { if (o.CompareTag("Player")) Serving = true; }
    void OnTriggerExit(Collider o) { if (o.CompareTag("Player")) Serving = false; }
    void Update()
    {
        if (PauseMenu.IsPaused || MainMenuUI.InMenu || GameState.Won || Time.time < next) return;
        next = Time.time + 4f;
        if (FindObjectsByType<ShopCustomer>(FindObjectsSortMode.None).Length >= 4) return;
        var c = GameObject.CreatePrimitive(PrimitiveType.Capsule); c.name = "Customer_" + (n++); Destroy(c.GetComponent<Collider>());
        c.GetComponent<Renderer>().material.color = Color.HSVToRGB(Random.value, 0.6f, 0.9f);
        c.transform.position = door.position;
        var sc = c.AddComponent<ShopCustomer>(); sc.counter = servePoint.position + new Vector3(0, 0, 0); sc.exit = door.position;
    }
}
