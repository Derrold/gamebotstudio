using UnityEngine;
/// <summary>MMORPG quest giver: walk up to accept, walk up again when ready to turn in. Quest 2 (Treant) unlocks at level 3.</summary>
public class MmoQuestGiver : MonoBehaviour
{
    public int quest; public string npcName = "Warden Hale"; public string offer = "";
    static readonly int[] RewardXp = { 150, 150, 400 }; static readonly int[] RewardGold = { 25, 20, 100 };
    void OnTriggerEnter(Collider o)
    {
        if (!o.CompareTag("Player")) return; int st = GenreState.Quest[quest];
        if (st == 0) { if (quest == 2 && GenreState.Level < 3) { GameHUD.Flash(npcName + ": come back at level 3, the Treant would crush you."); return; } GenreState.Quest[quest] = 1; GameHUD.Flash(npcName + ": " + offer); AchievementSystem.Unlock("quest_accept"); GenreState.MmoQuestCheck(); }
        else if (st == 1) GameHUD.Flash(npcName + ": not done yet.");
        else if (st == 2) { GenreState.Quest[quest] = 3; GenreState.QuestsDone++; GenreState.AddXp(RewardXp[quest]); GenreState.Gold += RewardGold[quest]; GameHUD.Flash(npcName + ": well done! +" + RewardXp[quest] + " XP"); if (GenreState.QuestsDone >= GenreState.QuestsTotal) { AchievementSystem.Unlock("hero_hearthvale"); GenreState.Win(); } }
    }
    void OnGUI()
    {
        if (MainMenuUI.InMenu) return; var cam = Camera.main; if (!cam) return; var sp = cam.WorldToScreenPoint(transform.position + Vector3.up * 2.6f); if (sp.z < 0 || sp.z > 45) return;
        int st = GenreState.Quest[quest]; string mark = st == 0 ? "!" : st == 2 ? "?" : st == 1 ? "..." : "";
        GUI.Label(new Rect(sp.x - 80, Screen.height - sp.y - 28, 160, 44), npcName + "\n" + mark, new GUIStyle(GUI.skin.label) { alignment = TextAnchor.MiddleCenter, fontSize = 16, fontStyle = FontStyle.Bold, normal = { textColor = Color.yellow } });
    }
}
