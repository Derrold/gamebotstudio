"""Persisted Settings for which model Game Bot should use.

The default is always the local Game Bot trained model (gamebot-trained) via
Ollama. Other installed Ollama models, a local OpenAI-compatible server
(LM Studio / llama.cpp), and optional cloud providers can be selected in the
app Settings. API keys are never stored in this file.
"""
from __future__ import annotations

import json
import os
from pathlib import Path

ROOT = Path(__file__).resolve().parent
PREFS_PATH = ROOT / "work" / "model_settings.json"

DEFAULT_MODEL = "gamebot-trained"
DEFAULT_PROVIDER = "ollama"

# LM Studio default; llama.cpp server is typically :8080 — the user can edit the URL.
DEFAULT_COMPAT_URL = "http://127.0.0.1:1234/v1"

PROVIDERS = ("ollama", "openai_compat", "openai", "anthropic", "openrouter", "xai")
CLOUD_PROVIDERS = ("openai", "anthropic", "openrouter", "xai")

CLOUD_NOTE = (
    "Cloud models send your chat prompts and game descriptions off this PC "
    "to the provider you chose. The default Game Bot model stays on this PC."
)

# Shown next to the default row in Settings.
DEFAULT_LABEL = "Game Bot trained model (recommended)"


def _load() -> dict:
    try:
        if PREFS_PATH.is_file():
            data = json.loads(PREFS_PATH.read_text(encoding="utf-8"))
            if isinstance(data, dict):
                return data
    except Exception:
        pass
    return {}


def _save(data: dict) -> None:
    PREFS_PATH.parent.mkdir(parents=True, exist_ok=True)
    clean = {
        "provider": data.get("provider") or DEFAULT_PROVIDER,
        "model": (data.get("model") or DEFAULT_MODEL).strip(),
        "compat_url": (data.get("compat_url") or "").strip(),
        "cloud_model": (data.get("cloud_model") or "").strip(),
    }
    PREFS_PATH.write_text(json.dumps(clean, indent=2) + "\n", encoding="utf-8")


def get() -> dict:
    data = _load()
    env_model = (os.environ.get("OLLAMA_MODEL") or os.environ.get("GAMEBOT_MODEL") or "").strip()
    provider = str(data.get("provider") or DEFAULT_PROVIDER).strip().lower()
    if provider not in PROVIDERS:
        provider = DEFAULT_PROVIDER
    model = str(data.get("model") or DEFAULT_MODEL).strip() or DEFAULT_MODEL
    if provider == "ollama" and not data.get("model") and env_model:
        model = env_model
    compat_url = str(data.get("compat_url") or "").strip() or DEFAULT_COMPAT_URL
    cloud_model = str(data.get("cloud_model") or "").strip()
    is_default = provider == "ollama" and model.split(":", 1)[0] == DEFAULT_MODEL
    return {
        "provider": provider,
        "model": model,
        "compat_url": compat_url,
        "cloud_model": cloud_model,
        "is_default": is_default,
        "cloud": provider in CLOUD_PROVIDERS,
        "cloud_note": CLOUD_NOTE if provider in CLOUD_PROVIDERS else "",
    }


def set_settings(provider: str = "", model: str = "", compat_url: str = "", cloud_model: str = "", **_ignored) -> dict:
    cur = get()
    p = (provider or cur["provider"] or DEFAULT_PROVIDER).strip().lower()
    if p not in PROVIDERS:
        p = DEFAULT_PROVIDER
    m = (model or cur["model"] or DEFAULT_MODEL).strip() or DEFAULT_MODEL
    url = (compat_url if compat_url is not None and str(compat_url).strip() else cur.get("compat_url") or DEFAULT_COMPAT_URL).strip()
    cm = (cloud_model if cloud_model is not None else cur.get("cloud_model") or "").strip()
    if p in CLOUD_PROVIDERS and not cm:
        cm = m if m != DEFAULT_MODEL else ""
    _save({"provider": p, "model": m, "compat_url": url, "cloud_model": cm})
    return public_info()


def active_model_name() -> str:
    s = get()
    if s["provider"] in CLOUD_PROVIDERS:
        return s.get("cloud_model") or s["model"] or s["provider"]
    if s["provider"] == "openai_compat":
        return s.get("cloud_model") or s["model"] or "local-model"
    return s["model"] or DEFAULT_MODEL


def is_default() -> bool:
    return bool(get().get("is_default"))


def public_info() -> dict:
    """Safe to send to the UI / health endpoint: no API keys."""
    import secret_store as SS
    s = get()
    keys = {p: SS.has_key(p) for p in CLOUD_PROVIDERS}
    return {
        "ok": True,
        "provider": s["provider"],
        "model": s["model"],
        "display_model": active_model_name(),
        "compat_url": s["compat_url"],
        "cloud_model": s["cloud_model"],
        "is_default": s["is_default"],
        "cloud": s["cloud"],
        "cloud_note": CLOUD_NOTE,
        "default_model": DEFAULT_MODEL,
        "default_label": DEFAULT_LABEL,
        "has_key": keys,
        "providers": list(PROVIDERS),
        "cloud_providers": list(CLOUD_PROVIDERS),
    }


def list_ollama_models() -> list[str]:
    try:
        from ollama_ensure import list_models
        names = list_models(timeout=5.0)
    except Exception:
        names = []
    out, seen = [], set()
    for n in names:
        key = n.strip()
        if not key or key.lower() in seen:
            continue
        seen.add(key.lower())
        out.append(key)
    # Always surface the default first, even if it is not installed yet.
    def _sort(n: str) -> tuple:
        base = n.split(":", 1)[0]
        return (0 if base == DEFAULT_MODEL else 1, n.lower())
    out.sort(key=_sort)
    if not any(n.split(":", 1)[0] == DEFAULT_MODEL for n in out):
        out.insert(0, DEFAULT_MODEL)
    return out
