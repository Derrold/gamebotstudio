using UnityEngine;
/// <summary>Side-on fighting camera that frames both fighters.</summary>
public class FightCamera : MonoBehaviour
{
    void LateUpdate()
    {
        if (!Fighter.P1 || !Fighter.P2) return;
        Vector3 mid = (Fighter.P1.transform.position + Fighter.P2.transform.position) / 2f; float span = Mathf.Abs(Fighter.P1.transform.position.x - Fighter.P2.transform.position.x);
        transform.position = Vector3.Lerp(transform.position, mid + new Vector3(0, 2.2f, -6.5f - span * 0.45f), Time.deltaTime * 4f);
        transform.rotation = Quaternion.Euler(8, 0, 0);
    }
}
