// Game Bot: download + import owned Asset Store packs inside the signed-in Unity Editor.
// Reads <project>\GameBotFetch\request.json, writes the status file named in it. The access token is never written anywhere.
#if UNITY_EDITOR
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Text.RegularExpressions;
using UnityEditor;
using UnityEngine;
using UnityEngine.Networking;

[InitializeOnLoad]
public static class GameBotAssetFetch
{
    [Serializable] public class Want { public string key; public string label; public string pattern; }
    [Serializable] public class Req
    {
        public int id; public string mode = "watch"; public Want[] wants = new Want[0]; public string[] names = new string[0];
        public string status; public string since; public int watch_minutes = 30; public bool import_into_project = false;
        public bool quit_when_done; public bool open_my_assets_on_fail = true;
    }
    [Serializable] public class Item { public long id; public string name; public string key; public string state; public float pct; public string path; public string msg; public string granted; }
    [Serializable] public class Status
    {
        public int req; public string state = "starting"; public string step = ""; public int done; public int total;
        public bool signed_in; public string error = ""; public string fallback = ""; public string api = "";
        public List<Item> items = new List<Item>(); public List<Item> owned = new List<Item>(); public string updated; public bool batchmode;
    }
    [Serializable] class PurchaseRow { public long packageId; public string displayName; public string grantTime; public bool isHidden; }
    [Serializable] class Purchases { public long total; public PurchaseRow[] results; }
    [Serializable] class DlInner { public string filename_safe_category_name, filename_safe_package_name, filename_safe_publisher_name, id, key, url; }
    [Serializable] class DlResult { public DlInner download; }
    [Serializable] class DlInfo { public DlResult result; }

    const BindingFlags F = BindingFlags.Instance | BindingFlags.Static | BindingFlags.Public | BindingFlags.NonPublic | BindingFlags.FlattenHierarchy;
    static string Proj => Directory.GetParent(Application.dataPath).FullName;
    static string ReqPath => Path.Combine(Proj, "GameBotFetch", "request.json");

    static Req s_Req; static Status s_St; static DateTime s_ReqTime; static double s_Next; static double s_Start; static double s_LastList = -999;
    static string s_Stage = "idle"; static UnityWebRequest s_Web; static Action<UnityWebRequest> s_WebDone;
    static Queue<Item> s_Queue = new Queue<Item>(); static Item s_Cur; static double s_CurStart; static bool s_Importing;
    static HashSet<long> s_Handled = new HashSet<long>(); static int s_ListOffset; static List<PurchaseRow> s_Rows = new List<PurchaseRow>();

    static GameBotAssetFetch()
    {
        EditorApplication.update += Tick;
        AssetDatabase.importPackageCompleted += n => OnImport(n, null);
        AssetDatabase.importPackageFailed += (n, e) => OnImport(n, e);
        AssetDatabase.importPackageCancelled += n => OnImport(n, "cancelled");
    }

    // ------------------------------------------------------------ status / request
    static void Save()
    {
        if (s_Req == null || s_St == null || string.IsNullOrEmpty(s_Req.status)) return;
        try
        {
            s_St.updated = DateTime.Now.ToString("s"); s_St.batchmode = Application.isBatchMode;
            s_St.done = s_St.items.Count(i => i.state == "imported" || i.state == "downloaded");
            s_St.total = s_St.items.Count;
            Directory.CreateDirectory(Path.GetDirectoryName(s_Req.status));
            var tmp = s_Req.status + ".tmp"; File.WriteAllText(tmp, JsonUtility.ToJson(s_St, true));
            if (File.Exists(s_Req.status)) File.Delete(s_Req.status); File.Move(tmp, s_Req.status);
        }
        catch (Exception e) { Debug.LogWarning("[GameBot] status write failed: " + e.Message); }
    }

    static void Step(string s) { if (s_St != null) { s_St.step = s; Debug.Log("[GameBot] " + s); Save(); } }

    static void LoadRequest()
    {
        try
        {
            if (!File.Exists(ReqPath)) return;
            var t = File.GetLastWriteTime(ReqPath);
            if (s_Req != null && t == s_ReqTime) return;
            var r = JsonUtility.FromJson<Req>(File.ReadAllText(ReqPath));
            if (r == null) return;
            s_ReqTime = t;
            if (s_Req != null && r.id == s_Req.id) { s_Req = r; return; }
            if (r.mode == "finish")
            {
                // Keep the last fetch results in the status file; just close.
                Status keep = s_St;
                try { if (keep == null && File.Exists(r.status)) keep = JsonUtility.FromJson<Status>(File.ReadAllText(r.status)); } catch { }
                s_Req = r; s_St = keep ?? new Status { req = r.id }; s_Stage = "finish"; Step("closing"); return;
            }
            s_Req = r; s_St = new Status { req = r.id }; s_Stage = "auth";
            s_Start = EditorApplication.timeSinceStartup; s_Handled.Clear(); s_Queue.Clear(); s_Cur = null; s_LastList = -999;
            // Survive domain reloads (an imported pack with scripts recompiles and wipes statics): keep finished items.
            try
            {
                if (!string.IsNullOrEmpty(r.status) && File.Exists(r.status) && r.mode != "finish")
                {
                    var old = JsonUtility.FromJson<Status>(File.ReadAllText(r.status));
                    if (old != null && old.req == r.id)
                    {
                        foreach (var i in old.items)
                        {
                            if (i.state == "importing") i.state = "imported";
                            if (i.state == "imported" || i.state == "failed") { s_St.items.Add(i); s_Handled.Add(i.id); }
                        }
                    }
                }
            }
            catch { }
            Step(r.mode == "finish" ? "closing" : "waiting for Unity sign-in");
        }
        catch (Exception e) { Debug.LogWarning("[GameBot] bad request.json: " + e.Message); }
    }

    // ------------------------------------------------------------ reflection helpers (Unity 6 internals)
#pragma warning disable UAC0005
    static Type FindType(string full)
    {
        foreach (var a in AppDomain.CurrentDomain.GetAssemblies()) { var t = a.GetType(full, false); if (t != null) return t; }
        return null;
    }
#pragma warning restore UAC0005
    static object Get(object o, string n)
    {
        if (o == null) return null; var t = o as Type ?? o.GetType(); var inst = o is Type ? null : o;
        var p = t.GetProperty(n, F); if (p != null) return p.GetValue(inst, null);
        var f = t.GetField(n, F); return f != null ? f.GetValue(inst) : null;
    }
    static object Connect() { return Get(FindType("UnityEditor.Connect.UnityConnect"), "instance"); }
    static string Token()
    {
        try { var c = Connect(); var ui = Get(c, "userInfo"); return Get(ui, "accessToken") as string; } catch { return null; }
    }
    static string Diag()
    {
        try
        {
            var c = Connect(); if (c == null) return "connect=null";
            var ui = Get(c, "userInfo");
            return $"ready={Get(c, "isUserInfoReady")} loggedIn={Get(c, "loggedIn")} online={Get(c, "online")} userValid={Get(ui, "valid")} hasToken={!string.IsNullOrEmpty(Get(ui, "accessToken") as string)}";
        }
        catch (Exception e) { return "diag " + e.GetType().Name; }
    }
    static bool InfoReady() { try { return (bool)(Get(Connect(), "isUserInfoReady") ?? false); } catch { return false; } }
    static string Host()
    {
        try
        {
            var c = Connect(); var en = FindType("UnityEditor.Connect.CloudConfigUrl");
            var m = c.GetType().GetMethod("GetConfigurationURL", F, null, new[] { en }, null);
            var h = m.Invoke(c, new[] { Enum.Parse(en, "CloudPackagesApi") }) as string;
            if (!string.IsNullOrEmpty(h)) return h.TrimEnd('/');
        }
        catch { }
        return "https://packages-v2.unity.com";
    }
    static string CacheRoot()
    {
        try
        {
            var u = FindType("UnityEditor.AssetStoreUtils");
            var b = u.GetMethod("BuildBaseDownloadPath", F).Invoke(null, new object[] { "", "" }) as string;
            if (!string.IsNullOrEmpty(b)) return b.TrimEnd('/', '\\');
        }
        catch { }
        return Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData), "Unity", "Asset Store-5.x");
    }

    // ------------------------------------------------------------ web
    static void Web(string path, Action<UnityWebRequest> done)
    {
        var tok = Token();
        s_Web = UnityWebRequest.Get(Host() + path);
        s_Web.SetRequestHeader("Authorization", "Bearer " + tok);
        s_Web.timeout = 60; s_WebDone = done; s_Web.SendWebRequest();
    }

    // ------------------------------------------------------------ main loop
    static void Tick()
    {
        var now = EditorApplication.timeSinceStartup;
        if (now < s_Next) return;
        s_Next = now + 0.5;
        LoadRequest();
        if (s_Req == null) return;
        if (s_Web != null)
        {
            if (!s_Web.isDone) return;
            var w = s_Web; var d = s_WebDone; s_Web = null; s_WebDone = null;
            try { d(w); } catch (Exception e) { Fail("web step failed: " + e.Message); }
            w.Dispose(); return;
        }
        try { Advance(now); } catch (Exception e) { Fail(e.GetType().Name + ": " + e.Message); }
    }

    static void Advance(double now)
    {
        switch (s_Stage)
        {
            case "auth":
                if (!string.IsNullOrEmpty(Token())) { s_St.signed_in = true; s_Stage = "list"; s_ListOffset = 0; s_Rows.Clear(); Step("signed in; reading My Assets"); return; }
                if ((int)(now - s_Start) % 10 == 0) { s_St.api = Diag(); Save(); }
                if (now - s_Start > (Application.isBatchMode ? 45 : 600))
                {
                    s_St.signed_in = false;
                    Fail(InfoReady() ? "Unity is not signed in. Open Unity Hub and sign in, then say rescan." : "Unity sign-in did not finish.", "not_signed_in");
                }
                return;
            case "list":
                Web($"/-/api/purchases?offset={s_ListOffset}&limit=100", w =>
                {
                    if (w.result != UnityWebRequest.Result.Success) { Fail($"My Assets list failed ({w.responseCode})", "list_failed"); return; }
                    var p = JsonUtility.FromJson<Purchases>(w.downloadHandler.text);
                    s_St.api = "rest";
                    if (p?.results != null) s_Rows.AddRange(p.results);
                    if (p != null && p.results != null && p.results.Length == 100 && s_Rows.Count < p.total && s_ListOffset < 5000) { s_ListOffset += 100; return; }
                    s_LastList = EditorApplication.timeSinceStartup; s_ListOffset = 0;
                    Plan(); s_Rows = new List<PurchaseRow>();
                });
                s_Stage = "listing"; return;
            case "listing":
                if (s_Web == null && s_LastList > 0) s_Stage = "work";
                else if (s_Web == null) s_Stage = "list";
                return;
            case "work":
                if (s_Cur == null && s_Queue.Count > 0) { s_Cur = s_Queue.Dequeue(); s_CurStart = now; StartDownload(s_Cur); return; }
                if (s_Cur != null) { Poll(s_Cur, now); return; }
                if (s_Importing) return;
                bool wantsLeft = s_Req.wants.Any(wt => !s_St.items.Any(i => i.key == wt.key && (i.state == "imported" || i.state == "downloaded")));
                if (s_Req.mode == "watch" && wantsLeft && now - s_Start < s_Req.watch_minutes * 60)
                {
                    s_St.state = "watching"; if (now - s_LastList > 20) { s_Stage = "list"; s_ListOffset = 0; s_Rows.Clear(); s_LastList = 0; }
                    Save(); return;
                }
                s_St.state = s_St.items.Any(i => i.state == "failed") ? "done_with_errors" : "done";
                Step(s_St.items.Count == 0 ? "nothing to download" : "all packs ready");
                s_Stage = s_Req.quit_when_done ? "finish" : "idle_done"; return;
            case "finish":
                Save(); s_Stage = "exit"; s_Next = now + 1.5; return;
            case "exit":
                EditorApplication.Exit(0); return;
        }
    }

    // ------------------------------------------------------------ choosing packs
    static void Plan()
    {
        var cache = CacheRoot();
        DateTime since; DateTime.TryParse(s_Req.since ?? "", out since);
        s_St.owned.Clear();
        foreach (var r in s_Rows.Where(r => !r.isHidden))
        {
            var it = new Item { id = r.packageId, name = r.displayName, granted = r.grantTime, state = "owned" };
            var have = FindCached(cache, r.displayName);
            if (have != null) { it.state = "in_cache"; it.path = have; }
            s_St.owned.Add(it);
        }
        foreach (var o in s_St.owned.OrderBy(x => x.state == "in_cache" ? 0 : 1))
        {
            if (s_Handled.Contains(o.id)) continue;
            string key = null;
            foreach (var wt in s_Req.wants)
                if (!string.IsNullOrEmpty(wt.pattern) && Regex.IsMatch(o.name ?? "", wt.pattern, RegexOptions.IgnoreCase)) { key = wt.key; break; }
            if (key == null && s_Req.names != null)
                foreach (var n in s_Req.names)
                {
                    if (string.IsNullOrEmpty(n)) continue;
                    bool exactExists = s_St.owned.Any(x => Norm(x.name) == Norm(n));
                    if (exactExists ? Norm(o.name) == Norm(n) : (o.name ?? "").IndexOf(n, StringComparison.OrdinalIgnoreCase) >= 0) { key = "named"; break; }
                }
            DateTime g;
            if (key == null && since > DateTime.MinValue && DateTime.TryParse(o.granted ?? "", out g) && g.ToLocalTime() >= since) key = "recent";
            if (key == null) continue;
            // At most 2 packs per category (some collections are many GB); packs the creator named or just added always count.
            if (key != "named" && key != "recent" && s_St.items.Count(i => i.key == key) >= 2) continue;
            s_Handled.Add(o.id);
            var item = new Item { id = o.id, name = o.name, key = key, state = o.state == "in_cache" ? "downloaded" : "queued", path = o.path, pct = o.state == "in_cache" ? 1 : 0 };
            s_St.items.Add(item);
            s_Queue.Enqueue(item);
        }
        Step($"My Assets: {s_St.owned.Count} owned, {s_Queue.Count} to fetch");
    }

    static string Norm(string s) { return Regex.Replace((s ?? "").ToLowerInvariant(), "[^a-z0-9]", ""); }
    static string FindCached(string cache, string name)
    {
        try
        {
            if (!Directory.Exists(cache)) return null; var n = Norm(name);
            foreach (var f in Directory.GetFiles(cache, "*.unitypackage", SearchOption.AllDirectories))
                if (Norm(Path.GetFileNameWithoutExtension(f)) == n) return f;
        }
        catch { }
        return null;
    }

    // ------------------------------------------------------------ download + import
    static void StartDownload(Item it)
    {
        if (it.state == "downloaded" && File.Exists(it.path)) { Import(it); return; }
        it.state = "downloading"; Step("downloading " + it.name);
        Web("/-/api/legacy-package-download-info/" + it.id, w =>
        {
            if (w.result != UnityWebRequest.Result.Success)
            {
                ItemFail(it, w.responseCode == 404 ? "the Asset Store no longer offers a download for this pack (deprecated or removed)"
                    : w.responseCode == 401 || w.responseCode == 403 ? "this Unity account can't download it (sign in with the account that owns it)"
                    : $"download info failed ({w.responseCode})");
                return;
            }
            var d = JsonUtility.FromJson<DlInfo>(w.downloadHandler.text)?.result?.download;
            if (d == null || string.IsNullOrEmpty(d.url)) { ItemFail(it, "no download url"); return; }
            var dest = new[] { (d.filename_safe_publisher_name ?? "").Replace(".", ""), (d.filename_safe_category_name ?? "").Replace(".", ""), (d.filename_safe_package_name ?? "").Replace(".", "") };
            var u = FindType("UnityEditor.AssetStoreUtils");
            string basePath = u.GetMethod("BuildBaseDownloadPath", F).Invoke(null, new object[] { dest[0], dest[1] }) as string;
            it.path = u.GetMethod("BuildFinalDownloadPath", F).Invoke(null, new object[] { basePath, dest[2] }) as string;
            if (File.Exists(it.path)) { it.state = "downloaded"; it.pct = 1; Save(); return; }
            var json = "{\"download\":{\"url\":\"" + d.url + "\",\"key\":\"" + d.key + "\"}}";
            var m = u.GetMethods(F).First(x => x.Name == "Download" && x.GetParameters().Length >= 6);
            var args = new object[m.GetParameters().Length];
            args[0] = "content__" + it.id; args[1] = d.url; args[2] = dest; args[3] = d.key; args[4] = json; args[5] = false;
            m.Invoke(null, args);
            s_St.api = "AssetStoreUtils.Download"; Save();
        });
    }

    static void Poll(Item it, double now)
    {
        if (it.state == "failed" || it.state == "imported") { s_Cur = null; return; }
        if (it.state == "importing")
        {
            try { var pu = FindType("UnityEditor.AssetPackage.Utility"); pu?.GetMethod("TickPackageImport", F)?.Invoke(null, null); } catch { }
            if (now - s_CurStart > 900) ItemFail(it, "import did not finish - in Unity: Window > Package Manager > My Assets > Import");
            return;
        }
        if (it.state == "downloaded") { if (File.Exists(it.path)) Import(it); else ItemFail(it, "file missing after download"); return; }
        if (string.IsNullOrEmpty(it.path)) { if (now - s_CurStart > 90) ItemFail(it, "no download info"); return; }
        try
        {
            var u = FindType("UnityEditor.AssetStoreUtils");
            var j = u.GetMethod("CheckDownload", F).Invoke(null, new object[] { "content__" + it.id, "", new string[0], "" }) as string;
            var mm = Regex.Match(j ?? "", "\"downloaded\"\\s*:\\s*(\\d+).*?\"total\"\\s*:\\s*(\\d+)");
            if (mm.Success) { var a = double.Parse(mm.Groups[1].Value); var b = double.Parse(mm.Groups[2].Value); if (b > 0) it.pct = (float)(a / b); }
        }
        catch { }
        if (File.Exists(it.path)) { it.state = "downloaded"; it.pct = 1; Save(); return; }
        if (now - s_CurStart > 1800) { ItemFail(it, "download timed out"); return; }
        if ((int)(now * 2) % 10 == 0) Save();
    }

    static void Import(Item it)
    {
        if (!s_Req.import_into_project) { it.state = "downloaded"; s_Cur = null; Save(); return; }
        it.state = "importing"; s_Importing = true; Step("importing " + it.name);
        // Unity 6.6+ asks the creator to confirm unsigned packages in a "Missing signature" window. That is a security
        // check: Game Bot never answers it. The import is queued and the creator confirms it in Unity.
        if (SignatureWindowVersion())
        {
            s_St.api = "AssetPackage.Package.Import (needs your OK in Unity)";
            it.msg = "confirm Unity's Missing signature window to finish the import";
            try
            {
                var pk = FindType("UnityEditor.AssetPackage.Package");
                var im = pk?.GetMethod("Import", F, null, new[] { typeof(string), typeof(bool) }, null);
                if (im != null) im.Invoke(null, new object[] { it.path, false });
                else
                {
#pragma warning disable 0618
                    AssetDatabase.ImportPackage(it.path, false);
#pragma warning restore 0618
                }
            }
            catch (Exception e) { ItemFail(it, "import failed: " + e.Message); return; }
            Save();
            return;
        }
        // Older Unity 6: internal immediate, no-GUI import (UnityEditor.AssetPackage.Utility.ImportPackageImmediately).
        try
        {
            var u = FindType("UnityEditor.AssetPackage.Utility");
            var m = u?.GetMethod("ImportPackageImmediately", F, null, new[] { typeof(string) }, null);
            if (m != null)
            {
                s_St.api = "AssetPackage.Utility.ImportPackageImmediately"; Save();
                var ok = m.Invoke(null, new object[] { it.path });
                if (ok is bool b && b)
                {
                    if (it.state == "importing") { it.state = "imported"; it.pct = 1; it.msg = ""; }
                    s_Importing = false; s_Cur = null; Step("imported " + it.name);
                    AssetDatabase.Refresh();
                    return;
                }
            }
        }
        catch (Exception e) { Debug.LogWarning("[GameBot] immediate import failed, using the delayed import: " + e.Message); }
        s_St.api = "AssetDatabase.ImportPackage";
#pragma warning disable 0618
        AssetDatabase.ImportPackage(it.path, false);
#pragma warning restore 0618
    }

    static bool SignatureWindowVersion()
    {
        var m = Regex.Match(Application.unityVersion ?? "", @"^(\d+)\.(\d+)");
        if (!m.Success) return true;
        int major = int.Parse(m.Groups[1].Value), minor = int.Parse(m.Groups[2].Value);
        return major > 6000 || (major == 6000 && minor >= 6);
    }

    static void OnImport(string name, string err)
    {
        var it = s_Cur ?? s_St?.items.FirstOrDefault(i => i.state == "importing");
        s_Importing = false;
        if (it == null) return;
        if (err == null) { it.state = "imported"; it.pct = 1; it.msg = ""; Step("imported " + it.name); }
        else ItemFail(it, "import failed: " + err);
        s_Cur = null; Save();
    }

    static void ItemFail(Item it, string msg)
    {
        it.state = "failed"; it.msg = msg; s_Cur = null; s_Importing = false; Step(it.name + ": " + msg);
        OpenMyAssets();
    }

    static void Fail(string msg, string code = "error")
    {
        if (s_St == null) return;
        s_St.state = "failed"; s_St.error = msg; s_St.fallback = code; Step(msg);
        OpenMyAssets();
        s_Stage = (Application.isBatchMode && s_Req != null && s_Req.quit_when_done) ? "finish" : "idle_done";
    }

    static void OpenMyAssets()
    {
        if (Application.isBatchMode || s_Req == null || !s_Req.open_my_assets_on_fail) return;
        try
        {
            var w = FindType("UnityEditor.PackageManager.UI.Internal.PackageManagerWindow");
            var m = w?.GetMethods(F).FirstOrDefault(x => x.Name == "OpenAndSelectPage" && x.GetParameters().Length >= 1);
            if (m != null)
            {
                var a = new object[m.GetParameters().Length]; a[0] = "MyAssets";
                for (int i = 1; i < a.Length; i++) a[i] = m.GetParameters()[i].HasDefaultValue ? m.GetParameters()[i].DefaultValue : null;
                m.Invoke(null, a); s_St.fallback += (s_St.fallback.Length > 0 ? "," : "") + "opened_my_assets"; return;
            }
        }
        catch { }
        try { UnityEditor.PackageManager.UI.Window.Open(""); s_St.fallback += ",opened_package_manager"; } catch { }
    }

    [MenuItem("GameBot/Fetch My Assets Packs")]
    static void Menu() { s_ReqTime = default(DateTime); s_Req = null; LoadRequest(); }
}
#endif
